"""Connector core primitives."""
