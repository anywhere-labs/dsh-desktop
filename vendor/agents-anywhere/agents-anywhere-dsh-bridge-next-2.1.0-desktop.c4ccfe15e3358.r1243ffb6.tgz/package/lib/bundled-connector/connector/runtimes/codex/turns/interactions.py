from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass
from typing import Any

from connector.logging import logger
from connector.runtime_protocol import (
    RuntimeOperationResult,
    RuntimeSessionStateCache,
    RuntimeUnsupportedError,
)
from connector.runtime_protocol.host import RuntimeHostClient
from connector.runtimes.codex.domain.approvals import (
    CodexApprovalResponse,
    approval_response_from_interaction,
)
from connector.runtimes.codex.domain.input_requests import (
    async_input_call_from_context,
    is_async_input_request_context,
    is_cancelled_input_action,
    is_input_request_context,
    user_input_response_from_interaction,
)
from connector.runtimes.codex.domain.notices import CodexNoticeRegistry
from connector.runtimes.codex.sdk.runtime_client import CodexRuntimeClient

EnsureStarted = Callable[[], Awaitable[None]]


@dataclass(slots=True)
class CodexInteractionController:
    host: RuntimeHostClient
    client: CodexRuntimeClient | None
    session_states: RuntimeSessionStateCache
    active_turn_ids: dict[str, str]
    notices: CodexNoticeRegistry
    ensure_started: EnsureStarted
    turn_actions: Any | None = None

    async def respond_interaction(
        self,
        session_id: str,
        notice_id: str,
        action_id: str,
        input_data: Mapping[str, Any] | None = None,
    ) -> RuntimeOperationResult:
        if self.client is None:
            raise RuntimeUnsupportedError("respond_interaction")
        data = dict(input_data or {})
        notice = self.notices.get(notice_id)
        if notice is not None and notice.status in {
            "closed",
            "resolved",
            "cancelled",
            "expired",
        }:
            return RuntimeOperationResult(
                ok=True,
                result={
                    "resolved": True,
                    "alreadyProcessed": True,
                    "noticeId": notice_id,
                    "sessionId": session_id,
                },
            )
        notice_context = self.notice_context_for_response(notice_id)
        request_id = data.get("requestId")
        if not isinstance(request_id, str | int):
            approval_source = data.get("approvalSource")
            if isinstance(approval_source, dict):
                request_id = approval_source.get("requestId")
        if not isinstance(request_id, str | int):
            request_id = notice_context.get("requestId")
        if not isinstance(request_id, str | int):
            raise TypeError("requestId is required to respond to a Codex interaction")
        if is_async_input_request_context(notice_context):
            return await self._respond_async_input(
                session_id=session_id,
                notice_id=notice_id,
                action_id=action_id,
                context={**notice_context, "answers": data.get("answers")},
            )
        response_context = interaction_response_context(notice_context, data)
        response = codex_interaction_response(action_id, response_context)
        logger.info(
            "codex approval respond started session_id={} notice_id={} action_id={} request_id={} decision={} payload_keys={} notice_context_found={}",
            session_id,
            notice_id,
            action_id,
            request_id,
            response.decision,
            sorted(response.payload.keys()),
            bool(notice_context),
        )
        await self.ensure_started()
        await self._notice_responding(
            notice_id=notice_id,
            action_id=action_id,
            decision=response.decision,
        )
        try:
            await self.client.respond(request_id, response.payload)
        except Exception as exc:
            logger.warning(
                "codex approval respond failed session_id={} notice_id={} action_id={} request_id={} decision={} error_type={} error={}",
                session_id,
                notice_id,
                action_id,
                request_id,
                response.decision,
                exc.__class__.__name__,
                str(exc) or exc.__class__.__name__,
            )
            await self._notice_response_failed(
                session_id=session_id,
                notice_id=notice_id,
                action_id=action_id,
                decision=response.decision,
                exc=exc,
            )
            raise
        logger.info(
            "codex approval respond completed session_id={} notice_id={} action_id={} request_id={} decision={}",
            session_id,
            notice_id,
            action_id,
            request_id,
            response.decision,
        )
        await self._notice_resolved(
            notice_id=notice_id,
            action_id=action_id,
            decision=response.decision,
            response_payload=response.payload,
        )
        cached_state = self.session_states.get(session_id)
        if cached_state is not None:
            next_status = (
                "waiting_approval"
                if self.notices.open_blocking_for_session(session_id)
                else "running"
                if self.active_turn_ids.get(session_id) is not None
                else "idle"
            )
            await self.session_states.update(
                session_id=session_id,
                external_session_id=cached_state.external_session_id,
                status=next_status,
                metadata={
                    "source": "codex.approval/responded",
                    "notice_id": notice_id,
                    "decision": response.decision,
                },
            )
        return RuntimeOperationResult(
            ok=True,
            result={
                "resolved": True,
                "noticeId": notice_id,
                "sessionId": session_id,
                "decision": response.decision,
                "response": response.payload,
            },
        )

    async def _respond_async_input(
        self,
        *,
        session_id: str,
        notice_id: str,
        action_id: str,
        context: Mapping[str, Any],
    ) -> RuntimeOperationResult:
        call = async_input_call_from_context(context)
        if is_cancelled_input_action(action_id):
            await self._notice_resolved(
                notice_id=notice_id,
                action_id=action_id,
                decision="cancelled",
                response_payload={},
            )
            return RuntimeOperationResult(
                ok=True,
                result={
                    "resolved": True,
                    "noticeId": notice_id,
                    "sessionId": session_id,
                    "decision": "cancelled",
                },
            )
        if self.turn_actions is None:
            raise RuntimeUnsupportedError("respond_async_input")
        thread_id = context.get("threadId")
        if not isinstance(thread_id, str) or not thread_id:
            cached = self.session_states.get(session_id)
            thread_id = cached.external_session_id if cached is not None else None
        if not isinstance(thread_id, str) or not thread_id:
            raise TypeError("threadId is required to answer request_user_input_async")
        envelope = call.reply_envelope({"answers": context.get("answers")})
        await self._notice_responding(
            notice_id=notice_id,
            action_id=action_id,
            decision="answered",
        )
        try:
            if self.active_turn_ids.get(session_id) is not None:
                result = await self.turn_actions.steer_turn(
                    session_id=session_id,
                    external_session_id=thread_id,
                    content=envelope,
                    client_message_id=call.client_message_id,
                )
                if not result.ok and result.code in {
                    "codex_no_active_turn",
                    "turn_not_found",
                }:
                    result = await self.turn_actions.start_turn(
                        session_id=session_id,
                        external_session_id=thread_id,
                        content=envelope,
                        client_message_id=call.client_message_id,
                    )
            else:
                result = await self.turn_actions.start_turn(
                    session_id=session_id,
                    external_session_id=thread_id,
                    content=envelope,
                    client_message_id=call.client_message_id,
                )
            if not result.ok:
                await self._notice_response_failed(
                    session_id=session_id,
                    notice_id=notice_id,
                    action_id=action_id,
                    decision="answered",
                    exc=RuntimeError(
                        result.message or result.code or "Codex rejected answer"
                    ),
                )
                return result
        except Exception as exc:
            await self._notice_response_failed(
                session_id=session_id,
                notice_id=notice_id,
                action_id=action_id,
                decision="answered",
                exc=exc,
            )
            raise
        await self._notice_resolved(
            notice_id=notice_id,
            action_id=action_id,
            decision="answered",
            response_payload={"message": envelope},
        )
        return RuntimeOperationResult(
            ok=True,
            result={
                "resolved": True,
                "noticeId": notice_id,
                "sessionId": session_id,
                "decision": "answered",
                "clientMessageId": call.client_message_id,
                "response": {"message": envelope},
            },
        )

    def notice_context_for_response(self, notice_id: str) -> Mapping[str, Any]:
        notice = self.notices.get(notice_id)
        if notice is None:
            return {}
        return notice.context

    def _notice_status_context(self, notice_id: str, status: str) -> Mapping[str, Any]:
        """Track questionnaire notices with the platform input status key."""

        notice = self.notices.get(notice_id)
        if notice is not None and is_input_request_context(notice.context):
            return {"inputStatus": status}
        return {"approvalStatus": status}

    async def _notice_responding(
        self,
        notice_id: str,
        action_id: str,
        decision: str,
    ) -> None:
        notice = self.notices.transition(
            notice_id,
            status="responding",
            context={
                **self._notice_status_context(notice_id, "responding"),
                "responseActionId": action_id,
                "decision": decision,
            },
            metadata={"source": "codex.approval/responding"},
        )
        if notice is not None:
            await self.host.notice_upsert(notice)

    async def _notice_resolved(
        self,
        notice_id: str,
        action_id: str,
        decision: str,
        response_payload: Mapping[str, Any],
    ) -> None:
        notice = self.notices.transition(
            notice_id,
            status="resolved",
            response_required=False,
            blocking=None,
            actions=(),
            context={
                **self._notice_status_context(notice_id, "resolved"),
                "responseActionId": action_id,
                "decision": decision,
                "responsePayload": response_payload,
            },
            metadata={"source": "codex.approval/responded"},
        )
        if notice is not None:
            await self.host.notice_upsert(notice)

    async def _notice_response_failed(
        self,
        session_id: str,
        notice_id: str,
        action_id: str,
        decision: str,
        exc: Exception,
    ) -> None:
        notice = self.notices.transition(
            notice_id,
            status="open",
            response_required=True,
            context={
                **self._notice_status_context(notice_id, "pending"),
                "responseActionId": action_id,
                "decision": decision,
            },
            metadata={
                "source": "codex.approval/respond_failed",
                "error": {
                    "code": exc.__class__.__name__,
                    "message": str(exc) or exc.__class__.__name__,
                },
                "retryable": True,
            },
        )
        if notice is not None:
            await self.host.notice_upsert(notice)
        cached_state = self.session_states.get(session_id)
        if cached_state is not None:
            notice = self.notices.get(notice_id)
            async_input = notice is not None and is_async_input_request_context(
                notice.context
            )
            await self.session_states.update(
                session_id=session_id,
                external_session_id=cached_state.external_session_id,
                status=cached_state.status if async_input else "waiting_approval",
                metadata={
                    "source": "codex.approval/respond_failed",
                    "notice_id": notice_id,
                },
            )


def codex_interaction_response(
    action_or_status: str,
    context: Mapping[str, Any],
) -> CodexApprovalResponse:
    """Build the app-server response for approvals and `request_user_input`."""

    if is_input_request_context(context):
        return CodexApprovalResponse(
            payload=user_input_response_from_interaction(action_or_status, context),
            decision=(
                "cancelled"
                if is_cancelled_input_action(action_or_status)
                else "answered"
            ),
        )
    return approval_response_from_interaction(action_or_status, context)


def interaction_response_context(
    notice_context: Mapping[str, Any],
    input_data: Mapping[str, Any],
) -> Mapping[str, Any]:
    notice_approval_source = notice_context.get("approvalSource")
    input_approval_source = input_data.get("approvalSource")
    if isinstance(notice_approval_source, Mapping) and isinstance(
        input_approval_source,
        Mapping,
    ):
        approval_source = {**notice_approval_source, **input_approval_source}
        return {
            **notice_context,
            **input_data,
            "approvalSource": approval_source,
        }
    return {**notice_context, **input_data}
