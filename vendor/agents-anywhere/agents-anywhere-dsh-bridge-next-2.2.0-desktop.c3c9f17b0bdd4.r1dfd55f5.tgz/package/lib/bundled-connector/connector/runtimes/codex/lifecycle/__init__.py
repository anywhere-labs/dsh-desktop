"""Codex runtime lifecycle actions."""
