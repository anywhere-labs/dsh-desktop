from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass, field
from typing import Any, Literal

RuntimeStatus = Literal[
    "idle",
    "waiting",
    "pending",
    "running",
    "stopping",
    "waiting_approval",
    "blocked",
    "error",
    "disconnected",
]

SelectionScope = Literal["model", "permission"]
CommandScope = Literal["runtime", "session", "turn"]
RuntimeCapabilityScope = Literal["runtime", "session"]
NoticeType = Literal["notification", "interaction"]
NoticeSeverity = Literal["info", "success", "warning", "error"]
SessionSourceAvailability = Literal[
    "available",
    "archived",
    "unavailable",
    "deleted",
    "missing",
    "unknown",
]
SessionSourceObservationOrigin = Literal["event", "inventory", "operation"]

CAPABILITY_SESSION_SEND_MESSAGE = "session.send_message"
CAPABILITY_SESSION_INTERRUPT = "session.interrupt"
CAPABILITY_SESSION_STEER = "session.steer"
CAPABILITY_SESSION_INTERACTION_APPROVAL = "session.interaction.approval"
CAPABILITY_RUNTIME_ATTACHMENT = "runtime.attachment"
CAPABILITY_RUNTIME_CONFIG = "runtime.config"
CAPABILITY_CATALOG_MODEL = "catalog.model"
CAPABILITY_CATALOG_PERMISSION = "catalog.permission"
CAPABILITY_CATALOG_EFFORT = "catalog.effort"
CAPABILITY_SESSION_COMMANDS = "session.commands"


@dataclass(frozen=True, slots=True)
class RuntimeIdentity:
    runtime: str
    runtime_version: str
    display_name: str | None = None
    protocol_version: str = "1.0"
    runtime_id: str | None = None


@dataclass(frozen=True, slots=True)
class RuntimeConfig:
    runtime: str
    revision: int
    values: Mapping[str, Any] = field(default_factory=dict)
    schema: Mapping[str, Any] | None = None
    ui_schema: Mapping[str, Any] | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
    runtime_id: str | None = None


@dataclass(frozen=True, slots=True)
class RuntimeConfigSchema:
    runtime: str
    revision: int
    schema: Mapping[str, Any]
    ui_schema: Mapping[str, Any] | None = None
    defaults: Mapping[str, Any] = field(default_factory=dict)
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class RuntimeInventoryItem:
    runtime: str
    runtime_type: str
    display_name: str
    available: bool
    configured: bool = False
    capabilities: Mapping[str, bool] = field(default_factory=dict)
    reason: str | None = None
    config_schema: RuntimeConfigSchema | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class RuntimeReasoningItem:
    id: str
    title: str
    selection_id: str
    description: str | None = None
    enabled: bool = True
    disabled_reason: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
    # Preselected for a new session, e.g. the runtime's configured model.
    default: bool = False


@dataclass(frozen=True, slots=True)
class RuntimeModelGroup:
    """Where a model is routed from; clients section the picker by it when a catalog has 2+."""

    id: str
    title: str
    # Row text under this group's header, without the provider; None keeps the item title.
    item_title: str | None = None


@dataclass(frozen=True, slots=True)
class RuntimeModelItem:
    id: str
    title: str
    selection_id: str | None = None
    description: str | None = None
    reasoning_items: tuple[RuntimeReasoningItem, ...] = ()
    enabled: bool = True
    disabled_reason: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
    group: RuntimeModelGroup | None = None
    # Preselected for a new session, e.g. the runtime's configured model.
    default: bool = False


@dataclass(frozen=True, slots=True)
class RuntimePermissionItem:
    id: str
    title: str
    selection_id: str
    description: str | None = None
    enabled: bool = True
    disabled_reason: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class RuntimeModelCatalog:
    runtime: str
    revision: int
    models: tuple[RuntimeModelItem, ...]
    runtime_id: str | None = None


@dataclass(frozen=True, slots=True)
class RuntimePermissionCatalog:
    runtime: str
    revision: int
    permissions: tuple[RuntimePermissionItem, ...]
    runtime_id: str | None = None


@dataclass(frozen=True, slots=True)
class RuntimeCapability:
    capability_id: str
    scope: RuntimeCapabilityScope
    runtime: str
    version: str = "1"
    session_id: str | None = None
    connector_id: str | None = None
    supported: bool = True
    available: bool = True
    allowed: bool = True
    unavailable_reason: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
    runtime_id: str | None = None


@dataclass(frozen=True, slots=True)
class RuntimeCapabilitySet:
    runtime: str
    revision: int
    capabilities: tuple[RuntimeCapability, ...] = ()
    session_id: str | None = None
    connector_id: str | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
    runtime_id: str | None = None


@dataclass(frozen=True, slots=True)
class SessionSourceState:
    availability: SessionSourceAvailability
    reason: str | None = None
    observed_at: str | None = None
    observation_origin: SessionSourceObservationOrigin = "inventory"


@dataclass(frozen=True, slots=True)
class SessionSourceObservation:
    session_id: str
    external_session_id: str | None
    runtime: str
    state: SessionSourceState
    runtime_id: str | None = None


@dataclass(frozen=True, slots=True)
class SessionMeta:
    session_id: str
    external_session_id: str | None
    runtime: str
    title: str | None = None
    cwd: str | None = None
    ordering_time: str | None = None
    source_state: SessionSourceState | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
    runtime_id: str | None = None


@dataclass(frozen=True, slots=True)
class SessionState:
    session_id: str
    external_session_id: str | None
    runtime: str
    status: RuntimeStatus
    selections: Mapping[str, str | None] = field(default_factory=dict)
    status_reason: str | None = None
    error: Mapping[str, Any] | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)
    runtime_id: str | None = None


@dataclass(frozen=True, slots=True)
class RuntimeCommand:
    id: str
    title: str
    description: str | None = None
    aliases: tuple[str, ...] = ()
    category: str | None = None
    scope: CommandScope = "session"
    enabled: bool = True
    disabled_reason: str | None = None
    accepts_args: bool = False
    args_schema: Mapping[str, Any] | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class RuntimeCommandResult:
    command: str
    ok: bool = True
    code: str | None = None
    message: str | None = None
    result: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class RuntimeAttachment:
    file_id: str
    name: str | None = None
    media_type: str | None = None
    size: int | None = None
    sha256: str | None = None


@dataclass(frozen=True, slots=True)
class RuntimeAttachmentContent:
    file_id: str
    name: str
    media_type: str
    content: bytes
    sha256: str | None = None


@dataclass(frozen=True, slots=True)
class RuntimeTimelineItem:
    id: str
    session_id: str
    type: str
    status: str
    order_seq: int
    content_hash: str
    role: str | None = None
    turn_id: str | None = None
    content: Mapping[str, Any] = field(default_factory=dict)
    source: Mapping[str, Any] = field(default_factory=dict)
    revision: int = 1
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class RuntimeTimelineSnapshot:
    session_id: str
    external_session_id: str | None
    runtime: str
    items: tuple[RuntimeTimelineItem, ...]
    complete: bool = False
    metadata: Mapping[str, Any] = field(default_factory=dict)
    runtime_id: str | None = None


@dataclass(frozen=True, slots=True)
class PreparedSessionTimelineSync:
    snapshot: RuntimeTimelineSnapshot | None
    commit: Callable[[], Awaitable[None]] | None = None


@dataclass(frozen=True, slots=True)
class SessionNotice:
    notice_id: str
    session_id: str
    runtime: str
    type: NoticeType
    title: str
    message: str | None = None
    severity: NoticeSeverity = "info"
    status: str = "open"
    interaction_type: str | None = None
    blocking: Mapping[str, Any] | None = None
    response_required: bool = False
    actions: tuple[Mapping[str, Any], ...] = ()
    source: Mapping[str, Any] = field(default_factory=dict)
    context: Mapping[str, Any] = field(default_factory=dict)
    metadata: Mapping[str, Any] = field(default_factory=dict)
    runtime_id: str | None = None


@dataclass(frozen=True, slots=True)
class RuntimeOperationResult:
    ok: bool = True
    code: str | None = None
    message: str | None = None
    result: Mapping[str, Any] = field(default_factory=dict)
    source_observation: SessionSourceObservation | None = None
