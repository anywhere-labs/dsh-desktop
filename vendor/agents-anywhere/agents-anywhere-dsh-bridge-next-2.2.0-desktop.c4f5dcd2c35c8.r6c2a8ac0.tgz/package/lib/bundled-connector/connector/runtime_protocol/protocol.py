from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Mapping
from typing import Any

from connector.runtime_protocol.errors import RuntimeUnsupportedError
from connector.runtime_protocol.model_connection import ModelConnectionStatus
from connector.runtime_protocol.models import (
    PreparedSessionTimelineSync,
    RuntimeAttachment,
    RuntimeCapabilitySet,
    RuntimeCommand,
    RuntimeCommandResult,
    RuntimeConfig,
    RuntimeIdentity,
    RuntimeModelCatalog,
    RuntimeOperationResult,
    RuntimePermissionCatalog,
    RuntimeTimelineSnapshot,
    SessionMeta,
    SessionNotice,
    SessionState,
)
from connector.runtime_protocol.workflows import (
    RuntimeWorkflowRequest,
    RuntimeWorkflowResult,
)


class AgentRuntime(ABC):
    """Connector -> Runtime."""

    @property
    def goals(self):
        return getattr(self, "_goals", None)

    @property
    def planning(self):
        return getattr(self, "_planning", None)

    @property
    def sync_mode(self) -> str:
        """Event runtimes own their acknowledged synchronization lifecycle."""
        return "polling"

    async def resynchronize(self, session_id: str | None = None, external_session_id: str | None = None) -> None:
        """Request event-stream calibration on reconnect or an explicit refresh."""
        raise RuntimeUnsupportedError("resynchronize")

    @property
    @abstractmethod
    def identity(self) -> RuntimeIdentity:
        raise NotImplementedError

    async def start(self) -> None:
        pass

    def model_connection_status(self) -> ModelConnectionStatus | None:
        """What this instance did with its model connection, when only it knows.

        Adapters that hand the connection to another process while starting
        report the outcome here; otherwise the provider's report from the
        config is used.
        """
        return None

    async def execute_workflow(self, request: RuntimeWorkflowRequest) -> RuntimeWorkflowResult:
        """Control-plane operation: never queue behind an engine/UI continuation."""
        raise RuntimeUnsupportedError(request.operation)

    async def get_session_configuration(self, session_id: str) -> dict[str, Any]:
        raise RuntimeUnsupportedError("get_session_configuration")

    async def update_session_configuration(self, session_id: str, values: Mapping[str, Any]) -> dict[str, Any]:
        raise RuntimeUnsupportedError("update_session_configuration")

    async def stop(self) -> None:
        pass

    async def apply_model_setting(self, config: RuntimeConfig) -> bool:
        """Take a config whose only change is the ``model`` setting, without restarting.

        The setting only decides what new sessions use, so a runtime that can
        swap it in place returns True and republishes its model catalog.
        Returning False lets the supervisor restart the runtime as usual.
        """
        return False

    async def get_config(self) -> RuntimeConfig:
        raise RuntimeUnsupportedError("get_config")

    async def get_runtime_capabilities(self) -> RuntimeCapabilitySet:
        return RuntimeCapabilitySet(
            runtime=self.identity.runtime,
            revision=0,
            capabilities=(),
            metadata={"source": "runtime.default-empty-capabilities"},
        )

    async def list_model_catalog(
        self,
        query: str | None = None,
        limit: int = 100,
    ) -> RuntimeModelCatalog:
        raise RuntimeUnsupportedError("list_model_catalog")

    async def list_scoped_model_catalog(self, session_id: str, query: str | None = None, limit: int = 100) -> RuntimeModelCatalog:
        return await self.list_model_catalog(query=query, limit=limit)

    async def list_permission_catalog(
        self,
        query: str | None = None,
        limit: int = 100,
    ) -> RuntimePermissionCatalog:
        raise RuntimeUnsupportedError("list_permission_catalog")

    async def list_sessions(
        self,
        limit: int = 100,
        cursor: str | None = None,
        force: bool = False,
    ) -> tuple[SessionMeta, ...]:
        raise RuntimeUnsupportedError("list_sessions")

    async def list_complete_session_inventory(
        self,
        page_size: int = 100,
        force: bool = False,
    ) -> tuple[SessionMeta, ...]:
        raise RuntimeUnsupportedError("list_complete_session_inventory")

    def supports_complete_session_inventory(self) -> bool:
        return (
            type(self).list_complete_session_inventory
            is not AgentRuntime.list_complete_session_inventory
        )

    async def get_session_snapshot(
        self,
        session_id: str,
        external_session_id: str | None = None,
        limit: int | None = None,
    ) -> RuntimeTimelineSnapshot:
        raise RuntimeUnsupportedError("get_session_snapshot")

    async def sync_session_timeline(
        self,
        session_id: str,
        external_session_id: str | None = None,
    ) -> bool:
        """Let runtimes override background scanner timeline sync.

        Return True when the runtime published or intentionally skipped timeline
        updates. Return False to let the connector publish get_session_snapshot().
        """
        _ = session_id, external_session_id
        return False

    async def prepare_session_timeline_sync(
        self,
        session_id: str,
        external_session_id: str | None = None,
    ) -> PreparedSessionTimelineSync | None:
        _ = session_id, external_session_id
        return None

    async def get_session_state(
        self,
        session_id: str,
        external_session_id: str | None = None,
    ) -> SessionState | None:
        return None

    async def get_session_notices(
        self,
        session_id: str,
        external_session_id: str | None = None,
    ) -> tuple[SessionNotice, ...]:
        return ()

    async def get_session_capabilities(
        self,
        session_id: str,
        external_session_id: str | None = None,
    ) -> RuntimeCapabilitySet:
        return RuntimeCapabilitySet(
            runtime=self.identity.runtime,
            revision=0,
            capabilities=(),
            session_id=session_id,
            metadata={
                "source": "runtime.default-empty-capabilities",
                "external_session_id": external_session_id,
            },
        )

    async def create_and_start_session(
        self,
        session_id: str,
        content: str,
        title: str | None = None,
        cwd: str | None = None,
        selections: Mapping[str, str | None] | None = None,
        attachments: tuple[RuntimeAttachment, ...] = (),
        client_message_id: str | None = None,
        runtime_options: Mapping[str, Any] | None = None,
    ) -> RuntimeOperationResult:
        raise RuntimeUnsupportedError("create_and_start_session")

    async def start_turn(
        self,
        session_id: str,
        external_session_id: str | None,
        content: str,
        selections: Mapping[str, str | None] | None = None,
        attachments: tuple[RuntimeAttachment, ...] = (),
        client_message_id: str | None = None,
        cwd: str | None = None,
    ) -> RuntimeOperationResult:
        _ = cwd
        raise RuntimeUnsupportedError("start_turn")

    async def steer_turn(
        self,
        session_id: str,
        external_session_id: str | None,
        content: str,
        attachments: tuple[RuntimeAttachment, ...] = (),
        client_message_id: str | None = None,
    ) -> RuntimeOperationResult:
        raise RuntimeUnsupportedError("steer_turn")

    async def interrupt_session(
        self,
        session_id: str,
        reason: str | None = None,
    ) -> RuntimeOperationResult:
        raise RuntimeUnsupportedError("interrupt_session")

    async def update_session_selections(
        self,
        session_id: str,
        external_session_id: str | None,
        selections: Mapping[str, str | None],
    ) -> RuntimeOperationResult:
        raise RuntimeUnsupportedError("update_session_selections")

    async def list_commands(
        self,
        session_id: str,
        external_session_id: str | None = None,
        query: str | None = None,
        limit: int = 50,
    ) -> tuple[RuntimeCommand, ...]:
        return ()

    async def list_runtime_commands(
        self,
        limit: int = 100,
    ) -> tuple[RuntimeCommand, ...]:
        return ()

    async def execute_command(
        self,
        session_id: str,
        command: str,
        external_session_id: str | None = None,
        raw: str | None = None,
        args: tuple[str, ...] = (),
    ) -> RuntimeCommandResult:
        raise RuntimeUnsupportedError("execute_command")

    async def respond_interaction(
        self,
        session_id: str,
        notice_id: str,
        action_id: str,
        input_data: Mapping[str, Any] | None = None,
    ) -> RuntimeOperationResult:
        raise RuntimeUnsupportedError("respond_interaction")
