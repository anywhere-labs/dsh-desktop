import type { Context } from '@deepseek-ai/cordis';
/** Required services for the listing tool; `pluginMarket` is awaited inside `apply`. */
export declare const inject: string[];
/**
 * Register the read-only `plugin_market` tool while the `pluginMarket` service is mounted. The service comes from the
 * optional custom plugin markets bundle, so a preset can keep this row without the tool appearing or the row waiting.
 * @param ctx - Agent-scoped tool registration context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=tools.d.ts.map