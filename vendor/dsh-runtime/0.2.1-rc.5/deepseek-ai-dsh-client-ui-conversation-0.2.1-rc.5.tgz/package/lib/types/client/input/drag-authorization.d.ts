import type { ClientRemote } from '@deepseek-ai/dsh-api-remotes/client';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
/** The Host directory-list capability needed to prove one dropped child is in the active workspace root. */
export type WorkspaceReferenceListRemote = {
    readonly workspaceFiles: Pick<ClientRemote['workspaceFiles'], 'list'>;
};
/** Check that the Host currently lists this exact child with the claimed kind. */
export declare function createWorkspaceReferenceAuthorizer(remote: WorkspaceReferenceListRemote, sessionId: SessionId): (path: string, kind: 'file' | 'directory', signal: AbortSignal) => Promise<boolean>;
export default createWorkspaceReferenceAuthorizer;
//# sourceMappingURL=drag-authorization.d.ts.map