/**
 * The files tab's workspace search: one query box with a name/content mode
 * toggle, and the bounded result list that replaces the tree while a query is
 * active. Pure props throughout; the body owns the state and the face call.
 */
import type { ReactNode } from 'react';
import type { RemoteFailure } from '@deepseek-ai/dsh-api-remotes/client';
import type { WorkspaceFileSearchMatch } from '@deepseek-ai/dsh-api-workspace-files/types';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
/** What the query matches: file basenames, or lines of file content. */
export type FilesSearchMode = 'name' | 'content';
/** One search's settled state, keyed by the request it answers. */
export interface FilesSearchOutcome {
    /** `<mode>:<query>` of the request this outcome answers. */
    readonly key: string;
    readonly searching: boolean;
    readonly matches: readonly WorkspaceFileSearchMatch[];
    readonly truncated: boolean;
    readonly failure?: RemoteFailure | undefined;
}
/** The displayed search state: the settled outcome or a searching placeholder over the previous hits. */
export type FilesSearchShown = Pick<FilesSearchOutcome, 'searching' | 'matches' | 'truncated' | 'failure'>;
/**
 * The displayed state of the live query: the settled outcome when it answers
 * this key, else a searching placeholder that keeps the previous hits visible.
 * @param settled - the last settled outcome, when any.
 * @param key - the live `<mode>:<query>`.
 * @returns what the results list draws right now.
 */
export declare function shownSearch(settled: FilesSearchOutcome | undefined, key: string): FilesSearchShown;
/** The basename of a `/`-joined workspace path. */
export declare function baseName(path: string): string;
/** The parent directory of a `/`-joined workspace path, empty at the root. */
export declare function dirName(path: string): string;
/**
 * Order name hits for display: fuzzy rank on the basename, ties keep walk order.
 * @param matches - name-mode hits in walk order.
 * @param query - the live query text.
 * @returns the hits in display order.
 */
export declare function rankNameMatches(matches: readonly WorkspaceFileSearchMatch[], query: string): WorkspaceFileSearchMatch[];
/**
 * Group content hits by file for display. The walk visits each file once, so
 * a file's hits are always consecutive.
 * @param matches - content-mode hits in walk order.
 * @returns per-file groups in first-hit order.
 */
export declare function groupContentMatches(matches: readonly WorkspaceFileSearchMatch[]): {
    path: string;
    matches: WorkspaceFileSearchMatch[];
}[];
/** The search row under the files tab header: the query box and the mode toggle. */
export declare function FilesSearchBar({ query, mode, onQuery, onMode, onOpenFirst, t }: {
    readonly query: string;
    readonly mode: FilesSearchMode;
    readonly onQuery: (query: string) => void;
    readonly onMode: (mode: FilesSearchMode) => void;
    readonly onOpenFirst: () => void;
    readonly t: TranslateNS<'sidebarFiles'>;
}): ReactNode;
/** The search outcome replacing the tree while a query is active. */
export declare function FilesSearchResults({ mode, shown, onOpen, t }: {
    readonly mode: FilesSearchMode;
    readonly shown: FilesSearchShown;
    readonly onOpen: (path: string, line?: number) => void;
    readonly t: TranslateNS<'sidebarFiles'>;
}): ReactNode;
//# sourceMappingURL=FilesSearch.d.ts.map