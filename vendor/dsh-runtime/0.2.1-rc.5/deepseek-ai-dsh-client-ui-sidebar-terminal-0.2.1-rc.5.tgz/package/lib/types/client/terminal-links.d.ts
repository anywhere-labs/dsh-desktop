/** Clickable `path:line` references detected in terminal output. */
import type { ILinkProvider } from '@xterm/xterm';
/** The slice of the xterm API the file-link provider reads. */
export interface TerminalLinkHost {
    readonly buffer: {
        readonly active: {
            getLine(y: number): {
                translateToString(trimRight?: boolean): string;
            } | undefined;
        };
    };
    registerLinkProvider(provider: ILinkProvider): {
        dispose(): void;
    };
}
/** How a detected file reference opens, and the directory relative paths resolve against. */
export interface TerminalFileLinkCallbacks {
    /**
     * Open the referenced file in the right Sidebar.
     * @param path - the path as printed, workspace-relative or absolute.
     * @param options - the 1-based referenced line and the working directory a relative path resolves against.
     */
    readonly openFile: (path: string, options: {
        line?: number | undefined;
        cwd?: string | undefined;
    }) => void;
    /** The terminal's working directory at activation time, when the Host reported one. */
    readonly cwd: () => string | undefined;
}
/** One `path:line[:column]` reference found in a line of terminal text. */
export interface TerminalFileLinkMatch {
    /** The matched text, including the line and any column number. */
    readonly text: string;
    /** The referenced path as printed. */
    readonly path: string;
    /** The 1-based referenced line. */
    readonly line: number;
    /** The string index where the match starts. */
    readonly index: number;
}
/**
 * Whether a matched token reads as a file path rather than a time, version or URL.
 * @param path - the token before the first colon.
 * @returns true when the token carries a directory separator or a file extension.
 */
export declare function isFilePathCandidate(path: string): boolean;
/**
 * Find every file reference in one line of terminal text.
 * @param text - the line as printed on screen.
 * @returns the matches in reading order, empty when none reads as a file.
 */
export declare function findFileLinks(text: string): TerminalFileLinkMatch[];
/**
 * Terminal cell columns a string occupies.
 * @param text - the string to measure.
 * @returns its width in cells, with wide code points counted twice.
 */
export declare function cellColumns(text: string): number;
/**
 * Turn grep-style `path:line` output into links that open the file at that line.
 * @param terminal - the xterm screen to scan.
 * @param callbacks - opening behavior and the terminal's live working directory.
 * @returns the registration disposer.
 */
export declare function registerTerminalFileLinks(terminal: TerminalLinkHost, callbacks: TerminalFileLinkCallbacks): {
    dispose(): void;
};
//# sourceMappingURL=terminal-links.d.ts.map