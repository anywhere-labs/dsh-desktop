/**
 * Pure geometry for the drag interaction: point tests, dock-zone resolution
 * against a real element rectangle, and tab-strip insertion slots. Kept free of
 * React and DOM types so the drop rules can be asserted without a browser; the
 * component layer measures rectangles and calls in.
 */
import type { DockZone, FloatRect, PaneId } from '../contract/types.ts';
/** A measured rectangle in viewport coordinates. */
export interface Rect {
    readonly x: number;
    readonly y: number;
    readonly width: number;
    readonly height: number;
}
/** Where a drag would land if released now. */
export type DropTarget = 
/** Into a tab strip at an explicit slot: a reorder or a cross-pane move. */
{
    readonly kind: 'strip';
    readonly paneId: PaneId;
    readonly index: number;
}
/** Onto a pane body: the centre moves the tab in, an edge splits the pane. */
 | {
    readonly kind: 'zone';
    readonly paneId: PaneId;
    readonly zone: DockZone;
};
/**
 * Whether a point is inside a rectangle, edges included.
 * @param rect - the rectangle.
 * @param x - point x in the same coordinates.
 * @param y - point y in the same coordinates.
 * @returns whether the point lies on or inside the rectangle.
 */
export declare function containsPoint(rect: Rect, x: number, y: number): boolean;
/**
 * Dock region a point falls in, relative to one pane's rectangle.
 * @param rect - the pane's measured box.
 * @param x - pointer x in the same coordinates.
 * @param y - pointer y in the same coordinates.
 * @param edge - edge band as a fraction; defaults to the model's value.
 * @returns the region; `'center'` when the point is not in an edge band.
 */
export declare function zoneInRect(rect: Rect, x: number, y: number, edge?: number): DockZone;
/**
 * Slot a tab would take in a strip, by comparing the pointer with each tab's midpoint.
 * @param tabRects - the strip's tab boxes in strip order.
 * @param x - pointer x.
 * @returns the insertion index, from 0 to `tabRects.length`.
 */
export declare function insertionIndex(tabRects: readonly Rect[], x: number): number;
/** What one pane's strip measured, for the room rule. */
export interface PaneMeasure {
    /** The pane's box, borders included. */
    readonly pane: Rect;
    /** The strip's box, inside the borders; its height is what a vertical half must carry. */
    readonly strip: Rect;
    /** Width of the chip box, the strip's one shrinking part. */
    readonly chipsWidth: number;
    /** Width of the fill: free space, not a control. */
    readonly fillWidth: number;
    /**
     * Footprint of the rendered split control (its width plus the strip's gap)
     * for embedders that hide blocked split controls: a half too narrow to
     * split hides its own control, so the rule leaves the footprint out of the
     * fixed part. Leaving it out is also what keeps the reading stable — the
     * control hiding sheds the same footprint from the strip, and a reading
     * that counted it would flip with the control's visibility and re-render
     * forever. Absent or 0 keeps the control in the fixed part, for embedders
     * that render a blocked control disabled.
     */
    readonly splitControlWidth?: number;
}
/** Pixel minimums the room rule holds each half to. */
export interface SplitMinimums {
    /** The divider a split puts between the halves. */
    readonly divider: number;
    /** One chip at its minimum: the smallest strip that still names a tab. */
    readonly chip: number;
    /** The smallest body under a strip: one secondary text line inside 12px of the body's own insets. */
    readonly body: number;
}
/**
 * The minimums where no computed style can be read, mirroring
 * `dockkit.module.css`: `.splitRow > .divider` takes no layout width (its
 * hairline is painted over the seam); `.tab` is 80px of content plus
 * 10px + 10px of padding (content-box), 100px; 12px above and below one 13px
 * secondary line at 1.6 line-height — the inset a body draws for itself, as
 * `.empty` does — is 45px, held to 48px.
 */
export declare const SPLIT_MINIMUMS: SplitMinimums;
/** Whether a pane's two halves after an equal split would each still work. */
export interface HalvesFit {
    /** A row split: each half holds the strip's fixed controls and one minimum chip. */
    readonly row: boolean;
    /** A column split: each half holds the strip and a minimum body. */
    readonly column: boolean;
}
/**
 * The room rule. After an equal split each half must hold what cannot shrink:
 * horizontally the strip's fixed part — its width minus the chip box, the
 * fill, and `splitControlWidth`, which is the padding, the gaps, and every
 * control a half would still draw — plus one chip at its minimum; vertically
 * the strip plus a minimum body. The
 * borders are what the pane's box exceeds the strip's by. An unmeasured pane
 * (no layout, as under jsdom) fits: the rule only blocks on a positive reading.
 * @param measure - the pane's rectangles.
 * @param minimums - the pixel minimums; defaults to the stylesheet's.
 * @returns whether a row and a column split each leave two working halves.
 */
export declare function halvesFit(measure: PaneMeasure, minimums?: SplitMinimums): HalvesFit;
/** How far a pointer must travel before a press becomes a drag, in pixels. */
export declare const DRAG_THRESHOLD = 4;
/**
 * Whether a press has travelled far enough to be a drag.
 * @param startX - press x.
 * @param startY - press y.
 * @param x - current pointer x.
 * @param y - current pointer y.
 * @returns whether either axis moved at least `DRAG_THRESHOLD`.
 */
export declare function passedThreshold(startX: number, startY: number, x: number, y: number): boolean;
/**
 * Split fractions after a divider drag.
 * @param sizes - the split's current fractions.
 * @param index - divider position: the boundary between `index` and `index + 1`.
 * @param delta - pointer travel along the split axis, as a fraction of the split's extent.
 * @returns new fractions; the two neighbours absorb the whole change.
 */
export declare function dividerSizes(sizes: readonly number[], index: number, delta: number): number[];
/** A width/height pair used as a floating-panel bound. */
export interface Size {
    readonly width: number;
    readonly height: number;
}
/**
 * A floating panel's rectangle after a drag.
 * @param rect - the rectangle the gesture started from.
 * @param dx - pointer travel on x.
 * @param dy - pointer travel on y.
 * @returns the moved rectangle; the size is unchanged.
 */
export declare function movedRect(rect: FloatRect, dx: number, dy: number): FloatRect;
/**
 * A floating panel's rectangle after a bottom-right resize.
 * @param rect - the rectangle the gesture started from.
 * @param dx - pointer travel on x.
 * @param dy - pointer travel on y.
 * @param min - smallest size the panel may take.
 * @returns the resized rectangle; the origin is unchanged.
 */
export declare function resizedRect(rect: FloatRect, dx: number, dy: number, min: Size): FloatRect;
/**
 * The viewport region floating panels stay inside: `[0, width]` horizontally and
 * `[top, height]` vertically, where `top` keeps the header clear of window chrome.
 */
export interface FloatBounds {
    readonly top: number;
    readonly width: number;
    readonly height: number;
}
/** How far past an edge the resistance lets a dragged panel travel, at most, in CSS pixels. */
export declare const FLOAT_RESISTANCE = 120;
/**
 * The nearest rectangle that lies inside the bounds, per axis. A panel larger
 * than the bounds on an axis takes the bounds' size on it, so its header
 * controls and resize corner stay reachable.
 * @param rect - any rectangle, possibly outside the bounds.
 * @param bounds - the viewport region.
 * @returns the rectangle moved inside the bounds, its size capped by them.
 */
export declare function legalFloatRect(rect: FloatRect, bounds: FloatBounds): FloatRect;
/**
 * Where a dragged panel draws when the pointer has taken it past an edge: the
 * legal rectangle plus a resisted share of the overflow on each axis.
 * @param desired - the rectangle the pointer travel asks for.
 * @param bounds - the viewport region.
 * @returns the drawn rectangle at the legal size; equal to `desired` while it is legal.
 */
export declare function resistedRect(desired: FloatRect, bounds: FloatBounds): FloatRect;
/**
 * The rectangle a drag must start from so that zero pointer travel draws
 * `drawn`, the inverse of `resistedRect`: a press on a panel still outside the
 * bounds picks it up where it is.
 * @param drawn - where the panel is drawn now.
 * @param bounds - the viewport region.
 * @returns the start rectangle at the legal size; equal to `drawn` while it is legal.
 */
export declare function unresistedRect(drawn: FloatRect, bounds: FloatBounds): FloatRect;
/**
 * A resized rectangle whose bottom-right corner stays inside the bounds, never
 * below the minimum size.
 * @param rect - the resized rectangle; its origin may lie outside the bounds.
 * @param bounds - the viewport region.
 * @param min - smallest size the panel may take.
 * @returns the rectangle with its size capped by the bounds.
 */
export declare function boundedResize(rect: FloatRect, bounds: FloatBounds, min: Size): FloatRect;
/**
 * Where a panel should appear when a tab is dropped outside the docked area.
 * @param x - drop point x.
 * @param y - drop point y.
 * @param size - the panel's size.
 * @returns a rectangle whose header sits under the drop point.
 */
export declare function floatRectAt(x: number, y: number, size: Size): FloatRect;
//# sourceMappingURL=geometry.d.ts.map