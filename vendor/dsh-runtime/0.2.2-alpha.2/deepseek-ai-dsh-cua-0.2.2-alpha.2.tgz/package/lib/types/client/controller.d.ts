/** One query projection for the permission page and activation guidance. */
import type { Context } from '@deepseek-ai/cordis';
import { type SnapshotStore } from '@deepseek-ai/dsh-client-store';
import type { CuaApplicationId, CuaApplicationState, CuaSystemPermission, CuaSystemPermissionState } from '../access-types.ts';
interface PermissionData {
    runtime: {
        persistent: boolean;
        writable: boolean;
    };
    system: CuaSystemPermissionState;
    applications: CuaApplicationState;
    icons: Record<string, string>;
}
/** Query failures retain the last observation without presenting it as current. */
interface Query<T> {
    value: T | null;
    busy: boolean;
    error: string | null;
}
/** Independently settled observations; the overall busy flag follows the latest refresh. */
export type PermissionView = {
    [K in keyof PermissionData]: Query<PermissionData[K]>;
} & {
    busy: boolean;
    changing: boolean;
    toast: {
        id: number;
        kind: 'requested' | 'opened' | 'revoked' | 'retryAllowed';
    } | {
        id: number;
        kind: 'failed';
        message: string;
    } | null;
};
/** Slot actions and the renderer-bound permission projection. */
export interface PermissionFace {
    hooks: {
        cuaPermissions: SnapshotStore<PermissionView>;
    };
    refresh: () => void;
    request: (permission: CuaSystemPermission) => void;
    openSettings: (permission: CuaSystemPermission) => void;
    revoke: (id: CuaApplicationId) => void;
    retryApproval: (id: CuaApplicationId) => void;
    dismissToast: () => void;
}
/** Serializes actions, pauses reads during management operations, and drops superseded or disposed results. */
export declare class PermissionController {
    private readonly remote;
    /** Last observed permissions and the lifetime of the current refresh/action. */
    readonly state: SnapshotStore<PermissionView>;
    private tail;
    private reads;
    private closed;
    private epoch;
    private sequence;
    /** @param remote Generated CUA Remote namespace; failed results are handled with query and action failures. */
    constructor(remote: Context['remote']['cuaAccess']);
    /**
     * Bind the permission projection to its user actions.
     * @returns Reactive state and controls shared by the page, prompt, and toast host.
     */
    face(): PermissionFace;
    /**
     * Update query admission from the management operation's synchronous notification.
     * @param changing Whether a bundle or row operation is pending; settlement refreshes observations.
     */
    setChanging(changing: boolean): void;
    /** Prevent publication after UI withdrawal and join the accepted Remote work. */
    dispose(): Promise<void>;
    private enqueue;
    private read;
}
export {};
//# sourceMappingURL=controller.d.ts.map