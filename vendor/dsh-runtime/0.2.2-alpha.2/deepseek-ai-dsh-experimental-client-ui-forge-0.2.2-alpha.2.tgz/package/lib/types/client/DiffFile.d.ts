/**
 * One file of the changes view: a sticky header with the path, badges, line
 * counts, and file actions, then its hunks unified or side by side with the
 * unchanged lines between them collapsed into rows that expand them.
 */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ForgeDiffFile } from '../types.ts';
import type { ForgePanelKey, NS } from './locales.ts';
type Translate = PropsLocale<typeof NS>['t'];
/** One action of a file's menu. */
export interface DiffFileAction {
    /** Dictionary key of the row label. */
    readonly label: ForgePanelKey;
    /** Runs the action. */
    readonly run: () => void;
}
/** New side of a file: its lines once read, `loading` while a read runs, or undefined before any. */
export type DiffFileText = readonly string[] | 'loading' | undefined;
/** Props of one file section. */
export interface DiffFileProps {
    /** Whether the owning tab is visible and may show temporary menus. */
    readonly visible: boolean;
    /** The file and its hunks. */
    readonly file: ForgeDiffFile;
    /** Whether the section shows its lines. */
    readonly expanded: boolean;
    /** Expand or collapse the section. */
    readonly onToggle: () => void;
    /** Whether the file shows the large-file notice instead of its lines until revealed. */
    readonly large: boolean;
    /** Whether the user revealed a large file. */
    readonly revealed: boolean;
    /** Show a large file anyway. */
    readonly onReveal: () => void;
    /** The file's new side, which supplies collapsed unchanged lines. */
    readonly text: DiffFileText;
    /** Indexes of the expanded gaps. */
    readonly open: ReadonlySet<number>;
    /** Expand one gap. */
    readonly onExpand: (index: number) => void;
    /** Whether deletions and additions show in two columns; a file with only additions or only deletions keeps one. */
    readonly split: boolean;
    /** Whether long lines wrap. */
    readonly wrap: boolean;
    /** Badge text after the path, or empty for none. */
    readonly badge: string;
    /** Hover text of the path: both paths of a renamed file, else the path. */
    readonly tooltip: string;
    /** Rows of the file's menu. */
    readonly actions: readonly DiffFileAction[];
    /** Copy the repository-relative path from the file header. */
    readonly onCopyPath: () => void;
    /** Receives the section element, which scrolling to the file targets. */
    readonly sectionRef: (element: HTMLElement | null) => void;
    /** Forge panel copy. */
    readonly t: Translate;
}
/**
 * Render added and deleted line counts, or the binary label for binary content.
 * @param props - the counts and copy.
 * @returns the counts.
 */
export declare function Counts({ file, t }: {
    readonly file: Pick<ForgeDiffFile, 'additions' | 'deletions' | 'binary'>;
    readonly t: Translate;
}): ReactNode;
/**
 * Render one file of a diff.
 * @param props - the file, its section and gap state, layout choices, menu actions, and copy.
 * @returns the file section.
 */
export declare function DiffFile(props: DiffFileProps): ReactNode;
export {};
//# sourceMappingURL=DiffFile.d.ts.map