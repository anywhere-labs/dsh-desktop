/** New Session option: start the Session in a new worktree, from a chosen local branch. */
import { type ReactNode } from 'react';
import type { HostObservable, InjectFace, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ForgeBranches } from '../types.ts';
import type { NS } from './locales.ts';
import type { PanelSnapshot } from './source.ts';
/** Business face of the New Session option. */
export interface WorktreeToggleInjected {
    /** Panel snapshot of the Session; the renderer binds it as `usePanel`. */
    readonly hooks: {
        readonly panel: HostObservable<PanelSnapshot>;
    };
    /**
     * Request a worktree from a base branch, replacing an open request.
     * @param from - base branch, or null for HEAD.
     * @returns whether the Host accepted it.
     */
    readonly request: (from: string | null) => Promise<boolean>;
    /**
     * Withdraw the open request.
     * @returns whether the Host accepted it.
     */
    readonly cancel: () => Promise<boolean>;
    /**
     * List the local branches of the Session's checkout.
     * @returns the branches, or undefined when they could not be read.
     */
    readonly branches: () => Promise<ForgeBranches | undefined>;
}
/** Full props of the New Session option. */
export type WorktreeToggleProps = InjectFace<WorktreeToggleInjected> & PropsLocale<typeof NS>;
/**
 * Render the worktree option while the Session can still start in a worktree:
 * the base branch menu once requested, then the checkbox. When the checkout
 * cannot host a worktree, the tooltip gives the reason and the checkbox only
 * withdraws an open request. Both stay fixed while the worktree is being
 * created.
 * @param props - panel snapshot hook, request actions, and copy.
 * @returns the option, or nothing once a turn started, the request settled, or no worktree service is mounted.
 */
export declare function WorktreeToggle({ usePanel, request, cancel, branches, t }: WorktreeToggleProps): ReactNode;
//# sourceMappingURL=WorktreeToggle.d.ts.map