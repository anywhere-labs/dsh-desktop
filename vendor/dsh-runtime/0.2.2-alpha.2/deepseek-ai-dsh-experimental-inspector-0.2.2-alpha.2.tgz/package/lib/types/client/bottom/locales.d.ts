/** Localized labels for the NodeJS inspector bottom panel and command. */
export declare const zh: {
    title: string;
    toggle: string;
    close: string;
    resize: string;
    frameTitle: string;
};
/** English labels checked against the bottom-panel dictionary. */
export declare const en: Record<keyof typeof zh, string>;
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Shared Inspector frontend copy. */
        inspectorPanel: keyof typeof zh;
    }
}
/** Japanese copy, checked against the English keys. */
export declare const ja: {
    title: string;
    toggle: string;
    close: string;
    resize: string;
    frameTitle: string;
};
/** Spanish dictionary, checked against the English keys. */
export declare const es: {
    title: string;
    toggle: string;
    close: string;
    resize: string;
    frameTitle: string;
};
/** French dictionary, checked against the English keys. */
export declare const fr: {
    title: string;
    toggle: string;
    close: string;
    resize: string;
    frameTitle: string;
};
/** German dictionary, checked against the English keys. */
export declare const de: {
    title: string;
    toggle: string;
    close: string;
    resize: string;
    frameTitle: string;
};
/** Russian dictionary, checked against the English keys. */
export declare const ru: {
    title: string;
    toggle: string;
    close: string;
    resize: string;
    frameTitle: string;
};
/** Portuguese dictionary, checked against the English keys. */
export declare const pt: {
    title: string;
    toggle: string;
    close: string;
    resize: string;
    frameTitle: string;
};
//# sourceMappingURL=locales.d.ts.map