/**
 * The viewer page's own Session row verbs.
 *
 * The viewer page renders the normal sidebar, so it carries ui-workspace's shipped Session row
 * entries, and each of them hides itself while the page's access snapshot excludes its endpoint. This
 * module registers the viewer's own branch row over the shipped one by id — the one verb a share can
 * grant, stated in the reader's words when the Host refuses it — and the row's branch mark.
 *
 * The Liveshare client face mounts this module only on a viewer page.
 *
 * @module @deepseek-ai/dsh-experimental-liveshare/src/client/viewer-session-row
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { SessionId } from '@deepseek-ai/dsh-session/types';
export declare const name = "liveshare-viewer-session-row";
/** The slot ledger, the locale seat, and the navigation service. */
export declare const inject: readonly string[];
/** The viewer share the branch row receives. */
export interface ViewerSessionRowInjected {
    /** Branch the row's Session the way this page's reader path does. */
    forkSession: (sessionId: SessionId) => void;
}
/** Props of the viewer's branch row: the row share, the menu hook, the locale seat, and the viewer share. */
export type ViewerForkMenuItemProps = PropsRuntime<'sidebar.workspaces.session.menu.item'> & PropsLocale<'liveshare'> & InjectFace<ViewerSessionRowInjected>;
/**
 * The branch row: present only while the access snapshot includes `session/fork` for the row's Session.
 *
 * The label is this package's own copy, and the click asks the Workspace navigation service for the
 * reader's branch: the child is created without the title write a reader does not hold, and opens
 * once the Host lists it.
 * @param props - owner share, menu open state, access Hook, locale seat, and the viewer share.
 * @returns the menu row, or null while the page may not branch that Session.
 */
export declare function ViewerForkMenuItem({ sessionId, useMenuOpenState, useSessionAccess, forkSession, t, }: ViewerForkMenuItemProps): import("react").JSX.Element | null;
/**
 * Read the stable code one refused branch carries.
 *
 * A share refusal decided by the access check arrives as {@link ACCESS_DENIED} with the share's own
 * code as its reason, which is the code the reader's copy names.
 * @param error - Rejection the fork reported.
 * @returns The Host's code, or undefined when the rejection named none.
 */
/**
 * Register the viewer's branch mark and its branch row over the shipped one.
 * @param ctx - browser context of the viewer's module table.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=viewer-session-row.d.ts.map