/** Entry point for the owner gateway worker, launched by the host over an IPC channel. */
export {};
//# sourceMappingURL=cli.d.ts.map