/** Environment removals preserve the shared credential policy across OAR's overlay API. */
/**
 * Translate the shared scrub into OAR's inherited-environment overlay.
 * @param extra - explicit deployment entries; null removes an inherited value.
 * @returns only scrub removals, changed proxy values, and explicit settings, preserving native removals.
 */
export declare function oarEnvironment(extra: Readonly<Record<string, string | null>>): Record<string, string | null>;
//# sourceMappingURL=environment.d.ts.map