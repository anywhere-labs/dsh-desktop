/**
 * One-shot OAR execution, root-answer selection, and owned session disposal.
 * Native records remain in OAR; DSH receives assistant text and fixed failure facts.
 *
 * @module @deepseek-ai/dsh-experimental-subagent-oar/run
 */
import type { Runtime } from '@botiverse/oar';
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import { type ResolvedSubagentStartRequest, type SubagentRun, type SubagentStopReason } from '@deepseek-ai/dsh-subagent';
/** Resolved deployment settings and the runtime owned by one provider instance. */
export interface OarRunSpec {
    /** Selected OAR runtime; installation is probed for each delegation. */
    readonly runtime: Runtime;
    /** Native model id; omitted to preserve native settings. */
    readonly model?: string;
    /** Native reasoning effort; unsupported choices fail at startup. */
    readonly effort?: string;
    /** Explicit environment applied after the shared credential scrub. */
    readonly env: Readonly<Record<string, string | null>>;
    /** Native process arguments; OAR validates arguments it owns. */
    readonly launchArgs: readonly string[];
    /** Optional turn deadline in milliseconds; excludes OAR session startup. */
    readonly timeoutMs?: number;
    /** Receives safe summaries; native causes are retained for debugging and can contain secrets. */
    readonly onError?: (error: Error, stopReason: SubagentStopReason) => void;
}
/**
 * Validate one text task before opening a native session.
 * @param prompt - content supplied by the shared subagent service.
 * @returns the text blocks in their original order, without inserted separators.
 */
export declare function textTask(prompt: readonly ContentBlock[]): string;
/**
 * Open one OAR session and return a one-shot DSH run. OAR cannot interrupt session
 * startup; cancellation during that await disposes the returned session before rejection.
 * @param request - text task, resolved child directory, parent, and cancellation signal.
 * @param spec - selected runtime, native settings, deadline, and safe diagnostic observer.
 * @returns the run after native session creation; post-publication failures settle through result.
 */
export declare function startOarRun(request: ResolvedSubagentStartRequest, spec: OarRunSpec): Promise<SubagentRun>;
//# sourceMappingURL=run.d.ts.map