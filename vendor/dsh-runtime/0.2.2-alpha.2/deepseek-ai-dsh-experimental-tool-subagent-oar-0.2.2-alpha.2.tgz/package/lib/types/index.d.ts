/** One delegation tool selects a configured external provider for each task. */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "experimental-tool-subagent-oar";
export declare const inject: string[];
/** Deployment-owned runtime choices exposed by the external delegation tool. */
export interface Config {
    /** Model-visible runtime aliases mapped to registered subagent provider names. */
    providers: Record<string, string>;
    /** Model-facing tool name (default subagent_oar). */
    toolName?: string;
}
export declare const Config: z<Config>;
/**
 * Register a tool that selects one configured external provider per task.
 * @param ctx - shared tool registry and managed subagent service.
 * @param config - runtime choices and the model-facing tool name.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map