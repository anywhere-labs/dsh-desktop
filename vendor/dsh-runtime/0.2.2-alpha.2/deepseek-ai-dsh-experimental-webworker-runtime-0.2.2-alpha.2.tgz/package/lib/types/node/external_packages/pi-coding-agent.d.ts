/** Agent directory discovery (unavailable). */
export declare const getAgentDir: (...args: never[]) => never;
/** Theme initialization (unavailable). */
export declare const initTheme: (...args: never[]) => never;
/** Agent session service creation (unavailable). */
export declare const createAgentSessionServices: (...args: never[]) => never;
/** Agent session creation from services (unavailable). */
export declare const createAgentSessionFromServices: (...args: never[]) => never;
/** Bash tool definition creation (unavailable). */
export declare const createBashToolDefinition: (...args: never[]) => never;
/** MCP extension creation (unavailable). */
export declare const createMcpExtension: (...args: never[]) => never;
/** Tool definition (unavailable). */
export declare const defineTool: (...args: never[]) => never;
/** CLI model selection (unavailable). */
export declare const resolveCliModel: (...args: never[]) => never;
/** Model registry construction (unavailable). */
export declare const ModelRegistry: (...args: never[]) => never;
/** Project trust store construction (unavailable). */
export declare const ProjectTrustStore: (...args: never[]) => never;
/** Model runtime construction and creation (unavailable). */
export declare const ModelRuntime: ((...args: never[]) => never) & {
    create: (...args: never[]) => never;
};
/** Settings manager construction and creation (unavailable). */
export declare const SettingsManager: ((...args: never[]) => never) & {
    create: (...args: never[]) => never;
};
/** Session manager construction and storage operations (unavailable). */
export declare const SessionManager: ((...args: never[]) => never) & {
    create: (...args: never[]) => never;
    open: (...args: never[]) => never;
    inMemory: (...args: never[]) => never;
    list: (...args: never[]) => never;
};
/** CommonJS interop marker: the worker loader hands `default` to default imports. */
export declare const __esModule = true;
/** CommonJS default export: the members `require()` hands a caller of this module. */
declare const _default: {
    getAgentDir: (...args: never[]) => never;
    initTheme: (...args: never[]) => never;
    createAgentSessionServices: (...args: never[]) => never;
    createAgentSessionFromServices: (...args: never[]) => never;
    createBashToolDefinition: (...args: never[]) => never;
    createMcpExtension: (...args: never[]) => never;
    defineTool: (...args: never[]) => never;
    resolveCliModel: (...args: never[]) => never;
    ModelRegistry: (...args: never[]) => never;
    ProjectTrustStore: (...args: never[]) => never;
    ModelRuntime: ((...args: never[]) => never) & {
        create: (...args: never[]) => never;
    };
    SettingsManager: ((...args: never[]) => never) & {
        create: (...args: never[]) => never;
    };
    SessionManager: ((...args: never[]) => never) & {
        create: (...args: never[]) => never;
        open: (...args: never[]) => never;
        inMemory: (...args: never[]) => never;
        list: (...args: never[]) => never;
    };
};
export default _default;
//# sourceMappingURL=pi-coding-agent.d.ts.map