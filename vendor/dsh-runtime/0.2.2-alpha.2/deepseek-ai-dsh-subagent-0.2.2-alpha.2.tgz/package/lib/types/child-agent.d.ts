/**
 * Shared in-process child composition: the delegation-depth budget, the
 * durable session metadata, the resolved child `AgentOptions`, the delegated
 * policy seed, and the scoped setup used by local activations.
 *
 * @module @deepseek-ai/dsh-subagent/child-agent
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent, AgentOptions, CreateAgentOptions } from '@deepseek-ai/dsh-agent';
import type { SandboxMode } from '@deepseek-ai/dsh-sandbox';
import type { Session, SessionId } from '@deepseek-ai/dsh-session';
import type { ToolRestriction } from '@deepseek-ai/dsh-tools';
/** Thrown when starting a child would exceed the requested depth cap. */
export declare class SubagentDepthError extends Error {
    readonly attemptedDepth: number;
    readonly maxDepth: number;
    constructor(attemptedDepth: number, maxDepth: number);
}
/**
 * Resolve the child's delegation depth from its parent and enforce an optional
 * cap. The persisted parent header is the monotone floor, so a resumed parent
 * cannot delegate as if it were top-level.
 * @param parent - the delegating parent agent.
 * @param maxDepth - optional absolute cap the resolved depth must not exceed.
 * @returns the child's non-negative safe-integer depth.
 * @throws {SubagentDepthError} when the resolved depth exceeds `maxDepth`.
 * @throws {RangeError} when the resolved depth leaves the safe-integer range.
 */
export declare function resolveChildDepth(parent: Agent, maxDepth: number | undefined): number;
/**
 * Resolve the parent values inherited by a child. The latest request header
 * owns provider, model, and reasoning effort after request-time selection;
 * creation options remain the fallback before the first request and retain
 * the configured output-token limit.
 * @param parent - delegating parent Agent.
 * @returns detached Agent options for child-option merging.
 */
export declare function parentAgentOptionsForDelegation(parent: Agent): AgentOptions;
/**
 * Resolve the child's `AgentOptions`: the parent's provider/model,
 * reasoning-effort, and maxTokens values unless the request overrides them,
 * stamped with the child's own delegation depth. Changing the route without
 * naming an effort clears the parent's route-owned effort so the selected
 * model resolves its own default.
 * @param parent - the delegating parent whose route the child inherits.
 * @param requested - per-child overrides, if any.
 * @param childDepth - the resolved delegation depth to stamp.
 * @returns the resolved options for `ctx.agents.create()`.
 */
export declare function resolveChildAgentOptions(parent: Agent, requested: AgentOptions | undefined, childDepth: number): AgentOptions;
/**
 * Build the child session's durable creation metadata: the parent's workspace,
 * its direct lineage, coarse product origin, the recursion budget that must
 * survive persistence, the seed boundary that separates inherited parent
 * history from child work, and the composition the child runs under.
 *
 * Omitted selection uses the parent's live composition, including any switch
 * made while the parent was blank.
 * @param parent - the delegating parent agent.
 * @param childDepth - the resolved delegation depth to persist.
 * @param isSeeded - whether this child inherits a parent-log prefix, including an explicitly empty one.
 * @param selectedPreset - independent selection, or omission to inherit the parent.
 * @returns the `meta` for `ctx.agents.create()`.
 */
export declare function childSessionMeta(parent: Agent, childDepth: number, isSeeded: boolean, selectedPreset?: string): NonNullable<CreateAgentOptions['meta']>;
/** The scoped composition a child agent's creation window applies. */
export interface ChildComposition {
    /** Independently mounted preset; omission shares the parent's standing generation. */
    readonly agentPreset?: string | undefined;
    /** Historical descriptor persona reapplied only during cold resume. */
    readonly persona?: string | undefined;
    /** Historical descriptor tool restriction reapplied only during cold resume. */
    readonly toolFilter?: ToolRestriction | undefined;
}
/**
 * Model-facing delegation-scope statement for every in-process child. A
 * runtime-context contribution rather than a system-prompt section, so the
 * deployment's system prompt stays uniform across parents and children.
 */
export declare const SUBAGENT_DELEGATION_CONTEXT: string;
/**
 * Compose a child before publication and restore historical descriptor overrides.
 * Explicit selection mounts the named preset; omission synchronously joins the
 * parent's current generation. Registrations belong to the child's scope.
 * @param childCtx - the child agent's scoped creation context.
 * @param parent - the delegating parent used when no preset is selected.
 * @param composition - independent preset and any overrides read from a historical descriptor.
 * @returns A promise when mounting an independent preset; otherwise completes synchronously.
 */
export declare function applyChildComposition(childCtx: Context, parent: Agent, composition: ChildComposition): void | Promise<void>;
/** Policy seeded onto a child session's log at the delegation boundary. */
export interface DelegatedPolicyOverrides {
    /**
     * The parent's current preset identity when it runs in Auto or Full access;
     * the child keeps it under the pinned `never` approval policy.
     */
    readonly permissionPreset: 'auto' | 'danger-full-access' | undefined;
    /** The parent session's explicit sandbox-mode override, or `undefined` without one. */
    readonly sandboxMode: SandboxMode | undefined;
    /**
     * `'never'` whenever the approval capability is composed, `undefined`
     * otherwise: a delegated child acts only within the sandbox scope fixed at
     * delegation, so its asks are rejected deterministically.
     */
    readonly approvalPolicy: 'never' | undefined;
}
/**
 * Capture the permission state to seed into one delegation. Call synchronously before
 * the child start's first await: a later parent switch belongs to the
 * parent's future, not to this child. Auto and Full access identities are
 * inherited only through the in-process DSH path so either can replace a stale
 * same-bundle fork value. Only the parent session's explicit sandbox override
 * is captured — never deployment defaults or one-shot grants — and the approval
 * policy is pinned to `'never'` regardless of the parent's own policy.
 * @param parent - the delegating parent agent.
 * @returns the sandbox override (or `undefined` without one) and the approval pin.
 */
export declare function captureDelegatedPolicyOverrides(parent: Agent): DelegatedPolicyOverrides;
/**
 * Append the captured delegation policy onto the child's own log as
 * `source: 'delegation'` events after Session announcement and before Agent registration, so the
 * child's effective policy is reconstructable from its log alone. Appends land
 * after any fork seed, so fresh policy wins stale seed state; later child
 * switches still win over these events.
 * @param childSession - the child's announced, writable Session.
 * @param overrides - the policy captured at delegation.
 */
export declare function appendDelegatedPolicyOverrides(childSession: Session, overrides: DelegatedPolicyOverrides): void;
/** Identity and lineage inputs shared by every in-process child creation. */
export interface ChildCreateInputs {
    /** The child's reserved session id. */
    readonly sessionId: SessionId;
    /** The delegating parent agent. */
    readonly parent: Agent;
    /** The resolved delegation depth. */
    readonly childDepth: number;
    /** How many leading seed events came from the parent's log. */
    readonly lineageSeedLength: number;
}
//# sourceMappingURL=child-agent.d.ts.map