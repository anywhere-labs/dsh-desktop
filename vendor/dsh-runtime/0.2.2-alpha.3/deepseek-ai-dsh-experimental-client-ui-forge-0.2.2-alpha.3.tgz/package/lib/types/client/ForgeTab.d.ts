/** Body of the forge sidebar tab: where the Session works, its local changes, and the change requests it created or pushed. */
import { type ReactNode } from 'react';
import type { HostObservable, InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { RemoteHostFacts } from '@deepseek-ai/dsh-api-remotes/client';
import type { MergeRequest } from '@deepseek-ai/dsh-experimental-forge/types';
import type { ForgePanelChangeRequest } from '../types.ts';
import { type ChangeRequestActions } from './ChangeRequestCard.tsx';
import type { NS } from './locales.ts';
import type { PanelSnapshot } from './source.ts';
/** Business face of the tab body. */
export interface ForgeTabInjected {
    /** Panel snapshot of the Session and the Host facts; the renderer binds them as `usePanel` and `useHost`. */
    readonly hooks: {
        readonly panel: HostObservable<PanelSnapshot>;
        readonly host: HostObservable<RemoteHostFacts>;
        readonly locale: HostObservable<string>;
    };
    /** Open the stream again after it ended. */
    readonly reconnect: () => void;
    /**
     * Reinspect the checkout, probe sign-in, and poll the change requests;
     * settles once the Host has inspected and probed, after reporting a failure.
     */
    readonly refresh: () => Promise<void>;
    /** Remove a change request from the Session, offering to undo it. */
    readonly remove: (entry: ForgePanelChangeRequest) => void;
    /** Mark a draft ready for review; settles once the outcome is reported. */
    readonly markReady: (entry: ForgePanelChangeRequest) => Promise<void>;
    /** Merge a change request as `request` describes; settles once the outcome is reported. */
    readonly merge: (entry: ForgePanelChangeRequest, request: MergeRequest) => Promise<void>;
    /** Read the complete checks of an opened change request. */
    readonly readChecks: NonNullable<ChangeRequestActions['readChecks']>;
    /** Check the removed worktree of the Session out again, reporting the outcome. */
    readonly restore: () => void;
    /** Open a URL outside the app. */
    readonly openLink: (url: string) => void;
    /** Copy text to the clipboard and report the outcome. */
    readonly copyText: (text: string) => void;
    /** Copy a path to the clipboard and report the outcome. */
    readonly copyPath: (path: string) => void;
    /** Record whether the tab is visible, for the header entry's pressed state. */
    readonly reportVisible: (visible: boolean) => void;
    /** Ask the Session's Agent to create a change request for its changes, reporting the outcome. */
    readonly createChangeRequest: () => void;
}
/** Full props of the tab body. */
export type ForgeTabProps = Pick<PropsRuntime<'sidebar.right.pane.tab'>, 'useTabInfo' | 'sessionId'> & InjectFace<ForgeTabInjected> & PropsLocale<typeof NS>;
/**
 * Render the forge tab of one Session. The local changes card shows whenever
 * the `branch` scope changes files, independently of bound change requests.
 * The only open change request starts expanded; once the
 * user expands or collapses a card, the panel keeps that choice across later updates.
 * @param props - tab information, panel snapshot and Host facts hooks, actions, and copy.
 * @returns the tab body.
 */
export declare function ForgeTab({ useTabInfo, sessionId, usePanel, useHost, useLocale, reconnect, refresh, remove, markReady, merge, readChecks, restore, openLink, copyText, copyPath, reportVisible, createChangeRequest, t, }: ForgeTabProps): ReactNode;
//# sourceMappingURL=ForgeTab.d.ts.map