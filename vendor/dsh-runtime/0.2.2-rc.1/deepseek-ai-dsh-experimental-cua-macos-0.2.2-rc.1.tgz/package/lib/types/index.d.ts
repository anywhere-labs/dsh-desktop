import Schema from '@deepseek-ai/schemastery';
import type { Context } from '@deepseek-ai/cordis';
import { CuaConfig } from '@deepseek-ai/dsh-cua';
export { GUIDANCE } from './guidance.ts';
/** Loader plugin identity. */
export declare const name = "experimental-cua-macos";
/** Services required by the shared CUA executor and the native launcher. */
export declare const inject: string[];
/** Native preparation, operation bounds, and profile-local application grants. */
export interface Config extends CuaConfig {
    /** Interval in milliseconds between permission and position checks while the native guide is open. */
    permissionPollIntervalMs: number;
}
/** Validate shared resource bounds and macOS guide configuration before preparing the helper. */
export declare const Config: Schema<{
    agentPreset?: string | false | null;
    allowedApps?: ({
        id?: string | null;
        name?: string | null;
        executablePath?: string | null;
    } & import("@deepseek-ai/cosmokit").Dict<any, string>)[] | null;
    helperPath?: string | null;
    buildTimeoutMs?: number | null;
    timeoutMs?: number | null;
    connectTimeoutMs?: number | null;
    screenshotTimeoutMs?: number | null;
    axTimeoutMs?: number | null;
    maxAppMatches?: number | null;
    maxClipboardBytes?: number | null;
    pasteReadTimeoutMs?: number | null;
    maxRequestBytes?: number | null;
    dragDurationMs?: number | null;
    maxClickHoldMs?: number | null;
    dragSteps?: number | null;
    maxResponseBytes?: number | null;
    textEventIntervalMs?: number | null;
    graceMs?: number | null;
    maxElements?: number | null;
    maxDepth?: number | null;
} & import("@deepseek-ai/cosmokit").Dict & {
    permissionPollIntervalMs?: number | null;
}, {
    agentPreset: string | false;
    allowedApps: Schemastery.ObjectT<NoInfer<{
        id: Schema<string, string, "defined">;
        name: Schema<string, string, "defined">;
        executablePath: Schema<string, string, "plain">;
    }>>[];
    helperPath: string;
    buildTimeoutMs: number;
    timeoutMs: number;
    connectTimeoutMs: number;
    screenshotTimeoutMs: number;
    axTimeoutMs: number;
    maxAppMatches: number;
    maxClipboardBytes: number;
    pasteReadTimeoutMs: number;
    maxRequestBytes: number;
    dragDurationMs: number;
    maxClickHoldMs: number;
    dragSteps: number;
    maxResponseBytes: number;
    textEventIntervalMs: number;
    graceMs: number;
    maxElements: number;
    maxDepth: number;
} & import("@deepseek-ai/cosmokit").Dict & {
    permissionPollIntervalMs: number;
}, "plain">;
/**
 * Mount logged native operations with separate Agent connections to the shared helper.
 * @param ctx - Host context with computer-use, subprocess and tool services.
 * @param config - Validated native preparation and operation bounds.
 * @returns Completion after native preparation and tool registration.
 */
export declare function apply(ctx: Context, config: Config): Promise<void>;
//# sourceMappingURL=index.d.ts.map