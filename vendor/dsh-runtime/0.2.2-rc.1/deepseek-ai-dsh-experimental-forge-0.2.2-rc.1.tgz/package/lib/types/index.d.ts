/** Registry of code-host providers with provider-neutral change requests and shared status polling. */
import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { ChangeRequestListener, ChangeRequestRef, ChangeRequestSnapshot, ChangeRequestUpdate, Config, ForgeActionFailure, ForgeFailure, ForgeProvider, ForgeReadiness, ForgeRepository, ForgeReviewRequest, ForgeReviewResult, MergeRequest } from './types.ts';
export { changeRequestKey } from './keys.ts';
export type * from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        forge: ForgeService;
    }
    interface Events {
        /**
         * Announces a provider registration or withdrawal after the registry changes.
         * Listener failures are logged without preventing other listeners from running.
         * @param forge - family whose provider changed.
         * @mode parallel
         */
        'forge/providers-changed'(forge: string): void | Promise<void>;
    }
}
/**
 * Registry of forge providers. Watchers of one change request share a single
 * polling loop; each forge has at most one fetch in flight, which batches
 * every due change request of that forge.
 */
export declare class ForgeService extends Service {
    static Config: z<Config>;
    private readonly config;
    private readonly providers;
    private readonly watches;
    private readonly fetching;
    private readonly pending;
    private readonly lifetime;
    private timer;
    /**
     * Poll what is due. A field rather than a method, so the timer runs it on
     * the instance itself: a polling round started through a caller's `ctx.forge`
     * would otherwise run on that caller's shadow receiver, and every later round
     * would nest one more shadow until a property write overflows the stack.
     */
    private readonly tick;
    constructor(ctx: Context, config: Config);
    /**
     * Register the provider of one forge family as an effect on the calling
     * fiber. Watches of that forge receive an `unavailable` failure when the
     * registration ends. Unregistering cancels and awaits its in-flight calls;
     * results from the withdrawn registration are discarded.
     * @param provider - provider to serve `provider.forge`.
     * @returns the disposer that unregisters the provider and waits for its calls to finish.
     * @throws when another provider already serves the same forge.
     */
    register(provider: ForgeProvider): () => Promise<void>;
    /**
     * Map a Git remote URL to a repository through the first provider that serves it.
     * @param url - fetch or push URL as Git reports it.
     * @returns the repository, or undefined when no provider serves the URL.
     */
    repositoryFromRemote(url: string): ForgeRepository | undefined;
    /**
     * Map a change request web URL through the first provider that serves it.
     * @param url - web URL of a pull or merge request.
     * @returns the change request, or undefined when no provider serves the URL.
     */
    changeRequestFromUrl(url: string): ChangeRequestRef | undefined;
    /**
     * Build the canonical web URL of a change request.
     * @param ref - change request served by a registered provider.
     * @returns the provider's canonical URL.
     * @throws when no provider serves the change request's forge.
     */
    changeRequestUrl(ref: ChangeRequestRef): string;
    /**
     * Find open change requests whose head is `branch`, excluding the default branch and forks.
     * @param repository - repository served by a registered provider.
     * @param branch - head branch name on the host.
     * @param signal - cancellation for the lookup.
     * @returns matching change requests, newest first as the provider reports them.
     * @throws when no provider serves the repository's forge or the lookup fails.
     */
    findByHead(repository: ForgeRepository, branch: string, signal: AbortSignal): Promise<readonly ChangeRequestRef[]>;
    /**
     * Report whether the provider can reach the repository's host with current credentials.
     * @param repository - repository served by a registered provider.
     * @param signal - cancellation for the probe.
     * @returns the provider's readiness for the host.
     * @throws when no provider serves the repository's forge.
     */
    readiness(repository: ForgeRepository, signal: AbortSignal): Promise<ForgeReadiness>;
    /**
     * Mark a draft change request ready for review, then poll it at once when it is watched.
     * @param ref - change request served by a registered provider.
     * @param signal - cancellation of the request.
     * @returns undefined once the host accepted the change, or why it did not.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    markReady(ref: ChangeRequestRef, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * Merge a change request while its head is still `request.headSha`, then
     * poll it at once when it is watched.
     * @param ref - change request served by a registered provider.
     * @param request - merge method and the head commit the user confirmed.
     * @param signal - cancellation of the request.
     * @returns undefined once the host merged it, or why it did not.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    merge(ref: ChangeRequestRef, request: MergeRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * Read complete check details independently of periodic polling.
     * @param ref - change request served by a registered provider.
     * @param signal - cancellation of the detail view.
     * @returns a complete snapshot or the provider's failure; unsupported providers return unavailable.
     * @throws on cancellation, provider disposal, or expiry of this read's own `fetchTimeoutMs` deadline.
     */
    fetchChecks(ref: ChangeRequestRef, signal: AbortSignal): Promise<ChangeRequestSnapshot | ForgeFailure>;
    /**
     * Read the changes of a change request as its host computes them.
     * @param ref - change request served by a registered provider.
     * @param signal - cancellation of the read.
     * @returns one unified patch with `a/` and `b/` path prefixes, or why the host did not provide it.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    diff(ref: ChangeRequestRef, signal: AbortSignal): Promise<string | ForgeFailure>;
    /**
     * Publish one comment or a completed review, then refresh the watched status.
     * @param ref - change request served by a registered provider.
     * @param request - explicitly selected commit, comments, and review decision.
     * @param signal - request cancellation.
     * @returns a publication URL or a failure, including an unknown write outcome.
     */
    submitReview(ref: ChangeRequestRef, request: ForgeReviewRequest, signal: AbortSignal): Promise<ForgeReviewResult>;
    /**
     * Read the text of one file at a commit of a change request's repository.
     * @param ref - change request served by a registered provider.
     * @param commit - commit object name.
     * @param path - path relative to the repository root.
     * @param signal - cancellation of the read.
     * @returns the text, or why the host did not provide it.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    fileText(ref: ChangeRequestRef, commit: string, path: string, signal: AbortSignal): Promise<string | ForgeFailure>;
    /**
     * Build the web page of one file at a commit of a change request's repository.
     * @param ref - change request served by a registered provider.
     * @param commit - commit object name.
     * @param path - path relative to the repository root.
     * @returns the provider's URL.
     * @throws when no provider serves the change request's forge.
     */
    fileUrl(ref: ChangeRequestRef, commit: string, path: string): string;
    /**
     * Watch one change request as an effect on the calling fiber. The first
     * watcher starts polling at once; listeners receive every later result,
     * and `latest` returns the current one. Polling stops when the last watcher
     * leaves. Listeners must not throw; a thrown error is logged and skipped.
     * @param ref - change request to poll.
     * @param listener - receives each polling result.
     * @returns the disposer that stops this watch.
     */
    watch(ref: ChangeRequestRef, listener: ChangeRequestListener): () => void;
    /**
     * Poll a watched change request at once, including after a terminal state.
     * A fetch already in flight is followed immediately by another fetch; an
     * unwatched change request is unchanged.
     * @param ref - change request to poll.
     */
    refresh(ref: ChangeRequestRef): void;
    /**
     * Read the latest polling result of a watched change request.
     * @param ref - change request to read.
     * @returns the latest result, or undefined before the first result or without a watch.
     */
    latest(ref: ChangeRequestRef): ChangeRequestUpdate | undefined;
    private provider;
    private providersChanged;
    private registration;
    private invoke;
    private missing;
    private schedule;
    private poll;
    /** Fetch one forge's batch; never rejects. */
    private fetch;
    private settle;
}
export default ForgeService;
//# sourceMappingURL=index.d.ts.map