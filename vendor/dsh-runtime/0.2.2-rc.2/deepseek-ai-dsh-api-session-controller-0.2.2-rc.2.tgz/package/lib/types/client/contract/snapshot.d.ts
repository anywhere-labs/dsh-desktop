/** Session-owned observable state excluding Conversation target data. */
import type { FileAttachmentRef } from '@deepseek-ai/dsh-attachment';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { SubagentAddress } from '@deepseek-ai/dsh-subagent/client';
import type { RemoteFailure } from '@deepseek-ai/dsh-typert-protocol';
import type { SessionRequestId } from '../../types.ts';
/** One image displayed by a local submission echo before durable admission. */
export interface PendingSubmissionImage {
    /** Browser-owned preview URL; its lifecycle belongs to the submitter, never this snapshot. */
    readonly previewUrl: string;
    /** Browser file name, when the file had one. */
    readonly name?: string;
    /** Intrinsic pixel width, when the submitter has probed it. */
    readonly width?: number;
    /** Intrinsic pixel height, when the submitter has probed it. */
    readonly height?: number;
}
/** Image branch of a local submission echo attachment. */
export interface PendingSubmissionImageAttachment {
    readonly type: 'image';
    readonly value: PendingSubmissionImage;
}
/** File branch of a local submission echo attachment. */
export interface PendingSubmissionFileAttachment {
    readonly type: 'file';
    readonly value: FileAttachmentRef;
}
/** One attachment displayed by a local submission echo, in prompt order. */
export type PendingSubmissionAttachment = PendingSubmissionImageAttachment | PendingSubmissionFileAttachment;
/** Client surface selected when a local submission begins. */
export type PendingSubmissionPlacement = 'transcript' | 'queued' | 'steering';
/**
 * One local prompt-submission echo: registered when a submission begins and
 * published once the Host accepts the prompt, so the conversation shows the
 * message before its durable admission completes. Client-memory only — reload
 * and reconnect rebuild the conversation from durable events alone.
 */
export interface PendingSubmission {
    /** The prompt RPC identity; the durable `user/message` source echoes it as `rpcId`. */
    readonly requestId: SessionRequestId;
    /** Surface fixed at submission time; Inbox acceptance does not move a Chat echo into the dock. */
    readonly placement: PendingSubmissionPlacement;
    /** Client wall-clock ms when the submission began. */
    readonly time: number;
    /** Prompt text exactly as it will be sent (one text block). */
    readonly text: string;
    /** Ordered image previews and durable file metadata matching the prompt attachments. */
    readonly attachments: readonly PendingSubmissionAttachment[];
}
/** History-open lifecycle of a Session event window. */
export type OpenState = 'cold' | 'loading' | 'open' | 'error';
/** Send/stop failure surfaced by Session consumers. */
export interface PromptError {
    readonly op: 'send' | 'stop';
    readonly error: RemoteFailure;
}
/** Immutable Session lifecycle and control snapshot. */
export interface SessionSnapshot {
    readonly sessionId: SessionId;
    /** Local prompt-submission echoes the Host accepted and that are not yet observed as durable events or queue occurrences. */
    readonly pendingSubmissions: readonly PendingSubmission[];
    readonly running: boolean;
    readonly subagent: {
        readonly address: SubagentAddress;
    } | null;
    readonly removed: boolean;
    readonly openState: OpenState;
    readonly openError: RemoteFailure | null;
    readonly hasMore: boolean;
    /** This Client Session has exposed an incomplete history window; remains true across replacements. */
    readonly historyWasPartial: boolean;
    /** Whether historyLoadStatus is loading, including Turn-jump requests. */
    readonly loadingOlder: boolean;
    /** History request status; pendingConsumption retains an unpublished ordinary page. */
    readonly historyLoadStatus: 'idle' | 'loading' | 'pendingConsumption' | 'error';
    readonly promptError: PromptError | null;
    readonly blank: boolean;
    readonly lastAgentError: string | null;
    /** A prompt call has begun on this Client Session object. */
    readonly promptAttempted: boolean;
    /** The first accepted prompt has not reached a durable `turn/start` event. */
    readonly awaitingFirstTurn: boolean;
}
//# sourceMappingURL=snapshot.d.ts.map