import type {
  SessionAssistantSettlementEntry, SessionEventLikeEntry, SessionTransientEventEntry,
} from '@deepseek-ai/dsh-api-session-controller/client'
import type { LlmAttemptId } from '@deepseek-ai/dsh-llm/brand'
import type {
  ConversationContextReader, ConversationLocationData, ConversationMatch, ConversationMatchResult,
  ConversationNodeContext, ConversationNodeDefinition, ConversationPreviousContext,
  ConversationLocationDataScope, ConversationPublication, ConversationViewBuilder,
  ConversationStartMatch,
  ConversationViewDefinition, ConversationViewNode, ConversationViewSnapshotMap,
  ConversationViewSnapshotStore,
} from '../contract/conversation.ts'
import { conversationContextKey } from '../contract/conversation.ts'
import type {
  ConversationGroupData, ConversationGroupDefinition, ConversationGroupedView,
} from '../contract/groups.ts'
import { ConversationGroupStore } from './group-store.ts'
import type { ConversationEventRegistry } from './event-registry.ts'
import {
  ConversationLocationIndex, type ConversationLocationDataChange,
} from './location-index.ts'

interface Dependency {
  readonly kind: string
  readonly key: string | undefined
  readonly revision: number | undefined
  readonly windowGap: boolean
}

interface InternalContext {
  readonly key: string
  readonly kind: string
  readonly id: string
  readonly definition: ConversationNodeDefinition
  startSeq: number | undefined
  start: ConversationStartMatch | undefined
  matches: ConversationMatch[]
  state: unknown
  revision: number
  readonly current: Map<string, ConversationViewNode | null>
  readonly locationData: Record<ConversationLocationDataScope, ConversationLocationData | null>
  dependencies: Map<string, Dependency>
}

interface PendingMatch {
  readonly definition: ConversationNodeDefinition
  readonly id: string
  readonly match: ConversationMatch
}

interface ViewState {
  readonly target: string
  readonly definition: ConversationViewDefinition
  readonly groupDefinition: ConversationGroupDefinition | undefined
  readonly isActive: ((snapshot: unknown) => boolean) | undefined
  builder: ConversationViewBuilder | undefined
  snapshot: unknown
}

interface GroupState {
  readonly definition: ConversationGroupDefinition
  state: unknown
  readonly store: ConversationGroupStore<unknown>
}

/**
 * Failure of an incremental Conversation update.
 * When `rebuilt` is true, every active view already shows a complete rebuild of
 * the loaded window, and `cause` is the original failure. When it is false, the
 * rebuild or its view replacement also failed, and `cause` is an
 * `AggregateError` of both failures; the next flush retries that rebuild or replacement.
 */
export class ConversationUpdateError extends Error {
  /** Whether every active view shows the complete rebuild. */
  readonly rebuilt: boolean

  /**
   * @param rebuilt - whether every active view shows the complete rebuild.
   * @param options - the original failure, or an `AggregateError` of both failures, as `cause`.
   */
  constructor(rebuilt: boolean, options: ErrorOptions) {
    super(rebuilt
      ? 'conversation update failed; the loaded window was rebuilt'
      : 'conversation update failed, and rebuilding the loaded window also failed', options)
    this.name = 'ConversationUpdateError'
    this.rebuilt = rebuilt
  }
}

const PUBLICATION_RANK: Record<ConversationPublication, number> = {
  none: 0,
  'animation-frame': 1,
  immediate: 2,
}

const LOCATION_DATA_SCOPES: readonly ConversationLocationDataScope[] = ['step', 'turn']

function emptyLocationData(): Record<ConversationLocationDataScope, ConversationLocationData | null> {
  return { step: null, turn: null }
}

function maximumPublication(
  left: ConversationPublication,
  right: ConversationPublication,
): ConversationPublication {
  return PUBLICATION_RANK[left] >= PUBLICATION_RANK[right] ? left : right
}

function startSeq(context: InternalContext): number | undefined {
  return context.startSeq
}

function insertionIndex(contexts: readonly InternalContext[], seq: number): number {
  let low = 0
  let high = contexts.length
  while (low < high) {
    const middle = low + Math.floor((high - low) / 2)
    const candidate = contexts[middle]
    if (candidate !== undefined && (candidate.startSeq as number) < seq) low = middle + 1
    else high = middle
  }
  return low
}

function contextSnapshot<State>(context: InternalContext): ConversationNodeContext<State> {
  return {
    key: context.key,
    kind: context.kind,
    id: context.id,
    matches: context.matches,
    start: context.start,
    state: context.state as State | undefined,
    current: context.current,
  }
}

function mergeMatches(
  key: string,
  additions: readonly ConversationMatch[],
  existing: readonly ConversationMatch[],
): ConversationMatch[] {
  const merged: ConversationMatch[] = []
  let added = 0
  let current = 0
  while (added < additions.length || current < existing.length) {
    const left = additions[added]
    const right = existing[current]
    if (left !== undefined && right !== undefined && left.event.seq === right.event.seq) {
      throw new Error(`conversation Context ${key} received duplicate Match ${left.event.seq}`)
    }
    if (right === undefined || (left !== undefined && left.event.seq < right.event.seq)) {
      merged.push(left as ConversationMatch)
      added++
    } else {
      merged.push(right)
      current++
    }
  }
  return merged
}

function conversationMatch(
  input: SessionEventLikeEntry,
  role: ConversationMatch['role'],
  location: ConversationMatch['location'],
): ConversationMatch {
  return { event: input.event, role, location }
}

/** Event Registry subset consumed by a Session-owned Assembler. */
export interface ConversationEventDefinitions extends Partial<Pick<ConversationEventRegistry, 'forEvent'>> {
  /** @returns ordinary Definitions in registration order. */
  entries(): readonly ConversationNodeDefinition[]
  /** @returns unmatched-event fallback, when registered. */
  fallbackEntry(): ConversationNodeDefinition | undefined
}

/** View Registry subset consumed by a Session-owned Assembler. */
export interface ConversationViewDefinitions {
  /** @returns view builder factories in registration order. */
  entries(): readonly ConversationViewDefinition[]
}

/** Registered grouping rules consumed by the target-neutral assembler. */
export interface ConversationGroupDefinitions {
  /** @returns grouping Definitions in registration order. */
  entries(): readonly ConversationGroupDefinition[]
  /** @param target - View target. @returns its optional Group Definition. */
  forTarget(target: string): ConversationGroupDefinition | undefined
}

const NO_GROUPS: ConversationGroupDefinitions = { entries: () => [], forTarget: () => undefined }

/**
 * Session-owned incremental engine that assembles business Contexts from a
 * contiguous Event window and materializes registered view snapshots.
 */
export class ConversationNodeAssembler implements ConversationViewSnapshotStore {
  private readonly contexts = new Map<string, InternalContext>()
  private readonly contextsByKind = new Map<string, InternalContext[]>()
  private readonly contextsBySeq = new Map<number, InternalContext[]>()
  private readonly contextsByTarget = new Map<string, Set<InternalContext>>()
  private readonly inputs = new Map<number, SessionEventLikeEntry>()
  private readonly locationIndex = new ConversationLocationIndex()
  private readonly dirty = new Set<InternalContext>()
  private readonly dirtyByTarget = new Map<string, Set<InternalContext>>()
  private readonly revised = new Set<InternalContext>()
  private readonly dependents = new Map<string, Set<InternalContext>>()
  private readonly views = new Map<string, ViewState>()
  private readonly groups = new Map<string, GroupState>()
  private readonly pendingGroupStores = new Set<ConversationGroupStore<unknown>>()
  private readonly activeTargets = new Set<string>()
  /** Matches of the event in dispatch, kept by index; dispatch is not reentrant and reuses both arrays. */
  private readonly matchedDefinitions: ConversationNodeDefinition[] = []
  private readonly matchedResults: ConversationMatchResult[] = []
  private hasMore = false
  private rebuildPending = false
  private replacePending = true
  private timelineDirty = true

  /**
   * @param eventDefinitions - live Event Definition registry.
   * @param viewDefinitions - live view builder registry.
   * @param groupDefinitions - optional registered grouping rules, independent of presentation modes.
   */
  constructor(
    private readonly eventDefinitions: ConversationEventDefinitions,
    private readonly viewDefinitions: ConversationViewDefinitions,
    private readonly groupDefinitions: ConversationGroupDefinitions = NO_GROUPS,
  ) {
    this.resetViewBuilders()
  }

  /**
   * Read the current open turn without activating a View.
   * @returns the latest turn number when its start is loaded and it remains open, otherwise undefined.
   */
  openTurn(): number | undefined {
    const snapshot = this.locationIndex.snapshot()
    const latest = snapshot.turnOrder.at(-1)
    const turn = latest === undefined ? undefined : snapshot.turns.get(latest)
    return turn?.status === 'open' && turn.start !== undefined ? turn.turn : undefined
  }

  /**
   * Replace the complete loaded window after open, resync, or gap repair.
   * @param entries - complete contiguous window.
   * @param hasMore - whether older history remains outside the window.
   * @returns immediate publication request.
   */
  replaceWindow(entries: readonly SessionEventLikeEntry[], hasMore: boolean): ConversationPublication {
    this.contexts.clear()
    this.contextsByKind.clear()
    this.contextsBySeq.clear()
    this.contextsByTarget.clear()
    this.inputs.clear()
    this.dirty.clear()
    this.dirtyByTarget.clear()
    this.revised.clear()
    this.dependents.clear()
    this.hasMore = hasMore
    const sorted = [...entries].sort((left, right) => left.event.seq - right.event.seq)
    for (const entry of sorted) this.inputs.set(entry.event.seq, entry)
    this.locationIndex.rebuild(sorted)
    this.timelineDirty = true
    for (const entry of sorted) this.matchInput(entry)
    this.replayDependencies()
    this.revised.clear()
    for (const context of this.contexts.values()) this.markDirty(context)
    this.replacePending = true
    return 'immediate'
  }

  /**
   * Add one contiguous live tail event without scanning existing Contexts.
   * @param record - appended Session event entry.
   * @returns highest requested publication cadence.
   */
  append(record: SessionEventLikeEntry): ConversationPublication {
    const event = record.event
    if (this.inputs.has(event.seq)) return 'none'
    if (this.revised.size > 0) this.revised.clear()
    this.inputs.set(event.seq, record)
    let publication: ConversationPublication = 'none'
    if (event.type !== 'assistant/live-chunk' && isLocationBoundary(event.type)) {
      const previousTimeline = this.locationIndex.snapshot()
      const changed = this.locationIndex.appendBoundary(event)
      if (this.locationIndex.snapshot() !== previousTimeline) {
        this.timelineDirty = true
        publication = 'immediate'
      }
      this.replayContexts(this.refreshMatchLocations(changed))
      if (changed.size > 0) publication = 'immediate'
    } else {
      this.locationIndex.appendNonBoundary(event)
    }
    publication = maximumPublication(publication, this.matchInput(record))
    if (this.replayRevisedDependents()) publication = 'immediate'
    if (this.revised.size > 0) this.revised.clear()
    return publication
  }

  /**
   * Retire one Assistant attempt's transient matches and apply its optional durable settlement.
   * Empty Contexts retain their keys and published nodes until the loaded window is rebuilt;
   * Definitions may hide those nodes when no start remains instead of withdrawing their identities.
   * @param attemptId - process-local attempt whose transient presentation ended.
   * @param entry - durable message or attempt event committed for the stream.
   * @returns highest requested publication cadence.
   */
  settleAssistant(
    attemptId: LlmAttemptId,
    entry?: SessionAssistantSettlementEntry,
  ): ConversationPublication {
    this.revised.clear()
    const retired = [...this.inputs.values()].filter((candidate): candidate is SessionTransientEventEntry => (
      candidate.type === 'transient'
      && candidate.event.data.attemptId === attemptId
    ))
    const retiredSeqs = new Set(retired.map(candidate => candidate.event.seq))
    const affected = new Set<InternalContext>()
    for (const seq of retiredSeqs) {
      this.inputs.delete(seq)
      for (const context of this.contextsBySeq.get(seq) ?? []) affected.add(context)
      this.contextsBySeq.delete(seq)
    }
    for (const context of affected) {
      context.matches = context.matches.filter(match => !retiredSeqs.has(match.event.seq))
    }
    this.locationIndex.removeAssistantTransients(retired.map(candidate => candidate.event))

    let publication: ConversationPublication = retired.length === 0 ? 'none' : 'immediate'
    if (entry !== undefined && !this.inputs.has(entry.event.seq)) {
      this.inputs.set(entry.event.seq, entry)
      this.locationIndex.insertAssistantSettlement(entry.event)
      const pending = new Map<string, PendingMatch[]>()
      publication = maximumPublication(publication, this.collectInput(entry, pending))
      this.applyPendingMatches(pending, affected)
    }
    this.replayContexts(affected)
    if (this.replayRevisedDependents()) publication = 'immediate'
    this.revised.clear()
    return publication
  }

  /**
   * Add an older page while preserving existing Context and view identities.
   * @param entries - newly loaded older Events.
   * @param hasMore - whether history still precedes the expanded window.
   * @returns highest requested publication cadence.
   */
  prepend(entries: readonly SessionEventLikeEntry[], hasMore: boolean): ConversationPublication {
    this.revised.clear()
    let publication: ConversationPublication = 'none'
    const previousHasMore = this.hasMore
    const fresh = entries
      .filter(entry => !this.inputs.has(entry.event.seq))
      .sort((left, right) => left.event.seq - right.event.seq)
    for (const entry of fresh) this.inputs.set(entry.event.seq, entry)
    this.hasMore = hasMore
    const previousTimeline = this.locationIndex.snapshot()
    const changedLocations = this.locationIndex.rebuild(this.sortedInputs())
    if (this.locationIndex.snapshot() !== previousTimeline) this.timelineDirty = true
    const affected = this.refreshMatchLocations(changedLocations)
    const pending = new Map<string, PendingMatch[]>()
    for (const entry of fresh) {
      publication = maximumPublication(publication, this.collectInput(entry, pending))
    }
    this.applyPendingMatches(pending, affected)
    this.replayContexts(affected)
    if ((this.revised.size > 0 || previousHasMore !== hasMore) && this.replayDependencies()) {
      publication = 'immediate'
    }
    if (changedLocations.size > 0) publication = 'immediate'
    this.revised.clear()
    return publication
  }

  /**
   * Rebuild against the current Registry set after a low-frequency plugin change.
   * @returns immediate publication request.
   */
  rebuildRegistry(): ConversationPublication {
    this.resetViewBuilders()
    return this.replaceWindow(this.sortedInputs(), this.hasMore)
  }

  /**
   * Materialize dirty Contexts and advance every active view builder.
   * When an incremental update throws, the assembler replays the complete loaded
   * window into new Contexts and replaces every active view before it throws a
   * {@link ConversationUpdateError}. A Definition that throws on every incremental
   * update therefore makes each flush replay the whole window. A failure on the
   * complete-replacement path propagates unchanged, publishes no view, and keeps
   * the replacement pending for the next flush.
   * @returns whether any view snapshot was rebuilt or incrementally applied.
   * @throws {@link ConversationUpdateError} when an incremental update fails.
   */
  flush(): boolean {
    if (this.rebuildPending) this.rebuildWindow()
    if (!this.replacePending && this.dirty.size === 0 && !this.timelineDirty) return false
    if (this.replacePending) return this.flushReplacement()

    try {
      return this.flushIncremental()
    } catch (error: unknown) {
      return this.recoverIncremental(error)
    }
  }

  private flushReplacement(): boolean {
    this.replaceLocationData()
    const updated: ViewState[] = []
    const changedTurns = this.locationIndex.takeChangedTurns()
    for (const target of this.activeTargets) {
      const view = this.views.get(target)
      if (view === undefined) continue
      this.updateView(view, true, this.buildTargetNodes(target, this.contextsByTarget.get(target)), changedTurns)
      updated.push(view)
    }
    this.replacePending = false
    this.dirty.clear()
    this.dirtyByTarget.clear()
    this.timelineDirty = false
    return this.publishViews(updated)
  }

  /** Replace partial incremental state with a complete rebuild, then report the original failure. */
  private recoverIncremental(error: unknown): never {
    try {
      this.rebuildWindow()
      this.flushReplacement()
    } catch (recoveryError: unknown) {
      throw new ConversationUpdateError(false, {
        cause: new AggregateError([error, recoveryError], 'conversation update and its rebuild failed'),
      })
    }
    throw new ConversationUpdateError(true, { cause: error })
  }

  /** Rebuild every Context from the loaded inputs; a failed rebuild stays pending for the next flush. */
  private rebuildWindow(): void {
    this.rebuildPending = true
    this.replaceWindow(this.sortedInputs(), this.hasMore)
    this.rebuildPending = false
  }

  private flushIncremental(): boolean {
    const updated: ViewState[] = []
    if (this.applyDirtyLocationData()) this.timelineDirty = true
    const changedTurns = this.locationIndex.takeChangedTurns()
    const timelineDirty = this.timelineDirty
    for (const target of this.activeTargets) {
      const view = this.views.get(target)
      if (view === undefined) continue
      const builder = view.builder
      if (builder === undefined) continue
      const upserts = this.buildTargetUpserts(target, this.dirtyByTarget.get(target))
      if (upserts.length === 0 && !timelineDirty) continue
      this.updateView(view, false, upserts, changedTurns)
      updated.push(view)
    }
    this.dirty.clear()
    this.dirtyByTarget.clear()
    this.timelineDirty = false
    return this.publishViews(updated)
  }

  /**
   * Add one target to the monotonic active set and materialize its current snapshot.
   * Pending Context work is flushed before the first complete replacement. When that
   * flush throws, the target stays inactive and a later activation retries it.
   * @param target - registered or subsequently registered view target.
   * @returns whether any active target snapshot changed.
   */
  activateTarget(target: string): boolean {
    const view = this.views.get(target)
    if (this.activeTargets.has(target)) return false
    const published = this.flush()
    this.activeTargets.add(target)
    if (view === undefined) return published
    this.replaceView(view)
    this.publishViews([view])
    return true
  }

  /**
   * Read the latest snapshot of a registered target.
   * @param target - registered view target.
   * @returns target snapshot, or undefined before registration or activation.
   */
  snapshot(target: string): unknown {
    return this.views.get(target)?.snapshot
  }

  get<Target extends Extract<keyof ConversationViewSnapshotMap, string>>(
    target: Target,
  ): ConversationViewSnapshotMap[Target] | undefined {
    return this.snapshot(target) as ConversationViewSnapshotMap[Target] | undefined
  }

  grouped<Target extends string>(
    target: Target,
  ): ConversationGroupedView<ConversationGroupData<Target>> | undefined {
    return this.groups.get(target)?.store as ConversationGroupedView<ConversationGroupData<Target>> | undefined
  }

  /**
   * Read targets whose owners classify their latest snapshot as visible activity.
   * @returns target ids contributing visible activity.
   */
  activityTargets(): ReadonlySet<string> {
    const active = new Set<string>()
    for (const target of this.activeTargets) {
      const view = this.views.get(target)
      if (view === undefined) continue
      if (view.isActive?.(view.snapshot) === true) active.add(view.target)
    }
    return active
  }

  private sortedInputs(): SessionEventLikeEntry[] {
    return [...this.inputs.values()].sort((left, right) => left.event.seq - right.event.seq)
  }

  private matchInput(input: SessionEventLikeEntry): ConversationPublication {
    // oxlint-disable-next-line typescript/unbound-method -- dispatchInput supplies the assembler receiver
    return this.dispatchInput(input, this.acceptMatch)
  }

  private collectInput(
    input: SessionEventLikeEntry,
    pending: Map<string, PendingMatch[]>,
  ): ConversationPublication {
    return this.dispatchInput(input, (definition, id, match) => {
      const key = conversationContextKey(definition.kind, id)
      const matches = pending.get(key) ?? []
      matches.push({ definition, id, match })
      pending.set(key, matches)
      return definition.publication?.(match) ?? 'immediate'
    })
  }

  private dispatchInput(
    input: SessionEventLikeEntry,
    accept: (
      this: ConversationNodeAssembler,
      definition: ConversationNodeDefinition,
      id: string,
      match: ConversationMatch,
    ) => ConversationPublication,
  ): ConversationPublication {
    const event = input.event
    let startMatch: ConversationMatch | undefined
    let updateMatch: ConversationMatch | undefined
    let location: ConversationMatch['location'] | undefined
    const matchFor = (role: ConversationMatch['role']): ConversationMatch => {
      location ??= this.locationIndex.locationOf(event)
      return role === 'start'
        ? startMatch ??= conversationMatch(input, role, location)
        : updateMatch ??= conversationMatch(input, role, location)
    }
    const definitions = this.matchedDefinitions
    const results = this.matchedResults
    definitions.length = 0
    results.length = 0
    const routes = this.eventDefinitions.forEvent?.(event.type)
    if (routes === undefined) {
      for (const definition of this.eventDefinitions.entries()) {
        const result = definition.match(event)
        if (result === null) continue
        definitions.push(definition)
        results.push(result)
      }
    } else {
      for (const { definition, match } of routes) {
        const result = match(event)
        if (result === null) continue
        definitions.push(definition)
        results.push(result)
      }
    }
    // Claims are resolved before any acceptance, so the outcome does not depend on registration order.
    let claims: Map<string, string> | undefined
    for (let index = 0; index < results.length; index++) {
      if ((results[index] as ConversationMatchResult).exclusive !== true) continue
      const definition = definitions[index] as ConversationNodeDefinition
      const target = definition.target
      if (target === undefined) {
        throw new Error(`conversation Definition "${definition.kind}" claims ${event.type} at seq ${String(event.seq)} without a target`)
      }
      const claimant = claims?.get(target)
      if (claimant !== undefined) {
        throw new Error(`conversation Definitions "${claimant}" and "${definition.kind}" both claim ${event.type} at seq ${String(event.seq)} on target "${target}"`)
      }
      (claims ??= new Map()).set(target, definition.kind)
    }
    let firstTarget: string | undefined
    let secondTarget: string | undefined
    let otherTargets: Set<string> | undefined
    let publication: ConversationPublication = 'none'
    for (let index = 0; index < results.length; index++) {
      const definition = definitions[index] as ConversationNodeDefinition
      const result = results[index] as ConversationMatchResult
      const target = definition.target
      if (target !== undefined && result.exclusive !== true && claims?.has(target) === true) continue
      // Inline target tracking avoids an additional closure allocation for each event.
      if (target !== undefined && target !== firstTarget && target !== secondTarget) {
        if (firstTarget === undefined) firstTarget = target
        else if (secondTarget === undefined) secondTarget = target
        else (otherTargets ??= new Set()).add(target)
      }
      publication = maximumPublication(publication, accept.call(this, definition, result.id, matchFor(result.role)))
    }
    const fallback = this.eventDefinitions.fallbackEntry()
    const target = fallback?.target
    if (fallback !== undefined && target !== undefined
      && target !== firstTarget && target !== secondTarget && otherTargets?.has(target) !== true) {
      const result = fallback.match(event)
      if (result !== null) {
        publication = maximumPublication(publication, accept.call(this, fallback, result.id, matchFor(result.role)))
      }
    }
    return publication
  }

  private createContext(
    definition: ConversationNodeDefinition,
    id: string,
    key: string,
  ): InternalContext {
    const context: InternalContext = {
      key,
      kind: definition.kind,
      id,
      definition,
      startSeq: undefined,
      start: undefined,
      matches: [],
      state: undefined,
      revision: 0,
      current: new Map(),
      locationData: emptyLocationData(),
      dependencies: new Map(),
    }
    this.contexts.set(key, context)
    this.indexTargetContext(context)
    return context
  }

  private acceptMatch(
    definition: ConversationNodeDefinition,
    id: string,
    match: ConversationMatch,
  ): ConversationPublication {
    const latest = this.contextsByKind.get(definition.kind)?.at(-1)
    const key = latest?.id === id ? latest.key : conversationContextKey(definition.kind, id)
    let context = this.contexts.get(key)
    context ??= this.createContext(definition, id, key)
    const starting = match.role === 'start' && context.start === undefined
    const previous = context.matches.at(-1)
    if (previous !== undefined && previous.event.seq >= match.event.seq) {
      throw new Error(`conversation Context ${key} received non-appended Match ${match.event.seq}`)
    }
    if (starting && context.matches.length > 0) {
      throw new Error(`conversation Context ${key} received an update before its start Match`)
    }
    context.matches.push(match)
    if (starting) {
      context.startSeq = match.event.seq
      context.start = match
      this.indexStartedContext(context)
    }
    let owners = this.contextsBySeq.get(match.event.seq)
    if (owners === undefined) {
      owners = []
      this.contextsBySeq.set(match.event.seq, owners)
    }
    owners.push(context)

    if (starting) {
      this.replayContext(context)
    } else if (context.state !== undefined) {
      const typed = contextSnapshot(context) as ConversationNodeContext & { readonly state: unknown }
      context.state = requireState(definition, 'update', definition.update(typed, match))
      context.revision++
      this.revised.add(context)
    }
    this.markDirty(context)
    return definition.publication?.(match) ?? 'immediate'
  }

  private applyPendingMatches(
    pending: ReadonlyMap<string, readonly PendingMatch[]>,
    affected: Set<InternalContext>,
  ): void {
    for (const [key, entries] of pending) {
      const first = entries[0]
      if (first === undefined) continue
      let context = this.contexts.get(key)
      context ??= this.createContext(first.definition, first.id, key)
      const additions = entries
        .map((entry) => {
          if (entry.definition !== context.definition || entry.id !== context.id) {
            throw new Error(`conversation Context ${key} received inconsistent Definition identity`)
          }
          let owners = this.contextsBySeq.get(entry.match.event.seq)
          if (owners === undefined) {
            owners = []
            this.contextsBySeq.set(entry.match.event.seq, owners)
          }
          owners.push(context)
          return entry.match
        })
        .sort((left, right) => left.event.seq - right.event.seq)
      context.matches = mergeMatches(context.key, additions, context.matches)
      affected.add(context)
      this.markDirty(context)
    }
  }

  private replayContexts(contexts: ReadonlySet<InternalContext>): void {
    this.refreshStarts(contexts)
    const ordered = [...contexts].sort((left, right) =>
      (left.startSeq ?? Number.POSITIVE_INFINITY) - (right.startSeq ?? Number.POSITIVE_INFINITY))
    for (const context of ordered) {
      if (context.start === undefined) {
        context.state = undefined
        this.replaceDependencies(context, new Map())
        context.revision++
        this.revised.add(context)
        this.markDirty(context)
        continue
      }
      this.replayContext(context)
    }
  }

  private refreshStarts(contexts: ReadonlySet<InternalContext>): void {
    const changed = new Set<InternalContext>()
    const startsByKind = new Map<string, InternalContext[]>()
    for (const context of contexts) {
      const start = context.matches.find(match => match.role === 'start')
      if (start === context.start) continue
      context.start = start
      context.startSeq = start?.event.seq
      changed.add(context)
      const starts = startsByKind.get(context.kind) ?? []
      if (start !== undefined) starts.push(context)
      startsByKind.set(context.kind, starts)
    }
    for (const [kind, starts] of startsByKind) {
      const existing = this.contextsByKind.get(kind) ?? []
      this.contextsByKind.set(kind, existing.filter(context => !changed.has(context)))
      this.indexStartedContexts(kind, starts)
    }
  }

  private replayContext(context: InternalContext): void {
    const start = context.start
    if (start === undefined) {
      context.state = undefined
      return
    }
    if (context.matches[0] !== start) {
      throw new Error(`conversation Context ${context.key} received an update before its start Match`)
    }
    const dependencies = new Map<string, Dependency>()
    const reader = this.readerFor(start.event.seq, dependencies)
    context.state = undefined
    context.state = requireState(
      context.definition,
      'start',
      context.definition.start(contextSnapshot(context), start, reader),
    )
    this.replaceDependencies(context, dependencies)
    for (let index = 1; index < context.matches.length; index++) {
      const match = context.matches[index]
      if (match === undefined) continue
      const typed = contextSnapshot(context) as ConversationNodeContext & { readonly state: unknown }
      context.state = requireState(
        context.definition,
        'update',
        context.definition.update(typed, match),
      )
    }
    context.revision++
    this.revised.add(context)
    this.markDirty(context)
  }

  private indexTargetContext(context: InternalContext): void {
    const target = context.definition.target
    if (target === undefined) return
    const contexts = this.contextsByTarget.get(target) ?? new Set<InternalContext>()
    contexts.add(context)
    this.contextsByTarget.set(target, contexts)
  }

  private markDirty(context: InternalContext): void {
    if (this.dirty.has(context)) return
    this.dirty.add(context)
    const target = context.definition.target
    if (target === undefined || !this.activeTargets.has(target)) return
    let contexts = this.dirtyByTarget.get(target)
    if (contexts === undefined) {
      contexts = new Set<InternalContext>()
      this.dirtyByTarget.set(target, contexts)
    }
    contexts.add(context)
  }

  private replaceDependencies(context: InternalContext, dependencies: Map<string, Dependency>): void {
    for (const dependency of context.dependencies.values()) {
      if (dependency.key === undefined) continue
      const current = this.dependents.get(dependency.key)
      current?.delete(context)
      if (current?.size === 0) this.dependents.delete(dependency.key)
    }
    context.dependencies = dependencies
    for (const dependency of dependencies.values()) {
      if (dependency.key === undefined) continue
      const current = this.dependents.get(dependency.key) ?? new Set()
      current.add(context)
      this.dependents.set(dependency.key, current)
    }
  }

  private replayRevisedDependents(): boolean {
    if (this.dependents.size === 0) return false
    const pending = [...this.revised]
    const affected = new Set<InternalContext>()
    for (let index = 0; index < pending.length; index++) {
      const dependency = pending[index]
      if (dependency === undefined) continue
      for (const dependent of this.dependents.get(dependency.key) ?? []) {
        if (affected.has(dependent)) continue
        affected.add(dependent)
        pending.push(dependent)
      }
    }
    if (affected.size > 0) this.replayContexts(affected)
    return affected.size > 0
  }

  private readerFor(
    beforeSeq: number,
    dependencies: Map<string, Dependency>,
  ): ConversationContextReader {
    return {
      previous: <State>(kind: string): ConversationPreviousContext<State> | undefined => {
        const predecessor = this.previousContext(kind, beforeSeq)
        dependencies.set(kind, {
          kind,
          key: predecessor?.key,
          revision: predecessor?.revision,
          windowGap: predecessor === undefined && this.hasMore,
        })
        if (predecessor?.state === undefined) return undefined
        const seq = startSeq(predecessor)
        if (seq === undefined) return undefined
        return {
          key: predecessor.key,
          kind: predecessor.kind,
          id: predecessor.id,
          startSeq: seq,
          state: predecessor.state as Readonly<State>,
          matches: predecessor.matches,
        }
      },
    }
  }

  private previousContext(kind: string, beforeSeq: number): InternalContext | undefined {
    const candidates = this.contextsByKind.get(kind) ?? []
    const indexBefore = insertionIndex(candidates, beforeSeq)
    for (let index = indexBefore - 1; index >= 0; index--) {
      const candidate = candidates[index]
      if (candidate?.state !== undefined) return candidate
    }
    return undefined
  }

  /** Insert one newly discovered start into its Definition's ordered predecessor index. */
  private indexStartedContext(context: InternalContext): void {
    const seq = context.startSeq
    if (seq === undefined) return
    const candidates = this.contextsByKind.get(context.kind) ?? []
    const previous = candidates.at(-1)
    if (previous === undefined || (previous.startSeq as number) < seq) candidates.push(context)
    else candidates.splice(insertionIndex(candidates, seq), 0, context)
    this.contextsByKind.set(context.kind, candidates)
  }

  private indexStartedContexts(kind: string, additions: readonly InternalContext[]): void {
    if (additions.length === 0) return
    const sorted = [...additions].sort((left, right) =>
      (left.startSeq as number) - (right.startSeq as number))
    const existing = this.contextsByKind.get(kind) ?? []
    const merged: InternalContext[] = []
    let before = 0
    let added = 0
    while (before < existing.length || added < sorted.length) {
      const left = existing[before]
      const right = sorted[added]
      if (right === undefined || (left !== undefined && (left.startSeq as number) < (right.startSeq as number))) {
        merged.push(left as InternalContext)
        before++
      } else {
        merged.push(right)
        added++
      }
    }
    this.contextsByKind.set(kind, merged)
  }

  private replayDependencies(): boolean {
    let replayed = false
    const ordered = [...this.contexts.values()]
      .filter(context => startSeq(context) !== undefined)
      .sort((left, right) => (startSeq(left) as number) - (startSeq(right) as number))
    for (const context of ordered) {
      if (context.state === undefined || context.dependencies.size === 0) continue
      const before = startSeq(context)
      if (before === undefined) continue
      let changed = false
      for (const dependency of context.dependencies.values()) {
        const current = this.previousContext(dependency.kind, before)
        const windowGap = current === undefined && this.hasMore
        if (current?.key !== dependency.key
          || current?.revision !== dependency.revision
          || windowGap !== dependency.windowGap) {
          changed = true
          break
        }
      }
      if (changed) {
        this.replayContext(context)
        replayed = true
      }
    }
    return replayed
  }

  private refreshMatchLocations(changedSeqs: ReadonlySet<number>): Set<InternalContext> {
    const affected = new Set<InternalContext>()
    if (changedSeqs.size === 0) return affected
    for (const seq of changedSeqs) {
      for (const context of this.contextsBySeq.get(seq) ?? []) affected.add(context)
    }
    for (const context of affected) {
      let start = context.start
      const matches = context.matches.map((match): ConversationMatch => {
        if (!changedSeqs.has(match.event.seq)) return match
        if (match.role === 'start') {
          const refreshed: ConversationStartMatch = {
            ...match,
            location: this.locationIndex.locationOf(match.event),
          }
          if (match === start) start = refreshed
          return refreshed
        }
        return { ...match, location: this.locationIndex.locationOf(match.event) }
      })
      context.matches = matches
      context.start = start
    }
    return affected
  }

  private buildNode(context: InternalContext, target: string): ConversationViewNode | null {
    if (context.definition.target !== target || context.definition.buildViewNode === undefined) return null
    const node = context.definition.buildViewNode(contextSnapshot(context))
    if (node === null) return null
    if (node.key !== context.key) {
      throw new Error(`conversation Definition "${context.kind}" returned unstable key "${node.key}"; expected "${context.key}"`)
    }
    if (node.target !== target) {
      throw new Error(`conversation Definition "${context.kind}" returned target "${node.target}" while building "${target}"`)
    }
    return node
  }

  private replaceView(view: ViewState): void {
    this.updateView(view, true, this.buildTargetNodes(view.target, this.contextsByTarget.get(view.target)), [])
  }

  private updateView(
    view: ViewState,
    replacing: boolean,
    nodes: readonly ConversationViewNode[],
    changedTurns: readonly number[],
  ): void {
    const builder = view.builder ?? view.definition.create()
    const definition = view.groupDefinition
    if (definition !== undefined && builder.groupInput === undefined) {
      throw new Error(`conversation group target "${view.target}" requires builder.groupInput()`)
    }
    view.builder = builder
    const timeline = this.locationIndex.snapshot()
    const snapshot = replacing
      ? builder.replace({ nodes, timeline, changedTurns })
      : builder.apply({ upserts: nodes, timeline, changedTurns })
    if (definition !== undefined && builder.groupInput !== undefined) {
      let context = this.groups.get(view.target)
      const initial = context === undefined
      if (context === undefined) {
        context = { definition, state: definition.create(), store: new ConversationGroupStore() }
      }
      const input = builder.groupInput()
      context.state = definition.update(context, input)
      const change = definition.buildGroups(context)
      if ((initial || input.kind === 'replace')
        && (change === null || change.entries === undefined || change.groups.kind !== 'replace')) {
        throw new Error(`conversation group target "${view.target}" requires complete grouping for replacement input`)
      }
      if (change !== null) {
        context.store.prepareAndInstall(change, input.readNode)
        this.pendingGroupStores.add(context.store)
      }
      this.groups.set(view.target, context)
    }
    view.snapshot = snapshot
  }

  private publishViews(updated: readonly ViewState[]): boolean {
    const changed = updated.length > 0 || this.pendingGroupStores.size > 0
    const stores = [...this.pendingGroupStores]
    this.pendingGroupStores.clear()
    for (const view of updated) view.builder?.publish?.()
    for (const store of stores) store.publish()
    this.locationIndex.publishData()
    return changed
  }

  private buildTargetNodes(
    target: string,
    contexts: Iterable<InternalContext> | undefined,
  ): ConversationViewNode[] {
    const nodes: ConversationViewNode[] = []
    for (const context of contexts ?? []) {
      const node = this.buildNode(context, target)
      context.current.set(target, node)
      if (node !== null) nodes.push(node)
    }
    return nodes
  }

  private buildTargetUpserts(
    target: string,
    contexts: Iterable<InternalContext> | undefined,
  ): ConversationViewNode[] {
    const upserts: ConversationViewNode[] = []
    for (const context of contexts ?? []) {
      const previous = context.current.get(target) ?? null
      const node = this.buildNode(context, target)
      if (node === null && previous !== null) {
        throw new Error(
          `conversation Definition "${context.kind}" withdrew materialized target "${target}"; return the same key with hidden visibility instead`,
        )
      }
      context.current.set(target, node)
      if (node !== null) upserts.push(node)
    }
    return upserts
  }

  private buildLocationData(
    context: InternalContext,
    scope: ConversationLocationDataScope,
    previous: ConversationLocationData | null,
  ): ConversationLocationData | null {
    if (context.definition.buildLocationData === undefined) return null
    const data = context.definition.buildLocationData(contextSnapshot(context), scope, previous)
    if (data === null) return null
    if (data.kind !== scope) {
      throw new Error(
        `conversation Definition "${context.kind}" published ${data.kind} data through its ${scope} scope`,
      )
    }
    if (data.key !== context.kind) {
      throw new Error(
        `conversation Definition "${context.kind}" published Location data key "${data.key}"; expected its owned kind`,
      )
    }
    if (!Number.isSafeInteger(data.turn) || data.turn < 0) {
      throw new Error(`conversation Definition "${context.kind}" published invalid turn ${data.turn}`)
    }
    if (data.kind === 'step' && (!Number.isSafeInteger(data.step) || (data.step as number) < 0)) {
      throw new Error(`conversation Definition "${context.kind}" published invalid step ${String(data.step)}`)
    }
    return data
  }

  private replaceLocationData(): void {
    const entries: { owner: string; data: ConversationLocationData }[] = []
    for (const scope of LOCATION_DATA_SCOPES) {
      for (const context of this.contexts.values()) {
        const data = this.buildLocationData(context, scope, context.locationData[scope])
        context.locationData[scope] = data
        if (data !== null) entries.push({ owner: context.key, data })
      }
      // Turn publishers may read Step data from this same flush, so each phase
      // installs the cumulative replacement before the next phase builds.
      this.locationIndex.replaceData(entries)
    }
  }

  private applyDirtyLocationData(): boolean {
    let changed = false
    for (const scope of LOCATION_DATA_SCOPES) {
      const changes: ConversationLocationDataChange[] = []
      for (const context of this.dirty) {
        const previous = context.locationData[scope]
        const next = this.buildLocationData(context, scope, previous)
        if (previous === next) continue
        context.locationData[scope] = next
        changes.push({ owner: context.key, previous, next })
      }
      changed = this.locationIndex.applyData(changes) || changed
    }
    return changed
  }

  private resetViewBuilders(): void {
    const definitions = this.viewDefinitions.entries()
    const targets = new Set(definitions.map(definition => definition.target))
    for (const [target, group] of this.groups) {
      if (!targets.has(target) || this.groupDefinitions.forTarget(target) !== group.definition) {
        group.store.clear()
        this.pendingGroupStores.add(group.store)
        this.groups.delete(target)
      }
    }
    this.views.clear()
    for (const definition of definitions) {
      const view: ViewState = {
        target: definition.target,
        definition,
        groupDefinition: this.groupDefinitions.forTarget(definition.target),
        isActive: definition.isActive === undefined
          ? undefined
          : snapshot => definition.isActive?.(snapshot) === true,
        builder: undefined,
        snapshot: undefined,
      }
      this.views.set(definition.target, view)
    }
    this.replacePending = true
  }
}

function isLocationBoundary(type: string): boolean {
  return type === 'turn/start' || type === 'turn/end' || type === 'step/start' || type === 'step/end'
}

function requireState(
  definition: ConversationNodeDefinition,
  phase: 'start' | 'update',
  state: unknown,
): unknown {
  if (state === undefined) {
    throw new Error(`conversation Definition "${definition.kind}" returned undefined from ${phase}()`)
  }
  return state
}
