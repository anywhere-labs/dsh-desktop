/** Shared directory application catalog, preference, and launch carrier for controls and menus. */
import { type SnapshotStore } from '@deepseek-ai/dsh-client-store';
import type { OpenInAppOutcome } from './outcome.ts';
/** Shared launch status for controls targeting the captured workspace path. */
export interface OpenInAppLaunchState {
    readonly phase: 'idle' | 'busy' | 'error';
    readonly path: string | null;
}
type Fetch = (input: string | URL, init?: RequestInit) => Promise<Response>;
/**
 * Owns the once-per-page availability read, the persisted last choice, and
 * the launch POST. Availability and choice publish through uSES-safe sources
 * so Session menus and directory controls share the same catalog and choice.
 */
export declare class OpenInAppController {
    private readonly fetcher;
    /** Installed app ids in host menu order; null until the host answered. */
    readonly apps: SnapshotStore<readonly string[] | null>;
    /** Last chosen app id, or empty before the first choice, shared across sessions and browser restarts. */
    readonly choice: SnapshotStore<string>;
    /** Current launch, shared by pointer and keyboard gestures. */
    readonly operation: SnapshotStore<OpenInAppLaunchState>;
    /**
     * Resolve the remembered nameable installed application, with the button's first-app fallback.
     * @returns the installed app id, or undefined while unavailable.
     */
    currentApp(): string | undefined;
    private loading;
    /**
     * @param fetcher - HTTP carrier for the apps read and the launch POST.
     */
    constructor(fetcher?: Fetch);
    /**
     * Read availability once per controller life; concurrent calls share the read.
     * A failed read publishes an empty list, which renders no button at all.
     * @returns after availability is published.
     */
    load(): Promise<void>;
    /**
     * Remember one picked app id.
     * @param appId - catalog id from the availability list.
     */
    choose(appId: string): void;
    /**
     * Launch one installed app on a workspace directory.
     * @param appId - catalog id from the availability list.
     * @param path - the session's absolute workspace directory.
     * Concurrent gestures are ignored until the current Host request settles.
     * @returns the acknowledged handoff, or `{ kind: 'skipped' }` while another
     * launch holds the operation, or a named failure when the Host refuses or
     * cannot be reached. Host and transport failures resolve without rejecting.
     */
    launch(appId: string, path: string): Promise<OpenInAppOutcome>;
    private run;
}
export {};
//# sourceMappingURL=controller.d.ts.map