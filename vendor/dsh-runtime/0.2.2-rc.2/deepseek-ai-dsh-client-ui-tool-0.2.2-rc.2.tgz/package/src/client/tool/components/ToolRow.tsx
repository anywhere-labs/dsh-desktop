import { Fragment, memo, useCallback, useMemo, type KeyboardEvent, type MouseEvent, type ReactNode } from 'react'
import clsx from 'clsx'
import {
  CodeBlock, DiffBlock, DisclosureRow, IconInspectOutlineRegular, ReadBlock, SearchBlock,
  TerminalBlock, TextShimmer, WebBlock,
  diffTotals,
} from '@deepseek-ai/dsh-client-ui-primitives'
import type { ContextMenuTriggerProps } from '@deepseek-ai/dsh-client-ui-context-menu/client'
import type { PropsRenderSlots, TranslateNS } from '@deepseek-ai/dsh-client-ui-slots'
import type { OpenFileOptions, UseDisclosure } from '@deepseek-ai/dsh-client-ui-chat/client'
import type { MessageImageLoader } from '@deepseek-ai/dsh-client-ui-conversation/client'
import { CHAT_DIFF_MAX_LINES, type DiffCardModel } from '../models/diff-card-model.ts'
import { CHAT_READ_MAX_LINES, type ReadCardModel } from '../models/read-card-model.ts'
import type { ImageCardModel } from '../models/image-card-model.ts'
import { CHAT_SEARCH_MAX_LINES, type SearchCardModel } from '../models/search-card-model.ts'
import {
  localizeTerminalCardModel, terminalBlockLabels, terminalExitLabel, type TerminalCardModel,
} from '../models/terminal-card-model.ts'
import {
  codeToolbarLabels, diffBlockLabels, readBlockLabels, searchBlockLabels, webBlockLabels,
} from '../models/primitive-labels.ts'
import type { AskQuestionCardModel } from '../models/ask-question-card-model.ts'
import {
  FILE_TARGET_MOVE, FILE_TARGET_SEPARATOR, formatToolBody, type ToolRowFileTarget, type ToolRowState, type ToolRowVariant,
} from '../models/tool-call-model.ts'
import type { WebCardModelProps } from '../models/web-card-model.ts'
import { AskQuestionCard } from './AskQuestionCard.tsx'
import { ToolDetails, type ToolDetailsModel } from './ToolDetails.tsx'
import { ExitCodeBadge } from './ExitCodeBadge.tsx'
import css from './ToolRow.module.css'

export interface ToolRowProps {
  /** Subscribe here, where the row owns its expanded body. */
  useDisclosure: UseDisclosure
  t: TranslateNS<'conversation'>
  variant: ToolRowVariant
  /** Wire tool name for tool-owned styling layered over the generic variant. */
  toolName?: string | undefined
  icon: ReactNode
  title: string
  summary: string
  /**
   * Trailing summary fragment rendered outside the ellipsized summary text, so
   * a narrow row clips the summary before this. Appears before diff totals
   * when both are present. null/absent omits this fragment. Error and stopped
   * rows omit both the suffix and diff totals.
   */
  summarySuffix?: string | null | undefined
  /** Original argument JSON formatted only while the row is expanded. */
  bodyRaw?: string | null | undefined
  /** Flattened result text for the expanded Output section; null/absent = no output section. */
  output?: string | null | undefined
  /** Ask-user transcript card; card fields are mutually exclusive and replace text sections. */
  askQuestion?: AskQuestionCardModel | null | undefined
  /**
   * First error line for rows without an exit status capsule; null/absent keeps
   * the ordinary summary. Rows with an exit capsule retain the command description.
   */
  errorSummary?: string | null | undefined
  /** Terminal card; card fields are mutually exclusive and replace text sections. */
  terminal?: TerminalCardModel | null | undefined
  /** Diff card with inline totals colored on header hover and while expanded. */
  diff?: DiffCardModel | null | undefined
  read?: ReadCardModel | null | undefined
  /**
   * Image-card material for a call whose result is an image (derived by
   * `imageCardModel`). Rendered through the `tool.call.images` slot, so the
   * tool layer never imports an attachment implementation nor handles URL
   * authorization.
   */
  image?: ImageCardModel | null | undefined
  /**
   * Dispatch the image gallery through the tool-owned `tool.call.images`
   * slot, supplied by the toolview that owns this row together with the
   * Gateway-authorized loader.
   */
  renderSlot?: PropsRenderSlots<'tool.call.images'>['renderSlot'] | undefined
  /** Gateway-authorized image URL loader for the gallery slot. */
  loadImage?: MessageImageLoader | undefined
  search?: SearchCardModel | null | undefined
  web?: WebCardModelProps | null | undefined
  /** Read-only fields/list card derived from a successful recorded result. */
  details?: ToolDetailsModel | null | undefined
  state: ToolRowState
  /**
   * Recorded file target or a supported argument fallback. With onOpenFile,
   * the summary opens that path through the owner's file-preview callback.
   */
  filePath?: string | undefined
  /** 1-based line the call was about; absent = open the file at its beginning. */
  filePathLine?: number | undefined
  /** Open the path (already cwd-resolved), landing on `filePathLine` when given. */
  onOpenFile?: ((path: string, options?: OpenFileOptions) => void) | undefined
  /** File gesture bindings supplied by the owning tool view. */
  fileContextMenuProps?: ContextMenuTriggerProps | undefined
  /**
   * Files a patch row names. When onOpenFile is set, the row state is `ok`, and
   * at least one target has a `filePath`, each such target renders as its own
   * link in place of the summary text; otherwise the row shows `summary`.
   */
  fileTargets?: readonly ToolRowFileTarget[] | undefined
  /** File gesture bindings for one `fileTargets` path, supplied by the owning tool view. */
  fileTargetContextMenuProps?: ((path: string) => ContextMenuTriggerProps) | undefined
  /** URL gesture bindings supplied by the owning tool view. */
  urlContextMenuProps?: ContextMenuTriggerProps | undefined
  /** Safe http(s) URL from tool args; when set, the summary renders as a link that opens it in a new tab. */
  href?: string | undefined
  /**
   * Jump to this call in the trajectory view: a hover-revealed Inspect pill
   * over the expanded body. Absent = no affordance.
   */
  inspect?: (() => void) | undefined
}

/** Keep a summary link click from toggling the row; the browser still follows the link. */
function stopLinkClick(event: MouseEvent<HTMLAnchorElement>): void {
  event.stopPropagation()
}

interface FileTargetLinkProps {
  label: string
  path: string
  onOpenFile: (path: string, options?: OpenFileOptions) => void
  contextMenuProps: ContextMenuTriggerProps | undefined
  onLinkKeyDown: (event: KeyboardEvent<HTMLElement>) => void
}

/** One openable file inside a multi-file summary; activating it never toggles the row. */
function FileTargetLink({ label, path, onOpenFile, contextMenuProps, onLinkKeyDown }: FileTargetLinkProps) {
  return (
    <button
      type="button"
      className={css.fileTargetLink}
      {...contextMenuProps}
      onClick={(event) => {
        event.stopPropagation()
        onOpenFile(path)
      }}
      onKeyDown={(event) => {
        onLinkKeyDown(event)
        contextMenuProps?.onKeyDown?.(event)
      }}
    >
      {label}
    </button>
  )
}

/** Visually hidden run-state label for color-only running and settlement cues. */
function stateStatus(state: ToolRowState, t: TranslateNS<'conversation'>): string | null {
  switch (state) {
    case 'preparing': return t('row.preparing')
    case 'running': return t('row.running')
    case 'error': return t('row.failed')
    case 'stopped': return t('row.stopped')
    default: return null
  }
}

/**
 * Render one localized tool summary and lazily mounted result card.
 * Preparation retains the icon, title, and optional tool-name summary without disclosure.
 * @param props - tool state, summary, output, and navigation callbacks.
 * @returns the tool disclosure.
 */
export const ToolRow = memo(function ToolRow({
  t,
  variant,
  toolName,
  icon,
  title,
  summary,
  summarySuffix,
  bodyRaw,
  output,
  askQuestion,
  errorSummary,
  terminal,
  diff,
  read,
  image,
  renderSlot,
  loadImage,
  search,
  web,
  details,
  state,
  filePath,
  filePathLine,
  onOpenFile,
  fileContextMenuProps, urlContextMenuProps, fileTargets, fileTargetContextMenuProps,
  href,
  inspect,
  useDisclosure,
}: ToolRowProps) {
  const { expanded, toggle: toggleExpand } = useDisclosure()
  const terminalLabels = useMemo(() => terminalBlockLabels(t), [t])
  const diffLabels = useMemo(() => diffBlockLabels(t), [t])
  const readLabels = useMemo(() => readBlockLabels(t), [t])
  const searchLabels = useMemo(() => searchBlockLabels(t), [t])
  const webLabels = useMemo(() => webBlockLabels(t), [t])
  const terminalBody = useMemo(() => terminal === undefined || terminal === null
    ? null
    : localizeTerminalCardModel(terminal, t), [terminal, t])
  const diffBody = diff ?? null
  const readBody = read ?? null
  const imageBody = image !== undefined && image !== null && renderSlot !== undefined && loadImage !== undefined
    ? image
    : null
  const searchBody = search ?? null
  const webBody = web ?? null
  const askQuestionBody = askQuestion ?? null
  const detailsBody = details ?? null
  const inputRaw = bodyRaw ?? null
  const outputText = output ?? null
  const card = askQuestionBody ?? terminalBody ?? diffBody ?? readBody ?? imageBody ?? searchBody ?? webBody ?? detailsBody
  const expandable = state !== 'preparing' && (inputRaw !== null || outputText !== null || card !== null)
  const open = expanded && expandable
  const bodyText = useMemo(
    () => open && card === null && inputRaw !== null ? formatToolBody(variant, inputRaw) : null,
    [card, inputRaw, open, variant],
  )
  const status = stateStatus(state, t)
  const running = state === 'running' || state === 'preparing'
  const normalSummary = terminalBody?.description ?? (open ? detailsBody?.expandedSummary ?? summary : summary)
  const exitLabel = terminalExitLabel(terminal, t)
  // Generic failures retain their first result line; command exits keep their description.
  const failureLine = state === 'error' && exitLabel === null ? errorSummary ?? normalSummary : null
  const summaryText = failureLine ?? normalSummary
  // Diff totals remain visible after the optional summary suffix.
  const diffStat = useMemo(() => diffBody === null ? null : diffTotals(diffBody.card.diffs), [diffBody])
  const settledWithCue = state === 'error' || state === 'stopped'
  const suffix = settledWithCue ? null : summarySuffix ?? null
  const totals = settledWithCue ? null : diffStat
  const openFile = useMemo(() => filePath !== undefined && onOpenFile !== undefined && !settledWithCue
    ? (event: MouseEvent<HTMLButtonElement>) => {
      event.stopPropagation()
      if (filePathLine === undefined) onOpenFile(filePath)
      else onOpenFile(filePath, { line: filePathLine })
    }
    : undefined, [filePath, filePathLine, onOpenFile, settledWithCue])
  const linkHref = settledWithCue ? undefined : href
  // Per-file links appear only on a successful result: TextShimmer accepts no
  // buttons, so running and failed rows keep the plain summary text.
  const openTarget = state === 'ok' && fileTargets?.some(target => target.filePath !== undefined) === true
    ? onOpenFile : undefined
  // Keep Enter/Space on the focused path or URL link from bubbling to the row's
  // keydown handler, which would preventDefault() the key and toggle expand
  // instead of activating the link — the keyboard analogue of the click
  // handlers' stopPropagation. Enter activates both links and Space activates
  // the path button; Space on a URL link does nothing.
  const summaryLinkKeyDown = useCallback((event: KeyboardEvent<HTMLElement>) => {
    if (event.key === 'Enter' || event.key === ' ') event.stopPropagation()
  }, [])
  // The code variant's program renders through CodeBlock (shiki), so only its
  // output joins the IN/OUT card; every other variant's input does too.
  const cardBody = variant === 'code' ? null : bodyText
  const collapsedContent = useMemo(() => summaryText !== '' && (
    /* An empty summary drops the separator with it (a row that is only
       its title shows no trailing dot). */
    <>
      <span className={css.sep} data-shimmer-decoration aria-hidden />
      {exitLabel === null && fileTargets !== undefined && openTarget !== undefined ? (
        <span className={css.fileLinks}>
          {fileTargets.map((target, index) => (
            <Fragment key={target.id}>
              {index > 0 && FILE_TARGET_SEPARATOR}
              {target.from !== undefined && `${target.from}${FILE_TARGET_MOVE}`}
              {target.filePath === undefined ? target.label : (
                <FileTargetLink
                  label={target.label}
                  path={target.filePath}
                  onOpenFile={openTarget}
                  contextMenuProps={fileTargetContextMenuProps?.(target.filePath)}
                  onLinkKeyDown={summaryLinkKeyDown}
                />
              )}
            </Fragment>
          ))}
        </span>
      ) : exitLabel === null && openFile !== undefined ? (
        <button
          type="button"
          className={css.fileLink}
          {...fileContextMenuProps}
          onClick={openFile}
          onKeyDown={(event) => {
            summaryLinkKeyDown(event)
            fileContextMenuProps?.onKeyDown?.(event)
          }}
        >
          <TextShimmer>{summaryText}</TextShimmer>
        </button>
      ) : exitLabel === null && linkHref !== undefined ? (
        <a
          className={css.fileLink}
          href={linkHref}
          {...urlContextMenuProps}
          target="_blank"
          rel="noopener noreferrer"
          onClick={stopLinkClick}
          onKeyDown={(event) => {
            summaryLinkKeyDown(event)
            urlContextMenuProps?.onKeyDown?.(event)
          }}
        >
          <TextShimmer>{summaryText}</TextShimmer>
        </a>
      ) : (
        <span
          className={clsx(
            css.summary,
            exitLabel === null && state === 'error' && css.errorSummary,
            exitLabel === null && state === 'stopped' && css.stoppedSummary,
          )}
        >
          <TextShimmer>{summaryText}</TextShimmer>
        </span>
      )}
      {exitLabel !== null && <ExitCodeBadge label={exitLabel} />}
      {suffix !== null && (
        <TextShimmer className={css.summarySuffix}>{suffix}</TextShimmer>
      )}
      {totals !== null && (
        <TextShimmer className={clsx(css.summarySuffix, css.diffStat)}>
          <span className={css.diffAdded}>{`+${totals.added}`}</span>{' '}<span className={css.diffRemoved}>{`-${totals.removed}`}</span>
        </TextShimmer>
      )}
    </>
  ), [summaryLinkKeyDown, fileContextMenuProps, urlContextMenuProps, linkHref, openFile, fileTargets, openTarget,
    fileTargetContextMenuProps, state, suffix, totals, summaryText, exitLabel])
  const expandedContent = useMemo(() => open ? (
    <div className={clsx(css.bodyWrap, detailsBody !== null && css.detailsBodyWrap)}>
      {askQuestionBody !== null
        ? <AskQuestionCard card={askQuestionBody} />
        : terminalBody !== null
          ? (
            <TerminalBlock
              {...terminalBody.card}
              maxLines={Infinity}
              labels={terminalLabels}
              className={css.terminalBody}
            />
          )
          : diffBody !== null
            ? (
              <>
                <DiffBlock {...diffBody.card} labels={diffLabels} maxLines={CHAT_DIFF_MAX_LINES} className={css.diffBody} />
                {state === 'error' && outputText !== null && (
                  <div className={css.ioCard}>
                    <div className={css.ioSection}>
                      <span className={css.ioLabel}>{t('row.output')}</span>
                      <span className={css.ioText} data-error>{outputText}</span>
                    </div>
                  </div>
                )}
              </>
            )
            : readBody !== null
              ? <ReadBlock {...readBody} labels={readLabels} maxLines={CHAT_READ_MAX_LINES} className={css.readBody} />
              : imageBody !== null
                ? (
                  /* Gallery, then the full path and each attached image's size.
                     These come from the image card model, never from the row's
                     flattened output, which JSON.stringifies the image block. They
                     stay visible when the attachment slot renders nothing. */
                  <div className={css.imageBody}>
                    {renderSlot !== undefined && loadImage !== undefined && renderSlot('tool.call.images', {
                      images: imageBody.images,
                      loadImage,
                      align: 'start',
                    })}
                    <div className={css.imageMeta}>
                      <div>{imageBody.path}</div>
                      {imageBody.images.map(({ attachment }, index) => (
                        <div key={index}>
                          {attachment.originalDimensions === undefined
                            ? t('row.imageSize', { width: attachment.width, height: attachment.height, bytes: attachment.bytes })
                            : t('row.imageSizeDownscaled', {
                              width: attachment.width,
                              height: attachment.height,
                              originalWidth: attachment.originalDimensions.width,
                              originalHeight: attachment.originalDimensions.height,
                              bytes: attachment.bytes,
                            })}
                        </div>
                      ))}
                    </div>
                    {imageBody.extraText !== null && <div className={css.imageExtra}>{imageBody.extraText}</div>}
                  </div>
                )
                : searchBody !== null
                  ? (
                    <>
                      <SearchBlock
                        {...searchBody.card}
                        labels={searchLabels}
                        maxLines={CHAT_SEARCH_MAX_LINES}
                        className={css.searchBody}
                      />
                      {/* A capped search's recovery locator lives only in the result
                      text; show it below the card so the dropped rows survive. */}
                      {searchBody.recovery !== undefined && (
                        <div className={css.searchRecovery}>{searchBody.recovery}</div>
                      )}
                    </>
                  )
                  : webBody !== null
                    ? <WebBlock {...webBody} labels={webLabels} className={css.webBody} />
                    : detailsBody !== null
                      ? <ToolDetails model={detailsBody} hasInspect={inspect !== undefined} t={t} onOpenFile={onOpenFile} />
                      : (
                        <>
                          {variant === 'code' && bodyText !== null && (
                            <div className={css.bodyScroll}>
                              <CodeBlock code={bodyText} lang="typescript" copyLabel={t('copy')} copiedLabel={t('copied')}
                                toolbarLabels={codeToolbarLabels(t)} className={css.codeBody} />
                            </div>
                          )}
                          {(cardBody !== null || outputText !== null) && (
                            <div className={css.ioCard}>
                              {cardBody !== null && (
                                <div className={css.ioSection}>
                                  <span className={css.ioLabel}>{t('row.input')}</span>
                                  <span className={css.ioText}>{cardBody}</span>
                                </div>
                              )}
                              {cardBody !== null && outputText !== null && (
                                <span className={css.ioDivider} aria-hidden />
                              )}
                              {outputText !== null && (
                                <div className={css.ioSection}>
                                  <span className={css.ioLabel}>{t('row.output')}</span>
                                  <span className={css.ioText} data-error={state === 'error' || undefined}>
                                    {outputText}
                                  </span>
                                </div>
                              )}
                            </div>
                          )}
                        </>
                      )}
      {inspect !== undefined && (
        <button
          type="button"
          className={css.inspectButton}
          onClick={inspect}
        >
          <IconInspectOutlineRegular />
          {t('row.inspect')}
        </button>
      )}
    </div>
  ) : undefined, [
    open, detailsBody, askQuestionBody, terminalBody, terminalLabels, diffBody, diffLabels, readBody, readLabels,
    imageBody, renderSlot, loadImage, searchBody, searchLabels, webBody, webLabels, inspect, t, onOpenFile,
    variant, bodyText, cardBody, outputText, state,
  ])
  return (
    <div className={css.root} data-variant={variant} data-tool={toolName} data-state={state}>
      {status !== null && <span className={css.visuallyHidden}>{status}</span>}
      <DisclosureRow
        rowClassName={css.row}
        leadingClassName={css.leading}
        titleClassName={css.title}
        icon={icon}
        title={title}
        running={running}
        open={open}
        expandable={expandable}
        expandOnRowClick
        keepContentWhenOpen
        onToggle={toggleExpand}
        collapsedContent={collapsedContent}
      >
        {expandedContent}
      </DisclosureRow>
    </div>
  )
})
