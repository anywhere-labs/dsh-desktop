import { toolFileInject, type ToolFileInjected } from '../file-menu.ts'
import type { Context } from '@deepseek-ai/cordis'
import { IconEditOutlineRegular } from '@deepseek-ai/dsh-client-ui-primitives'
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots'
import type { ToolCallViewProps } from '../../contract/slots.ts'
import { diffCardModel } from '../models/diff-card-model.ts'
import { toolRowModel } from '../models/tool-call-model.ts'
import { ToolRow } from '../components/ToolRow.tsx'
import { CONVERSATION_NS as NS } from '../../locale.ts'

type FileMutationRowProps = ToolCallViewProps & ToolFileInjected & PropsLocale<'conversation'>
const FILE_MUTATION_ICON = <IconEditOutlineRegular size={14} />

const CONTENT_FIELDS = ['content', 'old_string', 'new_string']
const KILOBYTE = 1024

/** Kilobytes of decoded input at every stage; null before any content field arrives. */
function contentKilobytes(block: FileMutationRowProps['block']): number | null {
  const { args } = block
  const open = CONTENT_FIELDS.find(key => args.has(key) && !args.complete(key))
  const completed = CONTENT_FIELDS.reduce((total, key) => key !== open && args.complete(key)
    ? total + (args.stringLength(key, { step: KILOBYTE }) ?? 0) : total, 0)
  if (open === undefined) {
    return CONTENT_FIELDS.some(key => args.has(key)) ? Math.ceil(completed / KILOBYTE) : null
  }
  const chars = completed + (args.stringLength(open, { step: KILOBYTE, offset: completed }) ?? 0)
  return Math.ceil(chars / KILOBYTE)
}

/**
 * Shows the path and decoded input size through preparation, execution, and
 * settlement, with the applied diff available once the call settles.
 */
export function FileMutationRow({
  toolName, block, cwd, home, openFile, useContextMenu, sessionId, resolveFilePath, inspect, useDisclosure, t,
}: FileMutationRowProps) {
  const { getTriggerProps } = useContextMenu()
  const model = toolRowModel(toolName, block, cwd, home)
  const path = model.filePath
  const diff = diffCardModel(block)
  const kilobytes = contentKilobytes(block)
  const size = kilobytes === null ? null : t('tool.preparing.content', { kilobytes })
  return (
    <ToolRow
      fileContextMenuProps={getTriggerProps(path === undefined ? undefined : () => ({
        kind: 'file', value: { sessionId, path: resolveFilePath(path) },
      }))}
      useDisclosure={useDisclosure}
      t={t}
      variant={model.variant}
      toolName={toolName}
      icon={FILE_MUTATION_ICON}
      title={t(model.titleKey)}
      summary={model.summary}
      summarySuffix={size !== null && model.summary !== '' ? size : undefined}
      output={model.output}
      errorSummary={model.errorSummary}
      diff={diff}
      state={model.state}
      filePath={model.filePath}
      fileTargets={model.fileTargets}
      fileTargetContextMenuProps={target => getTriggerProps(() => ({
        kind: 'file', value: { sessionId, path: resolveFilePath(target) },
      }))}
      onOpenFile={openFile}
      inspect={inspect}
    />
  )
}

/** Registers file-mutation conversation rows. */
export const fileMutationToolview = {
  name: 'file-mutation-toolview',
  inject: ['slots', 'sessions'],
  apply(ctx: Context): void {
    ctx.slots.inject('tool.call.toolview', function* () {
      yield ctx.slots.register({ name: 'tool.call.toolview', key: 'apply_patch', locale: NS, inject: toolFileInject(ctx) }, FileMutationRow)
      yield ctx.slots.register({ name: 'tool.call.toolview', key: 'edit', locale: NS, inject: toolFileInject(ctx) }, FileMutationRow)
      yield ctx.slots.register({ name: 'tool.call.toolview', key: 'write', locale: NS, inject: toolFileInject(ctx) }, FileMutationRow)
    })
  },
}
