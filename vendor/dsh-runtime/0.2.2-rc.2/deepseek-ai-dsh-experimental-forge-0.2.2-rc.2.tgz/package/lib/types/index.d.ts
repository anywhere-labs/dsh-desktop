/** Registry of code-host providers with provider-neutral change requests and shared status polling. */
import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { BranchUpdateRequest, ChangeRequestListener, ChangeRequestRef, ChangeRequestSnapshot, ChangeRequestUpdate, Config, ForgeCommitList, ForgeActionFailure, ForgeFailure, ForgeProvider, ForgeReadiness, ForgeRepository, ForgeRerunRequest, ForgeReviewData, ForgeReviewerCandidate, ForgeReviewersRequest, ForgeReviewRequest, ForgeReviewResult, ForgeReviewWrite, ForgeReviewWriteResult, ForgeViewedFiles, ForgeViewedRequest, MergeRequest } from './types.ts';
export { changeRequestKey } from './keys.ts';
export type * from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        forge: ForgeService;
    }
    interface Events {
        /**
         * Announces a provider registration or withdrawal after the registry changes.
         * Listener failures are logged without preventing other listeners from running.
         * @param forge - family whose provider changed.
         * @mode parallel
         */
        'forge/providers-changed'(forge: string): void | Promise<void>;
    }
}
/**
 * Registry of forge providers. Watchers of one change request share a single
 * polling loop; each forge has at most one fetch in flight, which batches
 * every due change request of that forge.
 */
export declare class ForgeService extends Service {
    static Config: z<Config>;
    private readonly config;
    private readonly providers;
    private readonly watches;
    private readonly fetching;
    private readonly pending;
    private readonly lifetime;
    private timer;
    /**
     * Poll what is due. A field rather than a method, so the timer runs it on
     * the instance itself: a polling round started through a caller's `ctx.forge`
     * would otherwise run on that caller's shadow receiver, and every later round
     * would nest one more shadow until a property write overflows the stack.
     */
    private readonly tick;
    constructor(ctx: Context, config: Config);
    /**
     * Register the provider of one forge family as an effect on the calling
     * fiber. Watches of that forge receive an `unavailable` failure when the
     * registration ends. Unregistering cancels and awaits its in-flight calls;
     * results from the withdrawn registration are discarded.
     * @param provider - provider to serve `provider.forge`.
     * @returns the disposer that unregisters the provider and waits for its calls to finish.
     * @throws when another provider already serves the same forge.
     */
    register(provider: ForgeProvider): () => Promise<void>;
    /**
     * Map a Git remote URL to a repository through the first provider that serves it.
     * @param url - fetch or push URL as Git reports it.
     * @returns the repository, or undefined when no provider serves the URL.
     */
    repositoryFromRemote(url: string): ForgeRepository | undefined;
    /**
     * Map a change request web URL through the first provider that serves it.
     * @param url - web URL of a pull or merge request.
     * @returns the change request, or undefined when no provider serves the URL.
     */
    changeRequestFromUrl(url: string): ChangeRequestRef | undefined;
    /**
     * Build the canonical web URL of a change request.
     * @param ref - change request served by a registered provider.
     * @returns the provider's canonical URL.
     * @throws when no provider serves the change request's forge.
     */
    changeRequestUrl(ref: ChangeRequestRef): string;
    /**
     * Find open change requests whose head is `branch`, excluding the default branch and forks.
     * @param repository - repository served by a registered provider.
     * @param branch - head branch name on the host.
     * @param signal - cancellation for the lookup.
     * @returns matching change requests, newest first as the provider reports them.
     * @throws when no provider serves the repository's forge or the lookup fails.
     */
    findByHead(repository: ForgeRepository, branch: string, signal: AbortSignal): Promise<readonly ChangeRequestRef[]>;
    /**
     * Report whether the provider can reach the repository's host with current credentials.
     * @param repository - repository served by a registered provider.
     * @param signal - cancellation for the probe.
     * @returns the provider's readiness for the host.
     * @throws when no provider serves the repository's forge.
     */
    readiness(repository: ForgeRepository, signal: AbortSignal): Promise<ForgeReadiness>;
    /**
     * Mark a draft change request ready for review, then poll it at once when it is watched.
     * @param ref - change request served by a registered provider.
     * @param signal - cancellation of the request.
     * @returns undefined once the host accepted the change, or why it did not.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    markReady(ref: ChangeRequestRef, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * Merge a change request while its head is still `request.headSha`, then
     * poll it at once when it is watched.
     * @param ref - change request served by a registered provider.
     * @param request - merge method and the head commit the user confirmed.
     * @param signal - cancellation of the request.
     * @returns undefined once the host merged it, or why it did not.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    merge(ref: ChangeRequestRef, request: MergeRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * Rerun the failed checks of a change request's head commit while the head is still `request.headSha`, then poll it
     * at once when it is watched.
     * @param ref - change request served by a registered provider.
     * @param request - the head commit whose checks the user saw.
     * @param signal - cancellation of the request.
     * @returns undefined once the host accepted the rerun, or why it did not; a provider that reruns no checks fails.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    rerunChecks(ref: ChangeRequestRef, request: ForgeRerunRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * Request reviews of a change request from more reviewers, then poll it at once when it is watched.
     * @param ref - change request served by a registered provider.
     * @param request - the reviewers to ask.
     * @param signal - cancellation of the request.
     * @returns undefined once the host accepted the request, or why it did not; a provider that requests no reviews fails.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    requestReviews(ref: ChangeRequestRef, request: ForgeReviewersRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * List accounts a review of a change request can be requested from.
     * @param ref - change request served by a registered provider.
     * @param query - text the login or name contains; empty for the host's suggestions and first accounts.
     * @param signal - cancellation of the read.
     * @returns the accounts, the host's suggestions first, or why the host did not list them; a provider that requests no
     * reviews returns `unsupported`.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    reviewerCandidates(ref: ChangeRequestRef, query: string, signal: AbortSignal): Promise<readonly ForgeReviewerCandidate[] | ForgeFailure>;
    /**
     * Bring the base branch's new commits into a change request's head branch while its head is still
     * `request.headSha`, then poll it at once when it is watched.
     * @param ref - change request served by a registered provider.
     * @param request - update method and the head commit the user confirmed.
     * @param signal - cancellation of the request.
     * @returns undefined once the host accepted the update, or why it did not; a provider that updates no branches fails.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    updateBranch(ref: ChangeRequestRef, request: BranchUpdateRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * Read complete check details independently of periodic polling.
     * @param ref - change request served by a registered provider.
     * @param signal - cancellation of the detail view.
     * @returns a complete snapshot or the provider's failure; unsupported providers return unavailable.
     * @throws on cancellation, provider disposal, or expiry of this read's own `fetchTimeoutMs` deadline.
     */
    fetchChecks(ref: ChangeRequestRef, signal: AbortSignal): Promise<ChangeRequestSnapshot | ForgeFailure>;
    /**
     * Read the changes of a change request at one head commit as its host
     * computes them. The first `stale` failure at a head commit polls a watched
     * change request again at once, so its next status names the current head;
     * later stale reads at the same commit wait for the regular poll, which
     * bounds the reads while the host's answers disagree. When the latest status of a watched change request names
     * `headSha`, its `baseSha` goes to the provider, which may then read the patch while it confirms the head.
     * @param ref - change request served by a registered provider.
     * @param headSha - head commit the patch must describe, usually the head of the latest status.
     * @param signal - cancellation of the read.
     * @returns one unified patch with `a/` and `b/` path prefixes, or why the host did not provide it at `headSha`.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    diff(ref: ChangeRequestRef, headSha: string, signal: AbortSignal): Promise<string | ForgeFailure>;
    /**
     * Read the review threads of a change request at one head commit. A
     * `stale` failure polls a watched change request again as {@link ForgeService.diff} does.
     * @param ref - change request served by a registered provider.
     * @param headSha - head commit the threads must be read at, usually the head of the displayed diff.
     * @param signal - cancellation of the read.
     * @returns the threads read at `headSha`, or why the host did not provide them; `unsupported` when the provider cannot read reviews.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    readReview(ref: ChangeRequestRef, headSha: string, signal: AbortSignal): Promise<ForgeReviewData | ForgeFailure>;
    /**
     * Write to the review threads or the pending review of a change request while its head is still `write.headSha`, then
     * poll the change request at once when it is watched, unless the provider cannot write reviews. A `stale` result polls
     * it as a stale read does.
     * @param ref - change request served by a registered provider.
     * @param write - the write and the head commit the user saw.
     * @param signal - cancellation of the write.
     * @returns whether the host took the write; `unsupported` when the provider cannot write reviews, and `unknown` when the
     * outcome must be checked on the host before the write is tried again.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    writeReview(ref: ChangeRequestRef, write: ForgeReviewWrite, signal: AbortSignal): Promise<ForgeReviewWriteResult>;
    /**
     * Read the signed-in user's viewed marks on the files of a change request at one head commit. A `stale` failure
     * polls a watched change request again as {@link ForgeService.diff} does.
     * @param ref - change request served by a registered provider.
     * @param headSha - head commit the marks must be read at, usually the head of the displayed diff.
     * @param signal - cancellation of the read.
     * @returns the marks read at `headSha`, why the host did not provide them, or undefined when the provider keeps no
     * viewed marks.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    viewedFiles(ref: ChangeRequestRef, headSha: string, signal: AbortSignal): Promise<ForgeViewedFiles | ForgeFailure | undefined>;
    /**
     * Set or clear the signed-in user's viewed mark on one file of a change request while its head is still
     * `request.headSha`. A `stale` failure polls a watched change request again as {@link ForgeService.diff} does.
     * @param ref - change request served by a registered provider.
     * @param request - the file, its mark, and the head commit the user saw.
     * @param signal - cancellation of the request.
     * @returns undefined once the host saved the mark, or why it did not; a provider that keeps no viewed marks fails.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    setViewed(ref: ChangeRequestRef, request: ForgeViewedRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * List the commits of a change request at its current head.
     * @param ref - change request served by a registered provider.
     * @param signal - cancellation of the read.
     * @returns the commits, why the host did not provide them, or undefined when the provider does not read commits.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    commits(ref: ChangeRequestRef, signal: AbortSignal): Promise<ForgeCommitList | ForgeFailure | undefined>;
    /**
     * Read the changes between two commits of a change request's repository.
     * @param ref - change request served by a registered provider.
     * @param base - full object name of the commit compared from.
     * @param head - full object name of a commit that descends from `base`.
     * @param signal - cancellation of the read.
     * @returns one unified patch with `a/` and `b/` path prefixes, or why the host did not provide it; a provider that
     * does not read commits returns `unavailable`.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    compare(ref: ChangeRequestRef, base: string, head: string, signal: AbortSignal): Promise<string | ForgeFailure>;
    /**
     * Publish one comment or a completed review, then refresh the watched status.
     * @param ref - change request served by a registered provider.
     * @param request - explicitly selected commit, comments, and review decision.
     * @param signal - request cancellation.
     * @returns a publication URL or a failure, including an unknown write outcome.
     */
    submitReview(ref: ChangeRequestRef, request: ForgeReviewRequest, signal: AbortSignal): Promise<ForgeReviewResult>;
    /**
     * Read the text of one file at a commit of a change request's repository.
     * @param ref - change request served by a registered provider.
     * @param commit - commit object name.
     * @param path - path relative to the repository root.
     * @param signal - cancellation of the read.
     * @returns the text, or why the host did not provide it.
     * @throws when no provider serves the change request's forge, or with `signal.reason` when it aborts.
     */
    fileText(ref: ChangeRequestRef, commit: string, path: string, signal: AbortSignal): Promise<string | ForgeFailure>;
    /**
     * Build the web page of one file at a commit of a change request's repository.
     * @param ref - change request served by a registered provider.
     * @param commit - commit object name.
     * @param path - path relative to the repository root.
     * @returns the provider's URL.
     * @throws when no provider serves the change request's forge.
     */
    fileUrl(ref: ChangeRequestRef, commit: string, path: string): string;
    /**
     * Watch one change request as an effect on the calling fiber. The first
     * watcher starts polling at once; listeners receive every later result,
     * and `latest` returns the current one. Polling stops when the last watcher
     * leaves. Listeners must not throw; a thrown error is logged and skipped.
     * @param ref - change request to poll.
     * @param listener - receives each polling result.
     * @returns the disposer that stops this watch.
     */
    watch(ref: ChangeRequestRef, listener: ChangeRequestListener): () => void;
    /**
     * Poll a watched change request at once, including after a terminal state.
     * A fetch already in flight is followed immediately by another fetch; an
     * unwatched change request is unchanged.
     * @param ref - change request to poll.
     */
    refresh(ref: ChangeRequestRef): void;
    /**
     * Read the latest polling result of a watched change request.
     * @param ref - change request to read.
     * @returns the latest result, or undefined before the first result or without a watch.
     */
    latest(ref: ChangeRequestRef): ChangeRequestUpdate | undefined;
    /** Poll a watched change request at once after the first `stale` read or write at `headSha`; later ones wait for the regular poll. */
    private staleRead;
    /**
     * Run one optional provider action, then poll the change request at once when it is watched and the provider has the
     * action.
     * @param ref - change request served by a registered provider.
     * @param signal - cancellation of the action.
     * @param pick - the provider's action, or undefined when it lacks the capability.
     * @param missing - what a provider without the action does not do, for its failure.
     * @param run - calls the action.
     * @returns the action's failure, or undefined once the host accepted it.
     */
    private act;
    private provider;
    private providersChanged;
    private registration;
    private invoke;
    private missing;
    private schedule;
    private poll;
    /** Fetch one forge's batch; never rejects. */
    private fetch;
    private settle;
}
export default ForgeService;
//# sourceMappingURL=index.d.ts.map