/**
 * LLM failure codes and helpers over the shared Harness error base. The base
 * class lives in `@deepseek-ai/dsh-error` and is re-exported here, so both
 * import paths name the same class.
 * @module @deepseek-ai/dsh-llm/error
 */

import { HarnessError } from '@deepseek-ai/dsh-error'

export { HarnessError }

/**
 * Every failure code the built-in providers and the LLM runtime raise. An entry
 * marked `retryChoice` is offered as a choice for a provider retry policy's
 * `retryableCodes`; being a choice does not make a code retried by default.
 */
export const LLM_FAILURE_CODES = {
  ABORTED: {},
  ACCOUNT_QUOTA: {},
  ACCOUNT_SIGN_IN_REQUIRED: {},
  ACCOUNT_TOKEN_INVALID: {},
  AUTH: {},
  CLIENT_UPGRADE_REQUIRED: {},
  CONTEXT_WINDOW_EXCEEDED: {},
  DISCOVERY_FAILED: {},
  DISCOVERY_UNSUPPORTED: {},
  DUPLICATE_ADAPTER: {},
  DUPLICATE_DIRECTORY: {},
  DUPLICATE_DISCOVERY: {},
  EMPTY_RESPONSE: { retryChoice: true },
  FILES_API: {},
  IMAGE_OFFLOAD_REQUIRED: {},
  INVALID_ADAPTER: {},
  INVALID_CATALOG: {},
  INVALID_CONFIG: {},
  INVALID_CREDENTIAL: {},
  INVALID_DIRECTORY: {},
  INVALID_DISCOVERY: {},
  INVALID_MODEL_CONTEXT: {},
  INVALID_MODEL_INFO: {},
  INVALID_MODEL_MAX_TOKENS: {},
  INVALID_MODEL_REASONING: {},
  INVALID_PREPARED_CALL: {},
  INVALID_REPLAY_STATE: {},
  INVALID_REQUEST: {},
  INVALID_RESPONSE: {},
  MALFORMED_RESPONSE: { retryChoice: true },
  MISSING_CREDENTIAL: {},
  MODEL_SWITCH_COMPACTION_FAILED: {},
  MODEL_UNSUPPORTED: {},
  NO_ADAPTER: {},
  NO_CREDENTIAL_STORE: {},
  NO_DISCOVERY: {},
  PI_AI_ERROR: {},
  QUOTA: { retryChoice: true },
  RATE_LIMIT: { retryChoice: true },
  REGISTRATION_DISPOSED: {},
  REQUEST_EXTENSION: {},
  REQUEST_HEADERS: {},
  SERVER: { retryChoice: true },
  STREAM_CLOSED: { retryChoice: true },
  TIMEOUT: { retryChoice: true },
  TRANSPORT: { retryChoice: true },
  UNKNOWN: {},
  UNKNOWN_MODEL: {},
  UNSTORABLE_PROVIDER_ID: {},
  UNSUPPORTED_CONTENT: {},
  UNSUPPORTED_OPTION: {},
  UNSUPPORTED_REASONING_EFFORT: {},
} as const satisfies Readonly<Record<string, { readonly retryChoice?: true }>>

/** A failure code from {@link LLM_FAILURE_CODES}, or an unclassified provider HTTP status. */
export type BuiltinLlmFailureCode = keyof typeof LLM_FAILURE_CODES | `HTTP_${number}`

/** The {@link LLM_FAILURE_CODES} entries marked as retry-policy choices, in definition order. */
export const RETRY_CODE_CHOICES: readonly BuiltinLlmFailureCode[] = Object.freeze(
  (Object.keys(LLM_FAILURE_CODES) as (keyof typeof LLM_FAILURE_CODES)[])
    .filter(code => 'retryChoice' in LLM_FAILURE_CODES[code]),
)

/** Canonical provider-neutral code for a model request rejected because its context window was exceeded. */
export const CONTEXT_WINDOW_EXCEEDED_CODE = 'CONTEXT_WINDOW_EXCEEDED' satisfies BuiltinLlmFailureCode

/** Canonical provider-neutral code for an exhausted account quota or balance. */
export const QUOTA_EXCEEDED_CODE = 'QUOTA' satisfies BuiltinLlmFailureCode

/** Account-token quota that can be replenished through the first-party billing page. */
export const ACCOUNT_QUOTA_EXCEEDED_CODE = 'ACCOUNT_QUOTA' satisfies BuiltinLlmFailureCode

/**
 * Canonical provider-neutral code for a response that completed normally but
 * carried no content blocks at all. Providers occasionally emit a degenerate
 * completion (a terminal stop with zero output); adapters classify it as this
 * failure instead of yielding an empty assistant message, because an empty
 * message silently ends the turn with nothing for the user or the loop to act
 * on. The attempt produced nothing durable, so retry policy treats it as safe
 * to repeat.
 */
export const EMPTY_RESPONSE_CODE = 'EMPTY_RESPONSE' satisfies BuiltinLlmFailureCode

/**
 * Canonical provider-neutral code for a credential that was supplied but
 * cannot be used — malformed rather than absent. Distinct from
 * `MISSING_CREDENTIAL` because the fix differs: correct the stored value
 * rather than supply one. Deliberately outside the default retryable set —
 * a malformed credential fails identically on every attempt.
 */
export const INVALID_CREDENTIAL_CODE = 'INVALID_CREDENTIAL' satisfies BuiltinLlmFailureCode

/** Structured codes and plain phrases that explicitly name a context bound being exceeded. */
const STRUCTURED_CONTEXT_OVERFLOW = new RegExp(
  String.raw`(?:^|[^a-z0-9])context[\s_-](?:length|window)[\s_-]`
  + String.raw`(?:exceed(?:ed|s)?|overflow(?:ed)?|limit[\s_-]exceeded)(?:$|[^a-z0-9])`,
  'i',
)

/** Request-size wording that ties "too large" directly to model context capacity. */
const TOO_LARGE_FOR_CONTEXT = new RegExp(
  String.raw`\b(?:request|prompt|input|messages?)\s+(?:is\s+|are\s+)?`
  + String.raw`too\s+(?:large|long)\s+for\s+(?:(?:this|the)\s+)?`
  + String.raw`(?:model(?:'s)?\s+)?context(?:\s+window)?\b`,
  'i',
)

/** "Exceeds" wording is safe only when its object is explicitly the model context. */
const EXCEEDS_MODEL_CONTEXT = new RegExp(
  String.raw`\b(?:input|prompt|request|messages?)\b.{0,40}`
  + String.raw`\b(?:exceed(?:s|ed)?|overflows?|is\s+larger\s+than)\b.{0,40}`
  + String.raw`\b(?:the\s+)?(?:model(?:'s)?\s+)?context(?:\s+(?:length|window))?\b`,
  'i',
)

/**
 * Recognize the context-overflow wording used by OpenAI-compatible providers
 * and library adapters. Adapters pass all available provider code, type, and
 * message text so both thrown and in-band delivery styles share one classifier.
 * @param detail - provider error code/type/message text joined into one string.
 * @returns true when the detail identifies a request exceeding the model context window.
 */
export function isContextWindowExceededError(detail: string): boolean {
  return STRUCTURED_CONTEXT_OVERFLOW.test(detail)
    || /\b(?:maximum|max)(?:\s+(?:allowed|supported))?\s+context\s+(?:length|window)\b/i.test(detail)
    || TOO_LARGE_FOR_CONTEXT.test(detail)
    || /\b(?:input|prompt|request)\s+(?:is\s+)?too\s+(?:long|large)\s+for\s+(?:this|the)\s+model\b/i.test(detail)
    || EXCEEDS_MODEL_CONTEXT.test(detail)
}

/**
 * Recognize provider wording that identifies an exhausted account quota rather
 * than a transient request-rate limit.
 * @param detail - provider error code/type/message text joined into one string.
 * @returns true only for terminal quota, balance, credit, budget, or usage-limit wording.
 */
export function isQuotaExceededError(detail: string): boolean {
  return /\binsufficient[\s_-]+(?:quota|balance|credits?)\b/i.test(detail)
    || /\b(?:quota|usage[\s_-]+limit)[\s_-]+(?:exceeded|exhausted|reached)\b/i.test(detail)
    || /\bexceed(?:ed|s)?[\s_-]+(?:(?:your|the)[\s_-]+)?(?:current[\s_-]+)?quota\b/i.test(detail)
    || /\b(?:balance|credits?)[\s_-]+(?:exhausted|depleted)\b/i.test(detail)
    || /\bout[\s_-]+of[\s_-]+(?:credits?|budget)\b/i.test(detail)
}

/**
 * Render a thrown value with its full `cause` chain and AggregateError
 * members, so transport wrappers like undici's `TypeError: fetch failed`
 * surface the underlying failure instead of masking it. Plain structured
 * failures render their own data-backed `message`. Diagnostic-surface
 * rendering only (messages, notices, logs) — never parse the result; route on
 * {@link HarnessError.code}.
 * @param value - the caught value (`unknown` in catch clauses).
 * @returns the outermost message first, each cause appended with `: ` (skipped
 * when it repeats the wrapper message verbatim), and AggregateError members
 * bracketed and `; `-joined.
 */
export function errorChain(value: unknown): string {
  // Tracks the active recursion path (entries removed on exit), so only true
  // cycles are flagged and a diamond-shared cause still renders in full.
  const path = new Set<unknown>()
  const render = (current: unknown): string => {
    if (path.has(current)) return '<circular cause>'
    path.add(current)
    try {
      if (!(current instanceof Error)) {
        if (typeof current === 'object' && current !== null) {
          const descriptor = Object.getOwnPropertyDescriptor(current, 'message')
          if (descriptor !== undefined && 'value' in descriptor && typeof descriptor.value === 'string') {
            return descriptor.value
          }
        }
        return String(current)
      }
      const message = current.message === '' ? current.name : current.message
      const members = current instanceof AggregateError && current.errors.length > 0
        ? ` [${current.errors.map(render).join('; ')}]`
        : ''
      const causeText = current.cause === undefined || current.cause === null
        ? ''
        : render(current.cause)
      // Wrappers like `new HarnessError(String(value), code, { cause: value })`
      // repeat their cause verbatim; rendering it again would only add noise.
      const cause = causeText === '' || causeText === message ? '' : `: ${causeText}`
      return `${message}${members}${cause}`
    } catch {
      // Only hostile coercion or hostile accessors (a throwing toString /
      // Symbol.toPrimitive on a non-Error, or a throwing message/name/cause/
      // errors getter on an Error subclass): this renderer feeds UI notices
      // and logs, so nothing may escape. Inner frames catch their own throws,
      // so only the hostile node collapses, not the whole chain.
      return '<unrenderable value>'
    } finally {
      path.delete(current)
    }
  }
  return render(value)
}

/**
 * Narrow an arbitrary thrown value to a HarnessError (for `instanceof` at runtime boundaries).
 * @param value - the caught value (`unknown` in catch clauses).
 * @returns true only for real instances; duck-typed or cross-realm errors do not narrow.
 */
export function isHarnessError(value: unknown): value is HarnessError {
  return value instanceof HarnessError
}

/**
 * Canonical code for a request an image-capable route cannot send until more
 * of its images are offloaded. The failure's `offloadImages` names how many
 * more of the oldest retained occurrences must be offloaded;
 * `dsh-compaction-image-offload` records an `image/offload` selection before
 * the agent or summarizer retries with freshly derived input.
 */
export const IMAGE_OFFLOAD_REQUIRED_CODE = 'IMAGE_OFFLOAD_REQUIRED' satisfies BuiltinLlmFailureCode
