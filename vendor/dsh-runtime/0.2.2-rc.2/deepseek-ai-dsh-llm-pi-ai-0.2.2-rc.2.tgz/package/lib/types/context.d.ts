/**
 * Harness request-history conversion into pi-ai's Context vocabulary.
 *
 * @module dsh-llm-pi-ai/context
 */
import type { GenerateOptions, ImageAttachmentAccessResolver } from '@deepseek-ai/dsh-llm';
import type { AttachmentStore, ImageAttachmentRef, ImageRequestTarget } from '@deepseek-ai/dsh-attachment';
import type { Context as PiContext } from '@earendil-works/pi-ai';
import type { PrefixDigests } from './prefix-binding.ts';
/** Inputs that bind deterministic request images to one current tool execution world. */
export interface PiImageRequestContext {
    /** Durable provider that resolves request-image bytes and provider-owned host objects. */
    attachments: AttachmentStore;
    /** Resolve current tool access separately from deterministic request-image versions. */
    resolveImageAccess: ImageAttachmentAccessResolver;
    /** Request-level bound on the base64-encoded payload of retained images; omission leaves the bound unchecked. */
    maxRequestImageBytes?: number;
    /** Request-level bound on retained image occurrences; omission leaves the count unchecked. */
    maxRequestImages?: number;
    /** Oldest occurrences offloaded per count overflow; omission offloads the minimum. */
    imageOffloadCountQuantum?: number;
    /** Route pixel and raw encoded-byte budgets. */
    requestImagePolicy?: PiImageRequestBudget;
}
/** Per-route budgets from which each request image's target is derived. */
export interface PiImageRequestBudget {
    /** Total-pixel budget; larger sources are downscaled proportionally. */
    maxPixels: number;
    /** Encoded-byte target for one request image. */
    maxBytes: number;
}
/**
 * Resolve the request target for one source under the route budgets.
 * @param ref - normalized source image.
 * @param budget - resolved route pixel and byte limits.
 * @returns dimensions and byte target shared by serialization and screenshot coordinate mapping.
 */
export declare function requestImageTarget(ref: ImageAttachmentRef, budget: PiImageRequestBudget): ImageRequestTarget;
/**
 * Convert text-only harness history to a synchronous pi-ai Context. Tool
 * result names are recovered from preceding assistant tool calls.
 * @param options - projected request; one-shot system text precedes the leading history prompt.
 * @param images - absent; selects the synchronous conversion.
 * @param onReplayDegrade - forwarded to {@link toPiAssistant} for each assistant message.
 * @param supportsMidConvoSystemMessages - native model capability; otherwise later system text becomes a user-role system-reminder.
 * @param prefixDigests - receives the recorded request-prefix digest of each replayed assistant message that has one.
 * @returns the pi-ai context; `tools` is omitted when the request declares none.
 * @throws {LlmError} `UNSUPPORTED_CONTENT` for images in any history role, including a leading system message.
 */
export declare function toPiContext(options: GenerateOptions, images?: undefined, onReplayDegrade?: (reason: string) => void, supportsMidConvoSystemMessages?: boolean, prefixDigests?: PrefixDigests): PiContext;
/**
 * Convert harness history to a pi-ai Context while resolving durable images.
 * Tool result names are recovered from preceding assistant tool calls. Image
 * occurrences the surface marks offloaded become text placeholders; when the
 * retained occurrences still exceed `maxRequestImages` or their exact base64
 * payload exceeds `maxRequestImageBytes`, the call fails with
 * `IMAGE_OFFLOAD_REQUIRED` naming how many more oldest occurrences must be
 * offloaded, rounded up to `imageOffloadCountQuantum` for a count overflow.
 * @param options - projected request; one-shot system text precedes the leading history prompt.
 * @param images - attachment provider, current path resolver, and request limits.
 * @param onReplayDegrade - forwarded to {@link toPiAssistant} for each assistant message.
 * @param supportsMidConvoSystemMessages - native model capability; otherwise later system text becomes a user-role system-reminder.
 * @param prefixDigests - receives the recorded request-prefix digest of each replayed assistant message that has one.
 * @returns the asynchronously resolved pi-ai context.
 */
export declare function toPiContext(options: GenerateOptions, images: PiImageRequestContext, onReplayDegrade?: (reason: string) => void, supportsMidConvoSystemMessages?: boolean, prefixDigests?: PrefixDigests): Promise<PiContext>;
//# sourceMappingURL=context.d.ts.map