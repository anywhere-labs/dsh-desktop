/**
 * Browser half of the browse directory-picker backend: fills ui-workspace's
 * three directory-flow holes with the in-app Select Workspace Directory dialog
 * (figma `Harness` 813-23126 family), driving the node half's
 * `directoryPicker/list`/`directoryPicker/createDirectory` primitives.
 * Mounting this package therefore composes both sides of the browse
 * interaction with one cordis.yml row; no client code branches on a
 * capability kind. The dialog's copy is locale-registered here — the flow
 * package owns its own strings.
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
/** Required services (cordis fiber inject): the slot registry, workspace UI service, and locale. */
export declare const inject: string[];
/**
 * Client plugin body: register the dialog's dictionaries and the browse flow
 * into all three directory-flow holes through `slots.inject()` because the
 * ui-workspace declarations may activate later or be replaced.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map