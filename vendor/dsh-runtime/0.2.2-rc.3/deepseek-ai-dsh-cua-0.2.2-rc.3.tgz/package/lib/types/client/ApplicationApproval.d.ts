/** Computer Use presentation over the existing pending-question answer channel. */
import type { PropsLocale, PropsRenderFactories, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ComposerChainProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
/**
 * Select application access and mouse-control questions; other interactions keep their renderer.
 * @param pending The session's currently elected interaction.
 * @returns Its Computer Use decision, or null for another interaction.
 */
export declare function selectApplicationApproval(pending: ComposerChainProps['pendingInteraction']): {
    pending: import("@deepseek-ai/dsh-client-ui-user-questions/client").PendingQuestion;
    item: import("@deepseek-ai/dsh-user-questions/types").AskUserQuestionItem;
    intent: {
        kind: "approval";
        approve: string;
        reject: string;
        always?: string;
        subject?: {
            name: string;
            icon?: string;
        };
        display?: {
            question: {
                en: string;
                [locale: string]: string;
            };
            detail?: {
                en: string;
                [locale: string]: string;
            };
            approve?: {
                en: string;
                [locale: string]: string;
            };
        };
    };
} | null;
/** Composer bindings for a Computer Use decision and caller-owned localized copy. */
export type ApplicationApprovalProps = PropsRuntime<'conversation.composer'> & PropsRenderFactories & PropsLocale<'cuaPermissions'> & {
    matched: NonNullable<ReturnType<typeof selectApplicationApproval>>;
    resolveText: (text: {
        en: string;
        [locale: string]: string;
    }) => string;
};
/**
 * Render the shared approval card without creating another request or answer lifetime.
 * @param props The existing pending question and renderer bindings.
 * @returns Fixed actions with the provider's original answer labels.
 */
export declare function ApplicationApproval({ matched: { pending, item, intent }, resolveText, renderFactorySlot, t }: ApplicationApprovalProps): import("react").ReactNode;
//# sourceMappingURL=ApplicationApproval.d.ts.map