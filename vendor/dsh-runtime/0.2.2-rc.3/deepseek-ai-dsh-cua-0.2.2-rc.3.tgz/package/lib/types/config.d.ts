/** Schemastery fields for platform-specific native CUA configuration. */
import Schema from '@deepseek-ai/schemastery';
/** Shared configuration fields extended by native platform providers. */
export declare const CuaConfigFields: {
    requireSystemPointerApproval: Schema<boolean, boolean, "defined">;
    agentPreset: Schema<string | false, string | false, "defined">;
    allowedApps: Schema<({
        id?: string | null;
        name?: string | null;
        executablePath?: string | null;
    } & import("@deepseek-ai/cosmokit").Dict)[], Schemastery.ObjectT<NoInfer<{
        id: Schema<string, string, "defined">;
        name: Schema<string, string, "defined">;
        executablePath: Schema<string, string, "plain">;
    }>>[], "defined">;
    helperPath: Schema<string, string, "plain">;
    buildTimeoutMs: Schema<number, number, "defined">;
    timeoutMs: Schema<number, number, "defined">;
    connectTimeoutMs: Schema<number, number, "defined">;
    screenshotTimeoutMs: Schema<number, number, "defined">;
    axTimeoutMs: Schema<number, number, "defined">;
    maxAppMatches: Schema<number, number, "defined">;
    maxClipboardBytes: Schema<number, number, "defined">;
    pasteReadTimeoutMs: Schema<number, number, "defined">;
    maxRequestBytes: Schema<number, number, "defined">;
    dragDurationMs: Schema<number, number, "defined">;
    maxClickHoldMs: Schema<number, number, "defined">;
    dragSteps: Schema<number, number, "defined">;
    maxResponseBytes: Schema<number, number, "defined">;
    textEventIntervalMs: Schema<number, number, "defined">;
    graceMs: Schema<number, number, "defined">;
    maxElements: Schema<number, number, "defined">;
    maxDepth: Schema<number, number, "defined">;
};
//# sourceMappingURL=config.d.ts.map