/** Session approval for explicit physical pointer moves, shared by capable CUA providers. */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
/** Access is scoped to the live Session and never grants application access. */
export declare class MouseControl {
    private readonly ctx;
    private readonly requireApproval;
    private readonly decisions;
    constructor(ctx: Context, requireApproval: boolean);
    /**
     * Select the per-call route and any approval required before dispatch.
     * @param agent Agent owning the live Session.
     * @param requested Whether the caller explicitly requested system-pointer movement.
     * @returns Native pointer mode and an optional preparation that must succeed before input.
     */
    resolve(agent: Agent, requested: boolean): {
        useSystemPointer: boolean;
        prepare?: (signal: AbortSignal) => Promise<void>;
    };
    private approve;
}
//# sourceMappingURL=mouse-control.d.ts.map