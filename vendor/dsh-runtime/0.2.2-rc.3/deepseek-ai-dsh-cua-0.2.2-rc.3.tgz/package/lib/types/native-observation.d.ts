/** Host-only decoding of native window observations before tool results reach a caller. */
import { z } from 'zod';
import type { JsonValue } from '@deepseek-ai/dsh-util-values';
import type { CuaCoordinates } from './coordinates.ts';
import { StateResult, WindowsResult } from './protocol.ts';
import type { CuaOperation } from './types.ts';
/**
 * Keep geometry for every live window but return only discovered or explicitly selected windows.
 * @param request - Authorized observation and its expected app/window identity.
 * @param result - Untrusted native reply, including any cache-only records.
 * @param coordinates - The calling Agent's screenshot and coordinate cache.
 * @returns Public observation with private fields removed.
 */
export declare function observeNativeWindows(request: Extract<CuaOperation, {
    method: 'getState' | 'listWindows';
}>, result: JsonValue, coordinates: CuaCoordinates): z.output<typeof WindowsResult> | z.output<typeof StateResult>;
//# sourceMappingURL=native-observation.d.ts.map