/**
 * In-memory view of one DeepSeek chat export ZIP archive. Opening reads the
 * central directory; a streaming pass inflates only the entries it is asked
 * for, and a by-name read serves a targeted fetch of one entry.
 */
import type { DeepseekChatImportFailureReason } from './types.ts';
/** One entry the archive directory lists. */
export interface ExportEntryInfo {
    /** Entry name, such as `manifest.json` or `chat_sessions/{id}.json`. */
    readonly name: string;
    /** Compressed size, in bytes. */
    readonly size: number;
    /** Declared uncompressed size, in bytes. */
    readonly originalSize: number;
    /** ZIP compression method: 0 is stored, 8 is deflated. */
    readonly compression: number;
}
/** How one streaming pass handles each entry it is shown. */
export interface ExportStreamHandler {
    /**
     * Decide whether one entry's bytes are needed, before it is inflated.
     * @param entry - directory record of the entry.
     * @returns true to deliver the bytes to {@link ExportStreamHandler.entry}, false to skip the entry.
     */
    select(entry: ExportEntryInfo): boolean;
    /**
     * Consume one entry `select` accepted.
     * @param entry - the accepted entry's directory record.
     * @param data - complete uncompressed bytes.
     * @returns completes when the entry is handled; the pass waits for it before delivering the next entry.
     */
    entry(entry: ExportEntryInfo, data: Uint8Array): Promise<void>;
    /**
     * Report one entry the pass could not deliver; the pass continues with the next entry.
     * @param entry - the rejected entry's directory record.
     * @param error - the failed size check or the inflation failure.
     */
    reject(entry: ExportEntryInfo, error: ExportEntryError): void;
}
/** The upload cannot be imported as a whole; `reason` selects the user-facing explanation. */
export declare class ExportSourceError extends Error {
    readonly reason: DeepseekChatImportFailureReason;
    readonly name = "ExportSourceError";
    /**
     * @param reason - failure category shown to the user.
     * @param message - English diagnostic.
     * @param options - underlying cause.
     */
    constructor(reason: DeepseekChatImportFailureReason, message: string, options?: ErrorOptions);
}
/** One entry cannot be read: it exceeds the per-entry byte limit, or its data is damaged. */
export declare class ExportEntryError extends Error {
    readonly oversized: boolean;
    readonly name = "ExportEntryError";
    /**
     * @param message - English diagnostic naming the entry.
     * @param oversized - true when the entry declares or stores more bytes than the per-entry limit, false when it is damaged.
     * @param options - underlying cause.
     */
    constructor(message: string, oversized: boolean, options?: ErrorOptions);
}
/** Read-only view of one export archive. */
export interface ExportArchive {
    /**
     * Run one streaming pass over the archive in entry order. Only the entries
     * `handler.select` accepts are inflated, one at a time; the pass waits for
     * each accepted entry to be handled and yields between archive chunks.
     *
     * Inflation is synchronous, so one archive chunk's output is produced before
     * the pass yields again. An entry that declares a small size but inflates
     * past the per-entry limit keeps inflating until the entry ends: the limit
     * then stops the bytes being kept, not the work being done.
     * @param handler - per-entry decision, consumption, and rejection report.
     * @param signal - cancellation, checked between chunks.
     * @returns completes after the last entry.
     * @throws {ExportSourceError} `unreadable-archive` when a data record is not in the directory
     * or the bytes cannot be read as a ZIP archive.
     */
    stream(handler: ExportStreamHandler, signal: AbortSignal): Promise<void>;
    /**
     * Decompress one entry by name. Each call re-parses the whole central
     * directory before inflating the entry, so a caller that needs several
     * entries pays one directory scan per call; {@link ExportArchive.stream} is
     * the linear alternative. Returns at most the size the entry declares: an
     * entry that inflates to more is truncated to that size, while
     * {@link ExportArchive.stream} reports the same condition as a size failure.
     * @param entry - archive name, such as `manifest.json` or a conversation `export_path`.
     * @param signal - cancellation; aborting terminates the decompression.
     * @returns the entry bytes, or undefined when the archive has no such entry.
     * @throws {ExportEntryError} when the entry declares or stores more than the per-entry byte limit,
     * declares a stored size other than the bytes it holds, or cannot be inflated.
     */
    read(entry: string, signal: AbortSignal): Promise<Uint8Array | undefined>;
}
/**
 * Open an export archive held in memory. Opening reads only the ZIP central
 * directory; entries are inflated when a pass or a read asks for them.
 * @param archive - complete ZIP bytes.
 * @param maxEntryBytes - largest declared uncompressed size of one entry.
 * @param signal - cancellation.
 * @returns a reader over the archive.
 * @throws {ExportSourceError} `unreadable-archive` when the bytes are not a readable ZIP archive
 * or carry more than one entry with the same name.
 */
export declare function openExportArchive(archive: Uint8Array, maxEntryBytes: number, signal: AbortSignal): Promise<ExportArchive>;
//# sourceMappingURL=archive.d.ts.map