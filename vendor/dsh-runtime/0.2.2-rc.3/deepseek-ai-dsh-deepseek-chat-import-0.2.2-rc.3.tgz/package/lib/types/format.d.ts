/**
 * JSON validation for the DeepSeek chat export (`export_format_version: 3`).
 *
 * Only fields the importer reads are validated. Fragment types the importer
 * does not map are accepted unchecked so later exporter additions do not
 * reject otherwise importable conversations.
 */
import { z } from 'zod';
/** The only `manifest.json` format version this importer reads. */
export declare const SUPPORTED_EXPORT_FORMAT_VERSION = 3;
/** `manifest.json`, the first archive entry. */
export declare const exportManifest: z.ZodObject<{
    export_format_version: z.ZodNumber;
}, z.core.$strip>;
/**
 * `chat_session_index.json`: one row per conversation, carrying the update
 * order the import selects by. The index's title, pinned flag, and message
 * count are not read and stay unvalidated.
 */
export declare const exportSessionIndex: z.ZodArray<z.ZodObject<{
    id: z.ZodString;
    inserted_at: z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>;
    updated_at: z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>;
}, z.core.$strip>>;
/** One validated conversation index row. */
export type ExportSessionIndexRow = z.infer<typeof exportSessionIndex>[number];
declare const fragmentEnvelope: z.ZodObject<{
    type: z.ZodString;
}, z.core.$loose>;
declare const exportMessage: z.ZodObject<{
    id: z.ZodNumber;
    parent_id: z.ZodNullable<z.ZodNumber>;
    role: z.ZodEnum<{
        USER: "USER";
        ASSISTANT: "ASSISTANT";
    }>;
    status: z.ZodString;
    inserted_at: z.ZodString;
    fragments: z.ZodArray<z.ZodObject<{
        type: z.ZodString;
    }, z.core.$loose>>;
}, z.core.$strip>;
/**
 * `chat_sessions/{id}.json`: one conversation and its complete message tree.
 * `current_message_id` may be absent or null; branch selection then falls back
 * to the greatest message id.
 */
export declare const exportSessionFile: z.ZodObject<{
    id: z.ZodString;
    title: z.ZodNullable<z.ZodString>;
    current_message_id: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    inserted_at: z.ZodString;
    messages: z.ZodArray<z.ZodObject<{
        id: z.ZodNumber;
        parent_id: z.ZodNullable<z.ZodNumber>;
        role: z.ZodEnum<{
            USER: "USER";
            ASSISTANT: "ASSISTANT";
        }>;
        status: z.ZodString;
        inserted_at: z.ZodString;
        fragments: z.ZodArray<z.ZodObject<{
            type: z.ZodString;
        }, z.core.$loose>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
/** One validated conversation file. */
export type ExportSessionFile = z.infer<typeof exportSessionFile>;
/** One validated message-tree node. */
export type ExportMessage = z.infer<typeof exportMessage>;
/** One fragment before type-specific validation. */
export type ExportFragmentEnvelope = z.infer<typeof fragmentEnvelope>;
declare const searchResult: z.ZodObject<{
    url: z.ZodString;
    title: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    snippet: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    published_at: z.ZodOptional<z.ZodNullable<z.ZodString>>;
}, z.core.$strip>;
declare const fileEntry: z.ZodObject<{
    id: z.ZodString;
    file_name: z.ZodString;
    file_size: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
    is_image: z.ZodBoolean;
    export_path: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
declare const knownFragment: z.ZodDiscriminatedUnion<[z.ZodObject<{
    type: z.ZodLiteral<"REQUEST">;
    content: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"RESPONSE">;
    content: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"THINK">;
    content: z.ZodString;
    elapsed_secs: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"TEMPLATE_RESPONSE">;
    content: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"TOOL_SEARCH">;
    queries: z.ZodArray<z.ZodString>;
    results: z.ZodArray<z.ZodObject<{
        url: z.ZodString;
        title: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        snippet: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        published_at: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strip>>;
    status: z.ZodOptional<z.ZodString>;
    stage_id: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"TOOL_OPEN">;
    status: z.ZodString;
    url: z.ZodNullable<z.ZodString>;
    title: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    stage_id: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"TOOL_FIND">;
    status: z.ZodString;
    pattern: z.ZodOptional<z.ZodString>;
    stage_id: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"READ_LINK">;
    results: z.ZodArray<z.ZodObject<{
        url: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        title: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strip>>;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"TOOL_IMAGE_SEARCH">;
    status: z.ZodString;
    results: z.ZodArray<z.ZodUnknown>;
    stage_id: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"PARTIAL_FILE_READ">;
    ratio: z.ZodNumber;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"TIP">;
    content: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    type: z.ZodLiteral<"FILE">;
    files: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        file_name: z.ZodString;
        file_size: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
        is_image: z.ZodBoolean;
        export_path: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>;
}, z.core.$strip>], "type">;
/** A fragment type the importer maps, with its fields validated. */
export type KnownFragment = z.infer<typeof knownFragment>;
/** One `FILE` fragment entry. */
export type ExportFileEntry = z.infer<typeof fileEntry>;
/** One `TOOL_SEARCH` result. */
export type ExportSearchResult = z.infer<typeof searchResult>;
/**
 * Validate one fragment whose type the importer maps.
 * @param fragment - fragment envelope from a validated message.
 * @returns the typed fragment, or undefined for a type the importer ignores.
 * @throws {z.ZodError} when a mapped fragment type lacks a required field.
 */
export declare function parseKnownFragment(fragment: ExportFragmentEnvelope): KnownFragment | undefined;
/**
 * Parse an export timestamp: an RFC 3339 UTC string with 0, 3, 6, or 9 fractional digits.
 * @param value - timestamp text from the export.
 * @returns epoch milliseconds, or undefined when the text is not a valid timestamp.
 */
export declare function parseExportTime(value: string): number | undefined;
export {};
//# sourceMappingURL=format.d.ts.map