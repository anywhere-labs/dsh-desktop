/**
 * Import of a complete DeepSeek chat export held in memory into a
 * caller-chosen Workspace, one conversation at a time.
 *
 * `chat_session_index.json` selects the conversations to import. One streaming
 * pass then stores the images of every chosen conversation and a second
 * converts and writes each chosen conversation as its entry arrives. Nothing
 * is inflated for a conversation the index did not choose.
 */
import type { ImageAttachmentRef, SaveImageAttachment } from '@deepseek-ai/dsh-attachment';
import { SessionId, SessionLogOffset } from '@deepseek-ai/dsh-session';
import type { SessionEvent, SessionHeader } from '@deepseek-ai/dsh-session';
import type { SessionHandle } from '@deepseek-ai/dsh-session-persistence';
import type { DeepseekChatImportResult } from './types.ts';
/** Services and inputs one import uses. */
export interface DeepseekChatImportDependencies {
    /** Durable store receiving each imported Session; a `SessionPersistence` satisfies it. */
    readonly persistence: {
        create(header: SessionHeader, options: {
            signal: AbortSignal;
        }): Promise<Pick<SessionHandle, 'append' | 'flush' | 'close'>>;
    };
    /** Optional Session-list projection cache refreshed after each write. */
    readonly projectionCache?: {
        coldSnapshot(header: SessionHeader, inheritedEventCount: SessionLogOffset, events: readonly SessionEvent[]): unknown;
    } | undefined;
    /** Optional image store; without it, exported images become synthetic file cards. */
    readonly attachments?: {
        saveImage(input: SaveImageAttachment): Promise<ImageAttachmentRef>;
    } | undefined;
    /**
     * Whether the target Workspace is still registered; checked before each write.
     * @param workspaceId - id of the target Workspace.
     * @returns false once the Workspace was removed.
     */
    readonly workspaceRegistered: (workspaceId: string) => boolean;
    /** Mint unique Session, message, and tool-call ids. */
    readonly createId: () => string;
    /** Diagnostic for each conversation that was not imported and each image left as a synthetic file card. */
    readonly warn: (message: string) => void;
}
/** The Workspace receiving the imported Sessions; a registry `Workspace` satisfies it. */
export interface DeepseekChatImportWorkspace {
    /** Workspace id reported in the result. */
    readonly id: string;
    /** Canonical existing directory, used as every imported Session's working directory. */
    readonly path: string;
    /**
     * Record one stored Session as a member.
     * @param sessionId - Session whose header cwd is {@link path}.
     */
    attachSession(sessionId: SessionId): Promise<void>;
}
/** Deployment limits of one import. */
export interface DeepseekChatImportLimits {
    /** Maximum number of Sessions to write. */
    readonly maxSessions: number;
    /** Largest declared uncompressed size of one archive entry. */
    readonly maxEntryBytes: number;
    /** Largest UTF-8 size of an imported title. */
    readonly maxTitleBytes: number;
}
/** One import request. */
export interface DeepseekChatImportRequest {
    /** Complete export ZIP bytes. */
    readonly archive: Uint8Array;
    /** Workspace receiving the Sessions. */
    readonly workspace: DeepseekChatImportWorkspace;
    /** Session count and size limits. */
    readonly limits: DeepseekChatImportLimits;
    /**
     * Progress after the selection and after each imported Session.
     * @param done - Sessions imported so far.
     * @param total - Sessions the import tries to write.
     */
    readonly onProgress: (done: number, total: number) => void;
}
/**
 * Import the conversations selected by the export index into a Workspace.
 *
 * Failures detected before the passes (an unreadable archive, a missing or
 * unreadable manifest or index, an oversized manifest or index entry, no
 * conversation) write nothing; an archive whose structure breaks during a pass
 * fails with `unreadable-archive` after the Sessions delivered before the break
 * were written. One streaming pass stores the images of every chosen
 * conversation before any conversation is parsed; a second converts each chosen
 * conversation as its entry arrives and looks the stored references up. Each
 * converted conversation is seed-validated with `Session.create` before it is
 * written; a conversation that fails is reported in `skipped`, the next older
 * conversation the index lists takes its place, and the others continue. That
 * replacement is read by name, so `ExportArchive.read` re-parses the central
 * directory once for it and a further image pass collects its images; neither
 * cost grows with the number of images.
 * @param deps - storage, Workspace, and id services.
 * @param request - archive bytes, target Workspace, limits, and progress callback.
 * @param signal - cancellation, checked between steps; written Sessions remain.
 * @returns the import summary.
 * @throws {ExportSourceError} for an archive-level failure, or `workspace-not-found` when the Workspace is removed during the import.
 */
export declare function importDeepseekChatExport(deps: DeepseekChatImportDependencies, request: DeepseekChatImportRequest, signal: AbortSignal): Promise<DeepseekChatImportResult>;
//# sourceMappingURL=importer.d.ts.map