/**
 * Review controls of the changes toolbar: the lens that keeps the files of one review layer, as a full-width
 * radio group above the file tree or as a menu where no tree shows; the switch that hides test files; and the
 * share of shown files the reader marked viewed. The thread list shares the segmented radio group.
 */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ChangesLens } from './changes-store.ts';
import type { NS } from './locales.ts';
/** Lenses in display order. */
export declare const LENSES: readonly ChangesLens[];
/** Props shared by both forms of the lens. */
export interface LensProps extends PropsLocale<typeof NS> {
    /** The lens shown. */
    readonly lens: ChangesLens;
    /** Files each lens keeps among the files the switch leaves. */
    readonly counts: Readonly<Record<ChangesLens, number>>;
    /** Whether test files hide, which disables the `test` lens. */
    readonly hideTests: boolean;
    /** Show another lens. */
    readonly choose: (lens: ChangesLens) => void;
}
/** One segment of a {@link SegmentedChoice}. */
export interface Segment<Value extends string> {
    /** Value the segment chooses. */
    readonly value: Value;
    /** Localized label. */
    readonly label: string;
    /** Count shown after the label, or null for none. */
    readonly count: number | null;
    /** Localized hover text of a disabled segment, or null for an enabled one. */
    readonly disabledTip: string | null;
}
/**
 * Render a radio group whose segments share its width, each with a count after its label; arrow keys, Home, and End
 * move between enabled segments.
 * @param props - the segments, the chosen value, the choose action, and the group's localized accessible name.
 * @returns the radio group.
 */
export declare function SegmentedChoice<Value extends string>({ segments, value, choose, label }: {
    readonly segments: readonly Segment<Value>[];
    readonly value: Value;
    readonly choose: (value: Value) => void;
    readonly label: string;
}): ReactNode;
/**
 * Render the lens as a radio group whose segments share its width.
 * @param props - the lens, its counts, whether test files hide, the choose action, and copy.
 * @returns the radio group.
 */
export declare function LensControl({ lens, counts, hideTests, choose, t }: LensProps): ReactNode;
/**
 * Render the lens as a menu button, for a toolbar without the file tree beside it.
 * @param props - the lens, its counts, whether test files hide, the choose action, copy, and whether the owning tab is visible.
 * @returns the trigger with its portalled menu.
 */
export declare function LensMenu({ lens, counts, hideTests, choose, visible, t }: LensProps & {
    readonly visible: boolean;
}): ReactNode;
/**
 * Render the switch that hides test files, with its label beside it where the toolbar has room.
 * @param props - whether test files hide, the toggle action, and copy.
 * @returns the switch and its label.
 */
export declare function HideTestsSwitch({ hidden, toggle, t }: PropsLocale<typeof NS> & {
    readonly hidden: boolean;
    readonly toggle: () => void;
}): ReactNode;
/**
 * Render how many of the shown files the reader marked viewed: a ring filled to the viewed share, then a label, or the
 * bare count that a narrow toolbar shows instead (`data-forge-progress` names each form for the toolbar's styles).
 * @param props - the viewed and shown file counts, and copy.
 * @returns the progress, or nothing without shown files.
 */
export declare function ViewedProgress({ viewed, total, t }: PropsLocale<typeof NS> & {
    readonly viewed: number;
    readonly total: number;
}): ReactNode;
//# sourceMappingURL=ReviewControls.d.ts.map