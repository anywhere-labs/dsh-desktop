/** Centered review submission with a summary, decision, and pending-comment count, and the discarding of a pending review. */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ForgePendingReview } from '@deepseek-ai/dsh-experimental-forge/types';
import type { ReviewQueue } from './review-queue.ts';
import type { NS } from './locales.ts';
/**
 * Submit a review independently of the diff scroll position; comments remain at their code locations. With a pending
 * review on the code host, the review holds its comments, and comment drafts kept in the browser must leave first.
 * @param props - durable queue, current head, the pending review, submission outcome, and modal actions.
 * @returns a portalled modal with keyboard focus ownership.
 */
export declare function SubmitReview({ queue, url, headSha, pending, own, busy, error, submit, discard, close, check, reconcile, t, }: PropsLocale<typeof NS> & {
    readonly queue: ReviewQueue;
    readonly url: string;
    readonly headSha: string;
    /** The signed-in user's pending review on the code host, or null without one. */
    readonly pending: ForgePendingReview | null;
    /** Whether the signed-in user authored the change request, which the code host lets them only comment on. */
    readonly own: boolean;
    readonly busy: boolean;
    readonly error: string | null;
    readonly submit: () => void;
    /** Discard the pending review, or undefined without one. */
    readonly discard: (() => void) | undefined;
    readonly close: () => void;
    readonly check: () => void;
    readonly reconcile: () => void;
}): ReactNode;
//# sourceMappingURL=SubmitReview.d.ts.map