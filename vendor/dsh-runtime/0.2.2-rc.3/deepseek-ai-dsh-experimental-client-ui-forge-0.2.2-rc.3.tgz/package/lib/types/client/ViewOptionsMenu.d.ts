/** The changes toolbar's More menu, which holds the view controls a narrow toolbar folds out of its row. */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { NS } from './locales.ts';
/** Toolbar state and actions the menu repeats. */
export interface ViewOptions {
    /** Whether any shown file is expanded, so the expansion row collapses them all. */
    readonly anyExpanded: boolean;
    /** Whether any file shows, so the expansion row has files to change. */
    readonly hasFiles: boolean;
    readonly toggleExpansion: () => void;
    readonly split: boolean;
    readonly toggleSplit: () => void;
    readonly wrap: boolean;
    readonly toggleWrap: () => void;
    /** Whether test files hide, or undefined when the toolbar offers no test switch. */
    readonly hideTests: boolean | undefined;
    readonly toggleTests: () => void;
    readonly refresh: () => void;
}
/**
 * Render the More button and its menu, which lists the controls of the toolbar's fold level when it opens (see
 * `observeToolbarFold`); the toolbar's styles hide the button while nothing folds.
 * @param props - the toolbar state and actions, whether the owning tab is visible, and copy.
 * @returns the button and its portalled menu.
 */
export declare function ViewOptionsMenu({ options, visible, t }: PropsLocale<typeof NS> & {
    readonly options: ViewOptions;
    readonly visible: boolean;
}): ReactNode;
//# sourceMappingURL=ViewOptionsMenu.d.ts.map