/** Reads the review threads of the change request a changes view shows and places them in its files. */
import type { ForgeReviewData, ForgeReviewThread } from '@deepseek-ai/dsh-experimental-forge/types';
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { LineThread } from './ReviewThreads.tsx';
import { type ThreadPlace, type ThreadView } from './review-threads.ts';
/** What the changes view knows about its change request when it reads threads. */
export interface ThreadReadInput {
    /** Whether the view is visible; a hidden view reads nothing. */
    readonly visible: boolean;
    /** Binding URL of the change request, or null for local changes. */
    readonly url: string | null;
    /** Head commit of the latest status, or null before one. */
    readonly head: string | null;
    /** Update time of the latest status, or null before one. */
    readonly updatedAt: string | null;
    /** Epoch milliseconds of the latest status, so every status asks the Host again; the Host answers from memory until the threads age. */
    readonly statusAt: number | null;
    /** Changes on each refresh. */
    readonly attempt: number;
    /** Changes after each write that may have changed the threads, which the Host no longer answers from memory. */
    readonly revision: number;
    /** Read the threads at a head commit; `fresh` skips the threads the host keeps. */
    readonly read: (url: string, headSha: string, fresh: boolean, signal: AbortSignal) => Promise<RemoteResult<ForgeReviewData>>;
}
/** The last threads read and why the latest read failed. */
export interface ThreadReadState {
    /** Threads of the last successful read for the URL, at any head, or null. */
    readonly review: ForgeReviewData | null;
    /** Message of the latest failed read, or null, also when the provider cannot read reviews. */
    readonly failure: string | null;
}
/**
 * Read the threads at the head of each status while the view is visible. A read refused because the head moved
 * keeps the previous threads; the next status names the new head and reads again. The first read after a refresh
 * asks the host to skip the threads it keeps, which a resolved thread leaves unchanged.
 * @param input - the change request and the reader.
 * @returns the last threads and the latest failure.
 */
export declare function useThreadRead(input: ThreadReadInput): ThreadReadState;
/** Threads of one file grouped by where they show, and how many of them are unresolved. */
export interface PlacedFileThreads {
    readonly lines: readonly LineThread[];
    readonly file: readonly ForgeReviewThread[];
    readonly outdated: readonly ForgeReviewThread[];
    readonly unresolved: number;
}
/** One thread and where the shown changes place it. */
export interface PlacedThread {
    readonly thread: ForgeReviewThread;
    readonly place: ThreadPlace;
}
/** Every thread with its place and the threads of each file. */
export interface PlacedThreads {
    /** Every thread in host order with its place. */
    readonly entries: readonly PlacedThread[];
    /** Threads of each path. */
    readonly files: ReadonlyMap<string, PlacedFileThreads>;
    /** Unresolved threads by path, for the file tree. */
    readonly unresolved: ReadonlyMap<string, number>;
}
/**
 * Place the threads of a review in the shown changes.
 * @param review - threads read at the head of the latest status, or null.
 * @param view - the shown changes, or null before they load.
 * @returns places, per-file groups, and unresolved counts.
 */
export declare function usePlacedThreads(review: ForgeReviewData | null, view: ThreadView | null): PlacedThreads;
//# sourceMappingURL=thread-state.d.ts.map