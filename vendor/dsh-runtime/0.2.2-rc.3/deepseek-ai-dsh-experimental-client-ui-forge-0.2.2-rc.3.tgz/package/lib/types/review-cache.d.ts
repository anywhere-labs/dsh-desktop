/**
 * Review threads of change requests kept in memory, so the changes view reads them from the code host again only
 * after the change request's head or update time changes, the kept threads reach their age limit, or a review write drops them.
 */
import type { ChangeRequestKey, ForgeReviewData } from '@deepseek-ai/dsh-experimental-forge';
/**
 * One read of review threads per change request, bounded by age and by the total UTF-8 size of the kept reads as
 * JSON; the least recently read change request leaves first. A read that started before a drop of any change request
 * is not kept, so threads read before a write never replace the drop.
 */
export declare class ReviewCache {
    private readonly maxBytes;
    private readonly maxAgeMs;
    private readonly entries;
    private bytes;
    /** Number of drops so far. */
    private drops;
    /**
     * @param maxBytes - most UTF-8 bytes kept together; a larger read is not kept.
     * @param maxAgeMs - age in milliseconds at which a kept read is no longer returned.
     */
    constructor(maxBytes: number, maxAgeMs: number);
    /**
     * Read the threads kept for a change request at a version while they are younger than the age limit, marking them
     * the most recently read.
     * @param key - the change request.
     * @param version - head commit and update time the reader needs.
     * @param now - current epoch milliseconds.
     * @returns the threads, or undefined when none are kept at that version or they reached the age limit.
     */
    get(key: ChangeRequestKey, version: string, now: number): ForgeReviewData | undefined;
    /**
     * Name the cache's state when a read starts, for {@link ReviewCache.set}.
     * @returns the token of the read.
     */
    token(): number;
    /**
     * Keep a read in place of the change request's earlier one, then drop the least recently read change requests
     * until the rest fit within `maxBytes`. A read whose token a drop outdated is not kept.
     * @param key - the change request.
     * @param version - head commit and update time the threads were read at.
     * @param review - the threads.
     * @param readAt - epoch milliseconds when the read started.
     * @param token - what {@link ReviewCache.token} returned when the read started.
     */
    set(key: ChangeRequestKey, version: string, review: ForgeReviewData, readAt: number, token: number): void;
    /**
     * Forget the threads kept for a change request, and every read in flight, after a write changed them.
     * @param key - the change request.
     */
    drop(key: ChangeRequestKey): void;
    private forget;
}
//# sourceMappingURL=review-cache.d.ts.map