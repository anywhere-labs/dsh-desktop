/**
 * Surface a viewer-facing notice when a plugin calls an owner-only route.
 *
 * A plugin's RPC error may be swallowed by that plugin's own UI. This page-level notice names the
 * plugin once per page so the reader learns why a panel is empty; it never retries or changes the
 * call itself.
 * @module @deepseek-ai/dsh-experimental-liveshare/src/client/viewer-plugin-warning
 */
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client';
import type { ViewerTranslate } from './locales.ts';
/**
 * Announce one plugin at most once on this page.
 * @param document - Page document that owns the notice.
 * @param plugin - Plugin namespace.
 * @param t - Viewer copy.
 */
export declare function reportViewerPluginWarning(document: Document, plugin: string, t: ViewerTranslate): void;
/**
 * Observe same-origin plugin RPC responses and name each failing plugin once.
 * @param document - Page document that owns the notice.
 * @param t - Viewer copy.
 * @returns Disposer restoring the global fetch and removing notices.
 */
export declare function installViewerPluginWarnings(document: Document, t: ViewerTranslate): () => void;
/**
 * Observe the Connection's logical RPC calls, which browser transports carry outside `fetch`.
 * @param connection - Viewer page Connection.
 * @param document - Page document that owns the notice.
 * @param t - Viewer copy.
 * @returns Disposer restoring the original call.
 */
export declare function installViewerRpcWarnings(connection: {
    readonly rpc?: ConnectionHandle['rpc'];
}, document: Document, t: ViewerTranslate): () => void;
//# sourceMappingURL=viewer-plugin-warning.d.ts.map