import type { Duplex } from 'node:stream';
import type { PtcProgramFormat } from '@deepseek-ai/dsh-ptc-runtime';
import type { PatchableStream } from './bootstrap.ts';
import type { ProgramImportHandler } from './evaluators/types.ts';
/** Process-owned environment, output and directory control consumed by the child. */
export interface ProgramProcess {
    env: NodeJS.ProcessEnv;
    stdout: PatchableStream;
    stderr: PatchableStream;
    exitCode?: string | number | null | undefined;
    chdir(directory: string): void;
}
/**
 * Serve sequential evaluations until the host closes the control channel.
 * @param stream - Inherited, already-adopted control endpoint.
 * @param maxMessageBytes - Maximum control message and queued output bytes.
 * @param processState - Native child process; structural test doubles do not replace Node's globals or built-in exports.
 * @param defaultFormat - Syntax used by installed bootstraps when the host omits it.
 * @param importHandler - Runner-local import decisions; omission retains native loading.
 * @returns After control closure and evaluator cleanup.
 */
export declare function runNodeMain(stream: Duplex, maxMessageBytes: number, processState: ProgramProcess, defaultFormat?: PtcProgramFormat, importHandler?: ProgramImportHandler): Promise<void>;
//# sourceMappingURL=process.d.ts.map