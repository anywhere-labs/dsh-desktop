/** Terminal registry backend whose sessions are Agent terminals in the Session's sidebar. */
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { AgentTerminalRequest } from '@deepseek-ai/dsh-api-terminal-controller';
import type { SandboxExecutionPolicy } from '@deepseek-ai/dsh-sandbox';
import type { Session } from '@deepseek-ai/dsh-session';
import type { TerminalBackend, TerminalBackendSpawnSpec } from '@deepseek-ai/dsh-terminal';
import type { Config } from './config.ts';
import { PanelTerminalSession } from './session.ts';
import type { PanelTerminal } from './session.ts';
/** Refusal for subagents, whose terminals would not appear where the user is looking. */
export declare const SUBAGENT_REFUSAL = "Subagents cannot open terminals because the user cannot see them; use bash for shell commands instead.";
/** Services the backend reaches for each new terminal. */
export interface PanelBackendServices {
    /** Open an Agent terminal through the Session's terminal controller. */
    readonly open: (agent: Agent, request: AgentTerminalRequest, signal: AbortSignal) => Promise<PanelTerminal>;
    /** Resolve the Session's sandbox policy, as the bash tool does. */
    readonly policy: (session: Session) => SandboxExecutionPolicy;
}
/** Startup thresholds and the bound of the returned startup screen. */
export type StartupOptions = Pick<Config, 'startupSilenceMs' | 'startupTimeoutMs' | 'probeIntervalMs' | 'maxReadBytes'>;
/**
 * Wait until the shell has printed, gone silent and owns the foreground, then render the screen.
 * @param terminal - newly opened Agent terminal.
 * @param options - startup thresholds and screen byte bound.
 * @param signal - cancellation of unpublished setup.
 * @returns the rendered startup screen.
 */
export declare function startup(terminal: PanelTerminal, options: StartupOptions, signal: AbortSignal): Promise<string>;
/** Opens each registry session as a sidebar terminal under the Session's sandbox policy. */
export declare class PanelTerminalBackend implements TerminalBackend {
    private readonly services;
    private readonly config;
    readonly type: string;
    /**
     * @param services - terminal allocation and sandbox policy resolution.
     * @param config - validated plugin configuration.
     */
    constructor(services: PanelBackendServices, config: Config);
    spawn(spec: TerminalBackendSpawnSpec): Promise<PanelTerminalSession>;
}
//# sourceMappingURL=backend.d.ts.map