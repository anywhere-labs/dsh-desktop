/** One sidebar terminal behind the terminal registry: sends, screen reads, signals and release to the person. */
import type { AgentTerminal, WebTerminalInfo } from '@deepseek-ai/dsh-api-terminal-controller';
import type { SandboxExecutionPolicy } from '@deepseek-ai/dsh-sandbox';
import type { SubprocessTerminalForeground } from '@deepseek-ai/dsh-subprocess';
import type { TerminalBackendSession, TerminalReadRequest, TerminalReadResult, TerminalSendOperation, TerminalSendRequest, TerminalSessionStatus, TerminalSignal, TerminalSignalResult } from '@deepseek-ai/dsh-terminal';
/** Refusal the model receives once the person has typed into an Agent terminal. */
export declare const TAKEN_OVER = "The user has taken over this terminal; read it with terminal_read or open a new terminal.";
/** Refusal the model receives once the Session's sandbox policy differs from the one the terminal launched under. */
export declare const POLICY_CHANGED = "The session sandbox settings changed after this terminal opened, so it no longer accepts input; open a new terminal with terminal_open. You can still read, signal or close this one.";
/** The Agent terminal capabilities a session uses. */
export type PanelTerminal = Pick<AgentTerminal, 'pid' | 'info' | 'revision' | 'changed' | 'drain' | 'write' | 'read' | 'mark' | 'inspectForeground' | 'signal' | 'close'>;
/** Thresholds that decide when a send returns, and the byte bound of returned text. */
export interface PanelSendOptions {
    readonly promptSilenceMs: number;
    readonly probeIntervalMs: number;
    readonly idleSilenceMs: number;
    readonly timeoutMs: number;
    readonly maxReadBytes: number;
}
/** The sandbox policy an Agent terminal launched under and the policy its Session resolves now. */
export interface PanelTerminalPolicy {
    readonly launched: SandboxExecutionPolicy;
    readonly current: () => SandboxExecutionPolicy;
}
/**
 * Whether two resolved policies confine commands the same way.
 * @param left - one resolved policy.
 * @param right - the other resolved policy.
 * @returns true when mode, workspace root and extra writable roots match.
 */
export declare function samePolicy(left: SandboxExecutionPolicy, right: SandboxExecutionPolicy): boolean;
/**
 * Read the monotonic clock used for every silence and deadline comparison.
 * @returns milliseconds since an arbitrary origin.
 */
export declare function now(): number;
/**
 * Translate the controller's takeover refusal into the model-facing explanation.
 * @param error - failure from an Agent terminal operation.
 * @returns the error to report.
 */
export declare function modelError(error: unknown): unknown;
/**
 * Project controller process state onto the registry's session status.
 * @param info - current terminal metadata.
 * @returns running, or exited with the shell's exit code when one exists.
 */
export declare function statusOf(info: WebTerminalInfo): TerminalSessionStatus;
/**
 * Inspect the foreground process group, treating an inspection failure as unknown.
 * @param terminal - terminal to inspect.
 * @returns the foreground facts, or undefined when they cannot be observed.
 */
export declare function inspect(terminal: PanelTerminal): Promise<SubprocessTerminalForeground | undefined>;
/**
 * Whether the shell is back at its prompt or the foreground program waits for terminal input.
 * @param terminal - terminal whose top-level process is the shell.
 * @param foreground - inspected foreground facts.
 * @returns true when typing would reach a reader now.
 */
export declare function waitsForInput(terminal: PanelTerminal, foreground: SubprocessTerminalForeground | undefined): boolean;
/**
 * Wait for a revision after `revision`, a delay, or `stop`, whichever comes first.
 * @param terminal - terminal whose changes are awaited.
 * @param revision - revision already observed.
 * @param delayMs - longest wait.
 * @param stop - ends the wait early.
 * @returns whether the terminal changed.
 */
export declare function changedWithin(terminal: PanelTerminal, revision: number, delayMs: number, stop: AbortSignal): Promise<boolean>;
/**
 * Keep the newest UTF-8 bytes of text without splitting a code point.
 * @param text - complete text.
 * @param maxBytes - byte bound.
 * @returns the kept suffix and whether anything was dropped.
 */
export declare function newestBytes(text: string, maxBytes: number): {
    text: string;
    truncated: boolean;
};
/**
 * Registry session over one Agent terminal; closing before takeover ends the terminal, afterwards it only releases it.
 * The shell keeps its launch policy, so a send is refused once the Session resolves a different one.
 */
export declare class PanelTerminalSession implements TerminalBackendSession {
    private readonly terminal;
    readonly motd: string;
    private readonly options;
    private readonly policy;
    private active;
    private closing;
    /**
     * @param terminal - committed Agent terminal.
     * @param motd - rendered screen after shell startup.
     * @param options - send thresholds and byte bound.
     * @param policy - the launch policy and the Session's current policy.
     */
    constructor(terminal: PanelTerminal, motd: string, options: PanelSendOptions, policy: PanelTerminalPolicy);
    /** Top-level process id of the terminal's shell. */
    get pid(): number;
    startSend(request: TerminalSendRequest): TerminalSendOperation;
    read(request: TerminalReadRequest): TerminalReadResult;
    signal(signal: TerminalSignal): Promise<TerminalSignalResult>;
    status(): TerminalSessionStatus;
    close(_reason: string): Promise<void>;
}
//# sourceMappingURL=session.d.ts.map