import type { ReactNode, RefObject } from 'react';
/** Selectable row (optionally with a nested submenu). */
export interface MenuItem {
    id: string;
    label: ReactNode;
    disabled?: boolean;
    /** Effective binding supplied by the command owner; omitted for unbound actions. */
    shortcut?: {
        keys: readonly string[];
        aria?: string | undefined;
    };
    /** Leading icon (figma .Menu_cell gap 8). */
    icon?: ReactNode;
    /** Destructive row: error-colored text/icon and danger hover fill. */
    danger?: boolean;
    /** Child choices opened by hover, focus, click, or ArrowRight; placement follows available space. */
    submenu?: readonly MenuEntry[];
}
/** Hairline between item groups (not selectable). */
export interface MenuSeparator {
    type: 'separator';
    id: string;
}
/** Non-interactive heading row above a group of items. */
export interface MenuLabel {
    type: 'label';
    id: string;
    text: string;
}
/** One primary-menu entry: a row, a separator, or a heading label. */
export type MenuEntry = MenuItem | MenuSeparator | MenuLabel;
/** Props for one component-rendered menu row. */
export interface MenuItemButtonProps {
    /** Visible row label. */
    children: ReactNode;
    /** Effective binding supplied by the command owner; omitted for unbound actions. */
    shortcut?: MenuItem['shortcut'];
    /** Leading icon (figma .Menu_cell gap 8). */
    icon?: ReactNode;
    /** Whether this row identifies the currently displayed page or view. */
    current?: boolean;
    /** Whether the row cannot be activated. */
    disabled?: boolean;
    /**
     * Why the disabled row cannot be activated. The row then stays hoverable and
     * focusable, shows the reason in a tooltip, and exposes it as the row's
     * description; an enabled row ignores it.
     */
    disabledReason?: string | undefined;
    /** Destructive row: error-colored text/icon and danger hover fill. */
    danger?: boolean;
    /**
     * Start a new group: a hairline above this row, the same one a
     * `{ type: 'separator' }` data entry draws. It comes and goes with the row,
     * so a row that renders nothing leaves no stray line; a data separator
     * directly before it draws no second line, and the list's first row draws none.
     */
    separatorBefore?: boolean;
    /** Row activation (click, Enter, or Tab on the focused row). */
    onSelect: () => void;
}
/**
 * Render one `role="menuitem"` row for a {@link Menu} whose rows are
 * components rather than `items` data: the same markup and styling as a data
 * row, so it joins the list's keyboard walk and post-selection focus return
 * without any shared state. Closing the menu stays the owner's decision, as
 * it is for data rows.
 * @param props.children - visible row label.
 * @param props.shortcut - effective key labels and accessible combination.
 * @param props.icon - optional leading icon.
 * @param props.current - whether the row identifies the currently displayed page or view.
 * @param props.disabled - whether the row cannot be activated.
 * @param props.disabledReason - why a disabled row cannot be activated, shown in a tooltip and read as its description.
 * @param props.danger - whether to use the destructive row colors.
 * @param props.separatorBefore - whether this row starts a new group (hairline above it).
 * @param props.onSelect - row activation callback.
 * @returns one menu-item row.
 */
export declare function MenuItemButton({ onSelect, ...props }: MenuItemButtonProps): import("react").JSX.Element;
/**
 * Render an anchored dropdown menu. While the list is open its keys mirror the
 * composer's: Tab settles the focused row — from the trigger, Tab enters the
 * list instead — and Escape or Shift+Tab close it and return focus to the
 * anchor's first button, and selecting a row does the same — the rows unmount
 * with the list. Only a keyboard on the trigger or inside the list is
 * intercepted; Tab presses elsewhere on the page stay the browser's. Escape
 * first returns from a visible child, while ArrowRight enters and ArrowLeft returns.
 * When neither side fits, click or ArrowRight opens a single-panel child page;
 * focus alone retains the parent page.
 * @param props.contextual - cursor positioning, context dismissal, and per-divider icon alignment.
 * @param props.exiting - retain an inert popup during dismissal or replacement fade.
 * @param props.returnFocus - original control captured before asynchronous menu preparation.
 * @param props.isExternalTrigger - recognizes external controls whose pointer presses should not dismiss;
 * omitted, every press outside the anchor and menu panels dismisses.
 * @param props.autoFocus - focus the first item on open; the arrow keys walk the list either way.
 * @param props.open - whether the list is showing (owner-controlled).
 * @param props.anchor - the trigger element (rendered in place).
 * @param props.items - selectable data rows and optional separators (default none; with no `children` either, the list is empty).
 * @param props.submenuBackLabel - localized single-panel return label; omitted uses the caller's
 * parent-row label beside a back arrow, without selecting that row.
 * @param props.selectedId - row shown as selected.
 * @param props.selectedIds - rows shown as selected when a menu contains independent option groups.
 * @param props.onSelect - data-row activation callback (not called for disabled rows or submenu parents that only open children).
 * @param props.onClose - invoked on outside click, Escape, or a window blur
 * that moved focus into an iframe (the only signal a pointerdown inside a
 * cross-origin iframe leaves).
 * @param props.align - list alignment against the anchor (default 'start').
 * @param props.side - open below (`bottom`, default) or above (`top`) the anchor.
 * @param props.portal - render the list into document.body, fixed-positioned
 * with CSS anchor positioning; it follows browser zoom and may exceed the
 * visual viewport. Use when an ancestor's overflow clipping would crop the
 * in-place list; default false keeps the pure-CSS in-place behavior.
 * @param props.closeOnPointerLeave - close the list once the pointer has left
 * both trigger and list for the pointer grace (default false keeps it open
 * until outside click/Escape/selection). The grace makes the 4px trigger->list
 * gap and a brief overshoot survivable; coming back cancels the close.
 * @param props.dense - reduce vertical row spacing without changing the standard typography or card width.
 * @param props.compact - use reduced menu typography and spacing.
 * @param props.anchorRef - external element used as the CSS anchor in portal mode.
 * @param props.anchorPoint - client viewport coordinates captured when a context menu opens.
 * @param props.minWidthFromAnchor - in portal mode, keep the menu at least as wide as its anchor, bounded by viewport margins.
 * @param props.footer - rows pinned below the scrolling items area, separated
 * by a hairline; contextual menus reuse an explicit leading separator. These rows stay visible while the items above scroll.
 * @param props.children - component rows rendered after `items` in the same
 * list, each a `role="menuitem"` button such as {@link MenuItemButton}; they
 * share the keyboard walk, the submenu exclusivity, and the post-selection
 * focus return.
 * @param props.selection - how a selected row is marked: a trailing check
 * (`'check'`, default — figma .Menu_cell) or the hover fill held on the row
 * with no check (`'fill'`, for icon-labelled rows where a trailing glyph
 * crowds the cell).
 * @param props.className - extra class on the anchor wrapper span.
 * @param props.listClassName - extra class on the dropdown card itself; the
 * only style hook that reaches a portaled list, which renders under
 * document.body outside the owner's DOM subtree.
 * @returns anchor wrapper with the conditional list.
 */
export declare function Menu({ open, anchor, items, children, submenuBackLabel, selectedId, selectedIds, onSelect, onClose, align, side, portal, closeOnPointerLeave, dense, compact, autoFocus, selection, anchorRef, anchorPoint, minWidthFromAnchor, footer, className, listClassName, contextual, exiting, returnFocus, isExternalTrigger }: {
    open: boolean;
    /** Pointer-positioned popup: cursor clearance, grouped icons, and context gestures. */
    contextual?: boolean;
    /** Recognizes external triggers exempt from outside dismissal; omitted exempts no external nodes. */
    isExternalTrigger?: (node: Node) => boolean;
    /** Resolve the original control for focus restoration and inert/hidden dismissal. */
    returnFocus?: (() => HTMLElement | null) | undefined;
    /** Retain a dismissed context popup during its short fade. */
    exiting?: 'dismiss' | 'replace' | undefined;
    autoFocus?: boolean;
    anchor: ReactNode;
    items?: readonly MenuEntry[];
    /** Localized return action; omitted uses the caller's parent label with a back arrow. */
    submenuBackLabel?: string | undefined;
    children?: ReactNode;
    footer?: readonly MenuEntry[];
    selectedId?: string | undefined;
    selectedIds?: readonly string[] | undefined;
    onSelect?: (id: string) => void;
    onClose: () => void;
    align?: 'start' | 'end';
    side?: 'bottom' | 'top' | 'right';
    portal?: boolean;
    closeOnPointerLeave?: boolean;
    dense?: boolean;
    compact?: boolean;
    selection?: 'check' | 'fill';
    anchorRef?: RefObject<HTMLElement | null> | undefined;
    /** Client coordinates captured for this opening; Safari offsets are applied once. */
    anchorPoint?: {
        readonly x: number;
        readonly y: number;
    } | undefined;
    minWidthFromAnchor?: boolean;
    className?: string | undefined;
    listClassName?: string | undefined;
}): import("react").JSX.Element;
//# sourceMappingURL=Menu.d.ts.map