/** GitHub pull request commit listing through GraphQL, pinned to one head commit across pages. */
import type { ChangeRequestRef, ForgeCommitList, ForgeFailure } from '@deepseek-ai/dsh-experimental-forge';
/** One page of a pull request's commits with its head; `cursor` continues after the previous page. */
export declare const COMMITS_QUERY = "query($owner: String!, $name: String!, $number: Int!, $first: Int!, $cursor: String) {\n  repository(owner: $owner, name: $name) {\n    pullRequest(number: $number) {\n      headRefOid\n      commits(first: $first, after: $cursor) {\n        totalCount\n        pageInfo { hasNextPage endCursor }\n        nodes { commit { oid messageHeadline authoredDate author { name user { login } } parents(first: 1) { nodes { oid } } } }\n      }\n    }\n  }\n}";
/** Runs one `gh` GraphQL request; resolves to its parsed JSON body, or why GitHub did not answer it. */
export type GraphqlReader = (args: readonly string[], signal: AbortSignal) => Promise<{
    readonly ok: true;
    readonly body: unknown;
} | {
    readonly ok: false;
    readonly failure: ForgeFailure;
}>;
/**
 * List a pull request's commits oldest first, at most `limit`, reading pages until the limit or the last commit.
 * Every page must report the head and commit count of the first page, so the list never mixes two pushes, and a cursor
 * no earlier page returned, so the listing ends.
 * @param read - runs one GraphQL request.
 * @param ref - validated pull request address.
 * @param limit - most commits listed.
 * @param signal - cancellation of every page.
 * @returns the commits at one head, or why GitHub did not list them.
 */
export declare function listCommits(read: GraphqlReader, ref: ChangeRequestRef, limit: number, signal: AbortSignal): Promise<ForgeCommitList | ForgeFailure>;
//# sourceMappingURL=commits.d.ts.map