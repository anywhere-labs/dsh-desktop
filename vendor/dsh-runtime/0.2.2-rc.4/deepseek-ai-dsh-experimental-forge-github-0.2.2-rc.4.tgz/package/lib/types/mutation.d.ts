/** GitHub GraphQL mutations sent once through `gh`, with the document and variables as JSON on standard input. */
import type { ForgeActionFailure } from '@deepseek-ai/dsh-experimental-forge';
import { type GhRunner } from './gh.ts';
/** One mutation and the payload field that holds its result. */
export interface GraphqlMutation {
    /** GraphQL document with one mutation field. */
    readonly query: string;
    /** Name of the mutation field, which holds the payload once GitHub applied the mutation. */
    readonly field: string;
    /** Variables of the document. */
    readonly variables: Readonly<Record<string, unknown>>;
}
/**
 * A mutation's result: the payload once GitHub applied it; else `failed` when GitHub refused it or `gh` could not start,
 * so nothing changed, or `unknown` when the mutation may have been applied and must be checked on GitHub.
 */
export type MutationResult = {
    readonly ok: true;
    readonly payload: unknown;
} | {
    readonly ok: false;
    readonly code: 'failed' | 'unknown';
    readonly message: string;
};
/**
 * Runs one mutation on `host` through {@link sendMutation}; resolves to undefined once GitHub applied it, to a `failed`
 * action failure when GitHub refused it, or to an `unknown` one when GitHub did not confirm it.
 */
export type GraphqlWriter = (host: string, mutation: GraphqlMutation, signal: AbortSignal) => Promise<ForgeActionFailure | undefined>;
/**
 * Send one mutation with its query and variables as JSON on stdin. The mutation is never retried.
 * @param gh - runs `gh` on the Host.
 * @param host - GitHub host the mutation goes to.
 * @param mutation - the document, its field, and its variables.
 * @param signal - cancellation of the request.
 * @returns the payload of `mutation.field`; `failed` when GitHub reports a refusal by its HTTP status or GraphQL error
 * type, or `gh` cannot start, else `unknown`.
 */
export declare function sendMutation(gh: GhRunner, host: string, mutation: GraphqlMutation, signal: AbortSignal): Promise<MutationResult>;
//# sourceMappingURL=mutation.d.ts.map