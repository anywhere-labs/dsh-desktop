/** GitHub writes to review threads and the pending review through GraphQL mutations, each after a check of the head. */
import type { ChangeRequestRef, ForgeReviewWrite, ForgeReviewWriteResult } from '@deepseek-ai/dsh-experimental-forge';
import type { GraphqlReader } from './commits.ts';
import type { GhRunner } from './gh.ts';
/** The pull request, its head, and the signed-in user's pending review; variables `owner` and `name` are strings, `number` an integer. */
export declare const WRITE_CHECK_QUERY = "query($owner: String!, $name: String!, $number: Int!) {\n  repository(owner: $owner, name: $name) { pullRequest(number: $number) { id headRefOid reviews(states: PENDING, first: 100) { nodes { id viewerDidAuthor } } } }\n}";
/** The same check plus the pull request that holds the thread or comment `target`, a string variable. */
export declare const WRITE_TARGET_CHECK_QUERY = "query($owner: String!, $name: String!, $number: Int!, $target: ID!) {\n  repository(owner: $owner, name: $name) { pullRequest(number: $number) { id headRefOid reviews(states: PENDING, first: 100) { nodes { id viewerDidAuthor } } } }\n  target: node(id: $target) { ... on PullRequestReviewThread { pullRequest { id } } ... on PullRequestReviewComment { pullRequest { id } } }\n}";
/** Start a pending review at a commit, with the line threads of `threads`. */
export declare const ADD_REVIEW_MUTATION = "mutation($pull: ID!, $commit: GitObjectID!, $threads: [DraftPullRequestReviewThread]) {\n  addPullRequestReview(input: { pullRequestId: $pull, commitOID: $commit, threads: $threads }) { pullRequestReview { id } }\n}";
/** Add one line thread to a pending review. */
export declare const ADD_THREAD_MUTATION = "mutation($review: ID!, $path: String!, $body: String!, $line: Int!, $side: DiffSide!, $startLine: Int, $startSide: DiffSide) {\n  addPullRequestReviewThread(input: {\n    pullRequestReviewId: $review, path: $path, body: $body, line: $line, side: $side, startLine: $startLine, startSide: $startSide\n  }) { thread { id } }\n}";
/** Reply to a thread, inside the pending review `review` when it is set. */
export declare const REPLY_MUTATION = "mutation($thread: ID!, $body: String!, $review: ID) {\n  addPullRequestReviewThreadReply(input: { pullRequestReviewThreadId: $thread, body: $body, pullRequestReviewId: $review }) { comment { id } }\n}";
/** Mark a thread resolved. */
export declare const RESOLVE_MUTATION = "mutation($thread: ID!) { resolveReviewThread(input: { threadId: $thread }) { thread { id } } }";
/** Mark a thread unresolved. */
export declare const UNRESOLVE_MUTATION = "mutation($thread: ID!) { unresolveReviewThread(input: { threadId: $thread }) { thread { id } } }";
/** Replace the text of a review comment. */
export declare const EDIT_COMMENT_MUTATION = "mutation($comment: ID!, $body: String!) {\n  updatePullRequestReviewComment(input: { pullRequestReviewCommentId: $comment, body: $body }) { pullRequestReviewComment { id } }\n}";
/** Delete a review comment. */
export declare const DELETE_COMMENT_MUTATION = "mutation($comment: ID!) { deletePullRequestReviewComment(input: { id: $comment }) { clientMutationId } }";
/** Submit a pending review with a decision and summary. */
export declare const SUBMIT_REVIEW_MUTATION = "mutation($review: ID!, $event: PullRequestReviewEvent!, $body: String) {\n  submitPullRequestReview(input: { pullRequestReviewId: $review, event: $event, body: $body }) { pullRequestReview { id } }\n}";
/** Delete a pending review with its comments. */
export declare const DELETE_REVIEW_MUTATION = "mutation($review: ID!) { deletePullRequestReview(input: { pullRequestReviewId: $review }) { pullRequestReview { id } } }";
/**
 * Write to the review threads or the pending review of a pull request. One read first checks that the head is still
 * `write.headSha`, finds the signed-in user's pending review, and, for a write to a thread or comment, that the pull
 * request holds it; a moved head returns `stale` and a thread or comment elsewhere `failed`, both without writing. A
 * pending reply without a pending review first starts an empty one at `write.headSha`; when the reply then fails, that
 * empty review stays. A reply at once is refused with `failed` while the user has a pending review, since GitHub would
 * add it to that review. Mutations send their variables as JSON on stdin, and none is retried: a refusal GitHub reports
 * returns `failed`, and an answer that does not show whether GitHub applied a mutation returns `unknown`.
 * @param read - runs the check as one GraphQL request.
 * @param gh - bounded, cancellable GitHub CLI runner for the mutations.
 * @param ref - pull request, with an owner and name already checked for inlining.
 * @param write - the write and the head commit the user saw.
 * @param signal - cancellation of the check and the mutations.
 * @returns whether GitHub took the write.
 * @throws with `signal.reason` when the signal aborts before a mutation is sent.
 */
export declare function writeGitHubReview(read: GraphqlReader, gh: GhRunner, ref: ChangeRequestRef, write: ForgeReviewWrite, signal: AbortSignal): Promise<ForgeReviewWriteResult>;
//# sourceMappingURL=review-writes.d.ts.map