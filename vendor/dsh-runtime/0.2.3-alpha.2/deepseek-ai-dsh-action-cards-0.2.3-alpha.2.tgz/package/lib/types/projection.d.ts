/** Recover cards from `action-card` blocks in answers, and decisions from `action-cards/decision` events and earlier plugin records. */
import { z } from 'zod';
import { SessionLogOffset } from '@deepseek-ai/dsh-session';
import type { ProjectionDefinition } from '@deepseek-ai/dsh-session-projection';
import type { ActionCardId } from './types.ts';
/** Kind-defined JSON object of a proposal or decision. */
export declare const fieldsSchema: z.ZodRecord<z.ZodString, z.ZodJSONSchema>;
/** Recorded decision of one card. */
export declare const decisionSchema: z.ZodObject<{
    cardId: z.ZodPipe<z.ZodString, z.ZodTransform<ActionCardId, string>>;
    action: z.ZodString;
    phase: z.ZodString;
    data: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodJSONSchema>>;
}, z.core.$strict>;
declare const stateSchema: z.ZodObject<{
    inheritedEventCount: z.ZodPipe<z.ZodNumber, z.ZodTransform<SessionLogOffset, number>>;
    offers: z.ZodBoolean;
    view: z.ZodObject<{
        proposals: z.ZodRecord<z.ZodString, z.ZodObject<{
            cardId: z.ZodPipe<z.ZodString, z.ZodTransform<ActionCardId, string>>;
            turn: z.ZodNumber;
            action: z.ZodString;
            title: z.ZodString;
            brief: z.ZodString;
            details: z.ZodRecord<z.ZodString, z.ZodJSONSchema>;
        }, z.core.$strict>>;
        decisions: z.ZodRecord<z.ZodString, z.ZodObject<{
            cardId: z.ZodPipe<z.ZodString, z.ZodTransform<ActionCardId, string>>;
            action: z.ZodString;
            phase: z.ZodString;
            data: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodJSONSchema>>;
        }, z.core.$strict>>;
    }, z.core.$strip>;
    admittedTurn: z.ZodNullable<z.ZodNumber>;
    pendingStatus: z.ZodRecord<z.ZodString, z.ZodNumber>;
}, z.core.$strip>;
/** Fold state; `view` is also the Client wire value. */
export type ActionCardState = z.infer<typeof stateSchema>;
/** Type of {@link actionCardProjection}: the fold plus its Client view wire. */
export type ActionCardProjectionDefinition = Omit<ProjectionDefinition<'actionCards', ActionCardState>, 'wire'> & {
    readonly wire: NonNullable<ProjectionDefinition<'actionCards', ActionCardState>['wire']>;
};
/**
 * Full-Session fold. The first valid `action-card` block in a turn's answer text becomes the card, named by the id of
 * its assistant message. Later blocks of that turn create no card. Interrupted answers, subagent Sessions and events inherited
 * by a forked Session create no proposals.
 */
export declare const actionCardProjection: ActionCardProjectionDefinition;
export {};
//# sourceMappingURL=projection.d.ts.map