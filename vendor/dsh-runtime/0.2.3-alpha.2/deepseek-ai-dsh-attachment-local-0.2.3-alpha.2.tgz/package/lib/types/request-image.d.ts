/** Deterministic cached image versions for model requests. */
import type { ImageVariantId } from '@deepseek-ai/dsh-attachment/types';
import type { ImageAttachmentRef, ImageRequestTarget, RequestImageAttachment, StoredImageAttachment } from '@deepseek-ai/dsh-attachment';
/** Transform version included in every cache and upload-index identity. */
export declare const REQUEST_IMAGE_TRANSFORM_VERSION = "request-image-v7";
/** Resolved encoder controls for deterministic byte-limit enforcement. */
export interface RequestImageResizePolicy {
    /** Minimum divisor of the long edge after an oversized encoding; greater than one. */
    minShrinkFactor: number;
    /** Fraction of the hard byte limit used to estimate the next size; greater than zero and at most one. */
    byteHeadroom: number;
}
/**
 * Complete deterministic identity for one attachment and route-chosen request target.
 * @param attachment - provider-independent durable normalized attachment reference.
 * @param target - route-chosen dimensions, hard byte limit, and preferred byte target.
 * @param policy - resolved size-reduction controls.
 * @returns branded digest over every request transform input.
 */
export declare function requestImageVariantId(attachment: ImageAttachmentRef, target: ImageRequestTarget, policy: RequestImageResizePolicy): ImageVariantId;
/**
 * Generate or reuse one request image below the local attachment cache root.
 * @param root - absolute attachment cache root; variants use its `request-images` child.
 * @param attachment - verified normalized attachment bytes and reference.
 * @param target - maximum dimensions, hard byte limit, and preferred byte target; small sources are never enlarged.
 * @param policy - resolved size-reduction controls.
 * @param signal - optional cancellation for cache I/O and image transformation.
 * @returns verified request bytes and deterministic variant identity.
 */
export declare function readRequestImageFile(root: string, attachment: StoredImageAttachment, target: ImageRequestTarget, policy: RequestImageResizePolicy, signal?: AbortSignal): Promise<RequestImageAttachment>;
//# sourceMappingURL=request-image.d.ts.map