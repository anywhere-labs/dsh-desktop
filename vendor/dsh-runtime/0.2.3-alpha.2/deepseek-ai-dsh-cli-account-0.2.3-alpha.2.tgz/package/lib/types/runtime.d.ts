/** One CLI plugin's account operations: one at a time, Host-owned, with a credential-free view that observers reread after each change. */
import type { Context } from '@deepseek-ai/cordis';
import type { ConnectorAccountSource, ConnectorOperationId } from '@deepseek-ai/dsh-client-ui-connector-account/types';
import type { CliCommandExecutor } from './executor.ts';
import type { CliAccountRegistration, CliAccountView, CliCommandFailure } from './types.ts';
/** The registration fields the runtime reads, and the executor and logger it works through. */
export type CliAccountRuntimeOptions<Account, Kind extends string, Phase extends string, Command extends string> = Pick<CliAccountRegistration<Account, Kind, Phase, Command, string>, 'name' | 'account' | 'check' | 'cancellable' | 'authorizationHosts' | 'perform'> & {
    /** The executor the runtime runs commands with and disposes with itself. */
    readonly executor: CliCommandExecutor;
    readonly logger: Context['logger'];
};
/**
 * List the last command of a failed operation as the diagnostic items a Plugins page failure shows after the plugin's
 * guidance.
 * @param failure - the last command a failed operation ran and its exit code.
 * @returns the command, then its exit code when it has one, such as `login` and `exit 3`; untranslated.
 */
export declare function failureDetails(failure: CliCommandFailure): string[];
/**
 * Runs at most one account operation at a time; observers see it without owning it, and the Service registers it as
 * the plugin's Plugins page account source. A failed operation logs and returns only its last command and that
 * command's exit code, because exceptions and native output may contain credentials.
 */
export declare class CliAccountRuntime<Account, Kind extends string, Phase extends string, Command extends string> implements ConnectorAccountSource<CliAccountView<Account, Kind, Phase, Command>> {
    private readonly options;
    private account;
    private active;
    private result;
    private readonly cancellable;
    private readonly listeners;
    private readonly lifetime;
    /** @param options - the plugin's registration fields, executor, and logger. */
    constructor(options: CliAccountRuntimeOptions<Account, Kind, Phase, Command>);
    /**
     * Replace the account the view reports and notify subscribers.
     * @param account - the account the latest check observed.
     */
    publish(account: Account): void;
    /**
     * Read the account, the active operation, and the last result.
     * @returns a view without credentials.
     */
    snapshot(): CliAccountView<Account, Kind, Phase, Command>;
    /**
     * Start one operation.
     * @param kind - the requested operation.
     * @returns the operation identity.
     * @throws while another operation runs, or after disposal.
     */
    start(kind: Kind): ConnectorOperationId;
    /** Start a check unless an operation already runs or the runtime is disposed. */
    refresh(): void;
    /**
     * Cancel the named operation if its current phase is cancellable, and wait for it to settle.
     * @param id - the operation to cancel; a finished operation or a phase that is not cancellable is ignored.
     * @returns after the operation settles, or at once when nothing is cancelled.
     */
    cancel(id: ConnectorOperationId): Promise<void>;
    /**
     * Call `listener` after each change of the view, without starting a check. An exception a listener throws is logged
     * and stops neither the other listeners nor the operation or call that changed the view.
     * @param listener - called synchronously after the account, operation, or result changes.
     * @returns a disposer that stops the calls.
     */
    observe(listener: () => void): () => void;
    /**
     * Refuse new work, cancel the active operation, wait for it, and dispose the executor.
     * @returns after account work and owned processes stop.
     */
    dispose(): Promise<void>;
    private changed;
    private interrupt;
    private execute;
    private run;
    private stage;
    private offer;
}
//# sourceMappingURL=runtime.d.ts.map