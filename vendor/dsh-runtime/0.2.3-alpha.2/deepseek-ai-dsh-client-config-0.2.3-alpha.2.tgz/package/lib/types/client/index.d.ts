/** Client face of the synced configuration types package; `@deepseek-ai/dsh-client-modules` provides the runtime. */
export type * from '../types.ts';
/** Register nothing in the browser. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map