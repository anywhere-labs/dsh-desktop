/** Ordered credential verification, independent of Connection's transport and source policy. */
import { Context, Service } from '@deepseek-ai/cordis';
import type { AuthenticationProvider, ConnectionTrustRequest, PeerAdmission } from './rpc.ts';
/** Credential verifier registry whose registrations belong to the calling plugin. */
export declare class ConnectionAuthentication extends Service {
    private readonly providers;
    private readonly owner;
    private disposed;
    /** @param ctx - scope owning the credential registry and its lifetime. */
    constructor(ctx: Context);
    /**
     * Add a credential verifier after the existing registrations.
     * @param provider - verifier owning its credential and Peer selection.
     * @returns disposer withdrawing this registration; the calling scope also withdraws it on unload.
     */
    register(provider: AuthenticationProvider): () => Promise<void>;
    /**
     * Verify credentials without applying an HTTP response or source policy.
     * @param request - current carrier headers and cancellation facts.
     * @returns the first live Peer, 401 if no provider accepts, or 503 when verification failed without success.
     */
    authenticate(request: ConnectionTrustRequest): PeerAdmission;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Credential verification shared by Host transports and authentication plugins. */
        'connection.authentication': ConnectionAuthentication;
    }
}
declare module './rpc.ts' {
    interface HostConnectionHandle {
        /** Credential verifier sub-service; consumers inject `connection.authentication`. */
        readonly authentication: ConnectionAuthentication;
    }
}
export default ConnectionAuthentication;
//# sourceMappingURL=authentication.d.ts.map