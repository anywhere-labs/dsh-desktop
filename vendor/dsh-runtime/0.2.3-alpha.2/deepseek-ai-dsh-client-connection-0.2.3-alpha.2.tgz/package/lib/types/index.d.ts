/** Host HTTP bridge for browser-client RPC. */
import type { Context } from '@deepseek-ai/cordis';
import type { IncomingMessage, ServerResponse } from 'node:http';
import z from '@deepseek-ai/schemastery';
import { type ConnectionRecoveryConfig } from './recovery-config.ts';
import type { ConnectionConfig } from './types.ts';
export type { AuthenticationProvider, PeerAdmission, ConnectionFetchMethod, ConnectionFetchHandler, ConnectionFetchRoute, ConnectionRpcEndpointMatcher, ConnectionRpcAttachment, ConnectionRpcFailure, ConnectionRpcHandler, ConnectionRpcHandlerResult, ConnectionRpcResult, ConnectionRequestBodyMode, ConnectionTrustRequest, ClientRequest, HostConnectionHandle, HostConnectionFetch, HostConnectionRpc, RpcMessage, ServerResponse, } from './rpc.ts';
export type { PeerId, PeerScope, Principal, RemoteInvocation } from '@deepseek-ai/dsh-typert-protocol';
export { RpcId, transportError } from './rpc.ts';
export { Peer } from './peer.ts';
export type { PeerOptions } from './peer.ts';
export { CONNECT_PATH, type ConnectionInteractions } from './connect-protocol.ts';
export { clientRequestSchema, rpcErrorSchema, rpcIdSchema, rpcMessageSchema, rpcResultSchema, serverResponseSchema, } from './rpc-schema.ts';
export { HostConnectionService } from './rpc-host.ts';
export { ConnectionAuthentication } from './authentication.ts';
export { API_PATH } from './api-path.ts';
/** Stable Cordis plugin name. */
export declare const name = "client-connection";
declare module '@deepseek-ai/cordis' {
    interface Events {
        /**
         * Admit or wrap an authenticated shared API request, including body transfer.
         * Existing requests continue when a listener refuses subsequent requests.
         * @param request - Authenticated incoming HTTP request.
         * @param response - Response owned until the delegated bridge settles.
         * @param next - Delegate to the next listener or the shared API bridge.
         * @mode waterfall
         */
        'connection/request'(request: IncomingMessage, response: ServerResponse, next: () => Promise<void>): Promise<void>;
    }
}
/** Services required before providing Connection. */
export declare const inject: string[];
export type { ConnectionConfig } from './types.ts';
/** Host request limits and trusted authorities; `recovery` is synced to the browser. */
export declare const Config: z<Omit<ConnectionConfig, 'recovery'> & {
    recovery?: ConnectionRecoveryConfig;
}, ConnectionConfig>;
/**
 * Provides carrier-neutral RPC and Fetch registries. When `webServer` is
 * present, the plugin applies Host/Origin checks and registered authentication
 * to WebServer routes and mounts the `/api` browser transport.
 * @param ctx - Host plugin context.
 * @param config - resolved plugin config (schema defaults applied).
 */
export declare function apply(ctx: Context, config?: ConnectionConfig): void;
//# sourceMappingURL=index.d.ts.map