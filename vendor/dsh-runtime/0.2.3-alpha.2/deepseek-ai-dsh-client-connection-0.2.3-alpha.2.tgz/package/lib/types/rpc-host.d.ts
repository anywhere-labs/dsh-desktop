/** Host registry and HTTP adapter for generic Connection RPC channels. */
import { Context, Service } from '@deepseek-ai/cordis';
import type { PeerScope, Principal } from '@deepseek-ai/dsh-typert-protocol';
import type { ConnectionInteractions } from './connect-protocol.ts';
import type { ConnectionAuthentication } from './authentication.ts';
import type { PeerAdmission, ConnectionFetchHandler, HostConnectionFetch, ConnectionTrustRequest, HostConnectionHandle, HostConnectionRpc } from './rpc.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Host Connection transport and RPC registrations. */
        connection: HostConnectionHandle;
    }
}
/** Host Connection service whose channel registrations belong to the caller fiber. */
export declare class HostConnectionService extends Service implements HostConnectionHandle {
    private readonly trustedHosts;
    /** Connection-owned Peer for trusted in-process callers, not network authentication. */
    readonly browserPeer: PeerScope;
    readonly authentication: ConnectionAuthentication;
    private readonly owner;
    private disposed;
    private readonly interceptors;
    private readonly fetchRoutes;
    readonly allowsRemoteAuthorities: boolean;
    /**
     * Provide the Host half over the active HTTP server.
     * @param ctx - owning Connection plugin context.
     * @param trustedHosts - deployment authorities accepted by the Host/Origin fence.
     */
    constructor(ctx: Context, trustedHosts: readonly string[]);
    /** Generic channel registry scoped to the Context reading this service. */
    get rpc(): HostConnectionRpc;
    /** Exact Fetch-route registry scoped to the Context reading this service. */
    get fetch(): HostConnectionFetch;
    /** Apply the carrier source policy and accept the first successful provider. */
    admit(request: ConnectionTrustRequest): PeerAdmission;
    /** Create one in-process Peer owned by the Context that read this service. */
    createPeer(options: {
        readonly principal: Principal;
        readonly interactions?: ConnectionInteractions;
    }): PeerScope;
    /** Check the deployment's request-source policy without credential verification. */
    private isTrustedRequest;
    /**
     * Compose one shared-channel Fetch handler from exact routes and its interceptor.
     * @param channel - shared channel mounted by Connection.
     * @returns Fetch handler that selects one owner or returns 404.
     */
    createSharedFetchHandler(channel: '/api'): ConnectionFetchHandler;
    private registerFetchRoute;
    private register;
    private registerInterceptor;
}
//# sourceMappingURL=rpc-host.d.ts.map