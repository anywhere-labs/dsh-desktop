/** Remote-stream transport for page-owned client entry reconciliation, rebuilt code replacement, and synced configuration. */
import type { Context } from '@deepseek-ai/cordis';
export type * from '../types.ts';
/** Cordis plugin name. */
export declare const name = "client-hmr";
/** Required services: the module system whose entry controller handles frames, the Remote carrier, and Remote access. */
export declare const inject: string[];
/**
 * Forward each stream generation's graph and rebuilds to the page's serial entry controller, which also applies each
 * row's synced configuration, while Remote access allows the stream.
 * @param ctx - Plugin context with the client module system and Remote carrier.
 * @returns the disposer of this plugin's `pluginEvents` namespace.
 */
export declare function apply(ctx: Context): Promise<() => Promise<void>>;
//# sourceMappingURL=index.d.ts.map