import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export type * from './types.ts';
/** Cordis plugin name. */
export declare const name = "client-hmr";
/** Required service: the client graph. */
export declare const inject: string[];
/** Plugin config, validated by the same-named schemastery schema. */
export interface Config {
    /** Bundle stat-poll interval in milliseconds (default 500, the build-side watcher's polling default). */
    pollIntervalMs?: number;
}
export declare const Config: z<Config>;
/**
 * Mount bundle watches and the plugin-events Remote service.
 * @param ctx - host plugin context carrying clientModules and webServer.
 * @param config - validated {@link Config}.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map