/** Host `pluginEvents` Remote service: an authenticated baseline-and-increment stream of graph and rebuild changes. */
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { PluginsEventFrame } from './types.ts';
/**
 * Streams start from the current graph; listeners attach before the baseline is read. Every Peer the Remote access
 * policies admit may follow; each frame carries the graph as that Peer may see it, so only the owner receives configured
 * synced values and every other Peer receives schema defaults.
 */
export declare class PluginEvents extends TypertRemoteService {
    static inject: string[];
    private readonly followers;
    /** @param ctx - Host context with the Web client graph. */
    constructor(ctx: Context);
    /**
     * Follow Web client graph and rebuild changes; every generation starts with a complete baseline.
     * @param signal - generation cancellation.
     * @returns the baseline followed by ordered increments; the stream ends when the service unloads.
     */
    follow(signal: AbortSignal): AsyncIterable<PluginsEventFrame>;
    private publish;
    private publishGraph;
}
export default PluginEvents;
//# sourceMappingURL=plugin-events.d.ts.map