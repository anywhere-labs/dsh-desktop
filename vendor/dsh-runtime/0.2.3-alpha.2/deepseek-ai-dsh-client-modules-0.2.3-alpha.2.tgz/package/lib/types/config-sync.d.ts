import type { Context } from '@deepseek-ai/cordis';
import type { Entry } from '@deepseek-ai/cordis-plugin-loader';
import type { Principal } from '@deepseek-ai/dsh-typert-protocol';
import type { WebBootEntry, WebBootGraph } from './client/manifest.ts';
/** Synced values per graph row, owned by the client module registry. */
export declare class SyncedConfigPublisher {
    private readonly ctx;
    private readonly changed;
    /** Last published values per row; undefined for a plugin without top-level volatile fields. */
    private readonly values;
    /**
     * Values the row's schema resolves from an empty Config, served to every non-owner Peer; undefined when the schema
     * declares no top-level volatile field or cannot resolve an empty Config.
     */
    private readonly defaults;
    /** Loader entry name per row of the last composed graph. */
    private rows;
    /** Current root plugin fiber per Loader entry name; of entries sharing a name, the one seen last. */
    private readonly fibers;
    /** `loader/volatile-update` listener disposer per Loader entry name. */
    private readonly watches;
    /**
     * @param ctx - the registry's context; the publisher's listeners leave with it.
     * @param entries - the Loader entries present when the registry starts.
     * @param changed - recomposes and republishes the graph after a row's values change.
     */
    constructor(ctx: Context, entries: Iterable<Entry>, changed: () => void);
    /**
     * Attach current synced values to composed rows, and drop the values of rows that left the graph.
     * @param entries - composed rows.
     * @param records - the registry table, keyed by row id, naming the Loader entry that supplies each row.
     * @returns the rows, each with its values when it has any.
     */
    apply(entries: WebBootEntry[], records: ReadonlyMap<string, {
        readonly loaderName: string;
    }>): WebBootEntry[];
    /**
     * The graph one Peer receives, at first render and in every plugin-events frame. The owner receives the configured
     * values; every other Peer receives each row's schema defaults instead, so the owner's values stay on the Host.
     * @param graph - the composed graph.
     * @param principal - the Peer's principal; undefined for the owner or an in-process caller.
     * @returns the graph itself for the owner, otherwise a copy whose row values are the schema defaults.
     */
    graphFor(graph: WebBootGraph, principal: Principal | undefined): WebBootGraph;
    private track;
    private republish;
    /**
     * Recompute one row's values; equal values (deep equality) change nothing.
     * @returns whether the row's values changed.
     */
    private refresh;
    private defaultValues;
}
//# sourceMappingURL=config-sync.d.ts.map