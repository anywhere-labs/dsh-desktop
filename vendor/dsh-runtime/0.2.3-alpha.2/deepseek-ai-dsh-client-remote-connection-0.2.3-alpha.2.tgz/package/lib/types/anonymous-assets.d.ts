/** Public pairing script served before the authenticated application loads. */
import type { Context } from '@deepseek-ai/cordis';
import type { PairingRecovery } from './anonymous/pairing.ts';
/**
 * Register the generated script in the Remote plugin's lifetime.
 * @param ctx - plugin scope containing the HTTP listener.
 * @param recovery - validated public timing and recovery limits.
 */
export declare function registerAnonymousPairing(ctx: Context, recovery: PairingRecovery): void;
//# sourceMappingURL=anonymous-assets.d.ts.map