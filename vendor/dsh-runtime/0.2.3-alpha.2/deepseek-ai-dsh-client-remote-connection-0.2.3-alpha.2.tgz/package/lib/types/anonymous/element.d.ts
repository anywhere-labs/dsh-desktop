/** Native element whose request state belongs to its connected document lifetime. */
import type { mountPairing, PairingRecovery } from './pairing.ts';
import type { pairingLocales, pairingMethodLabels } from './locales.ts';
interface PairingElement extends HTMLElement {
    connectedCallback(): void;
    disconnectedCallback(): void;
}
/**
 * Define the anonymous element from explicitly supplied browser code and public data.
 * Serialized into the public script; no runtime dependency may escape its parameters.
 * @param mount - instance-owned pairing interaction.
 * @param locales - public dictionaries selected by browser language.
 * @param labels - public request labels selected by browser language.
 * @param css - plugin-owned anonymous-page styles.
 * @param recovery - validated public timing and recovery limits.
 * @returns the registered element constructor.
 */
export declare function definePairingElement(mount: typeof mountPairing, locales: typeof pairingLocales, labels: typeof pairingMethodLabels, css: string, recovery: PairingRecovery): new () => PairingElement;
export {};
//# sourceMappingURL=element.d.ts.map