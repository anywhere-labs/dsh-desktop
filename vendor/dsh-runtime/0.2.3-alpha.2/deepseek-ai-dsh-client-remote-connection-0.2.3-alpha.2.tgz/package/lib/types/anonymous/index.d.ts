import type { PairingRecovery } from './pairing.ts';
/**
 * Serialize the self-contained browser entry and its public dictionaries and styles.
 * @param recovery - validated public timing and recovery limits.
 * @returns executable classic JavaScript with no authenticated Client dependencies.
 */
export declare function renderPairingScript(recovery: PairingRecovery): string;
//# sourceMappingURL=index.d.ts.map