/** Anonymous pairing copy available before the application locale service. */
declare const en: {
    readonly pairTitle: "Pair this device";
    readonly pairHint: "After requesting, open Settings → Remote connection on another signed-in device. Match the pairing code and approve to sign in here automatically.";
    readonly pairCreating: "Requesting approval…";
    readonly pairWaiting: "Waiting for approval…";
    readonly pairCancelling: "Cancelling this request…";
    readonly pairReplacing: "Cancelling the previous request before requesting again…";
    readonly pairChecking: "Checking sign-in status…";
    readonly pairRecovering: "Reconnecting automatically…";
    readonly pairRateLimited: "Too many requests. Retrying shortly…";
    readonly pairRateLimitError: "Too many requests. Wait a moment, then request again.";
    readonly pairCheckError: "Could not confirm sign-in. Check your connection, then request again.";
    readonly pairCode: "Pairing code";
    readonly pairRemaining: "Expires in {time}";
    readonly pairDenied: "The request was denied. You can request again.";
    readonly pairExpired: "The request expired. Request again.";
    readonly pairError: "Could not complete pairing. Check your connection, then request again.";
    readonly pairCreateError: "Could not request pairing. Check your connection, then request again.";
    readonly pairCancel: "Cancel request";
    readonly pairAgain: "Request again";
};
/** Stable keys shared by the anonymous pairing translations. */
export type PairingLocaleKey = keyof typeof en;
/** Public dictionaries embedded in the anonymous script before application startup. */
export declare const pairingLocales: {
    en: {
        readonly pairTitle: "Pair this device";
        readonly pairHint: "After requesting, open Settings → Remote connection on another signed-in device. Match the pairing code and approve to sign in here automatically.";
        readonly pairCreating: "Requesting approval…";
        readonly pairWaiting: "Waiting for approval…";
        readonly pairCancelling: "Cancelling this request…";
        readonly pairReplacing: "Cancelling the previous request before requesting again…";
        readonly pairChecking: "Checking sign-in status…";
        readonly pairRecovering: "Reconnecting automatically…";
        readonly pairRateLimited: "Too many requests. Retrying shortly…";
        readonly pairRateLimitError: "Too many requests. Wait a moment, then request again.";
        readonly pairCheckError: "Could not confirm sign-in. Check your connection, then request again.";
        readonly pairCode: "Pairing code";
        readonly pairRemaining: "Expires in {time}";
        readonly pairDenied: "The request was denied. You can request again.";
        readonly pairExpired: "The request expired. Request again.";
        readonly pairError: "Could not complete pairing. Check your connection, then request again.";
        readonly pairCreateError: "Could not request pairing. Check your connection, then request again.";
        readonly pairCancel: "Cancel request";
        readonly pairAgain: "Request again";
    };
    zh: Record<"pairTitle" | "pairHint" | "pairCreating" | "pairWaiting" | "pairCancelling" | "pairReplacing" | "pairChecking" | "pairRecovering" | "pairRateLimited" | "pairRateLimitError" | "pairCheckError" | "pairCode" | "pairRemaining" | "pairDenied" | "pairExpired" | "pairError" | "pairCreateError" | "pairCancel" | "pairAgain", string>;
};
/** Labels for the anonymous method and its initial request action. */
export declare const pairingMethodLabels: Readonly<Record<string, string> & {
    en: string;
}>;
export {};
//# sourceMappingURL=locales.d.ts.map