import type { PairingLocaleKey } from './locales.ts';
/** Browser operations owned by the anonymous document. */
export interface PairingBrowser {
    /** Fetch an application-relative pairing endpoint. */
    request: typeof fetch;
    /** Navigate after the requesting browser has received its login cookie. */
    navigate: (url: string) => void;
}
/** Public, Host-configured bounds for anonymous recovery. */
export interface PairingRecovery {
    readonly requestTtlMs: number;
    readonly pollIntervalMs: number;
    /** Bounds the complete response, including reading its body. */
    readonly requestTimeoutMs: number;
    /** Additional attempts after a transient failure. */
    readonly maxRetries: number;
    /** Caps exponential delays starting at pollIntervalMs. */
    readonly retryMaxDelayMs: number;
}
type Styles = Readonly<Record<string, string | undefined>>;
/**
 * Mount the anonymous controls with bounded, cancellable recovery and no authenticated Client modules.
 * Serialized into the public script: runtime dependencies stay inside this function or its parameters.
 * Native Promise chains keep Preview's async-lowering helpers out of the serialized function.
 * Creation retries reuse credentials generated before sending; replacement confirms the old request ended.
 * Unknown outcomes retain credentials. Expiry requires checking browser authorization before starting again.
 * @param method - the device-pairing method rendered by the anonymous page.
 * @param styles - anonymous pairing CSS classes.
 * @param t - localized interaction copy.
 * @param requestLabel - localized initial request action.
 * @param browser - fetch and navigation for this document.
 * @param recovery - validated Host timing and retry limits.
 * @returns disposer aborting requests, timers and document listeners.
 */
export declare function mountPairing(method: HTMLElement, styles: Styles, t: Readonly<Record<PairingLocaleKey, string>>, requestLabel: string, browser: PairingBrowser, recovery: PairingRecovery): () => void;
export {};
//# sourceMappingURL=pairing.d.ts.map