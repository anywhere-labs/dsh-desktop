import type { ObservableSnapshot } from '@deepseek-ai/dsh-client-store';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { RemoteConnectionContentProps } from './slots.ts';
import type { PairingDecision, PairingRequestId } from '../types.ts';
import type { ApprovalState } from './pairing-approval.ts';
/** Owner operations and mutation state bound by the client plugin. */
export interface PairingInjected {
    readonly hooks: {
        readonly approval: ObservableSnapshot<ApprovalState>;
    };
    /** @param id - selected request. @param decision - allow or deny. @returns after the operation settles. */
    decide: (id: PairingRequestId, decision: PairingDecision) => Promise<void>;
    /** Dismiss the latest approval outcome. */
    dismiss: () => void;
}
type Face = InjectFace<PairingInjected> & PropsLocale<'remoteConnection'>;
/**
 * Render pending request codes and connection source IP addresses within Remote connection settings.
 * @param props - standard resource hook, owner actions, mutation state and localized copy.
 * @returns the approval card with live requests or feedback about the list read.
 */
export declare function PairingRequests({ useResource, useApproval, decide, t }: Pick<RemoteConnectionContentProps, 'useResource'> & Face): import("react").JSX.Element;
/**
 * Announce the decision even when the owner has closed Settings.
 * @param props - mutation state, notice dismissal and localized copy.
 * @returns the current toast, or nothing.
 */
export declare function PairingToast({ useApproval, dismiss, t }: PropsRuntime<'shell.overlay'> & Face): import("react").JSX.Element | null;
export {};
//# sourceMappingURL=PairingRequests.d.ts.map