import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { RemoteConnectionContentProps } from './slots.ts';
/** Renderer-derived section data, localized copy, and actions. */
export type RemoteConnectionSectionProps = RemoteConnectionContentProps & PropsLocale<'remoteConnection'>;
/**
 * Present address prerequisites, an access address, available QR login, and pairing cards.
 * @param props - Section injection and standard slot props.
 * @returns Remote connection settings content.
 */
export declare function RemoteConnectionSection(props: RemoteConnectionSectionProps): import("react").JSX.Element;
//# sourceMappingURL=RemoteConnectionSection.d.ts.map