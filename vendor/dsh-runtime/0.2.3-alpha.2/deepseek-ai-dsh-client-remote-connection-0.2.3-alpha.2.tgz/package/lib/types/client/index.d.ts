/** Remote connection settings registration; invitation credentials stay in this plugin's memory. */
import type { Context } from '@deepseek-ai/cordis';
import { type RemoteConnectionLocaleKey } from './locales.ts';
export type { RemoteConnectionContentProps, RemoteConnectionExtensionProps } from './slots.ts';
export type { RemoteConnectionState } from './remote-connection-controller.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Remote connection settings copy. */
        remoteConnection: RemoteConnectionLocaleKey;
    }
}
/** Services consumed by the settings registration. */
export declare const inject: string[];
/**
 * Mount the Remote and register the browser settings section and polling.
 * @param ctx - Browser context providing the settings slot and authenticated Remote.
 * @returns After the generated service and any browser settings registrations are ready.
 */
export declare function apply(ctx: Context): Promise<void>;
//# sourceMappingURL=index.d.ts.map