/** In-memory login link and clipboard outcomes, independent of the QR invitation. */
import { type SnapshotStore } from '@deepseek-ai/dsh-client-store';
import type { TypertClientRemote } from '@deepseek-ai/dsh-typert-protocol';
/** Link readiness and clipboard feedback; credentials must never be persisted or logged. */
export interface LoginLinkState {
    /** Tokenized address displayed by the settings panel and used for explicit clipboard writes. */
    url: string | null;
    /** Credential-read or clipboard activity; failed reads leave the clean address copyable. */
    phase: 'loading' | 'ready' | 'copying' | 'error';
    /** Whether the credential warning is enabled for the current Remote connection settings visit. */
    copied: boolean;
    /** Transient clipboard outcome presented by the shell overlay. */
    notice: 'linkCopied' | 'copyFailed' | null;
    /** Identity of the latest notice; older toast completion cannot dismiss it. */
    sequence: number;
}
/** Link actions and private state bound by the slot renderer. */
export interface LoginLinkFace {
    /** Copy the credential link or clean access address without changing a QR invitation. */
    copyLink: () => void;
    /** Retry a failed login-link read. */
    reloadLink: () => void;
    /** Retire the specified clipboard notice. */
    dismissCopyNotice: (sequence: number) => void;
    /** Shared source for the settings panel and the longer-lived shell toast. */
    hooks: {
        loginLink: SnapshotStore<LoginLinkState>;
    };
}
/** Owns credential reads and clipboard writes; disposal drains them and discards late results. */
export declare class LoginLinkController {
    private readonly remote;
    private readonly write;
    private readonly accessAddress;
    private readonly canCopyCredential;
    /** In-memory credential and feedback, cleared when the plugin unloads. */
    readonly store: SnapshotStore<LoginLinkState>;
    private live;
    private loading;
    private copying;
    private readGeneration;
    private warningGeneration;
    private readonly pending;
    /**
     * @param remote - owner-authenticated login-link reader.
     * @param write - clipboard writer returning true only after a successful write.
     * @param accessAddress - current clean address, or null before an address has been read.
     * @param canCopyCredential - whether the current deployment permits copying a credential link.
     */
    constructor(remote: Pick<TypertClientRemote['remoteConnection'], 'loginUrl'>, write: (text: string) => Promise<boolean>, accessAddress: () => string | null, canCopyCredential: () => boolean);
    /**
     * Bind stable actions and the shared feedback source.
     * @returns settings and shell-overlay injection values.
     */
    inject(): LoginLinkFace;
    /**
     * Read the login link before a copy gesture so HTTP clipboard fallback keeps user activation.
     * @returns after the read settles; duplicate reads share it, and a refresh waits for a clipboard write.
     */
    load(): Promise<void>;
    /** Discard the previous deployment's credential and its outstanding read when the login address changes. */
    invalidate(): void;
    /** Clear the page's credential warning without discarding clipboard outcomes or the cached URL. */
    resetCopyWarning(): void;
    /**
     * Copy the cached credential or current clean address directly from the user's gesture.
     * @returns after clipboard completion; overlapping gestures share the write, and failures remain retryable.
     */
    copy(): Promise<void>;
    /**
     * Discard the credential, stop new work, and ignore late results.
     * @returns after all admitted reads, clipboard writes, and queued refreshes settle.
     */
    dispose(): Promise<void>;
    private track;
    private writeLink;
    private read;
    private active;
}
//# sourceMappingURL=login-link-controller.d.ts.map