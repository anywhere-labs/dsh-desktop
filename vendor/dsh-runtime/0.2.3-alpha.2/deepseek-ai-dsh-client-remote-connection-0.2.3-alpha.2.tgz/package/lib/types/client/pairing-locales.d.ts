/** Copy for Remote connection settings and owner approval. */
export declare const en: {
    readonly 'pairing.title': "Pairing requests";
    readonly 'pairing.description': "Open this app on the other device and request pairing. Compare the codes before approving.";
    readonly 'pairing.permission': "Approval gives that browser full access to this app, including approving other devices.";
    readonly 'pairing.code': "Pairing code";
    readonly 'pairing.sourceIp': "Source IP";
    readonly 'pairing.sourceIpUnknown': "Unknown";
    readonly 'pairing.approve': "Approve";
    readonly 'pairing.deny': "Deny";
    readonly 'pairing.retry': "Retry";
    readonly 'pairing.loading': "Loading pairing requests";
    readonly 'pairing.readFailed': "Could not load requests. Retry to refresh the list.";
    readonly 'pairing.approved': "Request approved";
    readonly 'pairing.denied': "Request denied";
    readonly 'pairing.unavailable': "This request is no longer awaiting approval";
    readonly 'pairing.failed': "Could not confirm your decision. Refresh the list before trying again.";
};
/** Keys shared by the pairing dictionaries. */
export type PairingLocaleKey = keyof typeof en;
/** Chinese pairing copy. */
export declare const zh: Record<PairingLocaleKey, string>;
/** Japanese pairing copy. */
export declare const ja: Record<PairingLocaleKey, string>;
/** Spanish pairing copy. */
export declare const es: Record<PairingLocaleKey, string>;
/** French pairing copy. */
export declare const fr: Record<PairingLocaleKey, string>;
/** German pairing copy. */
export declare const de: Record<PairingLocaleKey, string>;
/** Russian pairing copy. */
export declare const ru: Record<PairingLocaleKey, string>;
/** Portuguese pairing copy. */
export declare const pt: Record<PairingLocaleKey, string>;
//# sourceMappingURL=pairing-locales.d.ts.map