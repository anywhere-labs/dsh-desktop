import { Service, type Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { RemoteConnectionStatus, RemoteLoginId, RemoteLoginState, RemoteLoginTicket } from './types.ts';
import type { PairingDecision, PairingDecisionResult, PairingRequestId, PairingRequestsValue } from './pairing-types.ts';
export type * from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** QR invitations, private login links, and owner-approved browser pairing. */
        remoteConnection: RemoteConnection;
    }
}
/** Deployment timing and limits for remote browser login. */
export interface Config {
    /** Absolute lifetime in days for Remote browser credentials; default 30. */
    cookieMaxAgeDays: number;
    /** Invitation lifetime in milliseconds; expiry never renews an existing browser session. */
    ticketLifetimeMs: number;
    /** Interval in milliseconds between the settings panel's status reads. */
    pollIntervalMs: number;
    /** Limits for anonymous requests and approval delivery. */
    pairing: {
        /** Lifetime in milliseconds, including retries of approved delivery. Default: 300000. */
        requestTtlMs: number;
        /** Maximum retained requests, including terminal requests until expiry. Default: 32. */
        maxRequests: number;
        /** Minimum interval between anonymous creations across this process. Default: 1000. */
        requestIntervalMs: number;
        /** Minimum applicant polling interval and periodic approval-list refresh interval. Default: 2000. */
        pollIntervalMs: number;
        /** Complete anonymous HTTP request timeout in milliseconds. Default: 10000. */
        requestTimeoutMs: number;
        /** Additional attempts after network, timeout, rate-limit, or server failures. Default: 3. */
        maxRetries: number;
        /** Maximum exponential retry delay in milliseconds; at least pollIntervalMs. Default: 10000. */
        retryMaxDelayMs: number;
    };
}
/** Owner-authorized browser login through QR codes, private links, or pairing requests. */
export default class RemoteConnection extends TypertRemoteService {
    private readonly config;
    static inject: string[];
    static Config: z<Partial<Omit<Config, 'pairing'>> & {
        pairing?: Partial<Config['pairing']>;
    }, Config>;
    private readonly tickets;
    private readonly pairing;
    private readonly owner;
    private readonly lifetime;
    private readonly pending;
    private readonly requests;
    private disposed;
    /**
     * Register anonymous login routes independently of the authenticated application page.
     * @param ctx - Host containing browser authentication, anonymous pages, and the advertised URL.
     * @param config - validated deployment limits; pairing lifetime must exceed its polling interval.
     */
    constructor(ctx: Context, config: Config);
    /** Prepare durable Remote credentials before publishing anonymous routes. */
    [Service.init](): Promise<void>;
    private get stopped();
    private readRoot;
    private tokenLoginUrl;
    /**
     * Read prerequisites and the state of one invitation without disclosing its credential.
     * @param id - invitation to inspect, or null to inspect only deployment prerequisites.
     * @returns deployment availability and invitation state, with the polling interval.
     */
    status(id: RemoteLoginId | null): RemoteConnectionStatus;
    /**
     * Authorize a new browser by generating a one-use login invitation; replaces any older invitation.
     * @returns the invitation credential and its fixed expiry.
     */
    create(): RemoteLoginTicket;
    /**
     * Read the advertised URL carrying the process launch token; QR invitations are unchanged.
     * @returns owner-only login URL, reusable until the Host process restarts; never persist or log it.
     */
    loginUrl(): string;
    /**
     * Cancel an unused invitation; this never revokes a browser session already issued.
     * @param id - invitation being cancelled; an older ID cannot cancel a replacement.
     * @returns the invitation's final state, including used when a redemption won the race.
     */
    cancel(id: RemoteLoginId): RemoteLoginState;
    /**
     * Read pending requests without the credentials used to collect their sessions.
     * @param signal - current Remote call's cancellation.
     * @returns pending codes and the deployment's refresh interval.
     */
    pairingRequests(signal: AbortSignal): PairingRequestsValue;
    /**
     * Approve or deny one displayed code; the first decision is retained across retries.
     * @param id - request selected after comparing its code with the applicant's screen.
     * @param decision - allow or deny full owner access for the requesting browser.
     * @param signal - current Remote call's cancellation before the decision commits.
     * @returns committed decision, or unavailable after cancellation, expiry, or collection.
     */
    decidePairing(id: PairingRequestId, decision: PairingDecision, signal: AbortSignal): PairingDecisionResult;
    private requireOwner;
    private loginBaseUrl;
    private deployment;
}
//# sourceMappingURL=index.d.ts.map