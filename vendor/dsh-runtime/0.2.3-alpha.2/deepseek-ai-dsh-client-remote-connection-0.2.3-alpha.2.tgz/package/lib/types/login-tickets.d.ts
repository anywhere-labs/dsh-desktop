import type { RemoteLoginId, RemoteLoginState, RemoteLoginTicket } from './types.ts';
/** One outstanding invitation; regeneration replaces it without retaining credentials. */
export declare class LoginTickets {
    private ticket;
    /**
     * Replace the outstanding invitation with a fresh random credential.
     * @param root - advertised application directory URL.
     * @param lifetimeMs - validated invitation lifetime.
     * @returns the only response carrying the plaintext credential.
     */
    create(root: string, lifetimeMs: number): RemoteLoginTicket;
    /**
     * Read an invitation without revealing its credential.
     * @param id - requested invitation, or null to read no invitation.
     * @returns current state; an identifier displaced by regeneration is replaced.
     */
    state(id: RemoteLoginId | null): RemoteLoginState;
    /**
     * Invalidate only the named invitation; stale cancellation cannot cancel a replacement.
     * @param id - invitation to cancel.
     */
    cancel(id: RemoteLoginId): void;
    /**
     * Atomically validate and consume the credential before issuing a browser session.
     * @param token - credential supplied by the anonymous HTTP exchange.
     * @returns true for its sole successful exchange; all other attempts leave it unusable or unchanged.
     */
    consume(token: string): boolean;
    /** Remove the outstanding credential when its owning plugin unloads. */
    dispose(): void;
    private expire;
}
//# sourceMappingURL=login-tickets.d.ts.map