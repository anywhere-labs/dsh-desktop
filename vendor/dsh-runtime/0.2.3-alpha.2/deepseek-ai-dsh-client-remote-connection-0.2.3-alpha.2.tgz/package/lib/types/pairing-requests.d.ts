/** Bounded, process-local requests and repeatable delivery of an approved browser Cookie. */
import type { PairingCredential, PairingDecision, PairingDecisionResult, PairingRequestId, PairingTicket, PendingPairingRequest } from './pairing-types.ts';
/** Deployment limits resolved by the plugin configuration before allocation. */
export interface PairingLimits {
    readonly requestTtlMs: number;
    readonly maxRequests: number;
    readonly requestIntervalMs: number;
    readonly pollIntervalMs: number;
}
/** State result consumed by the HTTP response owner. */
export type PairingPoll = {
    readonly status: 'pending' | 'denied' | 'cancelled' | 'expired' | 'slow-down' | 'unavailable';
} | {
    readonly status: 'completed';
    readonly cookie: string;
};
/** Owns one plugin activation's private request tickets and decisions. */
export declare class PairingRequests {
    private readonly limits;
    private readonly records;
    private nextCreationAt;
    /** @param limits - complete, validated request lifetime, capacity, and cadence. */
    constructor(limits: PairingLimits);
    /**
     * Allocate one ticket; repeating its identity returns the retained ticket without renewing it.
     * Repeated creation cannot change an existing approval, denial, cancellation, or Cookie.
     * @param authority - normalized origin accepted by WebServer admission.
     * @param sourceIp - normalized IP observed on the creating connection, or null when unavailable.
     * @param credential - browser-generated identity and secret retained before the first HTTP request.
     * @returns ticket, or undefined on a credential conflict, creation rate limit, or full pool.
     */
    create(authority: string, sourceIp: string | null, credential: PairingCredential): PairingTicket | undefined;
    /**
     * Read only pending, unexpired requests without their private credentials.
     * @returns rows the owner can approve or deny.
     */
    list(): PendingPairingRequest[];
    /**
     * Keep the first decision when owner devices race or retry after a lost response.
     * @param id - request selected after comparing the displayed code.
     * @param decision - allow or deny access as the owner.
     * @returns committed decision or unavailable for an expired, cancelled, or collected request.
     */
    decide(id: PairingRequestId, decision: PairingDecision): PairingDecisionResult;
    /**
     * Read or cancel one ticket; only approval can sign a Cookie, once per ticket.
     * A failed signer leaves the approval intact. A lost delivery can be retried with
     * the same secret until expiry, receiving the same Cookie without extending it.
     * @param id - applicant's request identity.
     * @param secret - private ticket credential, never the display code.
     * @param authority - origin of this request, which must match ticket creation.
     * @param cancel - withdraw before approved delivery completes.
     * @param issueCookie - Remote credential issuer for the current request.
     * @returns request state and, only after approval, its retained Cookie.
     */
    poll(id: PairingRequestId, secret: string, authority: string, cancel: boolean, issueCookie: () => string | undefined): PairingPoll;
    /** Remove every private ticket and retained Cookie when the plugin unloads. */
    clear(): void;
    private prune;
    private publicValue;
}
//# sourceMappingURL=pairing-requests.d.ts.map