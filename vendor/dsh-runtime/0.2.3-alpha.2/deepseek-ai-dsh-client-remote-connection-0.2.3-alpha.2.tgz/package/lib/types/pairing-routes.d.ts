/** Anonymous pairing routes admitted by the WebServer's source policy. */
import type { Context } from '@deepseek-ai/cordis';
import type { ConnectionTrustRequest } from '@deepseek-ai/dsh-client-connection';
import type { PairingRequests } from './pairing-requests.ts';
/**
 * Register public POST routes and join in-flight bodies during plugin disposal.
 * Bodies above 1KiB receive 413 and close the connection without waiting for the remaining bytes.
 * @param ctx - plugin scope carrying the HTTP listener.
 * @param requests - this activation's private request pool.
 * @param lifetime - plugin lifetime, aborted before retained requests are cleared.
 * @param issueCookie - Remote-owned credential issuer, available after initialization.
 * @returns disposer that stops and drains requests before withdrawing the routes.
 */
export declare function registerPairingRoutes(ctx: Context, requests: PairingRequests, lifetime: AbortController, issueCookie: (request: ConnectionTrustRequest) => string | undefined): () => Promise<void>;
//# sourceMappingURL=pairing-routes.d.ts.map