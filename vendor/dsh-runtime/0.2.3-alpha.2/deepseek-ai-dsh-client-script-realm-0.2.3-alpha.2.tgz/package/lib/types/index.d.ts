/** Host entry; execution environments are provided by the Client plugin. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map