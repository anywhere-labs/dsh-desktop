/** Same-origin iframe implementation of the direct-reference ScriptRealm interface. */
import { type ScriptRealm, type ScriptRealmCreateOptions, type ScriptRealmFactory, type ScriptRealmId, type ScriptRealmScript } from '@deepseek-ai/dsh-client-script-realm/client';
/** Page carrier supplying the iframe mount and script URL base. */
export interface IFrameScriptRealmOptions {
    readonly document: Document;
}
/** An isolated global environment sharing ordinary references with its owning page. */
export declare class IFrameScriptRealm implements ScriptRealm {
    private readonly frame;
    readonly window: Window;
    readonly document: Document;
    private readonly pageDocument;
    private readonly options;
    readonly id: ScriptRealmId;
    private closed;
    private disposal;
    private readonly pending;
    private readonly abort;
    constructor(frame: HTMLIFrameElement, window: Window, document: Document, pageDocument: Document, options: ScriptRealmCreateOptions);
    expose(bindings: Readonly<Record<string, unknown>>): Promise<void>;
    execute(script: ScriptRealmScript): Promise<void>;
    dispose(): Promise<void>;
    private close;
    private assertLive;
    private executionError;
}
/**
 * Capture the provider page without creating an iframe until requested.
 * @param options - Owning page document and script URL base.
 * @returns Factory creating a ready, named iframe environment.
 */
export declare function createIFrameScriptRealmFactory(options: IFrameScriptRealmOptions): ScriptRealmFactory<IFrameScriptRealm>;
//# sourceMappingURL=iframe.d.ts.map