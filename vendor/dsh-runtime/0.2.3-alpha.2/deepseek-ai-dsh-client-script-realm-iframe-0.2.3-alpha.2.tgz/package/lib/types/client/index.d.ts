/** Optional browser provider; registering it does not allocate an iframe. */
import type { Context } from '@deepseek-ai/cordis';
/** Provider plugin identity. */
export declare const name = "script-realm-iframe";
/** Provider registry supplied by the kernel Client plugin. */
export declare const inject: string[];
/**
 * Register the iframe implementation using this provider's page document.
 * @param ctx - Registry-bearing provider context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map