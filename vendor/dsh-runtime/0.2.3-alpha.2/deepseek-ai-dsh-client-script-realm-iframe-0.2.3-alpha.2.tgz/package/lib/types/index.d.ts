/** Host entry for the optional browser iframe ScriptRealm provider. */
/** The iframe implementation has no Host-side behavior. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map