---
description: "可选操作卡片的浏览器端：已完成回答下方的卡片框架、供各卡片种类包填入的正文注册表，以及隐藏提供卡片的 action-card 代码块的层。"
kind: "package-reference"
---

# @deepseek-ai/dsh-client-ui-action-cards

[English](README.md) | 中文

## 概述

用户在已完成的回答下方看到一张可选操作卡片：标题、过长时会折叠的说明，以及提议该卡片的功能所提供的控件。回答里提供卡片的 `action-card` 代码块从不显示。如果实验在当前浏览器中没有提供控件，或者控件读不了卡片的字段，卡片只提供“暂不需要”。展示、展开和折叠卡片都不会发起模型请求。

## 目录

- [使用本包](#use-this-package)
- [实现原理](#understand-the-implementation)
- [延伸阅读](#further-exploration)
- [模型体验](#model-experience)
- [已知限制与后续工作](#known-limitations-and-deferred-work)
- [开发备注](#dev-note)

-----

<a id="use-this-package"></a>
## 使用本包

Web 组合（[`dsh-web-app`](../../bundle/web-app/README.zh.md)）会在本包旁挂载对应的 [Host 服务](../../interaction/action-cards/README.zh.md)。本浏览器组件没有配置字段。它在“设置 → 通用设置”中加入“个性化推荐”开关，写入 Host 服务的 `enabled` 字段。

### 注册卡片正文

种类的浏览器插件注入 `actionCards`，并在自己的 `ctx.effect` 中注册正文：`ctx.actionCards.register({ action, locale, Body })` 返回注销函数。框架为该动作的卡片渲染 `Body`，并传入：卡片、最新的已记录决定、会话 id、框架渲染的标题与折叠说明 `summary`、只提供“暂不需要”的后备内容 `fallback`、框架的折叠组件 `Folded`、绑定到该卡片的 `act(verb, payload?)`，以及正文自己语言命名空间的翻译函数 `t`。正文把 `summary` 放进自己的布局，卡片的 `details` 未通过自己的校验时改为渲染 `fallback`，并负责自己的标题栏、控件、状态和底部操作。为同一动作注册第二个正文属于注册错误。

-----

<a id="understand-the-implementation"></a>
## 实现原理

<details>
<summary>实现细节——点击展开</summary>

一个 `conversation.chat.turnTail` 条目读取 `actionCards` 会话投影，在某一轮以最终回答结束后展示该轮接受的卡片；没有回答文本就结束的轮次不显示卡片，若同一轮有多张卡片，显示卡片 id 最小的一张。框架把 `data-action-card` 设为卡片 id，并以卡片标题命名所在区域。折叠时，宽字素（如汉字）按两个拉丁字母宽度计算，约 260 个单位后折叠；折叠不测量布局，也不改动完整文本。

一个以 `action-card` 为键的 `conversation.chat.markdown.fence` 层不渲染任何内容，因此 Chat 流中凡是渲染 Markdown 的地方，这类代码块都被隐藏：包括回答、思考内容和压缩摘要中的代码块，以及 Host 没有收下的代码块。插件在顶层提供正文注册表，并在同一生命周期内注册词典和插槽条目；`actionCards` Remote 由 [`api-remotes`](../../api/remotes/README.zh.md) 挂载。通用设置里的开关行在 Host 提供 `action-cards` 配置时存在，显示已接受的 `enabled` 值；写入被拒绝或失败时保留原值并提示错误。

| 源码 | 内容 |
|---|---|
| [`src/client/mount.ts`](src/client/mount.ts) | 注册表、词典与插槽条目 |
| [`src/client/SettingsRow.tsx`](src/client/SettingsRow.tsx) | 通用设置开关 |
| [`src/client/Card.tsx`](src/client/Card.tsx) | 轮次尾部、框架、折叠、后备正文与代码块显示层 |
| [`src/client/registry.ts`](src/client/registry.ts) | 正文注册表与正文属性 |
| [`tests/`](tests/) | 位置、框架、后备正文、代码块与注册测试 |

</details>

-----

<a id="further-exploration"></a>
## 延伸阅读

- [操作卡片](../../interaction/action-cards/README.zh.md) — 框架背后的卡片代码块、卡片状态与用户操作。
- [个性化页面卡片](../ui-creation-recommendations/README.zh.md)和[推荐卡片](../ui-plugin-recommendations/README.zh.md) — 随产品提供的卡片正文。
- [插槽](../ui-slots/README.zh.md) — 轮次尾部与 Markdown 代码块层的注册。

<a id="model-experience"></a>
## 模型体验

间接影响来自 Host 卡片服务：卡片操作以 Remote 调用到达该服务，由它负责从回答中读出的卡片提议、决定和状态通知。

#### KV Cache 影响

渲染卡片、隐藏代码块不会改变任何模型请求。

## 已知限制与后续工作

<a id="known-limitations-and-deferred-work"></a>

- 动作没有注册正文的卡片只提供“暂不需要”，该功能的其他操作需要它的浏览器插件。即使该功能的 Host 插件已关闭，“暂不需要”仍然可用。
- 轮次尾部每轮只显示一张卡片，与 Host 每轮一张卡片的规则一致。

<a id="dev-note"></a>
### 开发备注

<details>
<summary>维护者工作背景——点击展开</summary>

无。

</details>
