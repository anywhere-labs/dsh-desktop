import type { ConfigFormSnapshot } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { HostObservable, InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** The Host `action-cards` field this row edits. */
export interface CardSettings {
    enabled: boolean;
}
/** Accepted settings and the writer supplied by the plugin. */
export interface SettingsRowInjected {
    hooks: {
        cardSettings: HostObservable<ConfigFormSnapshot<CardSettings>>;
    };
    /**
     * Write the switch.
     * @param enabled - requested value.
     * @returns whether the Host accepted it; transport failures reject.
     */
    setEnabled(enabled: boolean): Promise<boolean>;
}
/**
 * Render the accepted value; a refused or failed write keeps it and shows an error.
 * @param props - settings hook, writer and localized copy.
 * @returns the General settings row.
 */
export declare function SettingsRow({ useCardSettings, setEnabled, t }: PropsRuntime<'settings.general.item'> & PropsLocale<'actionCards'> & InjectFace<SettingsRowInjected>): import("react").JSX.Element;
//# sourceMappingURL=SettingsRow.d.ts.map