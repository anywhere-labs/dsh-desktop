/** Register the card frame, the hidden answer block, the General settings switch, their copy and the body registry. */
import type { Context } from '@deepseek-ai/cordis';
import { ActionCardRegistry } from './registry.ts';
import { type ActionCardKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        actionCards: ActionCardKey;
    }
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Card bodies by action kind; kinds register theirs inside their own `ctx.effect`. */
        actionCards: ActionCardRegistry;
    }
}
/** Required services (cordis fiber inject). */
export declare const inject: string[];
/**
 * Provide the body registry and register the UI for the plugin lifetime.
 * @param ctx - Client plugin context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=mount.d.ts.map