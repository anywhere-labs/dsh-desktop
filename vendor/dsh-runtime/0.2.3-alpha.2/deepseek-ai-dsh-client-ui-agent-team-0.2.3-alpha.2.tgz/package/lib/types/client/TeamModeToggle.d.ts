/** Session-owned Agent Teams summary and settings inside the model menu. */
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { NS } from './locales.ts';
/** Session selection callbacks supplied to the Team settings pane. */
export interface TeamModePaneInjected {
    /** Save the selection; null means success, otherwise the string describes the failure. */
    selectTeamMode: (enabled: boolean) => Promise<string | null>;
    /** Open a Session-targeted confirmation outside this menu. */
    requestDisableConfirmation: () => void;
}
/** Full props of the model-menu Team summary. */
export type TeamModeToggleProps = PropsRuntime<'conversation.input.model.options'> & PropsLocale<typeof NS>;
/** Full props of the model-menu Team settings pane. */
export type TeamModePaneProps = PropsRuntime<'conversation.input.model.pane'> & PropsLocale<typeof NS> & TeamModePaneInjected;
/**
 * Show the saved Team state and open its settings without changing the mode.
 * @param props - Session projection, pane navigation, and locale.
 * @returns the summary when Team mode is available on a root Session.
 */
export declare function TeamModeToggle(props: TeamModeToggleProps): import("react").JSX.Element | null;
/**
 * Present the explanation and persisted Team switch for a root Session.
 * @param props - Session projections, mode operations, menu dismissal, and locale.
 * @returns the Team settings content when its projection is available.
 */
export declare function TeamModePane(props: TeamModePaneProps): import("react").JSX.Element | null;
//# sourceMappingURL=TeamModeToggle.d.ts.map