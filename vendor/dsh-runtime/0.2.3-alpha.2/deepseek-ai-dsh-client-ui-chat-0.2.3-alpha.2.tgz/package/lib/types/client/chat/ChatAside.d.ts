import type { PropsRenderSlots } from '@deepseek-ai/dsh-client-ui-slots';
/**
 * Render the aside layer with its occupant. The Chat View's `renderSlot` is
 * stable per registration, so the layer renders once and transcript updates
 * do not re-render it; its geometry is CSS only.
 * @param props - the Chat View's slot renderer.
 * @returns the zero-height aside layer.
 */
export declare const ChatAside: import("react").MemoExoticComponent<({ renderSlot }: Pick<PropsRenderSlots<"conversation.chat.aside">, "renderSlot">) => import("react").JSX.Element>;
//# sourceMappingURL=ChatAside.d.ts.map