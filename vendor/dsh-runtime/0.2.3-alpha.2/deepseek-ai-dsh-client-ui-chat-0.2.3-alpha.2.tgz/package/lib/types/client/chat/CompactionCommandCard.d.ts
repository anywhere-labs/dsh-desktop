import type { ChatViewSlotProps, CommandRowOwnerProps } from '../contract/slots.ts';
import { type CompactionRowInjected } from './CompactionItem.tsx';
interface CompactionCommandCardProps extends CommandRowOwnerProps {
    openCompaction: CompactionRowInjected['openCompaction'] | undefined;
    t: ChatViewSlotProps['t'];
}
/** Render one manual compaction lifecycle without duplicating its checkpoint marker. */
export declare function CompactionCommandCard({ node, compaction, openCompaction, t }: CompactionCommandCardProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=CompactionCommandCard.d.ts.map