import type { Context } from '@deepseek-ai/cordis';
import type { CompactionSummaryNode, ConversationMatch, ConversationNodeDefinition } from '@deepseek-ai/dsh-client-ui-conversation/client';
declare module '../contract/chat-nodes.ts' {
    interface ChatNodeDataMap {
        /** Automatic compaction progress or committed checkpoint. */
        compaction: CompactionSummaryNode | CompactionProgress;
    }
}
/** Progress without a committed summary; terminal states never animate. */
export type CompactionProgress = {
    readonly kind: 'compaction-progress';
} & ({
    readonly status: 'running';
} | {
    readonly status: 'interrupted';
} | {
    readonly status: 'ended';
    readonly error?: string;
});
interface CompactionState {
    readonly ended?: ConversationMatch;
    readonly summary?: ConversationMatch;
    readonly checkpoint?: ConversationMatch;
}
/** Automatic compaction lifecycle and landed checkpoint Definition. */
export declare const compactionDefinition: ConversationNodeDefinition<CompactionState>;
/**
 * Register the automatic-compaction business contribution.
 * @param ctx - owning UI Conversation context.
 */
export declare function registerCompactionConversationNode(ctx: Context): void;
export {};
//# sourceMappingURL=compaction.d.ts.map