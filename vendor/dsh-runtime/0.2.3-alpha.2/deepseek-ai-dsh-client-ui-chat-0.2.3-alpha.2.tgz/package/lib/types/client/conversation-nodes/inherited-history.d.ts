import type { Context } from '@deepseek-ai/cordis';
import type { ConversationNodeDefinition } from '@deepseek-ai/dsh-client-ui-conversation/client';
declare module '../contract/chat-nodes.ts' {
    interface ChatNodeDataMap {
        /** Divider after the history a seeded Session inherited; the Node's anchor is the marker seq. */
        'inherited-history': Record<never, never>;
    }
}
/**
 * One divider at the latest inherited `session/end-seed` marker in the loaded
 * window. Ordered Context matches supply its position, including after older
 * pages load. A cut inside a Turn stays outside that Turn's process disclosure.
 */
export declare const inheritedHistoryDefinition: ConversationNodeDefinition<null>;
/**
 * Register the inherited-history divider contribution.
 * @param ctx - owning UI Conversation context.
 */
export declare function registerInheritedHistoryConversationNode(ctx: Context): void;
//# sourceMappingURL=inherited-history.d.ts.map