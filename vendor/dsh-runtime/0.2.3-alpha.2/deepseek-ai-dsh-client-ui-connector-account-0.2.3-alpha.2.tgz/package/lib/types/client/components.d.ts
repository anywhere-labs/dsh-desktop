/**
 * The account surfaces the Plugins page shows for registered connector accounts: a bundle's section with the
 * confirmation a button asks for, the title tag, the activation prompt, and the notice. Each is the slot entry that reads
 * this browser's state and calls the Host through the injected callbacks.
 */
import { type ReactNode } from 'react';
import type { InjectFace, PropsRuntime, Translate } from '@deepseek-ai/dsh-client-ui-slots';
import type { ConnectorAccountKey } from './locales.ts';
import type { ConnectorAccountFace, ConnectorBundleAccountFace } from './types.ts';
type FaceProps = InjectFace<ConnectorAccountFace> & {
    t: Translate<ConnectorAccountKey>;
};
type BundleFaceProps = InjectFace<ConnectorBundleAccountFace> & {
    t: Translate<ConnectorAccountKey>;
};
/**
 * The `plugins.bundle.config` entry: the account section on its bundle's page.
 * @param props - the bundle's face and the translator.
 * @returns the title, status line, buttons, detail, notes, failure, hint, and the confirmation a button asked for, or
 *   null before the Host lists the account.
 */
export declare function ConnectorAccountSectionEntry(props: BundleFaceProps): ReactNode;
/**
 * The `plugins.detail.badge` entry shared by every bundle that owns an account.
 * @param props - the open detail page's subject and the face.
 * @returns the display's tag on the page of an enabled bundle that owns an account, or of one of its rows, or null.
 */
export declare function ConnectorAccountBadgeEntry(props: FaceProps & Pick<PropsRuntime<'plugins.detail.badge'>, 'subject'>): ReactNode;
/**
 * The `plugins.bundle.activation` entry: guidance after the user switches a bundle on while its account is not
 * connected. Connect opens the bundle page and starts the display's `connect` command.
 * @param props - activation callbacks, the bundle's face, and the translator.
 * @returns a prompt shown while disconnected, or null before the Host lists the account. It waits while the account is
 *   checking or connecting, which may still end disconnected, and dismisses itself once the account is connected or
 *   unavailable.
 */
export declare function ConnectorAccountActivationEntry(props: BundleFaceProps & Pick<PropsRuntime<'plugins.bundle.activation'>, 'onDismiss' | 'onOpenDetails'>): ReactNode;
/**
 * The `shell.overlay` entry: account outcomes reported outside the Plugins panel's lifetime.
 * @param props - the face and the translator.
 * @returns the toast for the latest notice, or null.
 */
export declare function ConnectorAccountToastEntry({ useConnectorAccounts, resolveText, dismissNotice, t }: FaceProps): ReactNode;
export {};
//# sourceMappingURL=components.d.ts.map