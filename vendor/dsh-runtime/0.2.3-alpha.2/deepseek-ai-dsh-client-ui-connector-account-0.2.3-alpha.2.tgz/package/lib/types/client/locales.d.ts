/** Dictionary namespace of the shared account copy. */
export declare const NS = "connectorAccount";
/** Chinese dictionary and key source. */
export declare const zh: {
    close: string;
    'action.cancel': string;
    'activation.later': string;
    'failure.details': string;
    'notice.action-failed': string;
};
/** Every key the shared account surfaces translate. */
export type ConnectorAccountKey = keyof typeof zh;
/** English dictionary. */
export declare const en: Record<ConnectorAccountKey, string>;
/** Japanese dictionary. */
export declare const ja: Record<ConnectorAccountKey, string>;
/** Spanish dictionary. */
export declare const es: Record<ConnectorAccountKey, string>;
/** French dictionary. */
export declare const fr: Record<ConnectorAccountKey, string>;
/** German dictionary. */
export declare const de: Record<ConnectorAccountKey, string>;
/** Russian dictionary. */
export declare const ru: Record<ConnectorAccountKey, string>;
/** Portuguese dictionary. */
export declare const pt: Record<ConnectorAccountKey, string>;
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        connectorAccount: ConnectorAccountKey;
    }
}
//# sourceMappingURL=locales.d.ts.map