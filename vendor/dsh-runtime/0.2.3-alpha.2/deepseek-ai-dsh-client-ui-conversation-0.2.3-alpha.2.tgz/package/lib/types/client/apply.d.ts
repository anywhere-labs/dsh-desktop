import type { Context } from '@deepseek-ai/cordis';
import type { SyncedConfig } from '@deepseek-ai/dsh-client-config/types';
import type { ConversationConfig } from '../types.ts';
import { type ConversationKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Conversation shell, composer, queue, and dock copy. */
        conversation: ConversationKey;
    }
}
/**
 * Services required by the Conversation plugin. `uiSession.sessionStatus` provides the `useSessionStatus` hook the
 * Conversation shell renders with, so the plugin unloads and reloads with it.
 */
export declare const inject: string[];
/**
 * Mount the Conversation core and target-neutral presentation.
 * @param ctx - Client root context.
 * @param config - Host-synced live configuration.
 */
export declare function apply(ctx: Context, config: SyncedConfig<ConversationConfig>): void;
//# sourceMappingURL=apply.d.ts.map