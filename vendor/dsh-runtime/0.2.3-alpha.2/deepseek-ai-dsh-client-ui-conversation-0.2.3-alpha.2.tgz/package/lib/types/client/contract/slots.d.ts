/** Target-neutral Conversation slot declarations and composed component props. */
import type { ReactNode, RefObject } from 'react';
import type { FileAttachmentRef, ImageAttachmentRef } from '@deepseek-ai/dsh-attachment';
import type { SessionSnapshot } from '@deepseek-ai/dsh-api-session-controller/client';
import type { FileUploadReceiptId } from '@deepseek-ai/dsh-client-file-upload/client';
import type { ImageLightboxLabels } from '@deepseek-ai/dsh-client-ui-primitives';
import type { WorkspaceSnapshot } from '@deepseek-ai/dsh-api-workspace-controller/client';
import type { MaybeSnapshotSelectorHook, ObservableSnapshot, SnapshotSelectorHook } from '@deepseek-ai/dsh-client-store';
import type { ChildrenDecl, FactoryComponentPropsOf, FactoryLocalComponentPropsOf, InjectFace, PropsLocale, PropsRenderFactories, PropsRenderSlots, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionPendingInteraction } from '@deepseek-ai/dsh-client-ui-session/client';
import type { SessionId, SessionSeq } from '@deepseek-ai/dsh-session/types';
import type { WorkspaceId } from '@deepseek-ai/dsh-workspace/types';
import type { ComposerBlock } from './composer-blocks.ts';
import type { DraftAttachmentId, InputActions, InputNotice, InputState } from './input.ts';
import type { ComposerKeyboard, DraftSnapshot, EditSelection } from './draft-editor.ts';
import type { createConversationStore } from '../stores.ts';
import type { BusyEnterBehavior } from './composer-submission.ts';
import type { ConversationSnapshot } from './snapshot.ts';
import type { ViewTab } from './views.ts';
import type { UserTextDocumentInput, UserTextEvaluator, UserTextId, UserTextNode } from './user-text.ts';
declare module '@deepseek-ai/dsh-client-ui-context-menu/client' {
    interface ContextMenuTargetMap {
        /** Session Header More menu, independent of Session-row and title context actions. */
        sessionHeader: {
            readonly sessionId: SessionId;
        };
    }
}
/** Browser-owned draft attachment that has not crossed the durable Host boundary. */
export type ComposerAttachment = ComposerImageAttachment | ComposerFileAttachment;
/**
 * Browser-owned image. An ordinary Session's draft uploads it to the Host as
 * soon as it is added, and the prompt cites the receipt; a subagent
 * continuation's draft base64-encodes it into the prompt at send time.
 */
export interface ComposerImageAttachment {
    kind: 'image';
    id: DraftAttachmentId;
    file: File;
    previewUrl: string;
    /** Intrinsic pixel width, filled asynchronously by the intake header probe. */
    width?: number;
    /** Intrinsic pixel height, filled asynchronously by the intake header probe. */
    height?: number;
}
/** Browser-owned generic file whose bytes upload to the Host as soon as it is picked. */
export interface ComposerFileAttachment {
    kind: 'file';
    id: DraftAttachmentId;
    file: File;
}
/**
 * Upload lifecycle of one draft that uploads when it is added, not on send:
 * every file draft, and every image draft of an ordinary Session. A failed
 * upload the Host refused keeps the attachment refusal `reason`, because
 * retrying the same bytes cannot succeed.
 */
export type DraftFileUpload = {
    readonly status: 'uploading';
    readonly loaded: number;
    readonly total?: number;
} | {
    readonly status: 'ready';
    readonly receiptId: FileUploadReceiptId;
    readonly file: FileAttachmentRef;
} | {
    readonly status: 'ready';
    readonly receiptId: FileUploadReceiptId;
} | {
    readonly status: 'error';
    readonly message: string;
    readonly reason?: string;
};
/** Per-draft upload states keyed by draft attachment id. */
export type DraftFileUploads = Readonly<Record<string, DraftFileUpload>>;
/** Input state handed to the optional attachment presentation plugin. */
export interface ComposerAttachmentsOwnerProps {
    /** Browser-owned draft attachments in input order. */
    attachments: readonly ComposerAttachment[];
    /** Whether a document-level file drop may add attachments now. */
    canAcceptDrop: boolean;
    /**
     * Add one dropped batch through the composer's validation path.
     * @param files - dropped, pasted, or picked browser files in source order.
     * @param directories - members of `files` the drop source identified as directories.
     */
    onAddFiles: (files: readonly File[], directories?: ReadonlySet<File>) => void;
    /** Remove one draft attachment through the Conversation service. */
    onRemoveAttachment: (id: DraftAttachmentId) => void;
    /** Current per-draft upload states for file-kind attachments. */
    uploads: DraftFileUploads;
    /** Restart one failed file upload. */
    onRetryFile: (id: DraftAttachmentId) => void;
    /**
     * Explain one upload the Host refused; such a draft cannot be retried and
     * stays until it is removed.
     * @param reason - the refusal `reason` the failed upload carries.
     * @returns localized text naming the limit or the way out.
     */
    uploadFailureText: (reason: string) => string;
    /** Display-ready limits for the drop invitation. */
    dropLimits?: {
        readonly count: number;
        readonly size: string;
    } | undefined;
}
/**
 * One image inside a message record: a durable admitted reference, or the
 * local preview of a submission echo whose admission is still in flight.
 */
export type MessageImageSource = {
    readonly attachment: ImageAttachmentRef;
    /** Presentation-only name for the thumbnail and lightbox; loading uses the original reference. */
    readonly label?: string;
} | {
    readonly preview: {
        /** Browser-owned preview URL (lifecycle stays with the submitter). */
        readonly url: string;
        readonly name?: string;
        /** Intrinsic pixel width, when the intake probe has resolved it. */
        readonly width?: number;
        /** Intrinsic pixel height, when the intake probe has resolved it. */
        readonly height?: number;
    };
};
/** Durable image loader with an optional synchronous cache read. */
export type MessageImageLoader = ((attachment: ImageAttachmentRef) => Promise<string>) & {
    peek?: (attachment: ImageAttachmentRef) => string | undefined;
};
/** Message image group handed to the optional attachment presentation plugin. */
export interface MessageImagesOwnerProps {
    /** Durable references or submission-echo previews in source order. */
    images: readonly MessageImageSource[];
    /** Gateway-authorized image URL loader for the durable arm. */
    loadImage: MessageImageLoader;
    /** Horizontal placement inside the owning record. */
    align: 'start' | 'end';
    /** Force every image into the compact message-attachment tile size. */
    compact?: boolean;
    /** Fixed, uncropped thumbnail for an attachment list row. */
    thumbnail?: boolean;
}
/** Message-image strings the owner resolves from its own locale namespace. */
export interface MessageImageLabels {
    /** Fallback display name for an unnamed image. */
    image: string;
    /** Thumbnail tooltip inviting the original-image preview. */
    open: string;
    /** Accessible thumbnail label; receives the image's display name. */
    openNamed: (label: string) => string;
    /** Loading placeholder shown until bytes resolve. */
    loading: string;
    /** Retry-control label shown when the load fails. */
    loadFailed: string;
    /** Lightbox strings forwarded to the opened preview. */
    lightbox: ImageLightboxLabels;
}
/** Root-scoped image gallery input with explicit reading authority and optional caller copy. */
export interface MessageImagesContentInput extends MessageImagesOwnerProps {
    readonly labels?: MessageImageLabels;
}
/** Transform inputs and independently controlled rendering behavior. */
export interface UserTextInput extends UserTextDocumentInput {
    /** Enable renderer-owned reference actions; omitted values keep references read-only. */
    readonly interactive?: boolean;
    /** Use CSS single-line overflow ellipsis without shortening source text. */
    readonly ellipsis?: boolean;
}
/** Rule invalidation and document evaluation supplied by the data layer. */
export interface UserTextInjected {
    hooks: {
        userTextRevision: ObservableSnapshot<number>;
    };
    /** Each invocation creates a caller-owned data-layer cache without registry subscriptions. */
    createUserTextEvaluator: () => UserTextEvaluator;
    /** Report a failed rule while the original text remains visible. */
    reportTransformFailure: (error: unknown) => void;
}
/** JSON-only owner data common to every business text node. */
export interface UserTextNodeOwnerProps {
    readonly raw: string;
    readonly interactive: boolean;
}
/** Complete props for the selected business node, including its Session scope. */
export type UserTextNodeProps<Id extends UserTextId = UserTextId> = PropsRuntime<'conversation.user.text.node', Id>;
/** Selector hook over the current Session's assembled Conversation. */
export type UseConversation = SnapshotSelectorHook<ConversationSnapshot>;
/** Selector hook over the registered Conversation View roster. */
export type UseConversationViews = SnapshotSelectorHook<readonly ViewTab[]>;
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface SlotFactoryMap {
        /** Parse one original text and render its business nodes through the owned keyed Slot. */
        'conversation.user.text': {
            scope: 'session';
            props: UserTextInput;
            inject: UserTextInjected;
            children: {
                'conversation.user.text.node': {
                    kind: 'keyed';
                    scope: 'session';
                    inline: true;
                };
            };
        };
        /** Official reusable gallery, with explicit authorized loading and optional caller copy. */
        'conversation.images.content': {
            scope: 'root';
            props: MessageImagesContentInput;
            inject: {
                readonly fileDrag: import('@deepseek-ai/dsh-client-ui-primitives').FileDragActions;
            };
            locale: 'conversation';
        };
    }
    interface SlotMap {
        /** One business-owned inline renderer for a pure JSON text node. */
        'conversation.user.text.node': {
            kind: 'keyed';
            scope: 'session';
            inline: true;
            owner: UserTextNodeOwnerProps;
            keyProps: {
                [Id in UserTextId]: {
                    node: UserTextNode<Id>;
                };
            };
        };
        /** Conversation shell beneath its root-scoped main-panel entry. */
        'main.conversation': {
            kind: 'single';
            scope: 'session-maybe';
            inject: ConversationShellInjected;
        };
        /** Strict per-Session Conversation body. */
        'conversation.session': {
            kind: 'single';
            scope: 'session';
            owner: {
                view?: string;
            };
        };
        /** Resident navigation container, including when no Session is selected. */
        'conversation.header': {
            kind: 'single';
            scope: 'session-maybe';
        };
        /** Strict per-Session title, actions, and View navigation. */
        'conversation.session.header': {
            kind: 'single';
            scope: 'session';
            owner: {
                /** Parent-owned visibility shared with the header container styling. */
                hideChrome: boolean;
            };
        };
        /** Optional replacement for one Session breadcrumb title; overlays must portal because the title area clips overflow. */
        'conversation.session.header.lineage': {
            kind: 'single';
            scope: 'session';
            owner: ConversationHeaderLineageOwnerProps;
        };
        /** Title-adjacent Session actions in ascending order; overflow is clipped and faded before the utilities, so overlays must portal. */
        'conversation.session.header.actions': {
            kind: 'list';
            scope: 'session';
            owner: ConversationHeaderActionOwnerProps;
        };
        /** Right-aligned Session utilities in ascending order. */
        'conversation.session.header.utilities': {
            kind: 'list';
            scope: 'session';
            owner: ConversationHeaderActionOwnerProps;
        };
        /** Global navigation before the Session title, available without a Session. */
        'conversation.header.leading': {
            kind: 'single';
            scope: 'root';
            owner: ConversationHeaderLeadingOwnerProps;
        };
        /**
         * The header's far-right corner, past the utilities' edge and into the
         * header's own padding, for one control. The corner is laid out only while
         * its occupant renders something; an occupant with nothing to show renders
         * nothing, and the utilities take the header's edge.
         */
        'conversation.session.header.corner': {
            kind: 'single';
            scope: 'session';
            owner: ConversationHeaderCornerOwnerProps;
        };
        /** Rows of the View tab row's More menu; the header shows More only while this list has registrations. */
        'conversation.session.header.views.actions': {
            kind: 'list';
            scope: 'root';
            owner: ConversationViewActionsOwnerProps;
        };
        /** Registered Conversation target Views, rendered one at a time. */
        'conversation.view': {
            kind: 'list';
            scope: 'session';
            owner: ConvViewOwnerProps;
        };
        /**
         * Selector-routed replacements for the current Session's resident composer; fixed overlays must
         * portal to the document body because the docked composer contains them.
         */
        'conversation.composer': {
            kind: 'chain';
            scope: 'session';
            owner: ComposerChainProps;
        };
        /** Workspace picker shown by the blank-session Hero. */
        'conversation.hero.workspace': {
            kind: 'single';
            scope: 'root';
            owner: EmptyWorkspaceOwnerProps;
        };
        /** Layers wrapping the Conversation scroll body; `hero` reports a blank, standalone home. */
        'conversation.hero.frame': {
            kind: 'hoc';
            scope: 'root';
            owner: HeroFrameOwnerProps;
        };
        /** Brand mark shown before the blank-session headline. */
        'conversation.hero.brand.mark': {
            kind: 'single';
            scope: 'root';
            owner: HeroBrandMarkOwnerProps;
        };
        /** Agent-preset control staged for a New Session. */
        'conversation.hero.agentPreset': {
            kind: 'single';
            scope: 'session-maybe';
            owner: HeroAgentPresetOwnerProps;
        };
        /** Compact options right-aligned in the New Session row after the workspace and preset controls; rendered only with a Session. */
        'conversation.hero.options': {
            kind: 'list';
            scope: 'session';
        };
        /**
         * Full-width entries above the composer card; fixed overlays must portal to the document body
         * because the docked composer contains them.
         */
        'conversation.input.dock': {
            kind: 'list';
            scope: 'session';
            owner: InputZone;
        };
        /**
         * Floating entries rendered inside the resident composer card; fixed overlays must portal to
         * the document body because the docked composer contains them.
         */
        'conversation.input.overlay': {
            kind: 'list';
            scope: 'session';
        };
        /**
         * Ambient entries below the composer card; fixed overlays must portal to the document body
         * because the docked composer contains them.
         */
        'conversation.composer.dock': {
            kind: 'list';
            scope: 'session';
        };
        /**
         * Compact controls at the left of the composer tool row; fixed overlays must portal to the
         * document body because the docked composer contains them.
         */
        'conversation.input.left': {
            kind: 'list';
            scope: 'session';
        };
        /**
         * Compact controls before the composer submit action; fixed overlays must portal to the
         * document body because the docked composer contains them.
         */
        'conversation.input.right': {
            kind: 'list';
            scope: 'session';
        };
        /**
         * Compact action after the model selector; it can expand across the toolbar while retaining the
         * editor and submit action, and fixed overlays must portal to the document body because the
         * docked composer contains them.
         */
        'conversation.input.activity': {
            kind: 'single';
            scope: 'session';
            owner: InputActivityOwnerProps;
        };
        /**
         * Resident composer body, including the no-Session inert state; fixed overlays must portal to
         * the document body because the docked composer contains them.
         */
        'conversation.composer.bar': {
            kind: 'single';
            scope: 'session-maybe';
            owner: ComposerBarOwnerProps;
        };
        /**
         * Select by Session id to show noninteractive inline guidance in the built-in empty editor.
         * Its text names the textbox. When every selector declines, the editor shows its built-in prompt.
         */
        'conversation.input.placeholder': {
            kind: 'chain';
            scope: 'session';
            inline: true;
            owner: InputPlaceholderOwnerProps;
        };
        /**
         * Optional draft-attachment rail and drop target; fixed overlays must portal to the document
         * body because the docked composer contains them.
         */
        'conversation.input.attachments': {
            kind: 'single';
            scope: 'session-maybe';
            owner: ComposerAttachmentsOwnerProps;
        };
        /**
         * Plan control inside the composer tool row; fixed overlays must portal to the document body
         * because the docked composer contains them.
         */
        'conversation.input.plan': {
            kind: 'single';
            scope: 'session';
            owner: InputControlOwnerProps;
        };
        /**
         * Current-session permission control inside the composer tool row; fixed overlays must portal
         * to the document body because the docked composer contains them.
         */
        'conversation.input.permission': {
            kind: 'single';
            scope: 'session';
            owner: InputControlOwnerProps;
        };
        /**
         * Model selector inside the composer tool row. When expanded controls cannot
         * share a line, the row sets --dsh-composer-model-text-display to none and
         * --dsh-composer-model-icon-display to block for an occupant's compact display.
         * Fixed overlays must portal to the document body because the docked composer contains them.
         */
        'conversation.input.model': {
            kind: 'single';
            scope: 'session';
            owner: InputControlOwnerProps;
        };
    }
    interface SlotFactoryMap {
        /** Reusable Conversation content instantiated by presentation hosts. */
        'conversation.content': {
            scope: 'session-maybe';
            props: ConversationContentInputProps;
            children: {
                'conversation.session': {
                    kind: 'single';
                    scope: 'session';
                };
                'conversation.composer': {
                    kind: 'chain';
                    scope: 'session';
                };
                'conversation.composer.bar': {
                    kind: 'single';
                    scope: 'session-maybe';
                };
                'conversation.input.dock': {
                    kind: 'list';
                    scope: 'session';
                };
                'conversation.hero.frame': {
                    kind: 'hoc';
                    scope: 'root';
                };
                'conversation.hero.brand.mark': {
                    kind: 'single';
                    scope: 'root';
                };
                'conversation.hero.workspace': {
                    kind: 'single';
                    scope: 'root';
                };
                'conversation.hero.agentPreset': {
                    kind: 'single';
                    scope: 'session-maybe';
                };
                'conversation.hero.options': {
                    kind: 'list';
                    scope: 'session';
                };
            };
            inject: ConversationInjected;
            locale: 'conversation';
            slots: {
                views: {
                    scope: 'session';
                };
                widthControls: {
                    scope: 'root';
                    props: ConversationWidthControlsInputProps;
                };
            };
        };
    }
    interface GlobalStandardProps {
        /** Workspace selector supplied by the independently loaded Workspace UI. */
        useWorkspaces: SnapshotSelectorHook<WorkspaceSnapshot>;
    }
    interface SessionStandardProps {
        /** Selector hook over target-neutral Conversation assembly. */
        useConversation: UseConversation;
        /** Selector hook over the Session input machine. */
        useInput: SnapshotSelectorHook<InputState>;
        /** Stable public input actions for this Session. */
        inputActions: InputActions;
    }
    interface SessionMaybeStandardProps {
        /** Selector hook whose values are absent without a current Session. */
        useConversation: MaybeSnapshotSelectorHook<ConversationSnapshot>;
        /** Input values are absent without a current Session. */
        useInput: MaybeSnapshotSelectorHook<InputState>;
        /** Input actions are absent without a current Session. */
        inputActions: InputActions | undefined;
    }
}
/** Owner share of the Hero agent-preset control. */
export interface HeroAgentPresetOwnerProps {
    /** Marker field: the occupant owns its roster and staged selection. */
    children?: never;
}
/** Header actions derive their state from standard Session props. */
export interface ConversationHeaderActionOwnerProps {
    /** Marker field: entries receive no owner-specific values. */
    children?: never;
}
/** The header corner's occupant derives its state from standard Session props. */
export interface ConversationHeaderCornerOwnerProps {
    /** Marker field: the occupant receives no owner-specific values. */
    children?: never;
}
/** The leading seat exposes global navigation independently of a Session. */
export interface ConversationHeaderLeadingOwnerProps {
    /** Marker field: the occupant receives no owner-specific values. */
    children?: never;
}
/** Plain breadcrumb data handed to the optional lineage renderer. */
export interface ConversationHeaderLineageOwnerProps {
    /** Session represented by this breadcrumb title. */
    lineageSessionId: SessionId;
    /** Display title available to a combined title/control renderer. */
    displayTitle: string;
    /** Navigate to an ancestor title when present. */
    openTitle?: () => void;
}
/** Point-in-time owner values for composer extension entries. */
export interface InputZone {
    readonly session: SessionSnapshot;
    readonly input: InputState;
}
/** Conversation View entries obtain their data from registered standard hooks. */
export interface ConvViewOwnerProps {
    /** Open a tool call's inspector when an inspection target is available. */
    inspectCall: ((callId: string) => void) | undefined;
    /** Focus request addressed to the selected View. */
    viewRequest: import('./views.ts').ConversationViewRequest | null;
    /** Select a View and address one opaque focus identity to it. */
    openView: (view: string, focus: string) => void;
    /** Acknowledge the current one-shot focus request. */
    completeViewRequest: () => void;
}
/** Base props of one target-owned Conversation View entry. */
export type ConvViewProps = PropsRuntime<'conversation.view'>;
/**
 * Moves the draft of the Session a Hero shows to the Session that replaces it. The occurrence owner calls it at most
 * once per pick, synchronously with the step that shows the new Session, while it still retains both Sessions.
 */
export type WorkspaceSessionAdopter = (sessionId: SessionId) => void;
/**
 * Handles a Workspace the Hero's picker chose: resolves that Workspace's blank Session, shows it in place of the
 * Session shown before, and calls `adopt` with it in the same step. A pick the owner no longer wants resolves
 * without calling `adopt`; a pick that failed rejects, and the owner reports the failure.
 */
export type WorkspaceSelectedHandler = (workspaceId: WorkspaceId, adopt: WorkspaceSessionAdopter) => Promise<void>;
/** Business callbacks injected into the main Conversation shell. */
export interface ConversationShellInjected {
    /** Open the Workspace's blank Session as the main Session. */
    openWorkspace: WorkspaceSelectedHandler;
}
/** Business callbacks injected into the shared Conversation content. */
export interface ConversationInjected {
    /**
     * Move this occurrence's draft text and attachments to another Session. Both Sessions must be retained; a draft
     * with a submission in flight stays where it is.
     */
    moveDraft: WorkspaceSessionAdopter;
    /** Session-addressed composer block source, or the stable absent source. */
    hooks: {
        composerBlock: ObservableSnapshot<ComposerBlock | undefined>;
    };
}
/** Business callbacks injected into the strict Session body. */
export interface ConversationSessionInjected {
    /** Package-owned View roster source bound only for the Conversation body. */
    readonly hooks: {
        readonly conversationViews: ObservableSnapshot<readonly ViewTab[]>;
        readonly inspectCall: ObservableSnapshot<ConvViewOwnerProps['inspectCall']>;
    };
    /** Bind input draft persistence to the Session-owned store instance. */
    bindDraftPersistence: (write: (draft: DraftSnapshot) => void) => () => void;
    /** Select and activate one View while addressing an opaque focus request to it. */
    openView: (view: string, focus: string) => void;
}
/** One customizable View tab listed in the More menu. */
export interface ConversationViewActionEntry {
    /** View id. */
    readonly id: string;
    /** Resolved View label. */
    readonly label: string;
    /** False while the View is manually unpinned. A pinned View still enters More when the header's width budget cannot hold it. */
    readonly pinned: boolean;
    /** Whether this View is selected in this Session, independently of its pin state. */
    readonly active?: boolean;
}
/** Owner share of the View tab row's More menu rows. */
export interface ConversationViewActionsOwnerProps {
    /** Views outside the header in registration order. */
    readonly entries: readonly ConversationViewActionEntry[];
    /**
     * Select a View in this Session without changing its pin state.
     * @param id - Listed View id.
     */
    readonly onOpen: (id: string) => void;
    /**
     * Pin or unpin a View in every Session.
     * @param id - Listed View id.
     * @param pinned - Whether the View is manually pinned; the width budget can still fold it into More.
     */
    readonly onPinnedChange: (id: string, pinned: boolean) => void;
    /** Close the More menu. */
    readonly onDismiss: () => void;
}
/** Business callbacks injected into the strict Session header. */
export interface ConversationSessionHeaderInjected {
    /** Open the clicked title's actions. */
    /** Package-owned View roster source bound only for the Conversation header. */
    readonly hooks: {
        readonly conversationViews: ObservableSnapshot<readonly ViewTab[]>;
        /** Ids of unpinned View tabs held in memory and shared by every Session until plugin reload. */
        readonly entryPins: ObservableSnapshot<readonly string[]>;
        /** Whether `conversation.session.header.views.actions` has registrations. */
        readonly entryActions: ObservableSnapshot<boolean>;
    };
    /**
     * Pin or unpin one View tab in every Session; Chat is ignored.
     * @param id - View id.
     * @param pinned - Whether the View is manually pinned; the width budget can still fold it into More.
     */
    setPinned: (id: string, pinned: boolean) => void;
    /** Select a Session through the Session Controller. */
    open: (sessionId: SessionId) => void;
    /** Select and activate one registered Conversation View. */
    selectView: (view: string) => void;
}
/** Owner share of the resident composer bar. */
export interface ComposerBarOwnerProps {
    /** Hero uses centered placement; composer uses the active bottom placement. */
    variant: 'hero' | 'composer';
    /** Conversation content occurrence rendering this composer; an unaddressed document paste reaches the main one. */
    occurrence: ConversationContentInputProps['variant'];
    /** A feature-owned reason that makes message input inert while leaving model selection live. */
    blocked?: {
        readonly reason: string;
    };
    /** Lock all message actions while preserving the resident composer surface. */
    disabled?: boolean;
    /** Whether the shared Workspace picker is expanded. */
    workspacePickerOpen?: boolean;
    /** Open the Workspace picker from the inert composer surface. */
    onRequestWorkspace?: () => void;
    placeholder?: string;
    /** Optional content rendered above the composer surface. */
    accessory?: ReactNode;
}
/** One composer's entry in the document-level paste route. */
export interface ComposerFileIntakeTarget {
    /** Composer card containing every control of this composer. */
    readonly card: HTMLElement;
    /** Conversation content occurrence rendering the composer. */
    readonly occurrence: ConversationContentInputProps['variant'];
    /** Whether a routed paste may enter now; a refusing composer is skipped, and when no composer accepts the browser keeps the event. */
    readonly accepts: () => boolean;
    /**
     * Add one routed paste through the composer's intake validation.
     * @param files - pasted browser files in clipboard order.
     * @param directories - members of `files` the clipboard entry API identified as directories.
     */
    readonly add: (files: readonly File[], directories?: ReadonlySet<File>) => void;
}
/**
 * Join the document-level paste route shared by every composer of the plugin instance.
 * @param target - the registering composer.
 * @returns the disposer leaving the route; the last disposer removes the route's document listeners.
 */
export type ComposerFileIntake = (target: ComposerFileIntakeTarget) => () => void;
/** Package-private operations injected into the resident composer bar. */
export interface ComposerBarInjected {
    /** Document paste routing across mounted composers. */
    registerFileIntake: ComposerFileIntake;
    keyboard: ComposerKeyboard | undefined;
    /**
     * Register one picked batch; resolves to the rejection copy or null. Where
     * the browser shell reports host paths (the Desktop application), files
     * and folders with a real path become `@path` references in the draft
     * instead of uploads; `directories` names the members the drop source
     * identified as directories.
     */
    addFiles: ((files: readonly File[], directories?: ReadonlySet<File>) => string | null) | undefined;
    removeAttachment: ((id: DraftAttachmentId) => void) | undefined;
    resolveDraftAttachments: ((ids: readonly DraftAttachmentId[]) => readonly ComposerAttachment[]) | undefined;
    /** Restart one failed file upload; absent without a session. */
    retryFileUpload: ((id: DraftAttachmentId) => void) | undefined;
    toggleCommandMenu: ((selection: EditSelection) => void) | undefined;
    stop: (() => void) | undefined;
    /**
     * Submit empty input to retry the displayed failed generation.
     * @param failureSeq - sequence of the displayed failed turn/end.
     */
    retry: ((failureSeq: SessionSeq) => void) | undefined;
    hooks: {
        /** Readable sequence while the fixed Stop command is registered. */
        stopShortcut: ObservableSnapshot<readonly string[]>;
        /**
         * Live busy-state submission preference: the delivery mode plain Enter
         * and the primary Send button use while the addressed agent is busy.
         */
        busyEnter: ObservableSnapshot<BusyEnterBehavior>;
        /** Live per-draft upload states for drafts that upload when added. */
        fileUploads: ObservableSnapshot<DraftFileUploads>;
        notices: ObservableSnapshot<InputNotice | null>;
        lexicon: ObservableSnapshot<ReadonlyMap<'/' | '@', readonly string[]>>;
        menuLauncher: ObservableSnapshot<string | null>;
    };
}
/** Owner share of the named plan, permission, and model controls. */
export interface InputControlOwnerProps {
    /** Whether the composer currently refuses interaction. */
    locked: boolean;
}
/** A toolbar activity hides ordinary accessory controls while expanded; its occupant must release expansion on unmount. */
export interface InputActivityOwnerProps extends InputControlOwnerProps {
    /** @param active - whether the occupant needs the toolbar width before the submit action. */
    onActiveChange: (active: boolean) => void;
}
/** Adding a key here changes the default render keys for plugins using ComposerBarProps. */
declare const baseComposerChildren: {
    readonly 'conversation.input.attachments': {
        readonly kind: "single";
        readonly scope: "session-maybe";
    };
    readonly 'conversation.input.overlay': {
        readonly kind: "list";
        readonly scope: "session";
    };
    readonly 'conversation.input.permission': {
        readonly kind: "single";
        readonly scope: "session";
    };
    readonly 'conversation.input.left': {
        readonly kind: "list";
        readonly scope: "session";
    };
    readonly 'conversation.input.plan': {
        readonly kind: "single";
        readonly scope: "session";
    };
    readonly 'conversation.input.right': {
        readonly kind: "list";
        readonly scope: "session";
    };
    readonly 'conversation.input.model': {
        readonly kind: "single";
        readonly scope: "session";
    };
    readonly 'conversation.input.activity': {
        readonly kind: "single";
        readonly scope: "session";
    };
    readonly 'conversation.composer.dock': {
        readonly kind: "list";
        readonly scope: "session";
    };
};
/** Child slots owned by the built-in input bar. */
export declare const inputBarChildren: {
    readonly 'conversation.input.placeholder': {
        readonly kind: "chain";
        readonly scope: "session";
        readonly inline: true;
    };
    readonly 'conversation.input.attachments': {
        readonly kind: "single";
        readonly scope: "session-maybe";
    };
    readonly 'conversation.input.overlay': {
        readonly kind: "list";
        readonly scope: "session";
    };
    readonly 'conversation.input.permission': {
        readonly kind: "single";
        readonly scope: "session";
    };
    readonly 'conversation.input.left': {
        readonly kind: "list";
        readonly scope: "session";
    };
    readonly 'conversation.input.plan': {
        readonly kind: "single";
        readonly scope: "session";
    };
    readonly 'conversation.input.right': {
        readonly kind: "list";
        readonly scope: "session";
    };
    readonly 'conversation.input.model': {
        readonly kind: "single";
        readonly scope: "session";
    };
    readonly 'conversation.input.activity': {
        readonly kind: "single";
        readonly scope: "session";
    };
    readonly 'conversation.composer.dock': {
        readonly kind: "list";
        readonly scope: "session";
    };
};
/** Composer bar props for a registration's child keys. The default preserves the original child slots. */
export type ComposerBarProps<K extends keyof ChildrenDecl = keyof typeof baseComposerChildren> = PropsRuntime<'conversation.composer.bar'> & PropsRenderSlots<K> & InjectFace<ComposerBarInjected> & PropsLocale<'conversation'>;
/** Owner data for the built-in editor's placeholder selectors. */
export interface InputPlaceholderOwnerProps {
    /** Session displayed by this editor. */
    readonly sessionId: SessionId;
}
/** Owner values used to elect a composer takeover. */
export interface ComposerChainProps {
    /** Current Session identity used by temporary business-owned entries. */
    sessionId: SessionId | undefined;
    /** Current Session lifecycle state, absent without a selected Session. */
    session: SessionSnapshot | undefined;
    /** Effective business-owned interaction awaiting the user in this Session. */
    pendingInteraction: SessionPendingInteraction | undefined;
}
/** Conversation state exposed to scroll-body frame layers. */
export interface HeroFrameOwnerProps {
    /** Whether the body shows the blank home of a standalone, non-embedded Conversation. */
    hero: boolean;
}
/** Brand-mark presentation selected by the blank home. */
export interface HeroBrandMarkOwnerProps {
    /** Requested square edge in pixels. */
    size: number;
    /** Host class preserving the surrounding mark geometry. */
    className?: string | undefined;
}
/** Full props of the resident optional-Session Conversation shell. */
export type ConversationSlotProps = PropsRuntime<'main.conversation'> & PropsRenderSlots<'conversation.header'> & PropsRenderFactories;
/** Inputs shared by main and embedded Conversation content occurrences. */
export interface ConversationContentInputProps {
    variant: 'main' | 'embedded';
    phase: 'settling' | 'hero' | 'active';
    hero: boolean;
    /** What a Workspace picked in the Hero does in this occurrence; the main occurrence opens it as the main Session. */
    onWorkspaceSelected: WorkspaceSelectedHandler;
    /** Text the blank-session Hero shows instead of its default headline and preview badge. */
    headline?: string | undefined;
}
/** Values passed from shared content to its occurrence-selected width controls. */
export interface ConversationWidthControlsInputProps {
    /** Mounted Conversation body measured and styled by the selected controls. */
    container: HTMLDivElement | null;
    /** Current body phase; handles render only for an active transcript. */
    phase: ConversationContentInputProps['phase'];
}
/** Full props of the reusable Conversation Factory definition. */
export type ConversationContentProps = FactoryComponentPropsOf<'conversation.content'>;
/** Shared target-neutral Conversation store handle. */
export type ConversationStore = ReturnType<typeof createConversationStore>;
/** Full props of the Factory's caller-selectable Conversation View position. */
export type ConversationViewsProps = FactoryLocalComponentPropsOf<'conversation.content', 'views'>;
/** Full props of the Factory's caller-selected width-control position. */
export type ConversationWidthControlsProps = FactoryLocalComponentPropsOf<'conversation.content', 'widthControls'>;
/** Full props of the strict Session body. */
export type ConversationSessionSlotProps = PropsRuntime<'conversation.session'> & PropsRenderSlots<'conversation.view'> & PropsStore<ConversationStore> & InjectFace<ConversationSessionInjected>;
/** Full props of the resident navigation header. */
export type ConversationHeaderProps = PropsRuntime<'conversation.header'> & PropsRenderSlots<'conversation.header.leading' | 'conversation.session.header'>;
/** Full props of the strict Session header. */
export type ConversationSessionHeaderSlotProps = PropsRuntime<'conversation.session.header'> & PropsRenderFactories & PropsRenderSlots<'conversation.session.header.lineage' | 'conversation.session.header.actions' | 'conversation.session.header.utilities' | 'conversation.session.header.corner' | 'conversation.session.header.views.actions'> & PropsStore<ConversationStore> & InjectFace<ConversationSessionHeaderInjected> & PropsLocale<'conversation'>;
/** Full props of the draft-attachment renderer. */
export type ComposerAttachmentsProps = PropsRuntime<'conversation.input.attachments'> & PropsLocale<'conversation'>;
/** Owner share common to blank-session Workspace pickers. */
export interface EmptyWorkspaceOwnerProps {
    open: boolean;
    anchorRef?: RefObject<HTMLElement>;
    /** Currently selected Workspace, when available. */
    selectedId?: WorkspaceId | undefined;
    onPick: (workspaceId: WorkspaceId) => void;
    onClose: () => void;
}
export {};
//# sourceMappingURL=slots.d.ts.map