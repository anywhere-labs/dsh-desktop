/** Title content shared by strip chips and floating-panel headers. */
import type { ReactNode } from 'react';
/** The chip stylesheet fades the trailing edge without measuring the title. */
export declare function TabTitle({ children }: {
    readonly children: ReactNode;
}): ReactNode;
//# sourceMappingURL=TabTitle.d.ts.map