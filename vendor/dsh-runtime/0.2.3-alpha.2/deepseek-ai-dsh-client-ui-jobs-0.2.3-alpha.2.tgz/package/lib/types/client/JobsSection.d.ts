import type { JobsSnapshot, JobView } from '@deepseek-ai/dsh-api-job-controller/client';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { InjectFace, PropsLocale, PropsRenderFactories, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { createJobsSectionStore } from './jobs-store.ts';
import { NS } from './locales.ts';
/** Registration-side business face for the background-jobs section. */
export interface JobsSectionInjected {
    hooks: {
        /** Client jobs snapshot (rosters and observations) bound by the renderer as useJobs. */
        jobs: {
            getSnapshot(): JobsSnapshot;
            subscribe(listener: () => void): () => void;
        };
    };
    /**
     * Keep one session's roster current while the list is mounted; returns the
     * stop function. Reference-counted by the client service.
     */
    watchRows: (sessionId: SessionId) => () => void;
    /**
     * Start observing one job's live output; returns the stop function.
     * Reference-counted by the client service, so panels can overlap safely.
     */
    observe: (sessionId: SessionId | undefined, id: JobView['id']) => () => void;
    /**
     * Kill one background job on the human's behalf. Resolves `true` when the
     * registry admitted the request (`requested` or `already-finished`); row
     * state itself converges through the jobs control frames.
     */
    killJob: (sessionId: SessionId, jobId: string) => Promise<boolean>;
}
/** Full props for the Session panel's background-jobs section. */
export type JobsSectionProps = PropsRuntime<'conversation.session.panel.section'> & PropsRenderFactories & PropsLocale<typeof NS> & InjectFace<JobsSectionInjected> & PropsStore<ReturnType<typeof createJobsSectionStore>>;
/** Business face of the running dot on the Session panel toggle. */
export type JobsRunningIndicatorInjected = Pick<JobsSectionInjected, 'hooks' | 'watchRows'>;
/** Full props of the running dot on the Session panel toggle. */
export type JobsRunningIndicatorProps = PropsRuntime<'conversation.session.panel.indicator'> & PropsLocale<typeof NS> & InjectFace<JobsRunningIndicatorInjected>;
/**
 * Session panel section for this session's background jobs. Mounting it keeps
 * the session's roster stream open; it renders nothing until the session can
 * see at least one job, so the panel hides the section with its title. Live
 * rows come first; settled rows fold under a count that expands and clears
 * client-side. Each of the two groups shows five rows and then a fold control
 * that shows the rest, once that holds back two rows or more; the choice is
 * kept per Session. Expanding an observable row (a live job, or a settled one
 * with retained output) starts its observation stream, and collapsing it or
 * folding it out of the list stops it — output only flows while someone is
 * watching. A running row carries a two-press stop button that requests a
 * human kill through the job controller.
 * @param props - runtime slot currency, the jobs snapshot hook, the roster,
 *   observation, and kill controls, the fold store, and the namespace translator.
 * @returns the job list, or null when there is nothing to show.
 */
export declare function JobsSection({ sessionId, useJobs, watchRows, observe, killJob, useStore, actions, renderFactorySlot, t, useAccess, }: JobsSectionProps): import("react").JSX.Element | null;
/**
 * Show on the panel toggle that the Session's background jobs run while the
 * panel does not show them. The toggle stays mounted while the section does
 * not, so this keeps the Session's roster stream open itself; the client
 * service counts its watchers.
 * @param props - Session values, the jobs snapshot hook, the roster control, whether the panel shows, and copy.
 * @returns the dot with its name for assistive technology, or null with nothing to report.
 */
export declare function JobsRunningIndicator({ sessionId, panelShown, useJobs, watchRows, t }: JobsRunningIndicatorProps): import("react").JSX.Element | null;
//# sourceMappingURL=JobsSection.d.ts.map