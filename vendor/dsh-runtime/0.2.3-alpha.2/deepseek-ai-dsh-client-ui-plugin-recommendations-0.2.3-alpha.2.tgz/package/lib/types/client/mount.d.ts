import type { Context } from '@deepseek-ai/cordis';
import { type RecommendationKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        pluginRecommendations: RecommendationKey;
    }
}
/** Services the body needs; the shared card plugin provides `actionCards`. */
export declare const inject: string[];
/** Register the copy for the plugin lifetime, and the card body while the Plugins page can open.
 * @param ctx - Client plugin context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=mount.d.ts.map