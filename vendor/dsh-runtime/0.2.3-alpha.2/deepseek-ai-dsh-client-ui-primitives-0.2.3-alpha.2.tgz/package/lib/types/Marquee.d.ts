import type { HTMLAttributes, PointerEvent, RefObject } from 'react';
/** Pointer handlers of the row whose hover marquees one text; spread them onto the row. */
export interface HoverMarquee {
    /** Start the travel; touch pointers and text that fits do nothing. */
    readonly onPointerEnter: (event: PointerEvent) => void;
    /** Return the text to its start in one step, unless the marquee is held. */
    readonly onPointerLeave: () => void;
}
/** Options of {@link useHoverMarquee}. */
export interface HoverMarqueeOptions {
    /** Marquee the text while true, with or without the pointer on the row, such as while the row's menu is open. */
    readonly hold?: boolean | undefined;
}
/**
 * Marquee one-line text wider than its cell while the pointer is on its row:
 * the text travels at 30px/s until its far edge is in view, then rests there
 * under the pointer. Overflow of at most 8px stays put. Leaving returns the
 * text to the start in one step, because the resting ellipsis and the narrowed
 * cell would otherwise meet the text while it travelled back. The stylesheet
 * animates the travel and its fades, so the script only measures the overflow
 * once per entry; reduced motion shows the far edge at once.
 * @param text - ref to the clipping text element, a {@link MarqueeText}.
 * @param options - whether the marquee is held without the pointer.
 * @returns stable pointer enter and leave handlers for the row.
 */
export declare function useHoverMarquee(text: RefObject<HTMLElement | null>, { hold }?: HoverMarqueeOptions): HoverMarquee;
/** Props of single-line text that a {@link useHoverMarquee} can marquee. */
export type MarqueeTextProps = HTMLAttributes<HTMLSpanElement>;
/**
 * Render single-line text that clips with an ellipsis at rest and, while a
 * {@link useHoverMarquee} marquees it, drops the ellipsis and fades whichever
 * edge still hides text. The children sit in an inner span, which travels.
 */
export declare const MarqueeText: import("react").ForwardRefExoticComponent<MarqueeTextProps & import("react").RefAttributes<HTMLSpanElement>>;
//# sourceMappingURL=Marquee.d.ts.map