/** Menu search input with a leading magnifier and an optional clear button. */
import type { ComponentPropsWithoutRef, Ref } from 'react';
/**
 * Render a controlled search input.
 * @param props - localized labels, input value and attributes, and optional clear button.
 * @returns the search control with refs to its wrapper and native input.
 */
export declare function SearchField({ inputRef, rootRef, className, placeholder, value, onChange, clearLabel, onClear, ...input }: {
    inputRef?: Ref<HTMLInputElement>;
    rootRef?: Ref<HTMLDivElement>;
    className?: string | undefined;
    placeholder: string;
    value: string;
    onChange: (value: string) => void;
    clearLabel?: string | undefined;
    onClear: () => void;
} & Pick<ComponentPropsWithoutRef<'input'>, 'aria-label' | 'role'>): import("react").JSX.Element;
//# sourceMappingURL=SearchField.d.ts.map