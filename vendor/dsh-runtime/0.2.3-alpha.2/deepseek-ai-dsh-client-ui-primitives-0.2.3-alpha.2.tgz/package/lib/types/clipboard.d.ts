/**
 * Write text to the host clipboard, preferring the async Clipboard API and
 * falling back to `execCommand('copy')` when that API is missing (jsdom,
 * insecure contexts) or refuses the write (for example, a denied clipboard
 * permission). The fallback replaces the page selection and succeeds only while
 * the triggering user gesture's transient activation is still valid.
 * @param text - the exact text to place on the clipboard.
 * @returns true only when the host accepted the write.
 */
export declare function writeClipboard(text: string): Promise<boolean>;
//# sourceMappingURL=clipboard.d.ts.map