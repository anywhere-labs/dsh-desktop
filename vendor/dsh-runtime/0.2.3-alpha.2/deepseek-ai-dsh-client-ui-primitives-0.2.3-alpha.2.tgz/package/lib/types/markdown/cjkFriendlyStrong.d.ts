/**
 * Let asterisk strong emphasis open after CJK prose before punctuation, and close after punctuation
 * before CJK prose, without whitespace.
 */
import type { Extension } from 'micromark-util-types';
/**
 * Extend CommonMark asterisk strong emphasis for punctuation-delimited CJK
 * prose, as a micromark syntax extension for `fromMarkdown`.
 * @returns The micromark syntax extension.
 */
export declare function cjkFriendlyStrong(): Extension;
//# sourceMappingURL=cjkFriendlyStrong.d.ts.map