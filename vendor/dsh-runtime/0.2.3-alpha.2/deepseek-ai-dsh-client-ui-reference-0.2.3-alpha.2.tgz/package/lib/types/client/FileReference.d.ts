import type { UserTextNodeProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { HostObservable, InjectFace, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { NS } from './locales.ts';
import type { PathPresence } from './path-presence.ts';
/** Host-confirmed presence of mention paths in the rendering Session. */
export interface PathPresenceInjected {
    readonly keyedHooks: {
        /** Presence of one decoded mention path; subscribing starts its Host stat. */
        readonly pathPresence: (path: string) => HostObservable<PathPresence | undefined>;
    };
}
/** Session-authorized synchronous navigation; document reading belongs to the preview host. */
export interface FileReferenceInjected extends PathPresenceInjected {
    /**
     * Open or reveal a file in the current Sidebar using the originating Session's authority.
     * @param path - decoded path from the reference.
     * @throws if navigation fails; the reference keeps a local retry/close dialog.
     */
    readonly openFile: (path: string) => void;
    /** Resolve a reference from the live workspace root. @param path - Reference path. @returns Host path. */
    readonly resolveFilePath: (path: string) => string;
}
type FileReferenceProps = UserTextNodeProps<'file'> & InjectFace<FileReferenceInjected> & PropsLocale<typeof NS>;
type FolderReferenceProps = UserTextNodeProps<'folder'> & InjectFace<PathPresenceInjected>;
/**
 * Render a file chip once the Host confirms its path exists, and contain synchronous navigation failures without hiding the reference.
 * @param props - JSON node, interaction policy, Session-authorized navigation and presence, and locale seat.
 * @returns the original spelling until confirmation; afterwards an inline chip and, after a navigation failure, its body-portaled dialog.
 */
export declare function FileReference({ node, raw, interactive, openFile, resolveFilePath, sessionId, useContextMenu, usePathPresence, t, }: FileReferenceProps): import("react").JSX.Element;
/**
 * Render a directory as a label once the Host confirms its path exists, even when the containing text permits file navigation.
 * @param props - directory data, the original reference spelling, and Session-scoped presence.
 * @returns the original spelling until confirmation, then an inline non-interactive chip.
 */
export declare function FolderReference({ node, raw, usePathPresence }: FolderReferenceProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=FileReference.d.ts.map