import type { ClientModuleLoader } from '@deepseek-ai/dsh-client-modules/client';
/**
 * Materialized module styles installed synchronously in the main document. Each style element carries
 * `data-plugin` with the owning package and `data-path` with the stylesheet's path within that package.
 *
 * A module whose metadata or stylesheet text cannot be produced, or whose stylesheet path already carries
 * different CSS within its package, loses only that stylesheet: the failure is reported once on the console and every other
 * stylesheet is installed. A failed producer runs again only for a replacement module record.
 */
export declare class DocumentStyles {
    private readonly container;
    private readonly modules;
    private readonly records;
    private readonly produced;
    /** Stylesheets, by {@link styleKey}, whose current conflict has been reported. */
    private readonly conflicts;
    private unsubscribe;
    private mounted;
    private disposed;
    /** @param container - Style destination. @param modules - This renderer's module service. */
    constructor(container: HTMLElement, modules: Pick<ClientModuleLoader, 'subscribeModules' | 'activeRecords' | 'resolveAsset'>);
    /** Subscribe and synchronously install module styles; each instance can mount only once. */
    mount(): void;
    /** Unsubscribe and remove all installed resources. */
    dispose(): void;
    /** Produce one record's stylesheet text once, containing each producer failure to its own stylesheet. */
    private stylesOf;
    private collectStyles;
    private refresh;
}
//# sourceMappingURL=document-styles.d.ts.map