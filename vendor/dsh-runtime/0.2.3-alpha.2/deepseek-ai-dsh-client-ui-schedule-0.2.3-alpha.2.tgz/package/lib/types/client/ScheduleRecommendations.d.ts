/** Built-in task recommendations under the empty task catalog; choosing one prefills a new Session. */
import { type ReactNode } from 'react';
import type { TaskManagerKey } from './task-manager-locales.ts';
/** Props of the recommendation section. */
export interface ScheduleRecommendationsProps {
    /** Task-manager copy. */
    readonly t: (key: TaskManagerKey) => string;
    /**
     * Start a new Session with a recommendation's request prefilled.
     * @param prompt - the recommendation's localized request.
     */
    readonly onUse: (prompt: string) => void;
}
/**
 * Render the built-in recommendations as a two-column grid of tiles, each with
 * its title, description, and default run time.
 * @param props - copy and the prefill action.
 * @returns the section listing every recommendation.
 */
export declare function ScheduleRecommendations({ t, onUse }: ScheduleRecommendationsProps): ReactNode;
//# sourceMappingURL=ScheduleRecommendations.d.ts.map