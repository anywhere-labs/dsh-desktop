/** Copy for the recommended tasks shown in the empty task catalog. */
/** English recommendation copy. */
export declare const recommendationEn: {
    readonly 'recommend.heading': "Recommended";
    readonly 'recommend.dailyBrief.title': "Daily brief";
    readonly 'recommend.dailyBrief.description': "Recent changes in the workspace and what needs follow-up, with what to do first today.";
    readonly 'recommend.dailyBrief.schedule': "Weekdays at 9:00";
    readonly 'recommend.dailyBrief.prompt': "Create an automation task named \"Daily brief\": every weekday at 9:00, review the last 24 hours of changes in the current workspace and list what needs my follow-up and what to do first today; when the workspace is a code repository, also cover new commits, pull requests awaiting my review, and failing CI.";
    readonly 'recommend.weeklyReview.title': "Weekly review";
    readonly 'recommend.weeklyReview.description': "Your work in the workspace this week, with loose ends and what to do first next week.";
    readonly 'recommend.weeklyReview.schedule': "Fridays at 16:00";
    readonly 'recommend.weeklyReview.prompt': "Create an automation task named \"Weekly review\": every Friday at 16:00, review what I did in the current workspace this week and list what is still unfinished and what to do first next week; when the workspace is a code repository, look only at my commits this week and the pull requests I opened that were merged this week or are still open. Summarize here only; do not change files in the workspace.";
    readonly 'recommend.issueScan.title': "Issue scan";
    readonly 'recommend.issueScan.description': "Sort new issues into bugs, requests, and questions, and flag duplicates and ones that need a reply.";
    readonly 'recommend.issueScan.schedule': "Weekdays at 10:00";
    readonly 'recommend.issueScan.prompt': "Create an automation task named \"Issue scan\": every weekday at 10:00, scan new issues in the current workspace repository, sort them into bugs, requests, and questions, and flag duplicates and ones that need my reply. Summarize here only; do not reply on GitHub.";
    readonly 'recommend.pluginCompat.title': "Plugin compatibility check";
    readonly 'recommend.pluginCompat.description': "When a new DSH version ships, check whether installed and self-made plugins need changes.";
    readonly 'recommend.pluginCompat.schedule': "Daily at 10:00";
    readonly 'recommend.pluginCompat.prompt': "Create an automation task named \"Plugin compatibility check\": every day at 10:00, check whether a new DSH version is available; if so, read its upgrade guide, check whether each non-official or self-made plugin I have installed is affected, and list what to change and how.";
    readonly 'recommend.topicTracking.title': "Topic and paper tracking";
    readonly 'recommend.topicTracking.description': "Search for news and new arXiv papers on chosen topics and list the key points.";
    readonly 'recommend.topicTracking.schedule': "Daily at 9:00";
    readonly 'recommend.topicTracking.prompt': "Create an automation task named \"Topic and paper tracking\": every day at 9:00, search for new articles and arXiv papers on the topics I follow and list a few key points for each. Before creating it, ask me for the topics, keywords, and sources.";
    readonly 'recommend.branchCleanup.title': "Branch and worktree cleanup";
    readonly 'recommend.branchCleanup.description': "List local branches and worktrees whose pull requests merged or closed, and delete them after confirmation.";
    readonly 'recommend.branchCleanup.schedule': "Fridays at 17:00";
    readonly 'recommend.branchCleanup.prompt': "Create an automation task named \"Branch and worktree cleanup\": every Friday at 17:00, list local branches and worktrees in the current workspace whose pull requests are merged or closed, and delete them only after I confirm.";
    readonly 'recommend.weather.title': "Weather and travel";
    readonly 'recommend.weather.description': "Weather for today and the next three days, with a note when an umbrella or warmer clothes are needed.";
    readonly 'recommend.weather.schedule': "Daily at 7:30";
    readonly 'recommend.weather.prompt': "Create an automation task named \"Weather and travel\": every day at 7:30, tell me the weather in my city for today and the next three days, and call out when I should bring an umbrella, dress warmer, or expect travel disruption. Before creating it, ask me for my city.";
    readonly 'recommend.workout.title': "Weekly workout plan";
    readonly 'recommend.workout.description': "Plan next week's workouts around your goals and training days.";
    readonly 'recommend.workout.schedule': "Sundays at 20:00";
    readonly 'recommend.workout.prompt': "Create an automation task named \"Weekly workout plan\": every Sunday at 20:00, plan my workouts for next week around my goals and the days I can train, without asking me anything when it runs. Before creating it, ask me about my goals, how many days a week I can train, which days I am free, and where I train.";
};
/** Simplified Chinese recommendation copy. */
export declare const recommendationZh: Record<keyof typeof recommendationEn, string>;
/** Japanese recommendation copy. */
export declare const recommendationJa: Record<keyof typeof recommendationEn, string>;
/** Spanish recommendation copy. */
export declare const recommendationEs: Record<keyof typeof recommendationEn, string>;
/** French recommendation copy. */
export declare const recommendationFr: Record<keyof typeof recommendationEn, string>;
/** German recommendation copy. */
export declare const recommendationDe: Record<keyof typeof recommendationEn, string>;
/** Russian recommendation copy. */
export declare const recommendationRu: Record<keyof typeof recommendationEn, string>;
/** Portuguese recommendation copy. */
export declare const recommendationPt: Record<keyof typeof recommendationEn, string>;
//# sourceMappingURL=recommendation-locales.d.ts.map