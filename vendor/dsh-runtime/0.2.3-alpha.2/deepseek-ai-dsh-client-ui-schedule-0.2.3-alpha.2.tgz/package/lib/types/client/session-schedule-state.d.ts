/**
 * One Session's scheduled-task state for its header, Sidebar row mark, and hover card.
 *
 * These views project the Host catalog the page already owns — `schedule/catalog()`
 * returns every Host task with its delivery target — so N
 * visible rows share one Remote read and follow one `schedule/changed`
 * invalidation instead of issuing a query per row or header.
 */
import type { HostObservable, SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { ScheduleCatalogEntry } from '@deepseek-ai/dsh-schedule/client';
import type { CatalogSnapshot } from './catalog-source.ts';
/** Selector hook the renderer binds from a slot's `hooks.catalog` observable. */
export type SessionScheduleCatalogHook = SnapshotSelectorHook<CatalogSnapshot<ScheduleCatalogEntry>>;
/** Shared Host catalog observable an ambient surface injects through its slot. */
export type SessionScheduleCatalogObservable = HostObservable<CatalogSnapshot<ScheduleCatalogEntry>>;
/** One Session's active scheduled tasks as projected from the shared Host catalog. */
export interface SessionScheduleFacts {
    /** Whether the settled catalog holds at least one active task for the Session. */
    readonly hasActive: boolean;
    /** Active tasks of the Session in catalog order; empty unless the read settled. */
    readonly records: readonly ScheduleCatalogEntry[];
}
/**
 * Select active tasks whose fixed delivery target is this Session.
 * A Session with only paused or ended tasks has an empty list.
 *
 * Refreshes use the last successful catalog so the clock stays visible
 * while a delivery-triggered read is pending.
 * @param snapshot - shared Host catalog snapshot.
 * @param sessionId - Session whose facts are selected.
 * @returns this Session's active-task facts.
 */
export declare function selectSessionScheduleFacts(snapshot: CatalogSnapshot<ScheduleCatalogEntry>, sessionId: SessionId): SessionScheduleFacts;
/**
 * Select one Session's active-task facts from the shared Host catalog.
 * @param useCatalog - selector hook bound to the shared Host catalog observable.
 * @param sessionId - Session whose row is observed; reading activates nothing.
 * @returns this Session's facts, stable across other Sessions' updates.
 */
export declare function useSessionScheduleFacts(useCatalog: SessionScheduleCatalogHook, sessionId: SessionId): SessionScheduleFacts;
//# sourceMappingURL=session-schedule-state.d.ts.map