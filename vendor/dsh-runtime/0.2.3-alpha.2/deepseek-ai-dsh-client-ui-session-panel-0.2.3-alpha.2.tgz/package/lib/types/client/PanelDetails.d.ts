/**
 * The details of one Session panel row, shown in the row's HoverCard. The
 * plugin offers it as the `conversation.session.panel.details` Component
 * Factory, so the rows of every section describe themselves alike.
 */
import type { ReactNode } from 'react';
import type { FactoryComponentPropsOf } from '@deepseek-ai/dsh-client-ui-slots';
/**
 * Render a row's details on the HoverCard's dark surface in both themes: the
 * title, secondary lines, the state after its dot, and the measures on one
 * line, each after the 14px icon of its kind. Absent or empty parts render
 * nothing.
 * @param props - title, lines, state, and measures.
 * @returns the card body.
 */
export declare function PanelDetails({ title, lines, status, facts, }: FactoryComponentPropsOf<'conversation.session.panel.details'>): ReactNode;
//# sourceMappingURL=PanelDetails.d.ts.map