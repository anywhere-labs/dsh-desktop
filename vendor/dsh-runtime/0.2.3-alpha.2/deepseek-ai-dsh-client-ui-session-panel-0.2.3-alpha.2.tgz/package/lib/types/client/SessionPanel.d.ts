/** Floating Session panel in the Chat View's aside: section titles drawn from the section roster, bodies from the section slot. */
import { type ReactNode } from 'react';
import type { SessionPanelProps } from './slots.ts';
/**
 * Render the panel while it docks or shows as an overlay, and always its
 * dock probe. Each section keeps its title row and body; CSS hides a section
 * whose body rendered nothing. The overlay closes on Escape and on an
 * outside pointerdown. CSS sizes the docked panel from the Chat View's end
 * gutter and makes the probe 1px wide while the panel has room to dock: that
 * gutter holds it, or the transcript can move aside to leave it. The plugin
 * observes the probe, so the panel renders again only when the docking
 * decision flips. While the docking preference is on, the probe carries the
 * mark that has the Conversation body keep the panel's room free. A press
 * that shows or hides the panel plays its entrance or exit, and the probe
 * then carries the mark that has the Conversation body move the transcript
 * over the same time; a leaving panel stays until its exit ends. A panel that
 * shows or hides for its room, as on a switch to another Session or a resized
 * window, does so at once. The title row of every section but
 * Environment is draggable, which reorders the sections, and holds a drag
 * handle that its stylesheet shows on hover.
 * @param props - Session values, shared visibility, sections and their move action, the dock probes and their ref factory, and copy.
 * @returns the dock probe and, unless hidden, the panel.
 */
export declare function SessionPanel({ sessionId, useVisibility, useSections, useProbes, createProbeRef, closeOverlay, moveSection, renderSlot, t, }: SessionPanelProps): ReactNode;
//# sourceMappingURL=SessionPanel.d.ts.map