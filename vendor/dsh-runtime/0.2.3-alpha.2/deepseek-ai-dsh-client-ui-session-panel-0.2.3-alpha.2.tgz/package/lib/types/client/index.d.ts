/**
 * Session panel plugin, browser half: a Session header toggle and a floating
 * panel in the Chat View's aside. The panel draws the titles of the sections
 * other plugins register, lays out the rows they mark, offers the fold control
 * their lists end with and the details their rows show on hover, and ships the
 * Environment section with the working folder row.
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type SessionPanelKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Session panel copy. */
        sessionPanel: SessionPanelKey;
    }
}
export type { EnvironmentSectionProps, PanelDetailsFact, PanelDetailsProps, PanelFoldProps, ProjectRowInjected, ProjectRowProps, SessionPanelDockable, SessionPanelIndicatorOwnerProps, SessionPanelInjected, SessionPanelPresentation, SessionPanelProbes, SessionPanelProps, SessionPanelSectionEntry, SessionPanelSectionOwnerProps, SessionPanelToggleInjected, SessionPanelToggleProps, SessionPanelVisibility, } from './slots.ts';
/** Required services: the slot registry, dictionaries, and the Host facts of the Remote carrier. */
export declare const inject: string[];
/**
 * Client plugin body: register the dictionaries, the fold control and row
 * details Factories, the header toggle, the panel, and the Environment section
 * with its project row.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map