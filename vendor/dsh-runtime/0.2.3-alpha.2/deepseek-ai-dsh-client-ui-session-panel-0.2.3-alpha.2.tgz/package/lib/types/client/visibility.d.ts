/** Session panel visibility: the persisted docking preference, the transient overlay, the dock probes, and the presentation. */
import { type ObservableSnapshot } from '@deepseek-ai/dsh-client-store';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { SessionPanelDockable, SessionPanelPresentation, SessionPanelProbes, SessionPanelVisibility } from './slots.ts';
/** localStorage key of the docking preference. */
export declare const PINNED_STORAGE_KEY = "dsh.sessionPanel.pinned";
/**
 * Decide how the panel shows for one Session.
 * @param fits - whether the gutter can hold the docked panel.
 * @param visibility - shared visibility state.
 * @param sessionId - Session whose panel is decided.
 * @returns the presentation, or `hidden` when the panel renders nothing.
 */
export declare function presentationOf(fits: boolean, visibility: SessionPanelVisibility, sessionId: SessionId): SessionPanelPresentation | 'hidden';
/**
 * Visibility shared by every Session's toggle and panel, and whether each
 * mounted panel and each Session has room to dock. The panel's stylesheet
 * decides the room: each mounted panel renders a dock probe that is 1px wide
 * while its Chat View's end gutter holds the docked panel and 0 otherwise,
 * and this state observes only that probe, so it hears the decision flip
 * and nothing while the window resizes on one side of it or the transcript
 * grows. Docking follows one preference for all Sessions; at most one
 * Session's overlay is open, and it closes once its Session has room to dock
 * or no Chat View shows that Session any longer.
 */
export declare class SessionPanelState {
    private readonly pinned;
    private readonly overlay;
    private readonly room;
    private readonly fits;
    /** The Session of every attached probe. */
    private readonly owners;
    /** Stops observing each attached probe. */
    private readonly detachers;
    private current;
    /** Stops following the open overlay's gutter. */
    private unfollow;
    /** Combined visibility; the snapshot keeps its identity until a member changes. */
    readonly visibility: ObservableSnapshot<SessionPanelVisibility>;
    /**
     * Whether each Session with a mounted panel has room to dock it: true while
     * any of its probes does. The snapshot keeps its identity until a Session
     * gains or loses its entry or its room changes.
     */
    readonly dockable: ObservableSnapshot<SessionPanelDockable>;
    /**
     * Whether each attached probe's gutter holds the docked panel. The snapshot
     * keeps its identity until a probe attaches, detaches, or flips.
     */
    readonly probes: ObservableSnapshot<SessionPanelProbes>;
    /**
     * Create the element-ref lifecycle of one mounted panel's dock probe.
     * Attaching the element enters the probe without room and observes its
     * size; a probe at least 1px wide has room. Detaching stops the
     * observation and withdraws the probe. Without `ResizeObserver` the probe
     * stays without room, so the panel shows only as an overlay.
     * @param sessionId - Session the panel's Chat View shows.
     * @param probe - identity of the panel within the page.
     * @returns the ref callback for the probe element.
     */
    createProbeRef(sessionId: SessionId, probe: string): (element: HTMLElement | null) => void;
    /**
     * Show or hide the panel from a Session's toggle. With room to dock this
     * flips the docking preference and closes any overlay; otherwise it opens
     * or closes the Session's overlay. No effect while no Chat View shows the Session.
     * @param sessionId - Session whose header holds the toggle.
     */
    toggle(sessionId: SessionId): void;
    /**
     * Close a Session's overlay.
     * @param sessionId - Session whose overlay closes; another Session's overlay stays open.
     */
    closeOverlay(sessionId: SessionId): void;
    /** Stop following the open overlay's Session and stop observing every attached probe. */
    dispose(): void;
    private stopFollowing;
    private setOverlay;
    private attach;
    /** Record one probe's room, or its withdrawal, publishing only what changed. */
    private report;
}
//# sourceMappingURL=visibility.d.ts.map