/** Client Session status plugin: the `uiSession.sessionStatus` service, the `useSessionStatus` root hook, and reading. */
import type { Context } from '@deepseek-ai/cordis';
export type { SessionStatus, SessionStatusSnapshot, UiSessionStatus, UseSessionStatus } from './status.ts';
/** Required Controller, Remote, generated reading namespace, access, renderer, and Session UI services. */
export declare const inject: string[];
/**
 * Install `ctx.uiSession.sessionStatus`, publish it through the `useSessionStatus` root hook, and follow Host reading
 * records into it.
 * @param ctx - Client root context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map