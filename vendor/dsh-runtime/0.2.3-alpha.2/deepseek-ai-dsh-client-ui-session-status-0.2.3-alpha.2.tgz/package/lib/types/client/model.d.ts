/** React-free Client copy of the Host reading records; internal to the Session status plugin. */
import { type SnapshotStore } from '@deepseek-ai/dsh-client-store';
import type { TypertClientRemote } from '@deepseek-ai/dsh-typert-protocol';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { SessionReadState } from '../types.ts';
/** Reading records retained during reconnection; mutations require a ready baseline. */
export interface SessionReadSnapshot {
    readonly items: Readonly<Record<SessionId, SessionReadState>>;
    readonly ready: boolean;
}
/** Projects the ordered Host stream; mutation responses never replace reading records. */
export declare class SessionReadModel {
    private readonly remote;
    /** Current reading records and baseline readiness, published synchronously on every change. */
    readonly state: SnapshotStore<SessionReadSnapshot>;
    /** @param remote - generated `sessionStatus` Remote methods. */
    constructor(remote: Pick<TypertClientRemote['sessionStatus'], 'mark'>);
    /**
     * Replace the complete projection for a new connection.
     * @param items - complete authoritative baseline for the new stream generation.
     */
    replace(items: readonly SessionReadState[]): void;
    /**
     * Accept the next committed record from the ordered subscription.
     * @param item - Committed whole-record change.
     */
    accept(item: SessionReadState): void;
    /** Retain the last projection while disabling writes until a new baseline. */
    disconnected(): void;
    /**
     * Mark the Session through the latest completion known to this Client, without optimistically changing it.
     * @param sessionId - known Session identity.
     * @param unread - requested reminder state.
     * @throws when no current baseline exists or the Host or carrier rejects; reconnect to refresh an unknown outcome.
     */
    mark(sessionId: SessionId, unread: boolean): Promise<void>;
    /**
     * Acknowledge content received by the visible Session view.
     * @param sessionId - Known Session identity.
     * @param throughTurn - Latest completed turn received in the Session body.
     * @param clearManual - Clear the manual reminder of a Session the main view switched to.
     */
    acknowledge(sessionId: SessionId, throughTurn: number, clearManual: boolean): Promise<void>;
    private send;
}
//# sourceMappingURL=model.d.ts.map