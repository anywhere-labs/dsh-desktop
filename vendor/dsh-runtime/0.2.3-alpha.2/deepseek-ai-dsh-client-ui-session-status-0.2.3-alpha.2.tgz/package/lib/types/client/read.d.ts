/** Host reading records installed under the Session status table: the access-gated stream and acknowledgements. */
import type { Context } from '@deepseek-ai/cordis';
import type { UiSessionStatus } from './status.ts';
/**
 * Follow Host reading records into the status table's reading model and acknowledge reading in the visible main view.
 * The stream runs only while the current Peer may follow it, so a LiveShare viewer opens no stream and keeps
 * `readingReady` false; carrier reconnection replaces the complete reading baseline.
 * @param ctx - Client root context with `remote`, `remoteAccess`, and `sessions`.
 * @param status - status table whose reading model receives the records.
 */
export declare function installReading(ctx: Context, status: UiSessionStatus): void;
//# sourceMappingURL=read.d.ts.map