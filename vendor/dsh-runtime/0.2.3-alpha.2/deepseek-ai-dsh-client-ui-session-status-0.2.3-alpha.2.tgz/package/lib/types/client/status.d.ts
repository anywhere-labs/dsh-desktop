/** Client Session status table: running state, the effective pending interaction, and shared reading reminders. */
import { Service, type Context } from '@deepseek-ai/cordis';
import type { ISessions } from '@deepseek-ai/dsh-api-session-controller/client';
import type { HostObservable, SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionPendingInteraction } from '@deepseek-ai/dsh-client-ui-session/client';
export type {} from '@deepseek-ai/dsh-client-ui-session/client';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import { SessionReadModel } from './model.ts';
/** Independent UI status facts for one Session identity. */
export interface SessionStatus {
    /** Latest known running state; absent until a baseline or event establishes it. */
    readonly running: boolean | undefined;
    /** Highest-precedence domain request currently awaiting user interaction. */
    readonly pendingInteraction: SessionPendingInteraction | undefined;
    /**
     * Host-confirmed unread completion or explicit unread mark; an unacknowledged completion of the open Session the
     * visible, focused main view retains is not shown until the view leaves it.
     */
    readonly completionUnread: boolean;
    /** Latest unread completion ended with an execution error this Host observed. */
    readonly completionFailed: boolean;
}
/** Current UI status indexed by Session identity. */
export type SessionStatusSnapshot = ReadonlyMap<SessionId, SessionStatus>;
/** Selector hook over the unified Session UI status snapshot. */
export type UseSessionStatus = SnapshotSelectorHook<SessionStatusSnapshot>;
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface GlobalStandardProps {
        useSessionStatus: UseSessionStatus;
    }
}
declare module '@deepseek-ai/dsh-client-ui-session/client' {
    interface UiSessionService {
        /** Session status table; a plugin that reads it injects `uiSession.sessionStatus`. */
        readonly sessionStatus: UiSessionStatus;
    }
}
/**
 * Session status table provided as the `uiSession.sessionStatus` service and read as `ctx.uiSession.sessionStatus`.
 * Completion reminders come from the Host reading records shared by every Client of one Host; the
 * [package reference](../../README.md#use-this-package) states when each field is set and cleared.
 */
export declare class UiSessionStatus extends Service implements HostObservable<SessionStatusSnapshot> {
    private readonly sessions;
    private readonly pendingInteractions;
    private readonly running;
    private statusSnapshot;
    private viewedBinding;
    private viewedOpenState;
    private releaseViewed;
    private readonly statusListeners;
    /**
     * Package-internal Client copy of the Host reading records, which the reading installer follows into.
     * @internal
     */
    readonly reading: SessionReadModel;
    /** Whether reading marks can be sent: the current Host reading baseline has arrived. */
    readonly readingReady: HostObservable<boolean>;
    /**
     * @param ctx - Client root context; its generated `sessionStatus` Remote namespace sends reading marks.
     * @param sessions - Controller-owned Session catalog and bindings.
     * @param pendingInteractions - effective pending request by Session, published by ui-session.
     */
    constructor(ctx: Context, sessions: Pick<ISessions, 'list' | 'binding'>, pendingInteractions: HostObservable<ReadonlyMap<SessionId, SessionPendingInteraction>>);
    /**
     * Read the current status table; the reference changes only when a status fact changes.
     * @returns status by Session identity.
     */
    readonly getSnapshot: () => SessionStatusSnapshot;
    /**
     * Observe status table changes; a throwing listener is reported without stopping later listeners.
     * @param listener - called after each published change.
     * @returns unsubscribe.
     */
    readonly subscribe: (listener: () => void) => () => void;
    /**
     * Mark one Session read or unread through the latest completion known to this Client.
     * @param sessionId - known Session identity.
     * @param unread - requested reminder state.
     * @throws when reading is not synchronized or the Host or carrier rejects; reconnect to refresh an unknown outcome.
     */
    mark(sessionId: SessionId, unread: boolean): Promise<void>;
    private observeRunning;
    private reconcileStatus;
    /** Follow the main-view Session's binding, whose open state decides whether its natural reminder is hidden. */
    private followMainView;
    private publishStatus;
}
//# sourceMappingURL=status.d.ts.map