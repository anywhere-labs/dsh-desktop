import type { SessionReadFrame } from './types.ts';
type ChangedFrame = Extract<SessionReadFrame, {
    type: 'changed';
}>;
/** One follower's ordered committed updates. */
export declare class SessionReadFollower {
    private readonly frames;
    private wake;
    private readonly lifetime;
    private failure;
    /** Aborts when this follower closes, including while its consumer is paused. */
    get signal(): AbortSignal;
    /**
     * Enqueue one update for an active follower.
     * @param frame - committed whole-record replacement.
     */
    push(frame: ChangedFrame): void;
    /**
     * Wake the reader and end this generation, preserving the first close reason.
     * Queued frames are discarded; the next generation supplies a complete baseline.
     * @param failure - terminal stream failure, when present.
     */
    close(failure?: Error): void;
    /**
     * Consume queued changes until cancellation, teardown, or stream failure.
     * @param signal - Remote generation lifetime.
     * @returns ordered updates; rejects with the first terminal stream failure.
     */
    read(signal: AbortSignal): AsyncIterable<ChangedFrame>;
}
export {};
//# sourceMappingURL=feed.d.ts.map