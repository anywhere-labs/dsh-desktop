/** Account notification row above the sidebar account launcher. */
import type { InjectFace, PropsRenderSlots, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { AccountSectionInjected } from './AccountSection.tsx';
/** Notice row composed by the settings shell. */
export type AccountNoticesProps = PropsRuntime<'settings.notice'> & PropsRenderSlots<'settings.launcher.notifications'> & InjectFace<AccountSectionInjected>;
/**
 * @param props - settings navigation and account state.
 * @returns the account notification extension, active only when signed in outside onboarding.
 */
export declare function AccountNotices({ openSettings, useAccount, renderSlot }: AccountNoticesProps): import("react").JSX.Element;
//# sourceMappingURL=AccountNotices.d.ts.map