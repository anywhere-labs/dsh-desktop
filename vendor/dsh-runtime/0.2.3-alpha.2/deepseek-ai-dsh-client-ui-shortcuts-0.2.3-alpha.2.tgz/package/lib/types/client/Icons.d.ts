/**
 * Render the shortcut design artwork at its supplied size.
 * @param props - glyph kind and semantic color class.
 * @returns an ornamental SVG hidden from assistive technology.
 */
export declare function ShortcutIcon({ kind, className }: {
    kind: 'edit' | 'error' | 'success';
    className?: string | undefined;
}): import("react").JSX.Element;
//# sourceMappingURL=Icons.d.ts.map