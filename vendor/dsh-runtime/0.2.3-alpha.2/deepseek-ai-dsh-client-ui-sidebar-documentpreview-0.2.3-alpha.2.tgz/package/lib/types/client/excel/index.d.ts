/** Excel previews use ordinary authorized file bytes without Office conversion. */
import type { Context } from '@deepseek-ai/cordis';
import type { ExcelLimits } from '../../types.ts';
/**
 * Register the browser Excel viewer and its lifecycle-owned slot.
 * @param ctx - Preview and locale registries.
 * @param limits - Resolved parser limits.
 */
export declare function apply(ctx: Context, limits: ExcelLimits): void;
//# sourceMappingURL=index.d.ts.map