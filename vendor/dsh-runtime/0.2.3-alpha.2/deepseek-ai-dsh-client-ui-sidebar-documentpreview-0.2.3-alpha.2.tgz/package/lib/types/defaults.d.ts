/** Default preview limits, shared by the Host schema and the browser's fallback for an absent synced value. */
import type { ExcelLimits, OfficeLimits } from './types.ts';
/** Office cache limits a Config without `office` keys resolves to. */
export declare const OFFICE_DEFAULTS: Readonly<OfficeLimits>;
/** Spreadsheet parser limits a Config without `excel` keys resolves to. */
export declare const EXCEL_DEFAULTS: Readonly<ExcelLimits>;
//# sourceMappingURL=defaults.d.ts.map