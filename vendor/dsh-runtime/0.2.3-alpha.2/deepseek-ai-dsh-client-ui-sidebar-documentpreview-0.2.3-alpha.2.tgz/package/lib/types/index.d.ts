/** Host Loader entry declaring the browser document preview limits; previews belong to the Client. */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { DocumentPreviewConfig, ExcelLimits, OfficeLimits } from './types.ts';
/** Preview limits synced to the browser. */
export type Config = DocumentPreviewConfig;
/** Deployment limits synced to the browser, which applies them when the plugin activates. */
export declare const Config: z<{
    office?: Partial<OfficeLimits>;
    excel?: Partial<ExcelLimits>;
}, Config>;
/**
 * Register the browser plugin without Host behavior; the Loader validates the entry's Config, and the browser face
 * receives its volatile fields.
 * @param _ctx - Host context; unused.
 * @param _config - validated Config; unused on the Host.
 */
export declare function apply(_ctx: Context, _config: Config): void;
//# sourceMappingURL=index.d.ts.map