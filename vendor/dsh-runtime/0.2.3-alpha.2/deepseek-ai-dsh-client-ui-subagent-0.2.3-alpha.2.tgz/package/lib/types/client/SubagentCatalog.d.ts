/** Subagent catalog tree shared by the Session panel section and the breadcrumb switcher. */
import { type ReactNode } from 'react';
import type { SessionListState, SessionProjectionMap, SessionProjectionSnapshot, SessionSummary } from '@deepseek-ai/dsh-api-session-controller/client';
import type { SessionStatusSnapshot } from '@deepseek-ai/dsh-client-ui-session-status/client';
import type { SubagentAddress } from '@deepseek-ai/dsh-subagent/client';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { PanelDetailsProps } from '@deepseek-ai/dsh-client-ui-session-panel/client';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { NS } from './locales.ts';
/** One Session's direct subagents with their live activity. */
export type SubagentCatalogSnapshot = Omit<SessionProjectionSnapshot, 'values' | 'state'> & {
    state: 'idle' | 'loading' | 'ready' | 'migration-required' | 'error';
    entries: (SessionProjectionMap['subagentCatalog'][number] & {
        activity: 'running' | 'inactive';
    })[];
};
/** Catalogs of every Session whose projections the Client holds. */
export type Catalogs = Readonly<Record<SessionId, SubagentCatalogSnapshot>>;
/** Business actions supplied by the slot registrations. */
export type SubagentCatalogInjected = {
    openChild: (address: SubagentAddress) => void;
    openChildAside: (address: SubagentAddress) => void;
    refreshProjection: (parentSessionId: SessionId) => void;
    /** Read this catalog and its direct children after explicit activation or retry. */
    prepareCatalog: (parentSessionId: SessionId) => Promise<void>;
};
interface CatalogRowsProps {
    parentSessionId: SessionId;
    currentSessionId: SessionId | undefined;
    catalog: SubagentCatalogSnapshot;
    catalogs: Catalogs;
    summaries: Readonly<Record<SessionId, SessionSummary>>;
    expanded: ReadonlySet<SessionId>;
    level: number;
    openChild: (address: SubagentAddress) => void;
    openChildAside: (address: SubagentAddress) => void;
    refreshProjection: (parentSessionId: SessionId) => void;
    toggleBranch: (childSessionId: SessionId) => void;
    closeCatalog: () => void;
    panelDetails: CatalogTreeProps['panelDetails'];
}
/**
 * List the focusable rows of a catalog tree in display order.
 * @param root - the tree or an element that contains it.
 * @returns the rows that accept focus.
 */
export declare function treeItems(root: HTMLElement): HTMLElement[];
/** The agent name unique among the row's siblings, or the Session ID for entries recorded without one. */
/**
 * Name a catalog entry when it has no description.
 * @param entry - catalog entry.
 * @returns the entry's display name.
 */
export declare function entryName(entry: SubagentCatalogSnapshot['entries'][number]): string;
/**
 * Build every held Session's catalog from its projection and live status.
 * @param projections - projection snapshots by Session.
 * @param summaries - Session list rows by id.
 * @param statuses - live Session statuses.
 * @returns catalogs keyed by parent Session.
 */
export declare function deriveCatalogs(projections: SessionListState['projectionsBySession'], summaries: SessionListState['byId'], statuses: SessionStatusSnapshot): Catalogs;
/**
 * The direct subagents of `catalog`'s Session plus progress, as one phrase such as "2 of 3 done".
 * @param catalog - catalog whose entries are counted.
 * @param summaries - Session list rows by id.
 * @param t - subagent copy.
 * @returns the progress phrase, or an empty string without entries.
 */
export declare function progressOf(catalog: SubagentCatalogSnapshot, summaries: CatalogRowsProps['summaries'], t: TranslateNS<typeof NS>): string;
/**
 * Bind catalog preparation as a fire-and-forget level read; a rejection is
 * logged, and the next activation or retry prepares the level again.
 * @param prepareCatalog - the injected catalog action.
 * @returns a callback that prepares one level.
 */
export declare function levelPreparer(prepareCatalog: SubagentCatalogInjected['prepareCatalog']): (sessionId: SessionId) => void;
/** Props of one subagent tree. */
export interface CatalogTreeProps {
    /** Session whose direct catalog roots the tree. */
    rootSessionId: SessionId;
    /** Selected descendant highlighted in the tree. */
    currentSessionId?: SessionId | undefined;
    catalog: SubagentCatalogSnapshot;
    catalogs: Catalogs;
    summaries: CatalogRowsProps['summaries'];
    openChild: (address: SubagentAddress) => void;
    openChildAside: (address: SubagentAddress) => void;
    /** Read a level's catalog and its direct children; the tree calls it on branch expansion and retry. */
    prepareLevel: (parentSessionId: SessionId) => void;
    /** Called after a row opened a Session, so a surrounding popover or overlay can close. */
    onOpened: () => void;
    /** Focus the first row on mount, as a keyboard-opened popover does. */
    focusFirst?: boolean;
    /**
     * Renders the Session panel's row details. With it the tree lists one-line
     * rows, as the Session panel does, and each row shows its name, owner,
     * state, and measures in a hover card.
     */
    panelDetails?: ((details: PanelDetailsProps) => ReactNode) | undefined;
    t: TranslateNS<typeof NS>;
}
/**
 * Render a subagent tree with expandable branches and roving arrow-key focus.
 * A row offers expansion only after its own catalog has entries; expanding it
 * prepares that level, and collapsing a branch also collapses its descendants.
 * @param props - catalog data, actions, and copy.
 * @returns the tree.
 */
export declare function CatalogTree({ rootSessionId, currentSessionId, catalog, catalogs, summaries, openChild, openChildAside, prepareLevel, onOpened, focusFirst, panelDetails, t, }: CatalogTreeProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=SubagentCatalog.d.ts.map