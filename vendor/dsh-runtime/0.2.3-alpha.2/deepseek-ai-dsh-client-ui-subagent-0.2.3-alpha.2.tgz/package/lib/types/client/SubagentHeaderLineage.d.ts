import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { NS } from './locales.ts';
import { type SubagentCatalogInjected } from './SubagentCatalog.tsx';
export type { SubagentCatalogInjected } from './SubagentCatalog.tsx';
/** Full props for the session-header lineage renderer. */
export type SubagentHeaderLineageProps = PropsRuntime<'conversation.session.header.lineage'> & InjectFace<SubagentCatalogInjected> & PropsLocale<typeof NS>;
/**
 * Render one breadcrumb title together with its sibling switcher. The
 * Session's own subagents are listed by the Session panel section.
 * @param props - Breadcrumb title, session standard props, and catalog actions.
 * @returns A title-and-chevron sibling switcher, or nothing on a root session.
 */
export declare function SubagentHeaderLineage({ lineageSessionId, displayTitle, openTitle, useSessions, useSession, useSessionStatus, openChild, openChildAside, refreshProjection, prepareCatalog, t, }: SubagentHeaderLineageProps): import("react").JSX.Element | null;
//# sourceMappingURL=SubagentHeaderLineage.d.ts.map