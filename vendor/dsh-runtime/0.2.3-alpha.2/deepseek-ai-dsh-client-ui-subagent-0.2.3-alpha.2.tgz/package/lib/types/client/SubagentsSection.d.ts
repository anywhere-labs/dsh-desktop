import type { InjectFace, PropsLocale, PropsRenderFactories, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { NS } from './locales.ts';
import { type SubagentCatalogInjected } from './SubagentCatalog.tsx';
import type { createSubagentsSectionStore } from './subagents-store.ts';
/** Full props of the subagents section. */
export type SubagentsSectionProps = PropsRuntime<'conversation.session.panel.section'> & PropsRenderFactories & InjectFace<SubagentCatalogInjected> & PropsStore<ReturnType<typeof createSubagentsSectionStore>> & PropsLocale<typeof NS>;
/** Full props of the section's progress title control. */
export type SubagentsProgressProps = PropsRuntime<'conversation.session.panel.section.actions'> & PropsLocale<typeof NS>;
/** Full props of the running dot on the Session panel toggle. */
export type SubagentsRunningIndicatorProps = PropsRuntime<'conversation.session.panel.indicator'> & PropsLocale<typeof NS>;
/**
 * Render the Session's subagent tree, running subagents first and then the
 * most recently active ones. The list shows five rows and then a fold control
 * that shows the rest, once that holds back two rows or more; the choice is
 * kept per Session. The section renders nothing while the Session has no
 * subagents and no failed catalog read. Showing it reads nothing: rows offer
 * expansion from locally known catalogs, and expanding a branch or retrying a
 * failed read prepares that level. Opening a subagent closes the panel's
 * overlay.
 * @param props - Session hooks, panel owner values, the fold store, catalog actions, and copy.
 * @returns the section body, or null with nothing to show.
 */
export declare function SubagentsSection({ sessionId, dismissOverlay, useSessions, useSessionStatus, useStore, actions, openChild, openChildAside, prepareCatalog, renderFactorySlot, t, }: SubagentsSectionProps): import("react").JSX.Element | null;
/**
 * Render the direct subagents' progress beside the section title.
 * @param props - Session hooks and copy.
 * @returns the progress phrase, or null without subagents.
 */
export declare function SubagentsProgress({ sessionId, useSessions, useSessionStatus, t }: SubagentsProgressProps): import("react").JSX.Element | null;
/**
 * Show on the panel toggle that direct subagents run while the panel does not
 * show them. External tasks do not count, as in the section's progress.
 * @param props - Session hooks, whether the panel shows, and copy.
 * @returns the dot with its name for assistive technology, or null with nothing to report.
 */
export declare function SubagentsRunningIndicator({ sessionId, panelShown, useSessions, useSessionStatus, t }: SubagentsRunningIndicatorProps): import("react").JSX.Element | null;
//# sourceMappingURL=SubagentsSection.d.ts.map