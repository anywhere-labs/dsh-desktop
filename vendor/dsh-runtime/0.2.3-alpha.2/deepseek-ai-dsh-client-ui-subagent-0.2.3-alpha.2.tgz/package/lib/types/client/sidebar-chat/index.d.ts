/** Right-Sidebar presentation of an existing subagent or dragged root Session Conversation. */
import type { Context } from '@deepseek-ai/cordis';
import type { SessionReference, SessionTarget } from '@deepseek-ai/dsh-api-session-controller/client';
import type { ConversationViewsProps, WorkspaceSelectedHandler } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { HostObservable, PropsRenderFactories, PropsRenderSlots, PropsRuntime, TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { SubagentAddress } from '@deepseek-ai/dsh-subagent/client';
import { NS } from '../locales.ts';
import { type SessionDrag } from './SessionDropZone.tsx';
/** Stable implementation identity for the Sidebar tab body. */
export declare const SUBAGENT_CHAT_ID = "@deepseek-ai/dsh-client-ui-subagent";
/** Resource-address prefix for an embedded Session chat. */
export declare const SUBAGENT_CHAT_ADDRESS = "dsh-resource://subagentchat/session/";
/** Value retained by one live chat resource occurrence. */
export interface SubagentChatResource {
    readonly address: SessionTarget;
    readonly reference: SessionReference;
}
declare module '@deepseek-ai/dsh-api-session-controller/client' {
    interface SessionReferenceSourceMap {
        sidebarChat: unknown;
    }
}
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface ResourceProtocolMap {
        subagentchat: SubagentChatResource;
    }
    interface SlotMap {
        /** Session-scoped Conversation occurrence hosted by one Sidebar chat tab. */
        'sidebar.chat.conversation': {
            kind: 'single';
            scope: 'session';
            inject: SidebarChatInjected;
        };
    }
}
/**
 * Address one subagent Session together with the routing facts needed to restore it.
 * @param address - durable direct-parent subagent address.
 * @returns canonical Sidebar resource address.
 */
export declare function subagentChatAddress(address: SubagentAddress): string;
/**
 * Address one root Session, which carries no routing query.
 * @param sessionId - Session dragged from the Session list.
 * @returns canonical Sidebar resource address.
 */
export declare function sessionChatAddress(sessionId: SessionId): string;
/**
 * Parse one canonical Sidebar chat resource address.
 * @param value - possible chat resource address.
 * @returns the encoded direct-parent address, the root Session id of an address without a query,
 * or undefined for another or malformed resource.
 */
export declare function parseSubagentChatAddress(value: string): SessionTarget | undefined;
/**
 * Track Session rows dragged from the Session list while another Session is on screen.
 * @param doc - document whose drag events carry the rows' data.
 * @param mounted - reads the on-screen Session.
 * @returns the dragged Session with its drop targets, and the listener disposer.
 */
export declare function trackSessionDrags(doc: Document, mounted: () => SessionId | undefined): {
    readonly source: HostObservable<SessionDrag | undefined>;
    readonly dispose: () => void;
};
/** Navigation injected into the child-Session Conversation host. */
export interface SidebarChatInjected {
    /** Open the Workspace's blank Session as the main Session. */
    readonly openWorkspace: WorkspaceSelectedHandler;
}
/** Fixed Chat selection used by an embedded Conversation occurrence. */
export declare function FixedChatConversationView(props: ConversationViewsProps): import("react").JSX.Element;
/** Props supplied to the child-Session Conversation host. */
export type ConversationSlotPanelProps = PropsRuntime<'sidebar.chat.conversation'> & PropsRenderFactories;
/** Render the shared Conversation content for one explicitly provided child Session. */
export declare function ConversationSlotPanel({ sessionId, useSession, useConversation, useSessions, renderFactorySlot, openWorkspace, }: ConversationSlotPanelProps): import("react").ReactNode;
/** Props supplied to the parent-Session Sidebar tab body. */
export type SidebarChatTabProps = PropsRuntime<'sidebar.right.pane.tab'> & PropsRenderSlots<'sidebar.chat.conversation'>;
/** Bind a chat resource's child reference around its Conversation slot. */
export declare function SidebarChatTab({ useResource, useTabInfo, SessionProvider, renderSlot }: SidebarChatTabProps): import("react").JSX.Element;
/**
 * Register the chat resource owner and its right-Sidebar presentation.
 * @param ctx - Client root carrying Sessions, resources, Slots, and Sidebar registries.
 * @param t - Chat namespace translator used for fallback tab titles.
 */
export declare function registerSidebarChat(ctx: Context, t: TranslateNS<typeof NS>): void;
//# sourceMappingURL=index.d.ts.map