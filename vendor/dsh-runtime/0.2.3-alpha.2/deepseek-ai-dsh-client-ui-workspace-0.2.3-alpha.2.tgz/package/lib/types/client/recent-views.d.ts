/** Recently viewed Sessions that keep their history stream after leaving the main view. */
import type { ISessions } from '@deepseek-ai/dsh-api-session-controller/client';
import type { IWorkspaces } from '@deepseek-ai/dsh-api-workspace-controller/client';
import type { SessionStatusSnapshot } from '@deepseek-ai/dsh-client-ui-session-status/client';
import type { ObservableSnapshot } from '@deepseek-ai/dsh-client-store';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
/**
 * Attention-ordered retention of non-blank Sessions left by the main view.
 *
 * The state records only what the user did: the order in which Sessions left the main view and the Session it
 * shows now. {@link RecentSessionViews.sync} derives the Sessions to hold from that state and the current Session,
 * Workspace, and status snapshots, then retains the missing ones before releasing the rest. Each held Session has
 * one `recentViews` reference without facets, so its history stays loaded but nothing is derived from it.
 *
 * A Session that is running, awaits the user, or has an unread completion is neither counted nor evicted; beyond
 * the limit, the least recently left unpinned Session is evicted first, then the least recently left pinned one.
 * An evicted, removed, archived, or blank Session also leaves the order, so it returns only when the main view
 * leaves it again.
 */
export declare class RecentSessionViews {
    private readonly sessions;
    private readonly workspaces;
    private readonly status;
    private readonly limit;
    /** Sessions the main view left that are still candidates, most recently left first. */
    private order;
    private current;
    private readonly held;
    private syncing;
    /** Incremented by every sync request, so a running pass repeats while requests arrive during it. */
    private requests;
    /**
     * @param sessions - Session Controller that owns the references.
     * @param workspaces - Workspace Controller whose archived Sessions leave the list and whose pins order eviction.
     * @param status - unified Session UI status deciding which Sessions need attention.
     * @param limit - Host-synced count of Sessions needing no attention kept besides the main-view Session;
     * absent until a value arrives.
     */
    constructor(sessions: Pick<ISessions, 'list' | 'retain' | 'subagentAddress'>, workspaces: Pick<IWorkspaces, 'list'>, status: ObservableSnapshot<SessionStatusSnapshot>, limit: ObservableSnapshot<number | undefined>);
    /**
     * Record the Session the main view shows now and sync; call after retaining its main-view reference and before
     * releasing the previous one, so the previous Session is retained here first.
     * @param sessionId - Session the main view shows, or undefined when it shows none.
     */
    show(sessionId: SessionId | undefined): void;
    /**
     * Sync whenever the Session list, Workspace list, Session UI status, or recent-view limit changes.
     * @returns disposer that stops syncing and releases every held Session.
     */
    start(): () => void;
    /**
     * Hold exactly the Sessions the current state selects, retaining before releasing. Retaining publishes the
     * Session list synchronously, so a re-entrant call only records its request and the running sync repeats.
     */
    sync(): void;
    /**
     * The candidates to keep, in order: every eligible Session needing attention plus the first `limit` others.
     * No limit keeps every counted Session, which reaches the same result as the main view alone being loaded before
     * the Host sends one.
     */
    private selected;
    private acquire;
}
//# sourceMappingURL=recent-views.d.ts.map