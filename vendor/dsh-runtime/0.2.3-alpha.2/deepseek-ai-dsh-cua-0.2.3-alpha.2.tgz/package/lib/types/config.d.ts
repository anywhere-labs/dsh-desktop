/** Schemastery fields for platform-specific native CUA configuration. */
import Schema from '@deepseek-ai/schemastery';
import { type Config as NodeRuntimeConfig } from '@deepseek-ai/dsh-ptc-runtime-node';
import { RunCodeConfig } from '@deepseek-ai/dsh-tool-executor-ptc/run-code';
/** Resource bounds for the dedicated CUA program runtime and its nested tool calls. */
export interface CuaStandaloneRunCodeConfig {
    /** Node limits and launch settings; setting executionMode or scriptPersistence is rejected. */
    runtime: Omit<NodeRuntimeConfig, 'executionMode' | 'scriptPersistence'>;
    /** Timeout-scaled tool-call allowance and maximum concurrent subcalls. */
    executor: RunCodeConfig;
}
/** Validate CUA program limits with the shared Node and executor defaults. */
export declare const CuaStandaloneRunCodeConfig: Schema<Partial<CuaStandaloneRunCodeConfig>, CuaStandaloneRunCodeConfig>;
/** Fixed request-image target for screenshots when no model route selects one. */
export interface CuaScreenshotTargetConfig {
    /** Maximum long edge in pixels; byte-limit enforcement may reduce it further. */
    longEdge: number;
    /** Hard encoded-byte limit before Base64 expansion; oversized screenshots are reduced further. */
    maxBytes: number;
}
/** Validate an explicit screenshot target; omission resolves the target from the Agent's model route. */
export declare const CuaScreenshotTargetConfig: Schema<CuaScreenshotTargetConfig>;
/** Shared configuration fields extended by native platform providers. */
export declare const CuaConfigFields: {
    requireSystemInputApproval: Schema<boolean, boolean, "defined">;
    agentPreset: Schema<string | false, string | false, "defined">;
    standaloneRunCode: Schema<Partial<CuaStandaloneRunCodeConfig>, CuaStandaloneRunCodeConfig, "defined">;
    screenshotTarget: Schema<CuaScreenshotTargetConfig | undefined, CuaScreenshotTargetConfig | undefined, "plain">;
    allowedApps: Schema<({
        id?: string | null;
        name?: string | null;
        executablePath?: string | null;
    } & import("@deepseek-ai/cosmokit").Dict)[], Schemastery.ObjectT<NoInfer<{
        id: Schema<string, string, "defined">;
        name: Schema<string, string, "defined">;
        executablePath: Schema<string, string, "plain">;
    }>>[], "defined">;
    helperPath: Schema<string, string, "plain">;
    buildTimeoutMs: Schema<number, number, "defined">;
    timeoutMs: Schema<number, number, "defined">;
    connectTimeoutMs: Schema<number, number, "defined">;
    screenshotTimeoutMs: Schema<number, number, "defined">;
    axTimeoutMs: Schema<number, number, "defined">;
    maxAppMatches: Schema<number, number, "defined">;
    maxClipboardBytes: Schema<number, number, "defined">;
    pasteReadTimeoutMs: Schema<number, number, "defined">;
    maxRequestBytes: Schema<number, number, "defined">;
    dragDurationMs: Schema<number, number, "defined">;
    maxClickHoldMs: Schema<number, number, "defined">;
    dragSteps: Schema<number, number, "defined">;
    maxResponseBytes: Schema<number, number, "defined">;
    textEventIntervalMs: Schema<number, number, "defined">;
    graceMs: Schema<number, number, "defined">;
    maxElements: Schema<number, number, "defined">;
    maxDepth: Schema<number, number, "defined">;
};
//# sourceMappingURL=config.d.ts.map