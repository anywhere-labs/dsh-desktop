/** Scope and interruption shown before the user grants system input. */
export declare const systemInputControlPrompt: {
    question: {
        en: string;
        zh: string;
        ja: string;
        es: string;
        fr: string;
        de: string;
        ru: string;
        pt: string;
    };
    detail: {
        en: string;
        zh: string;
        ja: string;
        es: string;
        fr: string;
        de: string;
        ru: string;
        pt: string;
    };
};
//# sourceMappingURL=system-input-locales.d.ts.map