---
description: "在 macOS 和 Windows 上开启可选 Computer Use 及权限页面。"
kind: "package-bundle"
---

# @deepseek-ai/dsh-cua-bundle

[English](README.md) | 中文

## 概述

在 macOS 和 Windows 的插件页为已有和新建会话开启 Computer Use。PTC 通过 `run_code` 使用 `cua`，其他预设使用 `cua_run_code`。组合包随 DSH 提供且默认关闭，在受支持 Host 的实验性插件列表中显示。各 Host 加载对应平台的原生提供方和共享权限页面。关闭时不准备本机组件、不注册 CUA 工具或添加其模型指引。

## 目录

- [使用本包](#use-this-package)
- [理解实现](#understand-the-implementation)
- [进一步探索](#further-exploration)
- [模型体验](#model-experience)
- [已知限制与延后工作](#known-limitations-and-deferred-work)

-----

<a id="use-this-package"></a>
## 使用本包

在 macOS 或 Windows 上打开“插件 → 更多”，在实验性插件列表中开启 Computer Use。开启后组合包也会出现在插件主列表中，关闭后只留在实验性插件列表。启用后，详情页在配图下方、设置项上方显示使用建议，Windows 用户还可查看辅助程序的配置步骤。

在 macOS 上，组合包随 DSH 提供并随之升级，开启时无需下载。发布包包含已签名和公证的 helper，用户无需编译工具。源码 Web 和开发 Desktop 在开启时准备临时签名的 helper。请为 `DSH Computer Use.app` 授予辅助功能和屏幕录制权限。

各平台的原生准备和访问要求分别见 [macOS 提供方](../cua-macos/README.zh.md)和 [Windows 提供方](../cua-windows/README.zh.md)。源码 Web 在仓库根目录运行以下命令：

```sh
pnpm run build
pnpm dsh web
```

源码 Desktop 的启动方式和独立开发配置档见[桌面开发说明](../../../apps/desktop/README.zh.md)。需要使用 Computer Use 的配置档分别开启该功能。

开关将组合包选择保存到 profile 的 `package.json`。PTC 会话获得原始 `cua` 绑定；其他 Agent 无论是否组合 preset 都获得 `cua_run_code`，其中自动初始化 `cua` 对象，并保留独立的持久状态。通过卡片或详情页启用时，系统权限未就绪会显示设置引导。详情页提供“设为 PTC”按钮来修改新会话默认模式，已有会话保留原 preset。开关保持 PTC 执行方式和其他设置不变。详情页的“设为持久化”按钮单独开启 PTC 跨调用的内存状态保留，作用范围和重载行为见[权限页面](../cua/README.zh.md)。其他 preset 的 CUA 程序状态独立于此设置。提供方加载时准备本机组件，已有与源码摘要匹配的可执行文件时直接复用。

关闭会卸载提供方，并从其 Agent 作用域中撤回 CUA 工具。执行器配置、新会话默认值和已保存的授权保留。

组合包支持 macOS 和原生 Windows DSH Host，不在 WSL 中启用 Windows Computer Use。原生提供方作为可选依赖提供，各 Host 只加载对应平台的提供方；共享 CUA 和 Client 包仍随安装提供。其他 Host 默认不在插件列表和模型推荐中展示此组合包，并在保存设置前拒绝启用。profile 显式安装的依赖和已保存的选择仍保留管理入口。已选中的组合包会在启动时跳过并报告原因，仍可取消选择；已保存的用户设置保留。其他操作系统上的浏览器可以连接受支持的 DSH Host。

准备失败时，已保存的选择保留，CUA 操作不可用。刷新或重新打开插件页查看组件诊断，修复后重启 DSH。

显式启用会进行只读权限检查，可能启动 helper，但不会打开系统授权弹窗。[权限页面](../cua/README.zh.md) 提供系统申请入口、设置跳转和自动检测。任务访问应用前会单独询问用户。应用授权保存在按 profile 隔离的存储域中。会话授权跨 turn、连接、DSH 重启和 Computer Use 启停保留，只在原对话中生效。可以在同一页面撤销授权。

-----

<a id="understand-the-implementation"></a>
## 理解实现

<details>
<summary>维护者说明</summary>

组合包 patch 通过 `agentPreset: ptc` 挂载原生提供方和权限界面。直接将导出的 `cordis.patch.yml` 用作覆盖层时不会经过组合包准入；行级条件确保 macOS 提供方仅在 macOS 加载，Windows 提供方仅在原生 Windows 加载。仅加载共享条目不能提供计算机控制。工具通过现有 Agent 作用域注册，preset 文档保持不变。详情页按钮复用现有设置表单，仅在点击后保存 `agent-preset-registry.selectedDefault: ptc`。[CUA](../cua/README.zh.md)负责注册和销毁。

</details>

-----

<a id="further-exploration"></a>
## 进一步探索

[Computer use](../../../docs/subsystems/computer-use.zh.md)

-----

<a id="model-experience"></a>
## 模型体验

### 各 preset 中的 Computer Use

#### What the model sees

已有和新建 PTC 会话通过生成的 SDK 与 `run_code` 使用 `cua`，并获得 CUA 指引。其他 Agent 获得 `cua_run_code` 和相同的操作指引。关闭会撤回这些贡献，并释放专用 CUA 运行时。完整接口与输出约定由 [CUA](../cua/README.zh.md) 和 [PTC](../../ptc-runtime/ptc-runtime-node/README.zh.md#persistent-repl) 说明。

#### Token effect

CUA 生效时添加所选 preset 对应的工具 schema 和指引。关闭会撤回这些贡献，现有 PTC 执行说明保留。

#### KV Cache effect

CUA 生效和卸载会改变工具 schema 与系统指引，后续请求使用更新后的前缀。PTC 保留其顶层 `run_code` 工具。

## 已知限制与延后工作

<a id="known-limitations-and-deferred-work"></a>

- Windows 的 npm 安装包不含 helper。请按架构准备原生产物，并通过 `helperPath` 指定 exe。见 [Windows 配置说明](../cua-windows/README.zh.md#setup)。
- 系统权限需用户在 macOS 中确认，开启组合包不会自动授予权限。
- PTC 执行方式由 profile 共享，与 CUA 提供方持有的程序运行时分别配置。未启用 HMR 的 Host 在重启时应用已保存的变更。

<a id="dev-note"></a>
### 开发备注

None.
