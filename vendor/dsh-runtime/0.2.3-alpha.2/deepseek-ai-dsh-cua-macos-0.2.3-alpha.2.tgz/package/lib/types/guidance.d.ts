/** macOS operation levels, permissions, selectors, and native measurement units. */
export declare const PLATFORM_GUIDANCE = "macOS: accessibility tree operations are available at app or window level. Simulated keyboard input is available at app level. Simulated mouse input is available at window level. pressKey, click, and drag accept command, control (or ctrl), option (or alt), shift, and fn. pressKey also accepts cmd for command. For pointer input on a sheet, select its window ID with app.getWindow(id). For menu items outside a window, use app.invoke(id). findApps searches /Applications, /System/Applications, and ~/Applications. Use the Computer Use permission page to grant the helper application Accessibility and Screen Recording permissions in System Settings. Native window and AX bounds use macOS points, while delivered screenshots carry their own pixel dimensions. show does not switch Spaces, and Stage Manager can present reduced window geometry; explain any required foreground step before calling app.activate() or performing an advertised AXRaise action.";
/**
 * Select operation guidance for the current macOS configuration.
 * @param kind - Program environment receiving the instructions.
 * @param activityEnabled - Whether this connection reports recent activity.
 * @returns Model-facing instructions for the configured operations.
 */
export declare function macosGuidance(kind: 'raw' | 'standalone', activityEnabled: boolean): string;
/** Native PTC operation instructions for the default configuration. */
export declare const GUIDANCE: string;
/** Standalone program instructions for the default configuration. */
export declare const PROGRAM_GUIDANCE: string;
//# sourceMappingURL=guidance.d.ts.map