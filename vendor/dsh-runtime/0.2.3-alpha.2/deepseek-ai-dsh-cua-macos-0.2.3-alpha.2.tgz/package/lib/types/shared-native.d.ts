/** Per-Agent byte connections to the per-user native screenshot process. */
import type { Config } from './index.ts';
import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess';
import type { NativeClientConfig, NativeChannel } from '@deepseek-ai/dsh-cua/native-client';
export type { NativeChannel } from '@deepseek-ai/dsh-cua/native-client';
/**
 * Prepare or join the native process; writes wait for identity-checked readiness.
 * @param owner - Provider owning the short-lived native startup command.
 * @param config - Native runtime identity, operation limits and connection deadlines.
 * @param recentActivityWindowMs - Configured macOS activity lookback in milliseconds or "off".
 * @returns One independently disposable Agent connection, without operation replay.
 */
export declare function createSharedNativeChannel(owner: {
    subprocess: Pick<SubprocessRuntime, 'spawn'>;
}, config: NativeClientConfig, recentActivityWindowMs: Config['recentActivityWindowMs']): NativeChannel;
//# sourceMappingURL=shared-native.d.ts.map