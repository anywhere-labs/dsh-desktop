// Wire validation and nullable observations do not require desktop access.
import Foundation
import Testing
@testable import CuaNative

@Test func preservesJSONKindsAndNulls() throws {
    let value = JSONValue.object([
        "missing": .null,
        "flags": .array([.bool(true), .bool(false)]),
        "number": .number(1),
        "text": .string("中文 🧪"),
    ])
    let encoded = try JSONEncoder().encode(value)
    #expect(try JSONDecoder().decode(JSONValue.self, from: encoded) == value)
    #expect(value["absent"] == .null)
    #expect(value["flags"].number == nil)
    #expect(value["number"].string == nil)
}

@Test(arguments: [
    "{}", "[]", "null", "true",
    #"{"id":7,"method":"listApps","params":{}}"#,
    #"{"id":"a","method":null,"params":{}}"#,
    #"{"id":"a","method":"listApps"}"#,
    #"{"id":"a","method":"listApps","params":{},"extra":true}"#,
    #"{"id":"a","id":"b","method":"listApps","params":{}}"#,
    #"{"id":"a","method":"listApps","params":{},"params":{}}"#,
])
func refusesInvalidRequestEnvelopes(_ source: String) {
    #expect(throws: NativeFailure.self) {
        try NativeRequest(data: Data(source.utf8))
    }
}

@Test func retainsTheRequestIDForMethodLevelParameterErrors() throws {
    let request = try NativeRequest(data: Data(#"{"id":"call-7","method":"listApps","params":[]}"#.utf8))
    #expect(request.id == "call-7")
    #expect(request.method == "listApps")
    #expect(request.params == .array([]))
}

@Test func emitsUnknownWindowSpaceAsExplicitNull() throws {
    let window = WindowInfo(
        windowID: 7, pid: 42, appName: "Fixture", title: "Canvas",
        bounds: WindowBounds(x: -100, y: 40, width: 320, height: 200),
        isOnScreen: true, onCurrentSpace: nil
    )
    let encoded = try JSONEncoder().encode(window.json)
    let object = try #require(JSONSerialization.jsonObject(with: encoded) as? [String: Any])
    #expect(object["onCurrentSpace"] is NSNull)
    #expect(window.json["windowId"] == .string("7"))
    #expect(window.json["bounds"]["x"] == .number(-100))
    #expect(window.json["isOnScreen"] == .bool(true))
}

@Test(arguments: [
    (0, false, false, 200.0, true), (0, false, true, 0.0, true),
    (3, true, true, 200.0, true), (3, false, true, 200.0, false),
    (25, true, false, 200.0, false), (3, true, true, 0.0, false),
])
func discoversNormalWindowsAndVisibleAuxiliaryWindows(layer: Int, onScreen: Bool, currentSpace: Bool,
                                                      width: Double, expected: Bool) {
    let window = WindowInfo(windowID: 7, pid: 42, appName: "Fixture", title: "",
                            bounds: WindowBounds(x: 0, y: 0, width: width, height: 100),
                            isOnScreen: onScreen, onCurrentSpace: currentSpace, layer: layer)
    #expect(window.json.object?["cacheOnly"] == (expected ? nil : .bool(true)))
    #expect(window.json.object?.keys.contains("layer") == false)
}

@Test func separatesUnsupportedMethodsFromInvalidParameters() throws {
    let unsupported = try NativeRequest(data: Data(#"{"id":"call","method":"absent","params":{}}"#.utf8))
    do {
        _ = try RequestParameters(unsupported)
        Issue.record("Unsupported operation was admitted")
    } catch let error as NativeFailure {
        #expect(error.code == "UNSUPPORTED")
    }
    for source in [
        #"{"id":"call","method":"listApps","params":[]}"#,
        #"{"id":"call","method":"listApps","params":{"launch":true}}"#,
    ] {
        do {
            _ = try RequestParameters(NativeRequest(data: Data(source.utf8)))
            Issue.record("Invalid operation parameters were admitted")
        } catch let error as NativeFailure {
            #expect(error.code == "INVALID_ARGUMENT")
        }
    }
}

@Test func acceptsWindowIDStrings() throws {
    let request = try NativeRequest(data: Data(#"{"id":"call","method":"screenshot","params":{"windowId":"7"}}"#.utf8))
    let params = try RequestParameters(request)
    #expect(try params.windowID() == 7)
    #expect(try params.optionalWindowID() == 7)
}

@Test(arguments: ["true", "null", "7"])
func rejectsNonStringWindowIDs(_ value: String) throws {
    let request = try NativeRequest(data: Data("{\"id\":\"call\",\"method\":\"screenshot\",\"params\":{\"windowId\":\(value)}}".utf8))
    #expect(throws: NativeFailure.self) { try RequestParameters(request) }
}

@Test func validatesOptionalWindowIDsBeforeOperationDispatch() throws {
    let absent = try RequestParameters(NativeRequest(data: Data(#"{"id":"call","method":"getState","params":{}}"#.utf8)))
    #expect(try absent.optionalWindowID() == nil)
    let numeric = try NativeRequest(data: Data(#"{"id":"call","method":"listActions","params":{"windowId":7}}"#.utf8))
    #expect(throws: NativeFailure.self) { try RequestParameters(numeric) }
}

@Test func rejectsRoundedIntegerOverflowWithoutTrapping() throws {
    let request = try NativeRequest(data: Data(#"{"id":"call","method":"click","params":{"clickCount":9223372036854775808}}"#.utf8))
    let params = try RequestParameters(request)
    #expect(throws: NativeFailure.self) { try params.integer("clickCount", in: 0...Int.max) }
}

@Test(arguments: [("12", 12), ("007", 7)])
func resolvesDecimalElementIdentifiers(_ source: String, _ index: Int) throws {
    let request = try NativeRequest(data: Data("{\"id\":\"call\",\"method\":\"click\",\"params\":{\"elementId\":\"\(source)\"}}".utf8))
    #expect(try RequestParameters(request).elementIdIndex() == index)
}

@Test(arguments: [
    #"12"#, #""""#, #""-1""#, #""+1""#, #"" 1""#, #""1.0""#, #""abc""#, #""e12""#,
    #""9223372036854775808""#, #""١٢""#,
])
func rejectsNonDecimalElementIdentifiers(_ value: String) throws {
    let request = try NativeRequest(data: Data("{\"id\":\"call\",\"method\":\"click\",\"params\":{\"elementId\":\(value)}}".utf8))
    let params = try RequestParameters(request)
    #expect(throws: NativeFailure.self) { try params.elementIdIndex() }
}

@Test func nestedSeparatorsAndEscapedQuotesDoNotChangeEnvelopeFieldCount() throws {
    let request = try NativeRequest(data: Data(#"{"id":"call","method":"typeText","params":{"text":"comma, quote\" braces{}[] slash\\","nested":[1,{"x":2,"y":3}]}}"#.utf8))
    #expect(request.id == "call")
    #expect(request.params["nested"] == .array([.number(1), .object(["x": .number(2), "y": .number(3)])]))
}

@Test func resolvesTextEventIntervalFromHelperArguments() throws {
    #expect(try HelperConfiguration(arguments: []).textEventIntervalSeconds == 0.00025)
    #expect(try HelperConfiguration(arguments: ["--text-event-interval-ms", "0.5"]).textEventIntervalSeconds == 0.0005)
    #expect(try HelperConfiguration(arguments: ["--text-event-interval-ms", "0"]).textEventIntervalSeconds == 0)
    #expect(try HelperConfiguration(arguments: ["--text-event-interval-ms", "1000"]).textEventIntervalSeconds == 1)
    for invalid in ["-1", "1000.1", "nan", "inf", "absent"] {
        #expect(throws: NativeFailure.self) {
            try HelperConfiguration(arguments: ["--text-event-interval-ms", invalid])
        }
    }
}

@Test func disclosureFlagsRejectNonBooleanWireValues() throws {
    for source in ["true", "false"] {
        let params = try RequestParameters(NativeRequest(data: Data("{\"id\":\"read\",\"method\":\"getState\",\"params\":{\"details\":\(source)}}".utf8)))
        #expect(try params.optionalBoolean("details") == (source == "true"))
        #expect(try params.optionalBoolean("includeMenus") == nil)
    }
    for source in ["1", "null", "\"true\""] {
        let params = try RequestParameters(NativeRequest(data: Data("{\"id\":\"read\",\"method\":\"getState\",\"params\":{\"includeMenus\":\(source)}}".utf8)))
        #expect(throws: NativeFailure.self) { try params.optionalBoolean("includeMenus") }
    }
}

@Test(arguments: ["null", "true", "[1]", "[\"\"]"])
func rejectsMalformedApplicationIconPaths(_ value: String) throws {
    let request = try NativeRequest(data: Data("{\"id\":\"icons\",\"method\":\"applicationIcons\",\"params\":{\"paths\":\(value)}}".utf8))
    #expect(throws: NativeFailure.self) { try RequestParameters(request).strings("paths") }
}
