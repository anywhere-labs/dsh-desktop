import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess';
import { type NativeChannel, type NativeClientConfig } from '@deepseek-ai/dsh-cua/native-client';
import { type WindowsTransport } from './native-transport.ts';
type Owner = {
    subprocess: Pick<SubprocessRuntime, 'spawn'>;
};
/** One provider owns a service lease; Agent connections own only their application and snapshot state. */
export declare class WindowsNativeRuntime {
    private readonly owner;
    private readonly pollIntervalMs;
    private readonly launchWaitMs;
    private readonly transport;
    private helper;
    private disposal;
    private readonly channels;
    /**
     * @param owner Managed subprocess provider.
     * @param pollIntervalMs Clipboard and application-readiness polling interval.
     * @param launchWaitMs Maximum observation wait after a Shell launch; expiry is not a launch failure.
     * @param transport Resolved native Windows or WSL connection method.
     */
    constructor(owner: Owner, pollIntervalMs: number, launchWaitMs: number, transport?: WindowsTransport);
    /**
     * Connect one Agent without transferring process ownership to that Agent.
     * @param config Executable identity and per-connection limits.
     * @returns The byte stream used by the shared native request client.
     */
    connect(config: NativeClientConfig): NativeChannel;
    /** Close Agent pipes and join this Host's connector; other Hosts retain their service leases. */
    dispose(): Promise<void>;
}
export {};
//# sourceMappingURL=native-runtime.d.ts.map