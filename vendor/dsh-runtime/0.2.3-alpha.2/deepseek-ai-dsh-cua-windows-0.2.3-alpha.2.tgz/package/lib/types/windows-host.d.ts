import { type HostEnvironmentFacts } from '@deepseek-ai/dsh-native-command';
import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess';
import type { NativeArchitecture } from './native-build.ts';
/** DSH execution environment, independently of the Windows desktop it controls. */
export type WindowsHost = 'windows' | 'wsl';
/**
 * Resolve the Host before compiling or launching native code.
 * @param facts Process and kernel facts; omitted fields use the current Host.
 * @returns Native Windows or WSL; ordinary Linux has no Windows desktop provider.
 */
export declare function windowsHost(facts?: HostEnvironmentFacts): WindowsHost;
/** Managed command lifetime for WSL capability and path queries. */
export interface WslPreparation {
    subprocess: Pick<SubprocessRuntime, 'spawn'>;
    signal: AbortSignal;
    timeoutMs: number;
    graceMs: number;
    powershellPath: string;
}
/**
 * Verify that WSL can start Windows programs and resolve the Windows runtime architecture.
 * @param spec Managed process policy and Windows PowerShell executable.
 * @returns Windows architecture and a WSL-visible cache directory on the Windows filesystem.
 */
export declare function prepareWsl(spec: WslPreparation): Promise<{
    architecture: NativeArchitecture;
    cacheDirectory: string;
}>;
/**
 * Retain the helper on the Windows filesystem so Explorer can launch the shared desktop service.
 * @param helperPath Absolute executable path visible to WSL.
 * @param cacheDirectory Windows user cache translated to a WSL path.
 * @param signal Provider preparation lifetime.
 * @returns Content-addressed executable path, without modifying the source payload.
 */
export declare function retainWslHelper(helperPath: string, cacheDirectory: string, signal: AbortSignal): Promise<string>;
//# sourceMappingURL=windows-host.d.ts.map