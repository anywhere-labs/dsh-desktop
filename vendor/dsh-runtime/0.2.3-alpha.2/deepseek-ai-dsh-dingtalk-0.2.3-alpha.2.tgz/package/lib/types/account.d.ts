/** Check, sign-in, and sign-out of the dws account that the user's terminal shares, as the operations `ctx.cliAccounts` runs. */
import type { CliOperationControl } from '@deepseek-ai/dsh-cli-account/types';
import type { DwsRelease } from './release.ts';
import type { DingtalkAccountState, DingtalkCommand, DingtalkOperationKind, DingtalkPhase } from './types.ts';
type Control = CliOperationControl<DingtalkAccountState, DingtalkPhase, DingtalkCommand>;
/** The dws and skill installation each check prepares before its first command. */
type Release = Pick<DwsRelease, 'installed' | 'install'>;
/**
 * Bind the DingTalk account operations to the dws installation.
 * @param release - the dws and skill installation.
 * @returns the function that carries out one operation with dws and publishes the account each check observes; it
 *   throws when the installation or a command fails, `auth status` prints an unknown status, a sign-in leaves no
 *   signed-in account, or a sign-out finds none to sign out.
 */
export declare function performWith(release: Release): (kind: DingtalkOperationKind, control: Control, signal: AbortSignal) => Promise<void>;
export {};
//# sourceMappingURL=account.d.ts.map