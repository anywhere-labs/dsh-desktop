/**
 * DingTalk plugin: installs dws and its upstream skills from the pinned release into the DSH cache, registers dws and
 * its account with `ctx.cliAccounts`, which tells the model dws's absolute path once both are installed and shows the
 * account on the Plugins page, and registers the `dingtalk` skill once its root is published. In a profile, the
 * release in place replaces the earlier ones in that profile's cache directory. The CLI's sign-in is shared with the
 * user's own terminal.
 * @module @deepseek-ai/dsh-dingtalk
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
/** Plugin name. */
export declare const name = "dingtalk";
/** Services the CLI's account and its skill register with. */
export declare const inject: string[];
/** Where dws and its skills come from, and how long one download may take. */
export interface Config {
    /** Absolute directory holding the `dws` executable; when set, dws is not downloaded. */
    binDir?: string;
    /** Directory holding the upstream skills laid out as `multi/` in the release's `dws-skills.zip`; when set, they are not downloaded. */
    skillsDir?: string;
    /** Release download prefixes tried in order for what `binDir` and `skillsDir` do not provide; each serves `v<version>/<asset name>`. */
    releaseUrls: string[];
    /** How long one prefix may take to deliver an asset before the next one is tried. */
    releaseTimeoutMs: number;
}
/** Validates {@link Config}. */
export declare const Config: z<Config>;
/**
 * Register dws with its account, and its skill, and start preparing both.
 * @param ctx - Context carrying the CLI account Service and the skill registry.
 * @param config - dws and skills locations, and download prefixes.
 * @throws when `binDir` holds no executable `dws`, `skillsDir` is not a directory, the pinned release has no archive for
 *   this platform, or the skill root cannot be written.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map