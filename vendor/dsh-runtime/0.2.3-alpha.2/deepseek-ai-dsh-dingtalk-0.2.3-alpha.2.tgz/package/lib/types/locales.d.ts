/** The DingTalk text the Plugins page shows; the browser resolves it in its active language. */
/** Chinese dictionary and key source. */
export declare const zh: {
    'section.title': string;
    'status.checking': string;
    'status.disconnected': string;
    'status.unavailable': string;
    'status.connected': string;
    'step.downloading': string;
    'step.authorizing': string;
    'step.connecting': string;
    'step.signing-out': string;
    'detail.disconnected': string;
    'detail.unavailable': string;
    'detail.missing': string;
    'detail.connected': string;
    'detail.connectedAs': string;
    'detail.connectedIn': string;
    'detail.authorizing': string;
    hint: string;
    failed: string;
    'failed.signIn': string;
    'action.connect': string;
    'action.open': string;
    'action.cancel': string;
    'action.signOut': string;
    'action.addAccount': string;
    'action.retry': string;
    'badge.connected': string;
    'badge.disconnected': string;
    'badge.connecting': string;
    'badge.unavailable': string;
    'signOut.title': string;
    'signOut.body': string;
    'activation.title': string;
    'activation.body': string;
    'notice.connected': string;
    'notice.signed-out': string;
};
/** Every key of the DingTalk text. */
export type DingtalkTextKey = keyof typeof zh;
/** English dictionary. */
export declare const en: Record<DingtalkTextKey, string>;
/** Japanese dictionary. */
export declare const ja: Record<DingtalkTextKey, string>;
/** Spanish dictionary. */
export declare const es: Record<DingtalkTextKey, string>;
/** French dictionary. */
export declare const fr: Record<DingtalkTextKey, string>;
/** German dictionary. */
export declare const de: Record<DingtalkTextKey, string>;
/** Russian dictionary. */
export declare const ru: Record<DingtalkTextKey, string>;
/** Portuguese dictionary. */
export declare const pt: Record<DingtalkTextKey, string>;
/** The dictionary of every shipped language. */
export declare const dictionaries: {
    zh: {
        'section.title': string;
        'status.checking': string;
        'status.disconnected': string;
        'status.unavailable': string;
        'status.connected': string;
        'step.downloading': string;
        'step.authorizing': string;
        'step.connecting': string;
        'step.signing-out': string;
        'detail.disconnected': string;
        'detail.unavailable': string;
        'detail.missing': string;
        'detail.connected': string;
        'detail.connectedAs': string;
        'detail.connectedIn': string;
        'detail.authorizing': string;
        hint: string;
        failed: string;
        'failed.signIn': string;
        'action.connect': string;
        'action.open': string;
        'action.cancel': string;
        'action.signOut': string;
        'action.addAccount': string;
        'action.retry': string;
        'badge.connected': string;
        'badge.disconnected': string;
        'badge.connecting': string;
        'badge.unavailable': string;
        'signOut.title': string;
        'signOut.body': string;
        'activation.title': string;
        'activation.body': string;
        'notice.connected': string;
        'notice.signed-out': string;
    };
    en: Record<"section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.downloading" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.disconnected" | "detail.unavailable" | "detail.missing" | "detail.connected" | "detail.connectedAs" | "detail.connectedIn" | "detail.authorizing" | "hint" | "failed" | "failed.signIn" | "action.connect" | "action.open" | "action.cancel" | "action.signOut" | "action.addAccount" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "activation.title" | "activation.body" | "notice.connected" | "notice.signed-out", string>;
    ja: Record<"section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.downloading" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.disconnected" | "detail.unavailable" | "detail.missing" | "detail.connected" | "detail.connectedAs" | "detail.connectedIn" | "detail.authorizing" | "hint" | "failed" | "failed.signIn" | "action.connect" | "action.open" | "action.cancel" | "action.signOut" | "action.addAccount" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "activation.title" | "activation.body" | "notice.connected" | "notice.signed-out", string>;
    es: Record<"section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.downloading" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.disconnected" | "detail.unavailable" | "detail.missing" | "detail.connected" | "detail.connectedAs" | "detail.connectedIn" | "detail.authorizing" | "hint" | "failed" | "failed.signIn" | "action.connect" | "action.open" | "action.cancel" | "action.signOut" | "action.addAccount" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "activation.title" | "activation.body" | "notice.connected" | "notice.signed-out", string>;
    fr: Record<"section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.downloading" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.disconnected" | "detail.unavailable" | "detail.missing" | "detail.connected" | "detail.connectedAs" | "detail.connectedIn" | "detail.authorizing" | "hint" | "failed" | "failed.signIn" | "action.connect" | "action.open" | "action.cancel" | "action.signOut" | "action.addAccount" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "activation.title" | "activation.body" | "notice.connected" | "notice.signed-out", string>;
    de: Record<"section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.downloading" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.disconnected" | "detail.unavailable" | "detail.missing" | "detail.connected" | "detail.connectedAs" | "detail.connectedIn" | "detail.authorizing" | "hint" | "failed" | "failed.signIn" | "action.connect" | "action.open" | "action.cancel" | "action.signOut" | "action.addAccount" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "activation.title" | "activation.body" | "notice.connected" | "notice.signed-out", string>;
    ru: Record<"section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.downloading" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.disconnected" | "detail.unavailable" | "detail.missing" | "detail.connected" | "detail.connectedAs" | "detail.connectedIn" | "detail.authorizing" | "hint" | "failed" | "failed.signIn" | "action.connect" | "action.open" | "action.cancel" | "action.signOut" | "action.addAccount" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "activation.title" | "activation.body" | "notice.connected" | "notice.signed-out", string>;
    pt: Record<"section.title" | "status.checking" | "status.disconnected" | "status.unavailable" | "status.connected" | "step.downloading" | "step.authorizing" | "step.connecting" | "step.signing-out" | "detail.disconnected" | "detail.unavailable" | "detail.missing" | "detail.connected" | "detail.connectedAs" | "detail.connectedIn" | "detail.authorizing" | "hint" | "failed" | "failed.signIn" | "action.connect" | "action.open" | "action.cancel" | "action.signOut" | "action.addAccount" | "action.retry" | "badge.connected" | "badge.disconnected" | "badge.connecting" | "badge.unavailable" | "signOut.title" | "signOut.body" | "activation.title" | "activation.body" | "notice.connected" | "notice.signed-out", string>;
};
//# sourceMappingURL=locales.d.ts.map