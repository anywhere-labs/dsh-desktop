/**
 * The pinned dws release the plugin installs into the DSH cache: the executable and the upstream skills. In a profile
 * they go to that profile's own cache directory, where the release in place replaces the earlier ones.
 */
import type { Context } from '@deepseek-ai/cordis';
/** The name dws's guides and scripts run it by. */
export declare const PROGRAM = "dws";
/**
 * Name the executable file as the release archives carry it.
 * @param platform - the Host platform.
 * @returns `dws`, or `dws.exe` on Windows.
 */
export declare function executableFileName(platform: NodeJS.Platform): string;
/** One release asset as the release's `checksums.txt` and asset list describe it. */
export interface DwsArchive {
    /** Asset name under the release tag. */
    readonly name: string;
    /** Exact size in bytes; a response declaring another `Content-Length` is refused before its body is read. */
    readonly bytes: number;
    /** Lowercase hexadecimal SHA-256 digest. */
    readonly sha256: string;
}
/** One dws release: its executable archives keyed by `<platform>-<arch>`, and its platform-independent skills archive. */
export interface DwsReleaseManifest {
    readonly version: string;
    readonly archives: Readonly<Partial<Record<string, DwsArchive>>>;
    /** `dws-skills.zip`, whose `multi/` directory holds one directory per upstream skill. */
    readonly skills: DwsArchive;
}
/** The release this plugin version installs. */
export declare const DWS_RELEASE: DwsReleaseManifest;
/** Where dws and its skills come from. */
export interface DwsReleaseOptions {
    /** Absolute directory holding an executable `dws`, `dws.exe` on Windows; when set, the executable is not downloaded. */
    readonly binDir?: string | undefined;
    /** Directory holding the upstream skills laid out as `multi/` in `dws-skills.zip`; when set, they are not downloaded. */
    readonly skillsDir?: string | undefined;
    /** Release download prefixes tried in order; each serves `v<version>/<asset name>`. */
    readonly releaseUrls: readonly string[];
    /** How long one prefix may take to deliver an asset before the next one is tried. */
    readonly releaseTimeoutMs: number;
    /**
     * The profile that loads the plugin: its Harness home and its name. Its downloads go to its own cache directory,
     * `$DSH_HOME/cache/dingtalk/<profile>`. Without one they go to `$DSH_HOME/cache/dingtalk`, which several
     * installations may share.
     */
    readonly profile?: {
        readonly home: string;
        readonly name: string;
    } | undefined;
}
/** Locates dws and the `dingtalk` skill, and installs from the pinned release whichever is missing. */
export declare class DwsRelease {
    private readonly options;
    private readonly logger;
    private readonly release;
    /**
     * The directory holding `dws` (`dws.exe` on Windows): `binDir`, or `dws-<version>-<platform>-<arch>` in the cache
     * directory, which is `$DSH_HOME/cache/dingtalk/<profile>` in a profile and `$DSH_HOME/cache/dingtalk` without one.
     */
    readonly directory: string;
    /**
     * The skill root `skill-<digest>` in the cache directory: a copy of the packaged `dingtalk/SKILL.md` and a
     * `dingtalk/guides` link to the upstream skills. The digest covers the entry and the link target, so a published root
     * never changes.
     */
    readonly skillRoot: string;
    /** The upstream skills the guides link points to: `skillsDir`, or `dws-skills-<version>` in the cache directory. */
    private readonly guides;
    /** The profile's own cache directory, whose other releases {@link prune} deletes; undefined without a profile. */
    private readonly owned;
    private readonly entry;
    private readonly archive;
    private pruned;
    /**
     * Publish the skill root at once when the upstream skills are already present, so the first skill catalog lists it.
     * @param options - the configured directories, download prefixes, and the time one prefix may take.
     * @param logger - receives one warning for each download source that fails or does not deliver in time.
     * @param release - the release to install; defaults to {@link DWS_RELEASE}.
     * @throws when `binDir` holds no executable `dws`, `skillsDir` is not a directory, the release has no archive for this
     *   platform, or the skill root cannot be written.
     */
    constructor(options: DwsReleaseOptions, logger: Context['logger'], release?: DwsReleaseManifest);
    /**
     * Check whether dws and the skill are in place.
     * @returns whether `directory` holds an executable `dws`, the upstream skills exist, and the skill root is published.
     */
    installed(): boolean;
    /**
     * Download whichever of the executable archive and the skills archive is missing, verify its size and digest, extract it
     * beside its cache directory, and publish it there by rename; then publish the skill root. A prefix that does not
     * deliver an asset within `releaseTimeoutMs` is skipped for the next one. A directory that another process published
     * first is kept. A failure other than an abort is logged as a warning before it is thrown, because the account
     * operation that runs the installation discards what it throws. A finished installation starts {@link prune} without
     * waiting for it.
     * @param signal - aborts the downloads and the publishes without trying another prefix.
     * @returns after `dws` is executable in `directory` and the skill root is published.
     * @throws when `binDir` or `skillsDir` lost its content, every source of an archive fails, or the executable archive holds
     *   no `dws`.
     */
    install(signal: AbortSignal): Promise<void>;
    /**
     * Delete from the profile's own cache directory every published dws, skills directory, and skill root that this
     * release does not use, once: on the first call that finds {@link installed} true. It deletes nothing without a
     * profile, while {@link installed} is false, so an earlier release stays until this one is in place, or after that
     * call. A process whose release a process running another plugin version deleted therefore installs it again without
     * deleting that process's release. An entry that cannot be deleted, such as a `dws.exe` that still runs on Windows,
     * is logged as a warning and stays until a later load.
     * @returns after the deletion finishes or stops at an entry it cannot delete; it never rejects.
     */
    prune(): Promise<void>;
    private prepare;
    private executable;
    private published;
    /** Fill a sibling staging directory, then rename its output to `directory` unless another process published one first. */
    private publish;
    /** Publish the skill root the same way, synchronously, so a constructor-time root is in place before the first catalog. */
    private assemble;
    private download;
    private fetchArchive;
}
//# sourceMappingURL=release.d.ts.map