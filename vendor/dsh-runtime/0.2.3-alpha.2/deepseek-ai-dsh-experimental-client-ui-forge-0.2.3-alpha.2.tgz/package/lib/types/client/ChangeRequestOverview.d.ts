/**
 * Overview rows of an expanded change request card, each one line: the checks outcome, the review decision with the
 * reviewers' avatars, the merge state, and the issues linked to the change request. Details and actions open in a menu
 * from the row: the checks grouped by outcome with the rerun of the failed ones, the reviewers with review requests,
 * and the branch update.
 */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { BranchUpdateRequest, ChangeRequestCheck, ChangeRequestReviewer, ChangeRequestSnapshot, ForgeRerunRequest, ForgeReviewerCandidate } from '@deepseek-ai/dsh-experimental-forge/types';
import type { ForgePanelKey, NS } from './locales.ts';
import { type ChangeRequestEntry } from './status.ts';
type Translate = PropsLocale<typeof NS>['t'];
/** Requests reviews of a change request from more reviewers; settles once the outcome is reported. */
type RequestReviews = (entry: ChangeRequestEntry, reviewers: readonly Pick<ChangeRequestReviewer, 'kind' | 'login'>[]) => Promise<void>;
/** Lists the accounts a review of the change request at `url` can be requested from. */
type ListCandidates = (url: string, query: string, signal: AbortSignal) => Promise<readonly ForgeReviewerCandidate[]>;
/** Overview actions of a card; a surface without a Session binding omits them. */
export interface OverviewActions {
    /** Rerun the failed checks; settles once the outcome is reported. */
    readonly rerunChecks?: ((entry: ChangeRequestEntry, request: ForgeRerunRequest) => Promise<void>) | undefined;
    /** Request reviews from more reviewers; settles once the outcome is reported. */
    readonly requestReviews?: RequestReviews | undefined;
    /** List accounts a review can be requested from; rejects with the host's reason. */
    readonly reviewerCandidates?: ListCandidates | undefined;
    /** Bring the base branch's new commits into the head branch; settles once the outcome is reported. */
    readonly updateBranch?: ((entry: ChangeRequestEntry, request: BranchUpdateRequest) => Promise<void>) | undefined;
}
/**
 * One action at a time per control: it stays disabled until the previous action settles.
 * @returns whether an action runs, and the function that runs one.
 */
export declare function useBusy(): readonly [boolean, (action: () => Promise<void>) => void];
/**
 * The parts of one fact row: its glyph, its one-line value after the fact's name, which only assistive technology
 * reads unless the value names the fact itself, an optional trailing part, and the chevron of a row that opens something.
 * @param props - the fact's name for assistive technology, the glyph, the value with its tone, the trailing part, and
 * whether the row opens something.
 * @returns the row's cells.
 */
export declare function RowParts({ label, icon, value, tone, trailing, opens }: {
    readonly label: string | undefined;
    readonly icon: ReactNode;
    readonly value: ReactNode;
    readonly tone?: string | undefined;
    readonly trailing?: ReactNode;
    readonly opens: boolean;
}): ReactNode;
type CheckGroup = 'failed' | 'running' | 'cancelled' | 'passed' | 'other';
/** Checks of one outcome group. */
export interface CheckGroupList {
    readonly group: CheckGroup;
    /** Name of the group. */
    readonly label: ForgePanelKey;
    readonly checks: readonly ChangeRequestCheck[];
}
/**
 * Group checks by outcome, leaving out empty groups.
 * @param checks - the checks of the head commit.
 * @param kind - the failed, running, and cancelled groups, which need attention, or the passed and skipped ones.
 * @returns the groups in display order.
 */
export declare function checkGroups(checks: readonly ChangeRequestCheck[], kind: 'attention' | 'quiet'): readonly CheckGroupList[];
/**
 * How long a check took, or that it is queued or running.
 * @param check - the check.
 * @param t - forge panel copy.
 * @returns the text, empty for a finished check without times.
 */
export declare function checkTime(check: ChangeRequestCheck, t: Translate): string;
/**
 * The checks outcome in a few words: what needs attention, else that all passed.
 * @param snapshot - the snapshot whose checks are summarized.
 * @param t - forge panel copy.
 * @returns the summary.
 */
export declare function checksValue(snapshot: ChangeRequestSnapshot, t: Translate): string;
type CheckRead = {
    readonly kind: 'idle' | 'loading';
} | {
    readonly kind: 'ready';
    readonly snapshot: ChangeRequestSnapshot;
} | {
    readonly kind: 'failed';
    readonly message: string;
};
type ReadChecks = ((url: string, headSha: string, signal: AbortSignal) => Promise<ChangeRequestSnapshot>) | undefined;
/**
 * Complete a check list the poll read only in part: while `active`, read the complete list of the snapshot's head
 * independently of polling, and stop when `active` ends or the head moves.
 * @param snapshot - the polled snapshot.
 * @param active - whether the checks are shown in full.
 * @param readChecks - loads the complete checks, or undefined on a surface that cannot.
 * @returns the snapshot to display, the state of the read, and a function that reads again.
 */
export declare function useCompleteChecks(snapshot: ChangeRequestSnapshot, active: boolean, readChecks: ReadChecks): {
    readonly displayed: ChangeRequestSnapshot;
    readonly read: CheckRead;
    readonly retry: () => void;
};
/**
 * Render the state of a complete-checks read that has not finished: that it loads, or why it failed with a retry.
 * @param props - the read, the retry, and copy.
 * @returns the status line, or null when nothing is being read or the read finished.
 */
export declare function ChecksReadStatus({ read, retry, t }: {
    readonly read: CheckRead;
    readonly retry: () => void;
    readonly t: Translate;
}): ReactNode;
/** Props of the checks row. */
export interface ChecksRowProps {
    readonly entry: ChangeRequestEntry;
    readonly snapshot: ChangeRequestSnapshot;
    readonly openLink: (url: string) => void;
    /** Load complete check details independently of polling; cancellation follows the open menu. */
    readonly readChecks: ReadChecks;
    readonly rerunChecks: OverviewActions['rerunChecks'];
    readonly t: Translate;
}
/**
 * The rerun of failed checks, when the change request is open, the signed-in user may rerun, and a rerun can start.
 * @param displayed - the snapshot whose checks are shown.
 * @param rerunChecks - the surface's rerun action.
 * @returns the action, or undefined when no rerun is offered.
 */
export declare function rerunOf(displayed: ChangeRequestSnapshot, rerunChecks: OverviewActions['rerunChecks']): OverviewActions['rerunChecks'];
/**
 * Render the checks outcome as a row whose menu lists the failed, running, and cancelled checks by group, offers to
 * rerun the failed ones, and lists the passed and skipped ones on request. A list the poll read only in part is
 * completed while the menu is open.
 * @param props - the change request, its snapshot, the link and read actions, the rerun action, and copy.
 * @returns the row with its menu.
 */
export declare function ChecksRow({ entry, snapshot, openLink, readChecks, rerunChecks, t }: ChecksRowProps): ReactNode;
/** Props of the review row. */
export interface ReviewRowProps {
    readonly entry: ChangeRequestEntry;
    readonly snapshot: ChangeRequestSnapshot;
    /** The aggregate review outcome. */
    readonly value: string;
    /** Tone of the aggregate outcome. */
    readonly tone: string | undefined;
    readonly requestReviews: OverviewActions['requestReviews'];
    readonly reviewerCandidates: OverviewActions['reviewerCandidates'];
    readonly openLink: (url: string) => void;
    readonly t: Translate;
}
/**
 * Render the review decision as a row with the first reviewers' avatars. Its menu lists each reviewer with their
 * latest outcome or that their review is requested, and, when the signed-in user may request reviews, offers to ask a
 * reviewer again and to request a review from someone else through a search.
 * @param props - the change request, its snapshot, the aggregate outcome, the review request actions, and copy.
 * @returns the row with its menu.
 */
export declare function ReviewRow({ entry, snapshot, value, tone, requestReviews, reviewerCandidates, openLink, t }: ReviewRowProps): ReactNode;
/**
 * The reviewers a review can be asked of again: people who reviewed and are not asked now. Bots review on their own
 * triggers.
 * @param reviewers - the change request's reviewers.
 * @returns the reviewers to offer.
 */
export declare function reviewersToAskAgain(reviewers: readonly ChangeRequestReviewer[]): readonly ChangeRequestReviewer[];
/**
 * Render the menu items that request reviews: one per reviewer to ask again, then the search for someone else.
 * @param props - the reviewers to ask again, whether a separator precedes the first item, the request and search
 * handlers, and copy.
 * @returns the items.
 */
export declare function ReviewRequestItems({ again, separated, onRequest, onSearch, t }: {
    readonly again: readonly ChangeRequestReviewer[];
    readonly separated: boolean;
    readonly onRequest: (reviewer: Pick<ChangeRequestReviewer, 'kind' | 'login'>) => void;
    readonly onSearch: () => void;
    readonly t: Translate;
}): ReactNode;
/**
 * Render one reviewer: avatar, login, what kind of reviewer, and their latest outcome or pending request.
 * @param props - the reviewer, the head commit their outcome is compared with, and copy.
 * @returns the line.
 */
export declare function ReviewerLine({ reviewer, headSha, t }: {
    readonly reviewer: ChangeRequestReviewer;
    readonly headSha: string;
    readonly t: Translate;
}): ReactNode;
/**
 * Render the searchable account list of a review request: the host's suggestions first, then accounts matching the
 * search.
 * @param props - the change request URL, the listing, the choice handler, and copy.
 * @returns the search field and its list.
 */
export declare function ReviewerSearch({ url, list, choose, t }: {
    readonly url: string;
    readonly list: ListCandidates;
    readonly choose: (login: string) => void;
    readonly t: Translate;
}): ReactNode;
/** Props of the merge row. */
export interface MergeRowProps {
    readonly entry: ChangeRequestEntry;
    readonly snapshot: ChangeRequestSnapshot;
    /** Glyph of the row. */
    readonly icon: ReactNode;
    /** The merge conflict status. */
    readonly value: string;
    /** Tone of the conflict status. */
    readonly tone: string | undefined;
    readonly updateBranch: OverviewActions['updateBranch'];
    readonly t: Translate;
}
/**
 * Render the merge state as a row: the conflict status and whether the head is behind its base. While the signed-in
 * user can update the head branch, the row opens the update menu: a title, one row per method, and the confirmation,
 * which is refused once the head moved after the menu opened.
 * @param props - the change request, its snapshot, the row glyph and status, the update action, and copy.
 * @returns the row, with its menu when the branch can be updated.
 */
export declare function MergeRow({ entry, snapshot, icon, value, tone, updateBranch, t }: MergeRowProps): ReactNode;
/**
 * A speech bubble, the glyph of review threads.
 * @param props - glyph size in pixels.
 * @returns the decorative glyph.
 */
export declare function ThreadGlyph({ size }: {
    readonly size?: number;
}): ReactNode;
/**
 * Render the issues linked to the change request, which the host closes once it merges, as one row of links, each
 * named by its number with its title in a tooltip, or nothing without one. More issues than the provider read end the
 * row with a note.
 * @param props - the snapshot, the link action, and copy.
 * @returns the row, or null.
 */
export declare function IssuesRow({ snapshot, openLink, t }: {
    readonly snapshot: ChangeRequestSnapshot;
    readonly openLink: (url: string) => void;
    readonly t: Translate;
}): ReactNode;
export {};
//# sourceMappingURL=ChangeRequestOverview.d.ts.map