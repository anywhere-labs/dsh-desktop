/** Session panel section listing the Session's change requests, and its title control. */
import { type ReactNode } from 'react';
import type { HostObservable, InjectFace, PropsLocale, PropsRenderFactories, PropsRenderSlots, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { MergeRequest } from '@deepseek-ai/dsh-experimental-forge/types';
import { type ChangeRequestActions } from './ChangeRequestCard.tsx';
import type { createChangeRequestsSectionStore } from './change-requests-store.ts';
import type { NS } from './locales.ts';
import type { PanelSnapshot } from './source.ts';
import { type ChangeRequestEntry } from './status.ts';
/** Business face of the change requests section. */
export interface ChangeRequestsSectionInjected {
    /** Panel snapshot of the Session and the active language; bound as `usePanel` and `useLocale`. */
    readonly hooks: {
        readonly panel: HostObservable<PanelSnapshot>;
        readonly locale: HostObservable<string>;
    };
    /**
     * Reinspect the checkout, probe sign-in, and poll the change requests;
     * settles once the Host has inspected and probed, after reporting a failure.
     */
    readonly refresh: () => Promise<void>;
    /** Remove a change request from the Session, offering to undo it. */
    readonly remove: (entry: ChangeRequestEntry) => void;
    /** Mark a draft ready for review; settles once the outcome is reported. */
    readonly markReady: (entry: ChangeRequestEntry) => Promise<void>;
    /** Merge a change request as `request` describes; settles once the outcome is reported. */
    readonly merge: (entry: ChangeRequestEntry, request: MergeRequest) => Promise<void>;
    /** Read the complete checks of an opened change request. */
    readonly readChecks: NonNullable<ChangeRequestActions['readChecks']>;
    /** Rerun the failed checks or one check; settles once the outcome is reported. */
    readonly rerunChecks: NonNullable<ChangeRequestActions['rerunChecks']>;
    /** Request reviews from more reviewers; settles once the outcome is reported. */
    readonly requestReviews: NonNullable<ChangeRequestActions['requestReviews']>;
    /** List accounts a review can be requested from. */
    readonly reviewerCandidates: NonNullable<ChangeRequestActions['reviewerCandidates']>;
    /** Bring the base branch's new commits into the head branch; settles once the outcome is reported. */
    readonly updateBranch: NonNullable<ChangeRequestActions['updateBranch']>;
    /** Open a URL outside the app. */
    readonly openLink: (url: string) => void;
    /** Copy text to the clipboard and report the outcome. */
    readonly copyText: (text: string) => void;
    /** Open the changes view of a bound change request in the right sidebar. */
    readonly viewChanges: (entry: ChangeRequestEntry) => void;
}
/** Full props of the change requests section. */
export type ChangeRequestsSectionProps = PropsRuntime<'conversation.session.panel.section'> & Pick<PropsRenderSlots<'forge.change-request.card.actions'>, 'renderSlot'> & PropsRenderFactories & InjectFace<ChangeRequestsSectionInjected> & PropsStore<ReturnType<typeof createChangeRequestsSectionStore>> & PropsLocale<typeof NS>;
/** Business face of the section's title control. */
export interface ChangeRequestsActionsInjected {
    /** Panel snapshot of the Session; bound as `usePanel`. */
    readonly hooks: {
        readonly panel: HostObservable<PanelSnapshot>;
    };
}
/** Full props of the section's title control. */
export type ChangeRequestsActionsProps = PropsRuntime<'conversation.session.panel.section.actions'> & InjectFace<ChangeRequestsActionsInjected> & PropsLocale<typeof NS>;
/**
 * Render the Session's change request cards. The section shows while the
 * Session binds a change request or the repository's host needs sign-in, which
 * a status row above the cards says; a lost stream shows in the Environment
 * section instead. The list shows three cards and then the panel's fold
 * control, which shows the rest; the choice is kept per Session. A card starts
 * expanded when the Session binds exactly one change request; a card the user
 * expands or collapses keeps that choice in the Session's store, across
 * updates and while the panel is hidden. Viewing changes closes the panel's
 * overlay.
 * @param props - panel snapshot hooks, card actions, panel owner values, the store, and copy.
 * @returns the cards, or null with neither bound change requests nor a sign-in to complete.
 */
export declare function ChangeRequestsSection({ usePanel, useLocale, dismissOverlay, refresh, remove, markReady, merge, readChecks, rerunChecks, requestReviews, reviewerCandidates, updateBranch, openLink, copyText, viewChanges, useStore, actions: store, renderSlot, renderFactorySlot, t, }: ChangeRequestsSectionProps): ReactNode;
/**
 * Render the change request count beside the section title.
 * @param props - panel snapshot hook.
 * @returns the count, or null without bound change requests.
 */
export declare function ChangeRequestsActions({ usePanel }: ChangeRequestsActionsProps): ReactNode;
//# sourceMappingURL=ChangeRequestsSection.d.ts.map