/** The changes view's body while it reads: a status line above file cards drawn as skeletons. */
import type { ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { NS } from './locales.ts';
/**
 * Render the reading state of the changes view. The status line is the only text and announces itself politely;
 * the cards are hidden from assistive technology.
 * @param props - whether changed files show their sides in two columns, and copy.
 * @returns the status line and the skeleton cards.
 */
export declare function ChangesLoading({ split, t }: {
    readonly split: boolean;
} & PropsLocale<typeof NS>): ReactNode;
//# sourceMappingURL=ChangesLoading.d.ts.map