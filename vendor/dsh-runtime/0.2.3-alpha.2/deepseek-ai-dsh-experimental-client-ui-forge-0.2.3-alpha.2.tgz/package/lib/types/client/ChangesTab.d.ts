/**
 * Body of the changes tab: the local changes of the Session's checkout in a
 * chosen scope, or the changes of one of its change requests, as one list of
 * file sections under a toolbar that jumps between files and switches the
 * layout. The view reads the changes when it opens, on each navigation, on
 * refresh, and when the change request's head or the checkout's `branch`
 * scope summary changes; a read keeps the previous changes on screen until it settles.
 * File sections receive values that keep their identity across renders, so a
 * render of the view redraws only the sections whose own values changed, and
 * an expanded file draws its lines once its section comes near the scrollport.
 */
import { type ReactNode } from 'react';
import type { HostObservable, InjectFace, PropsLocale, PropsRenderSlots, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { SidebarRightTabInfo } from '@deepseek-ai/dsh-client-ui-sidebar-right/client';
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { ForgeBaseBranches, ForgeChangeRequestDiff, ForgeCommitRange, ForgeExtensionState, ForgeLensFrame, ForgeLensRequest, ForgeLocalCommits, ForgeLocalDiff, ForgeLocalScope } from '../types.ts';
import type { ForgeCommitList, ForgeReviewData, ForgeReviewRequest, ForgeReviewResult, ForgeReviewThread, ForgeReviewWrite, ForgeReviewWriteResult, ForgeViewedFiles, ForgeViewedRequest } from '@deepseek-ai/dsh-experimental-forge/types';
import { type ReviewQueue } from './review-queue.ts';
import type { QuoteCopy, ReviewSelection } from './review.ts';
import { type ChangesSource, type ChangesTarget } from './changes-address.ts';
import type { createChangesStore } from './changes-store.ts';
import { type ViewedFiles } from './viewed-files.ts';
import type { ForgePanelKey, NS } from './locales.ts';
import type { ForgeLensDescription } from './changes-service.ts';
import type { ViewAnnotations } from './annotations.ts';
import type { HostStream, NoticeOptions, PanelSnapshot, StreamSnapshot } from './source.ts';
import { type ChangesPanelState } from './status.ts';
/** Business face of the changes tab body. */
export interface ChangesTabInjected {
    /** Append a frozen comment to the main input without submitting it. */
    readonly addReviewToInput: (selection: ReviewSelection) => boolean | Promise<boolean>;
    /** Records retained across Session switches and cleared when this tab occurrence closes. */
    readonly reviewQueue: (tab: Pick<ChangesViewTab, 'id' | 'signal'>) => ReviewQueue;
    /** Publish one comment or a completed review; never retries mutations. */
    readonly submitReview: (url: string, request: ForgeReviewRequest) => Promise<RemoteResult<ForgeReviewResult>>;
    /**
     * Panel source while visible, which the renderer releases for an inactive key; and the plugin annotations of a view by
     * its address, which the renderer binds as `useAnnotations`.
     */
    readonly keyedHooks: {
        readonly panel: (visibility: string) => HostObservable<PanelSnapshot> | undefined;
        readonly annotations: (address: string) => HostObservable<ViewAnnotations>;
    };
    /** Lens titles Client plugins describe and the Host's lenses and annotation limit; bound as `useLenses` and `useExtensions`. */
    readonly hooks: {
        readonly lenses: HostObservable<readonly ForgeLensDescription[]>;
        readonly extensions: HostObservable<StreamSnapshot<ForgeExtensionState | null>>;
    };
    /** Classify the shown files with a Host lens; `signal` aborts the stream. */
    readonly changesLens: (request: ForgeLensRequest, signal: AbortSignal) => HostStream<ForgeLensFrame>;
    /** Open the panel stream again after it ended. */
    readonly reconnect: () => void;
    /** Read the local changes of one scope; `signal` aborts the read. */
    readonly localDiff: (scope: ForgeLocalScope, signal: AbortSignal) => Promise<RemoteResult<ForgeLocalDiff>>;
    /** Read the branches the `branch` scope can compare with, whose names contain `query`; `signal` aborts the read. */
    readonly diffBases: (query: string, signal: AbortSignal) => Promise<RemoteResult<ForgeBaseBranches>>;
    /** Read the new side of one file in a local scope. */
    readonly localText: (scope: ForgeLocalScope, path: string) => Promise<RemoteResult<string>>;
    /** List the commits of the `branch` scope compared with `base`, or with the automatic fork point for null; `signal` aborts the read. */
    readonly localCommits: (base: string | null, signal: AbortSignal) => Promise<RemoteResult<ForgeLocalCommits>>;
    /** Read the changes of a change request, or of consecutive commits of it, by its binding URL; `signal` aborts the read. */
    readonly changeRequestDiff: (url: string, commits: ForgeCommitRange | null, signal: AbortSignal) => Promise<RemoteResult<ForgeChangeRequestDiff>>;
    /** List the commits of a change request, or null when its provider does not read commits; `signal` aborts the read. */
    readonly changeRequestCommits: (url: string, signal: AbortSignal) => Promise<RemoteResult<ForgeCommitList | null>>;
    /** The Session's viewed marks, kept in the browser for local changes, chosen commits, and hosts that keep none. */
    readonly viewedFiles: ViewedFiles;
    /**
     * Read the signed-in user's viewed marks on a change request's files at `headSha`, or null when its provider keeps
     * none; `fresh` skips the marks the host keeps, and `signal` aborts the read.
     */
    readonly changeRequestViewed: (url: string, headSha: string, fresh: boolean, signal: AbortSignal) => Promise<RemoteResult<ForgeViewedFiles | null>>;
    /** Set or clear the signed-in user's viewed mark on one file of a change request. */
    readonly setFileViewed: (url: string, request: ForgeViewedRequest) => Promise<RemoteResult<void>>;
    /** Read one file of a change request at a commit. */
    readonly changeRequestText: (url: string, commit: string, path: string) => Promise<RemoteResult<string>>;
    /** Read the review threads of a change request at the head of its latest status; `signal` aborts the read. */
    readonly changeRequestReview: (url: string, headSha: string, fresh: boolean, signal: AbortSignal) => Promise<RemoteResult<ForgeReviewData>>;
    /** Write to the review threads or the pending review of a change request; never retries a write. */
    readonly changeRequestReviewWrite: (url: string, write: ForgeReviewWrite) => Promise<RemoteResult<ForgeReviewWriteResult>>;
    /** Quote a whole review thread of the change request at `url` in the main input without submitting it. */
    readonly addThreadToInput: (thread: ForgeReviewThread, url: string, range: string | null) => boolean | Promise<boolean>;
    /** Open a URL outside the app. */
    readonly openLink: (url: string) => void;
    /** Copy a path to the clipboard and report the outcome. */
    readonly copyPath: (path: string) => void;
    /** Ask the Session's Agent to create a change request for its changes, reporting the outcome. */
    readonly createChangeRequest: () => void;
    /** Show a notice: a failure unless the options name another tone, with the undo action they carry. */
    readonly report: (key: ForgePanelKey, options?: NoticeOptions) => void;
}
/** Full props of the changes tab body. */
export type ChangesTabProps = Pick<PropsRuntime<'sidebar.right.pane.tab'>, 'useTabInfo' | 'sessionId'> & Pick<PropsRenderSlots<'forge.changes.toolbar' | 'forge.changes.file.menu' | 'forge.diff.line.annotation' | 'forge.diff.comment.actions'>, 'renderSlot'> & PropsStore<ReturnType<typeof createChangesStore>> & InjectFace<ChangesTabInjected> & PropsLocale<typeof NS>;
/** The tab facts the changes view reads: its sidebar tab's, or the review page's for one change request. */
export interface ChangesViewTab extends Pick<SidebarRightTabInfo['tab'], 'visible' | 'navigation' | 'signal'> {
    /** Identity the view's choices and pending review comments are kept under. */
    readonly id: string;
    /** Bind the view's refresh to the tab's refresh command; returns the unbinding. */
    readonly actions: Pick<SidebarRightTabInfo['tab']['actions'], 'bindCommands'>;
}
/** Props of the changes view, which the changes tab and the review page draw. */
export type ChangesViewProps = Omit<ChangesTabProps, 'useTabInfo' | 'sessionId' | 'usePanel' | 'useAnnotations'> & {
    /** Tab facts. */
    readonly tab: ChangesViewTab;
    /** What the view shows. */
    readonly source: ChangesSource;
    /** The view plugins see, or null on the review page, where plugin slots and annotations do not show. */
    readonly target: ChangesTarget | null;
    /** The panel facts while known, and whether their stream ended. */
    readonly snapshot: {
        readonly state: ChangesPanelState | null;
        readonly disconnected: boolean;
    } | undefined;
    /** Plugin annotations of the view, or undefined before any. */
    readonly annotations: ViewAnnotations | undefined;
    /** Open a file of the checkout in the right sidebar, by its absolute path; undefined where no sidebar shows. */
    readonly openFile: ((path: string) => void) | undefined;
    /** Copy of the quote actions where they quote somewhere other than the Session's input. */
    readonly quoteCopy?: QuoteCopy | undefined;
};
/**
 * Render the changes tab of one Session.
 * @param props - tab information, the tab's choices, the panel snapshot hook, reads and actions, and copy.
 * @returns the view body.
 */
export declare function ChangesTab({ useTabInfo, sessionId, usePanel, useAnnotations, ...props }: ChangesTabProps): ReactNode;
/**
 * Render the changes of a Session's checkout or of one change request.
 * @param props - tab facts, what the view shows, the view's choices, the panel facts, reads and actions, and copy.
 * @returns the view body.
 */
export declare function ChangesView({ tab, source, target, snapshot, annotations: viewAnnotations, openFile, quoteCopy, useStore, actions, reconnect, localDiff, diffBases, localText, localCommits, changeRequestDiff, changeRequestText, changeRequestCommits, changeRequestReview, changeRequestReviewWrite, viewedFiles, changeRequestViewed, setFileViewed, openLink, copyPath, createChangeRequest, addReviewToInput, addThreadToInput, reviewQueue, submitReview, report, useLenses, useExtensions, changesLens, renderSlot, t: translate, }: ChangesViewProps): ReactNode;
//# sourceMappingURL=ChangesTab.d.ts.map