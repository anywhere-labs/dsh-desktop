/** Resizable file navigation; width belongs to the mounted tab and survives hiding the pane. */
import { type ReactNode } from 'react';
import { type ChangedFilesProps } from './ChangedFiles.tsx';
/** Placement of a tab's file navigator; hiding it retains its viewing choices. */
export type FileTreePosition = 'right' | 'left' | 'hidden';
/**
 * Render a keyboard- and pointer-resizable tree beside the diff.
 * @param props - tree rows, pane position, the toggle's controlled element id, the width the cell above the tree needs,
 * and the receiver of the shown width.
 * @returns the bounded pane and its resize separator.
 */
export declare function FileTreePane({ position, id, least, onWidth, ...props }: ChangedFilesProps & {
    readonly position: FileTreePosition;
    readonly id: string;
    /** Width in pixels the toolbar cell above the tree needs, which raises the pane's least width above its own. */
    readonly least?: number;
    /** Receives the pane's width in pixels whenever it changes, so the toolbar can align a cell with it. */
    readonly onWidth: (width: number) => void;
}): ReactNode;
//# sourceMappingURL=FileTreePane.d.ts.map