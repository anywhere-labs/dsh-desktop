/** The changes toolbar's filter lens menu: the Host's lenses with the files each keeps among the shown files. */
import { type ReactNode } from 'react';
import { type MenuEntry } from '@deepseek-ai/dsh-client-ui-primitives';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { LensRun } from './lens-filter.ts';
import type { NS } from './locales.ts';
/** One lens the view offers. */
export interface LensChoice {
    /** Identity of the Host lens. */
    readonly id: string;
    /** Title in the current language, or the identity when no Client plugin describes it. */
    readonly title: string;
    /** Files the lens keeps among the shown files, or null before it ran for them. */
    readonly count: number | null;
}
/** Menu row identity of choosing no lens. */
export declare const NO_LENS = "lens:none";
/**
 * Menu row identity of choosing a lens.
 * @param id - the lens identity.
 * @returns the row identity.
 */
export declare function lensRowId(id: string): string;
/**
 * Read the lens a menu row chooses.
 * @param row - a row identity.
 * @returns the lens identity, null for no lens, or undefined for a row that chooses no lens.
 */
export declare function lensOfRow(row: string): string | null | undefined;
/**
 * The rows that choose a lens: a heading, No lens, and each lens with its count.
 * @param lenses - the lenses offered.
 * @param t - forge panel copy.
 * @returns the menu entries.
 */
export declare function lensEntries(lenses: readonly LensChoice[], t: PropsLocale<typeof NS>['t']): MenuEntry[];
/**
 * Render the lens menu button: Lens while none is chosen; the chosen lens's title, tinted, with the files it keeps, or
 * its progress while it runs.
 * @param props - the offered lenses, the chosen one, its run, the choose action, whether the owning tab is visible, and copy.
 * @returns the trigger with its portalled menu.
 */
export declare function LensFilterMenu({ lenses, chosen, run, choose, visible, t }: PropsLocale<typeof NS> & {
    readonly lenses: readonly LensChoice[];
    readonly chosen: LensChoice | null;
    readonly run: LensRun;
    readonly choose: (lens: string | null) => void;
    readonly visible: boolean;
}): ReactNode;
//# sourceMappingURL=LensFilter.d.ts.map