/** Dialog that names the new branch of a requested worktree, from the New Session option or after a failed attempt. */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { NS } from './locales.ts';
/**
 * Outcome of a worktree request: accepted; refused for its branch name, which the dialog shows; or failed otherwise,
 * which the request reports itself.
 */
export type WorktreeRequestResult = 'accepted' | 'invalid-name' | 'branch-exists' | 'failed';
/** Props of the naming dialog. */
export interface WorktreeNameDialogProps extends PropsLocale<typeof NS> {
    /** `name` names the branch of the open request; `retry` renames it after a failed attempt, then tries again. */
    readonly mode: 'name' | 'retry';
    /** Text the field starts with: the chosen name, or the prefix of generated names. */
    readonly initial: string;
    /** Prefix of generated names; a field that holds only the prefix names no branch yet. */
    readonly prefix: string;
    /** Base of the request, or null for HEAD. */
    readonly from: string | null;
    /** Whether the request already names its branch, which offers a return to generated names. */
    readonly named: boolean;
    /**
     * Request the worktree on `name`, or on generated names for null; in `retry` mode the caller also tries again
     * once the request is accepted.
     */
    readonly submit: (name: string | null) => Promise<WorktreeRequestResult>;
    /** Close the dialog without a request. */
    readonly close: () => void;
}
/**
 * Render the dialog: one branch name field checked against Git's branch-name rules while it is typed, and checked by
 * the Host when it is confirmed. A refused name keeps the dialog open with the reason under the field; an accepted
 * request closes it.
 * @param props - mode, starting text, prefix, base, the request, and copy.
 * @returns the dialog.
 */
export declare function WorktreeNameDialog({ mode, initial, prefix, from, named, submit, close, t }: WorktreeNameDialogProps): ReactNode;
//# sourceMappingURL=WorktreeNameDialog.d.ts.map