/**
 * Line annotations of one changes view: every source's annotations merged by path, and where each one shows in a
 * file's lines.
 */
import type { HostObservable } from '@deepseek-ai/dsh-client-ui-slots';
import type { ChangesTarget } from './changes-address.ts';
import type { ForgeAnnotationSource, ForgeLineAnnotation } from './changes-service.ts';
/** One annotation with the source that draws it. */
export interface SourcedAnnotation {
    /** Identity of the source, the key of its `forge.diff.line.annotation` entry. */
    readonly source: string;
    readonly annotation: ForgeLineAnnotation;
}
/** Annotations of one view by path, in source order and then each source's order. */
export type ViewAnnotations = ReadonlyMap<string, readonly SourcedAnnotation[]>;
/**
 * The merged annotations of one view. It observes each registered source while a reader subscribes, starting with
 * the first reader and stopping after the last; a file whose annotations did not change keeps its list, so its section
 * does not draw again.
 */
export declare class AnnotationView implements HostObservable<ViewAnnotations> {
    private readonly sources;
    private readonly target;
    private snapshot;
    private readonly listeners;
    /** The followed sources in stacking order, each with its observable for this view and its unsubscribe. */
    private followed;
    private stopSources;
    /**
     * @param sources - the registered sources.
     * @param target - the view's Session and source.
     */
    constructor(sources: HostObservable<readonly ForgeAnnotationSource[]>, target: ChangesTarget);
    readonly getSnapshot: () => ViewAnnotations;
    readonly subscribe: (listener: () => void) => (() => void);
    /** Follow the sources registered now, observing each new one once and releasing each withdrawn one, then merge. */
    private sync;
    private follow;
    private merge;
}
//# sourceMappingURL=annotations.d.ts.map