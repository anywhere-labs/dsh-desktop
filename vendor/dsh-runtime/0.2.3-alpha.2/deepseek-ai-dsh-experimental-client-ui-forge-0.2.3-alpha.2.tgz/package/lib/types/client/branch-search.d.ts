/** The search shared by the branch pickers: the query, the listing it read, and the status a menu shows instead of rows. */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { NS } from './locales.ts';
/** A branch picker's search while its menu is shown. */
export interface BranchSearch<T> {
    /** Text in the search field. */
    readonly query: string;
    /** Change the search text; the listing is read again after a short pause. */
    readonly setQuery: (query: string) => void;
    /** The last listing that arrived, or null before the first one. */
    readonly listing: RemoteResult<T> | null;
    /** Read the listing again, as after a failed read. */
    readonly retry: () => void;
    /** Clear the search text, as when the menu closes. */
    readonly reset: () => void;
}
/**
 * Read the branches of a picker while its menu is shown: at once on opening and on a retry, and after a pause while
 * the search text changes. Each new read cancels the one before; the last listing stays until the next arrives.
 * @param shown - whether the menu is shown.
 * @param list - reads the branches whose names contain the query; the signal aborts the read.
 * @returns the search state.
 */
export declare function useBranchSearch<T>(shown: boolean, list: (query: string, signal: AbortSignal) => Promise<RemoteResult<T>>): BranchSearch<T>;
/**
 * The status a branch menu shows instead of its rows: reading, a failed read with a retry, or no matching branch.
 * @param props - the listing, whether no row matches, the retry, the status row's class, and copy.
 * @returns the status row, or null while the menu shows rows.
 */
export declare function branchSearchStatus({ listing, empty, retry, className, t }: {
    readonly listing: RemoteResult<unknown> | null;
    readonly empty: boolean;
    readonly retry: () => void;
    readonly className: string | undefined;
} & PropsLocale<typeof NS>): ReactNode;
//# sourceMappingURL=branch-search.d.ts.map