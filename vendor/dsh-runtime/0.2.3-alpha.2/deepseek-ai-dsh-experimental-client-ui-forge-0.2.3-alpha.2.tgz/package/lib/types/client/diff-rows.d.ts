/**
 * Drawn rows of one file diff: numbered patch lines, their side-by-side
 * pairing, and the unchanged lines between hunks, which stay collapsed until
 * the file's new side supplies them.
 */
import type { ForgeDiffFile, ForgeDiffHunk } from '../types.ts';
/** One drawn line with its number on each side that has it. */
export type DiffRow = {
    readonly kind: 'add';
    readonly old: null;
    readonly new: number;
    readonly text: string;
} | {
    readonly kind: 'del';
    readonly old: number;
    readonly new: null;
    readonly text: string;
} | {
    readonly kind: 'context';
    readonly old: number;
    readonly new: number;
    readonly text: string;
};
/** One side of a side-by-side row. */
export interface SplitCell {
    readonly kind: DiffRow['kind'];
    readonly no: number;
    readonly text: string;
}
/** One side-by-side row; a side without a line is null. */
export interface SplitRow {
    readonly left: SplitCell | null;
    readonly right: SplitCell | null;
}
/** Unchanged lines one step of a gap shows, and the most a gap shows on one click: the step of GitHub's and GitLab's diffs. */
export declare const EXPAND_STEP = 20;
/** The lines a gap shows: `top` continue the hunk above it, `bottom` lead into the hunk below it. */
export interface GapReveal {
    readonly top: number;
    readonly bottom: number;
}
/** How a click expands a gap: one step down from the hunk above it, one step up from the hunk below it, or wholly. */
export type GapExpansion = 'down' | 'up' | 'all';
/** Where a gap sits: before the first hunk, between two hunks, or after the last hunk. */
export type GapEdge = 'leading' | 'middle' | 'trailing';
/** A run of drawn rows, or unchanged lines drawn as one row that expands them. */
export type DiffSegment = {
    readonly kind: 'rows';
    readonly rows: readonly DiffRow[];
}
/**
 * `index` is the hunk the lines precede, or the hunk count for the lines after the last hunk; `count` is null while
 * the length of the file is unknown. The hidden lines are new-side lines `from` to `to`, null while unknown, whose old
 * numbers are `offset` higher.
 */
 | {
    readonly kind: 'gap';
    readonly index: number;
    readonly count: number | null;
    readonly edge: GapEdge;
    readonly from: number;
    readonly to: number | null;
    readonly offset: number;
}
/** Consecutive hunks a filter lens folds, drawn as one row that shows them, with the unchanged lines between them. */
 | {
    readonly kind: 'folded';
    readonly hunks: readonly number[];
};
/**
 * Number the lines of a hunk. Context lines count on both sides, deletions on
 * the old side, and additions on the new side; a `\ No newline at end of file`
 * marker is not a line.
 * @param hunk - one hunk.
 * @returns the rows in patch order.
 */
export declare function hunkRows(hunk: ForgeDiffHunk): DiffRow[];
/**
 * Pair rows for the side-by-side view: each run of deletions sits beside the
 * run of additions that follows it, row by row, and context rows fill both sides.
 * @param rows - rows in patch order.
 * @returns the paired rows.
 */
export declare function splitRows(rows: readonly DiffRow[]): SplitRow[];
/**
 * Split file text into lines as a patch numbers them; a final line ending ends the last line.
 * @param text - the file text.
 * @returns the lines with any carriage returns kept.
 */
export declare function textLines(text: string): string[];
/**
 * Whether file text is the new side the hunks describe: every context and
 * added line sits at its number. A file changed after its diff was read fails.
 * @param lines - the file's lines.
 * @param hunks - hunks of the file's diff.
 * @returns whether the lines match.
 */
export declare function matchesHunks(lines: readonly string[], hunks: readonly ForgeDiffHunk[]): boolean;
/**
 * Lay out one file as runs of rows separated by collapsed unchanged lines.
 * Unchanged lines before a hunk, between hunks, and after the last hunk
 * collapse into one gap each; once `lines` is known, a gap draws the lines its
 * reveal shows at its top and bottom, and a gap whose reveal covers it joins
 * the rows around it. The lines after the last hunk are unknown until `lines`
 * arrives, unless the file is new, deleted, or its last hunk reaches its end. Consecutive folded hunks draw as one
 * folded segment that takes the unchanged lines between them too.
 * @param file - one file of a diff.
 * @param lines - the file's new side, which {@link matchesHunks} accepted, or undefined while it has not been read.
 * @param open - the lines each expanded gap shows, by gap index.
 * @param folded - indexes of the hunks a filter lens folds.
 * @returns the segments in file order.
 */
export declare function segmentsOf(file: ForgeDiffFile, lines: readonly string[] | undefined, open: ReadonlyMap<number, GapReveal>, folded?: ReadonlySet<number>): DiffSegment[];
/**
 * Show more of one gap: a step down from the hunk above it, a step up from the hunk below it, or all of it.
 * @param open - the lines each expanded gap of a file shows, by gap index.
 * @param index - the gap.
 * @param expansion - which way the gap expands.
 * @returns the reveals with that gap's widened.
 */
export declare function revealGap(open: ReadonlyMap<number, GapReveal> | undefined, index: number, expansion: GapExpansion): ReadonlyMap<number, GapReveal>;
/**
 * Whether a gap still hides a line.
 * @param gap - the gap segment.
 * @param side - the side that numbers the line.
 * @param line - the line.
 * @returns whether the line is among the gap's hidden lines.
 */
export declare function hidesLine(gap: Extract<DiffSegment, {
    kind: 'gap';
}>, side: 'L' | 'R', line: number): boolean;
/**
 * Count the rows a file's hunks draw.
 * @param file - one file of a diff.
 * @returns the number of context, added, and deleted lines in its hunks.
 */
export declare function drawnLines(file: ForgeDiffFile): number;
//# sourceMappingURL=diff-rows.d.ts.map