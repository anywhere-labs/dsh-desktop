/** A changes view's filter lens: the request to the Host, its progress and result, and which hunks it folds. */
import type { ForgeDiffHunk, ForgeLensFrame, ForgeLensKeep, ForgeLensRequest, ForgeRegisteredLens } from '../types.ts';
import type { HostStream } from './source.ts';
/** Where a lens request stands for the shown files. */
export type LensRun = 
/** No lens is chosen, or the files have not loaded. */
{
    readonly kind: 'idle';
}
/** The lens runs; `done` and `total` are null before it reports progress. */
 | {
    readonly kind: 'running';
    readonly done: number | null;
    readonly total: number | null;
}
/** The files the lens keeps, by path. */
 | {
    readonly kind: 'ready';
    readonly files: Readonly<Record<string, ForgeLensKeep>>;
}
/**
 * The request failed with a Remote error code and message, or with `forgePanel/lens-interrupted` and no message when the
 * stream ended without a result, as after a lost connection.
 */
 | {
    readonly kind: 'failed';
    readonly code: string;
    readonly message: string;
};
/** What a view knows when it asks for a lens. */
export interface LensRunInput {
    /** Whether the view is visible; a hidden view starts no request. */
    readonly visible: boolean;
    /** The chosen registered lens, or null for none. */
    readonly lens: ForgeRegisteredLens | null;
    /** The source of the shown files, or null before they load. */
    readonly source: ForgeLensRequest['source'] | null;
    /** `lensVersion` of the shown files, or null before they load. */
    readonly version: string | null;
    /** Changes on each retry. */
    readonly attempt: number;
    /** Open the Host's lens stream. */
    readonly open: (request: ForgeLensRequest, signal: AbortSignal) => HostStream<ForgeLensFrame>;
}
/** The run of the chosen lens and the results already known for the shown files. */
export interface LensRunState {
    readonly run: LensRun;
    /**
     * Read what a registered lens keeps of the shown files.
     * @returns the kept files once that lens, at that version, answered for the shown source and files.
     */
    readonly resultOf: (lens: ForgeRegisteredLens) => Readonly<Record<string, ForgeLensKeep>> | undefined;
}
/**
 * Ask the Host for the chosen lens whenever the shown source or files, the lens or its version, or the attempt change,
 * keeping the results of every lens asked for the same source and files. A view that becomes hidden stops its request;
 * a result already known is not asked for again.
 * @param input - the view's lens, files, and stream opener.
 * @returns the run and the known results.
 */
export declare function useLensRun(input: LensRunInput): LensRunState;
/**
 * The hunks of a kept file that touch none of the lens's lines on either side.
 * @param hunks - the file's hunks.
 * @param keep - what the lens keeps of the file.
 * @returns the indexes of the hunks to fold, empty when the lens names no lines.
 */
export declare function foldedHunks(hunks: readonly ForgeDiffHunk[], keep: ForgeLensKeep): ReadonlySet<number>;
//# sourceMappingURL=lens-filter.d.ts.map