/**
 * The review page's detail of one change request: its header with state, repository, labels, title, author, times, and
 * branches; the ready-or-merge and more actions; and the summary, changes, and chat tabs. The summary shows the
 * description beside the status column.
 */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ChangeRequestDescription } from '@deepseek-ai/dsh-experimental-forge/types';
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { ForgeReviewChangeRequest } from '../../types.ts';
import { type ChangeRequestActions } from '../ChangeRequestCard.tsx';
import type { StreamRead } from './host-stream.ts';
import type { NS } from '../locales.ts';
import type { ReviewTab } from './review-store.ts';
type Translate = PropsLocale<typeof NS>['t'];
/** Props of the detail. */
export interface ReviewDetailProps {
    /** URL of the change request. */
    readonly url: string;
    /** The change request stream. */
    readonly read: StreamRead<ForgeReviewChangeRequest>;
    /** Shown tab. */
    readonly tab: ReviewTab;
    /** Show a tab. */
    readonly onTab: (tab: ReviewTab) => void;
    /** Whether the list column hides. */
    readonly listHidden: boolean;
    /** Hide or show the list column. */
    readonly onToggleList: () => void;
    /** Leave the detail for the list, where the page shows one column. */
    readonly onBack: () => void;
    /** Current epoch milliseconds for relative times. */
    readonly now: number;
    /** Active UI language for numeric formatting. */
    readonly locale: string;
    /** The card actions, acting on this change request. */
    readonly actions: ChangeRequestActions;
    /** Read the description and labels. */
    readonly readDescription: (url: string, signal: AbortSignal) => Promise<RemoteResult<ChangeRequestDescription>>;
    /** The changes tab's content, kept while the detail shows so pending review comments survive tab switches. */
    readonly renderChanges: (frame: ForgeReviewChangeRequest) => ReactNode;
    /** The chat tab's content. */
    readonly renderChat: (frame: ForgeReviewChangeRequest) => ReactNode;
    /** Quotes added to the conversation while the chat tab was not shown. */
    readonly unseenQuotes: number;
    /** Forge panel copy. */
    readonly t: Translate;
}
/**
 * Render the detail of one change request.
 * @param props - the change request stream, the tab, actions, and copy.
 * @returns the detail.
 */
export declare function ReviewDetail({ url, read, tab, onTab, listHidden, onToggleList, onBack, now, locale, actions, readDescription, renderChanges, renderChat, unseenQuotes, t, }: ReviewDetailProps): ReactNode;
export {};
//# sourceMappingURL=ReviewDetail.d.ts.map