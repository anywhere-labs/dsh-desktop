/**
 * A change request's labels on one line: labels that do not fit fold into a `+N` chip whose tooltip names every label.
 * The fold is measured again whenever the line's width changes.
 */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ChangeRequestLabel } from '@deepseek-ai/dsh-experimental-forge/types';
import type { NS } from '../locales.ts';
type Translate = PropsLocale<typeof NS>['t'];
/**
 * Count the labels that fit before the chip: every label fits when all of them fit in the line, otherwise the labels
 * that end before the line's width less the chip's.
 * @param widths - each label's width with its gap, in order.
 * @param available - the line's width.
 * @param chip - the chip's width with its gap.
 * @returns how many labels show.
 */
export declare function fittingLabels(widths: readonly number[], available: number, chip: number): number;
/**
 * Render the labels on one line.
 * @param props.labels - labels in host order.
 * @param props.truncated - whether the host has more labels than `labels`.
 * @param props.t - forge panel copy.
 * @returns the line, or null without labels.
 */
export declare function ReviewLabels({ labels, truncated, t }: {
    readonly labels: readonly ChangeRequestLabel[];
    readonly truncated: boolean;
    readonly t: Translate;
}): ReactNode;
export {};
//# sourceMappingURL=ReviewLabels.d.ts.map