/**
 * The review page's list column: the search box that also opens a pasted change request link, the repository filter,
 * and one foldable section per list with its items, empty state, and failure.
 */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ForgeViewerFilter } from '@deepseek-ai/dsh-experimental-forge/types';
import type { ForgeReviewFrame } from '../../types.ts';
import type { NS } from '../locales.ts';
import { type ReviewRepository } from './review-lists.ts';
import type { ReviewView } from './review-store.ts';
type Translate = PropsLocale<typeof NS>['t'];
/** Props of the list column. */
export interface ReviewListProps {
    /** The latest list frame, or undefined before the first. */
    readonly frame: ForgeReviewFrame | undefined;
    /** Why the list stream stopped, or null while it runs. */
    readonly stopped: {
        readonly code: string;
        readonly message: string;
    } | null;
    /** URL of the change request shown in full, or null. */
    readonly selected: string | null;
    /** Search text. */
    readonly query: string;
    /** Repository the lists are read in, or null for every repository. */
    readonly repository: ReviewRepository | null;
    /** Whether the review-requested list leaves out requests made only of the user's teams. */
    readonly directOnly: boolean;
    /** Folded sections. */
    readonly folded: Partial<Record<ForgeViewerFilter, boolean>>;
    /** Whether a refresh the reader asked for is in flight. */
    readonly refreshing: boolean;
    /** Current epoch milliseconds for relative times. */
    readonly now: number;
    /** Show a change request in full. */
    readonly onSelect: (url: string) => void;
    /** Change the search text. */
    readonly onSearch: (query: string) => void;
    /** Repositories the lists named while read in every repository, offered whatever repository the lists are read in now. */
    readonly repositories: readonly ReviewRepository[];
    /** Read the lists in one repository, or in every repository. */
    readonly onScope: (repository: ReviewRepository | null) => void;
    /** Toggle whether the review-requested list leaves out team requests. */
    readonly onToggleDirect: () => void;
    /** How list items show: two lines each, or one line each with the rest on hover. */
    readonly view: ReviewView;
    /** Choose how list items show. */
    readonly onView: (view: ReviewView) => void;
    /** Fold or unfold a section. */
    readonly onFold: (filter: ForgeViewerFilter) => void;
    /** Read every list again. */
    readonly onRefresh: () => void;
    /** Open the list stream again after it stopped. */
    readonly onRetry: () => void;
    /** Copy text and report the outcome. */
    readonly copyText: (text: string) => void;
    /** Forge panel copy. */
    readonly t: Translate;
}
/**
 * Render the list column.
 * @param props - the latest frame, the reader's choices, and their handlers.
 * @returns the column.
 */
export declare function ReviewList(props: ReviewListProps): ReactNode;
export {};
//# sourceMappingURL=ReviewList.d.ts.map