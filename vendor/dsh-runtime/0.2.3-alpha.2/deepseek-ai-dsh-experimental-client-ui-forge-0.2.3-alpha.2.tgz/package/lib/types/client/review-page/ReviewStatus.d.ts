/**
 * The status column of the review page's summary: the merge state, the checks that need attention, each reviewer with
 * their outcome, and the changed lines with the linked issues, each in a block of its own. A finished change request
 * shows how it ended, its changed lines, and its reviewers. The blocks read the facts and run the actions of the
 * Session panel's change request card.
 */
import { type ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ChangeRequestSnapshot } from '@deepseek-ai/dsh-experimental-forge/types';
import type { ForgeReviewChangeRequest } from '../../types.ts';
import { type ChangeRequestActions } from '../ChangeRequestCard.tsx';
import type { NS } from '../locales.ts';
type Translate = PropsLocale<typeof NS>['t'];
/** Props of the status column and of its blocks. */
export interface StatusProps {
    /** The change request. */
    readonly frame: ForgeReviewChangeRequest;
    /** Its latest snapshot. */
    readonly snapshot: ChangeRequestSnapshot;
    /** The actions the page offers on it. */
    readonly actions: ChangeRequestActions;
    /** Forge panel copy. */
    readonly t: Translate;
}
/**
 * Render the status column.
 * @param props - the change request, its snapshot, how rows name it, the current time, the actions, the number
 * locale, and copy.
 * @returns the blocks.
 */
export declare function ReviewStatus({ frame, snapshot, name, now, actions, locale, t }: StatusProps & {
    readonly name: string;
    readonly now: number;
    readonly locale: string;
}): ReactNode;
export {};
//# sourceMappingURL=ReviewStatus.d.ts.map