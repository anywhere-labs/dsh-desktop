/** A React hook that reads one Host stream, reopening it when its key or attempt changes. */
import type { HostStream } from '../source.ts';
/** The state of one stream: its latest frame, and why it stopped when it did. */
export interface StreamRead<F> {
    /** Latest frame of the current key, or undefined before the first. */
    readonly frame: F | undefined;
    /** Why the stream stopped: a Remote error code and message, `ended` when the Host closed it, or null while it runs. */
    readonly stopped: {
        readonly code: string;
        readonly message: string;
    } | null;
    /** Open the stream again. */
    readonly retry: () => void;
}
/**
 * Read a Host stream while `key` is not null, keeping its latest frame. A new key or a retry closes the open stream and
 * opens another; unmounting closes it.
 * @param open - opens the stream for a key.
 * @param key - identity of the stream to read, or null to read none.
 * @param subscribeReset - subscribes to transport resets, after which the stream opens again.
 * @returns the latest frame, the stop reason, and the retry action.
 */
export declare function useHostStream<F>(open: (key: string, signal: AbortSignal) => HostStream<F>, key: string | null, subscribeReset: (listener: () => void) => () => void): StreamRead<F>;
//# sourceMappingURL=host-stream.d.ts.map