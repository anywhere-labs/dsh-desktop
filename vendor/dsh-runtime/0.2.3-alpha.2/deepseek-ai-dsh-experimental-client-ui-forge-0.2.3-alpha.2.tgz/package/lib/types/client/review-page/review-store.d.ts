/**
 * Choices of the review page that outlive its mount: the change request shown in full, its tab, whether the list column
 * hides, which list sections fold, the repository the lists are read in, the search text, the conversation the page
 * started for each change request, and the changes view's choices for each change request.
 */
import { type EngineStoreHandle } from '@deepseek-ai/dsh-client-store';
import type { ForgeViewerFilter } from '@deepseek-ai/dsh-experimental-forge/types';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import { type ChangesState } from '../changes-store.ts';
import { type ReviewRepository } from './review-lists.ts';
/** A tab of the review page's detail. */
export type ReviewTab = 'summary' | 'changes' | 'chat';
/** How the list column shows its items: two lines each, or one line each with the rest in a hover card. */
export type ReviewView = 'detailed' | 'compact';
/** The review page's choices, and those of its changes view by change request URL. */
export interface ReviewPageState extends ChangesState {
    /** Web URL of the change request shown in full, or null. */
    selected: string | null;
    /** Tab of the detail. */
    tab: ReviewTab;
    /** Whether the list column hides. */
    listHidden: boolean;
    /** List sections the reader folded. */
    folded: Partial<Record<ForgeViewerFilter, boolean>>;
    /** Repository the lists are read in, or null for every repository. */
    repository: {
        readonly owner: string;
        readonly name: string;
    } | null;
    /**
     * Repositories the lists named while they were read in every repository, which the repository menu keeps offering
     * while the lists are read in one.
     */
    repositories: readonly ReviewRepository[];
    /** Text the lists are searched for. */
    query: string;
    /** Whether the review-requested list leaves out requests that ask only one of the user's teams. */
    directOnly: boolean;
    /** The conversation the page's chat started for a change request, by its URL, until the page reloads. */
    conversations: Record<string, SessionId>;
    /** How the list column shows its items. */
    view: ReviewView;
    /** Quotes added to each change request's conversation while its chat tab was not shown, by URL. */
    unseenQuotes: Record<string, number>;
}
declare const reviewActions: {
    select: (state: ReviewPageState, url: string | null) => void;
    tabbed: (state: ReviewPageState, tab: ReviewTab) => void;
    viewed: (state: ReviewPageState, view: ReviewView) => void;
    quoted: (state: ReviewPageState, url: string) => void;
    toggledList: (state: ReviewPageState) => void;
    folded: (state: ReviewPageState, filter: ForgeViewerFilter) => void;
    scopedTo: (state: ReviewPageState, repository: ReviewPageState["repository"]) => void;
    /**
     * Record the repositories the lists read in every repository name: a complete read replaces the record, and a read
     * still under way or failed in part adds to it.
     */
    listed: (state: ReviewPageState, repositories: ReviewPageState["repositories"], complete: boolean) => void;
    searched: (state: ReviewPageState, query: string) => void;
    toggledDirect: (state: ReviewPageState) => void;
    conversed: (state: ReviewPageState, url: string, session: SessionId | null) => void;
    navigated: (draft: ChangesState, tabId: string, revision: number) => void;
    scoped: (draft: ChangesState, tabId: string, scope: import("../../types.ts").ForgeLocalScope["kind"]) => void;
    based: (draft: ChangesState, tabId: string, base: import("../../types.ts").ForgeBaseBranch | null) => void;
    committed: (draft: ChangesState, tabId: string, commits: import("../../types.ts").ForgeCommitRange | null) => void;
    lensed: (draft: ChangesState, tabId: string, lens: import("../changes-store.ts").ChangesLens) => void;
    filtered: (draft: ChangesState, tabId: string, lens: string | null) => void;
    toggledTests: (draft: ChangesState, tabId: string) => void;
    toggledSplit: (draft: ChangesState, tabId: string) => void;
    toggledWrap: (draft: ChangesState, tabId: string) => void;
    forget: (draft: ChangesState, tabId: string) => void;
};
/**
 * Declare the review page's choices, kept by the framework for the page entry's lifetime.
 * @returns the entry's store handle.
 */
export declare function createReviewStore(): EngineStoreHandle<ReviewPageState, typeof reviewActions>;
export {};
//# sourceMappingURL=review-store.d.ts.map