/**
 * Host stream sources (per-Session panel states and the change request states
 * of the Session list) and the store behind action notices.
 */
import type { HostObservable } from '@deepseek-ai/dsh-client-ui-slots';
import type { ForgeChangeRequestListState, ForgeChangeRequestStatesFrame, ForgePanelState } from '../types.ts';
import type { ForgePanelKey } from './locales.ts';
/** What a stream source publishes: the value its frames built, and whether the stream ended while read. */
export interface StreamSnapshot<S> {
    /** Value built from the frames so far. */
    readonly state: S;
    /** Whether the stream ended while surfaces still read it. */
    readonly disconnected: boolean;
}
/** What the panel surfaces of one Session read; `state` is null before the first one arrives. */
export type PanelSnapshot = StreamSnapshot<ForgePanelState | null>;
/** One open Host stream. */
export interface HostStream<F> extends AsyncIterable<F> {
    /** Close the stream. */
    dispose: () => void;
}
/** One open stream of panel states. */
export type PanelStream = HostStream<ForgePanelState>;
/** Whether the page is hidden, and when that changes. */
export interface PageVisibility {
    /** Whether the page is hidden now. */
    readonly hidden: () => boolean;
    /**
     * Subscribe to changes of the page's visibility.
     * @param listener - called after each change.
     * @returns the unsubscribe function.
     */
    readonly subscribe: (listener: () => void) => () => void;
}
/**
 * How long a page stays hidden before a source that follows its visibility closes its stream, so a short switch to
 * another window or tab reopens nothing.
 */
export declare const HIDDEN_GRACE_MS = 30000;
/** The visibility of the document, for the sources whose Host stream polls a code host. */
export declare const pageVisibility: PageVisibility;
/** Stream opener, connection-reset subscription, and optional page visibility of a source. */
export interface StreamSourceDeps<F> {
    /**
     * Open the Host stream.
     * @param signal - aborts the stream.
     * @returns the stream.
     */
    readonly open: (signal: AbortSignal) => HostStream<F>;
    /**
     * Subscribe to transport resets, after which an open stream no longer delivers.
     * @param listener - called on each reset.
     * @returns the unsubscribe function.
     */
    readonly subscribeReset: (listener: () => void) => () => void;
    /** The page's visibility, for a source whose Host stream costs requests while nobody can see its value. */
    readonly visibility?: PageVisibility;
}
/** Stream opener, connection-reset subscription, and optional page visibility of one Session's panel source. */
export type PanelSourceDeps = StreamSourceDeps<ForgePanelState>;
/** A value built from a Host stream that runs only while a surface subscribes. */
export interface StreamSource<S> {
    /** Snapshot observable; the renderer binds it as a selector hook. */
    readonly observable: HostObservable<StreamSnapshot<S>>;
    /** Open the stream again after it ended; a no-op while it runs or nobody subscribes. */
    readonly reconnect: () => void;
    /** Close the stream and the reset subscription and drop every subscriber. */
    readonly close: () => void;
}
/** Panel state of one Session, streamed only while a surface subscribes. */
export interface PanelSource {
    /** Snapshot observable; the renderer binds it as `usePanel`. */
    readonly hooks: {
        readonly panel: HostObservable<PanelSnapshot>;
    };
    /** Open the stream again after it ended; a no-op while it runs or nobody subscribes. */
    readonly reconnect: () => void;
    /** Close the stream and the reset subscription and drop every subscriber. */
    readonly close: () => void;
}
/**
 * Create a source that folds a Host stream into one value. The first
 * subscriber opens the stream and the last one closes it; the value stays
 * readable for the next subscriber. A stream that ends or fails while
 * subscribed marks the snapshot disconnected until `reconnect` or a transport
 * reset reopens it. A source given the page's visibility closes its stream
 * once the page has been hidden for {@link HIDDEN_GRACE_MS} and opens it again
 * when the page shows; meanwhile the value stays and is not marked
 * disconnected.
 * @param deps - stream opener, reset subscription, and the page's visibility for a source that pauses.
 * @param initial - value before the first frame.
 * @param fold - the value after one frame.
 * @returns the source.
 */
export declare function createStreamSource<F, S>(deps: StreamSourceDeps<F>, initial: S, fold: (state: S, frame: F) => S): StreamSource<S>;
/**
 * Create the panel source of one Session: the latest state the Host streamed.
 * @param deps - stream opener, reset subscription, and the page's visibility for a source that pauses.
 * @returns the source.
 */
export declare function createPanelSource(deps: PanelSourceDeps): PanelSource;
/**
 * The known change request states after one `changeRequestStates` frame: a
 * baseline replaces them, and a change replaces the states it carries.
 * @param states - states by URL before the frame.
 * @param frame - the frame.
 * @returns states by URL after the frame.
 */
export declare function foldStates(states: ReadonlyMap<string, ForgeChangeRequestListState>, frame: ForgeChangeRequestStatesFrame): ReadonlyMap<string, ForgeChangeRequestListState>;
/** One action notice; `seq` keys the toast so a repeated notice restarts it. */
export interface ActionNotice {
    /** Dictionary key of the notice text. */
    readonly key: ForgePanelKey;
    /** Values interpolated into the text. */
    readonly params: Readonly<Record<string, string | number>>;
    /** `success` reports a completed action; `failure` a refused or failed one. */
    readonly tone: 'success' | 'failure';
    /** Reverts the reported action, or undefined when it cannot be undone. */
    readonly undo: (() => void) | undefined;
    /** Increasing report number. */
    readonly seq: number;
}
/** Optional parts of a reported notice. */
export interface NoticeOptions {
    /** Values interpolated into the text. */
    readonly params?: Readonly<Record<string, string | number>>;
    /** Defaults to `failure`. */
    readonly tone?: ActionNotice['tone'];
    /** Reverts the reported action. */
    readonly undo?: () => void;
}
/** Store that action wiring reports into and one `shell.overlay` entry reads. */
export interface NoticeSource {
    /** Current notice, or null while none shows; the renderer binds it as `useNotice`. */
    readonly hooks: {
        readonly notice: HostObservable<ActionNotice | null>;
    };
    /**
     * Show one notice, replacing the shown one.
     * @param key - dictionary key of the text.
     * @param options - interpolated values, tone, and undo action.
     */
    readonly report: (key: ForgePanelKey, options?: NoticeOptions) => void;
    /** Clear the shown notice. */
    readonly dismiss: () => void;
}
/**
 * Create the action notice store.
 * @returns the store.
 */
export declare function createNoticeSource(): NoticeSource;
//# sourceMappingURL=source.d.ts.map