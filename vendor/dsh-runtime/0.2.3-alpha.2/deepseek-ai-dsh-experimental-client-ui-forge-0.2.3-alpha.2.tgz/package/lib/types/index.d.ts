/** Host Remote of the forge panel: checkout, code host, sign-in, change request, and worktree state per Session. */
import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { BranchUpdateMethod, ChangeRequestDescription, ChangeRequestReviewer, ChangeRequestSnapshot, ForgeCommitList, ForgeRerunRequest, ForgeReviewData, ForgeReviewerCandidate, ForgeReviewRequest, ForgeReviewResult, ForgeReviewWrite, ForgeReviewWriteResult, ForgeViewedFiles, ForgeViewedRequest, MergeMethod } from '@deepseek-ai/dsh-experimental-forge';
import type { WorktreeCleanup } from '@deepseek-ai/dsh-experimental-worktree/types';
import type { Session, SessionId } from '@deepseek-ai/dsh-session';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { Config, ForgeBaseBranches, ForgeChangeRequestDiff, ForgeChangeRequestStatesFrame, ForgeCommitRange, ForgeReviewChangeRequest, ForgeReviewCountFrame, ForgeReviewFrame, ForgeExtensionState, ForgeLens, ForgeLensFrame, ForgeLensRequest, ForgeLocalCommits, ForgeLocalDiff, ForgeLocalScope, ForgePanelState, ForgeWorktreeBases } from './types.ts';
export type * from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Remote that serves the forge panel of the GUI. */
        forgePanel: ForgePanelController;
    }
}
/**
 * Serves the forge panel. Following a Session inspects the checkout of its
 * current directory using the Session's permissions and execution world, recognizes the
 * code host of the upstream remote or `origin`, probes sign-in for that host,
 * and polls the Session's bound change requests through `ctx.forge` until the
 * last follower of that Session leaves. A worktree request makes the panel
 * create a branch and checkout through an optional `ctx.worktrees` and enter
 * it while the Session's first message waits in the inbox, or at the first
 * step proposal of a message no wait took. After a failed or stopped attempt
 * the message keeps waiting for another attempt or for the request to be
 * withdrawn. A message also waits while the worktree the Session works in is
 * gone, until that worktree is checked out again or left for the source
 * checkout. Changes to a Session's checkout run as Agent maintenance, so a
 * message that arrives meanwhile waits for them.
 */
export declare class ForgePanelController extends TypertRemoteService {
    static inject: string[];
    static Config: z<Config>;
    private readonly home;
    private readonly config;
    private readonly panels;
    /** What the last panel of a Session kept when its last follower left. */
    private readonly keptPanels;
    private worktreeStates;
    private creations;
    private readonly patches;
    private readonly layers;
    private readonly reviews;
    /** The viewed marks read for each change request, by head commit. */
    private readonly viewed;
    private readonly lenses;
    private readonly lensResults;
    /** Review changes `forge/review-changed` announced per change request, which each panel entry reports. */
    private readonly reviewRevisions;
    private states;
    private readonly viewerLists;
    /** The change request a review conversation's draft quotes, per Session, bound once its first message enters the inbox. */
    private readonly staged;
    /** Review page streams of change requests shown in full, which a review change makes publish again. */
    private readonly reviewFollowers;
    private readonly stopPanels;
    private readonly stopStates;
    constructor(ctx: Context, config: Config);
    protected [Service.init](): Promise<void>;
    /**
     * Stream the panel state of a Session: the current state first, then each
     * later state. Intermediate states may be skipped when the reader is slower
     * than the updates. The stream ends when `signal` aborts or the Remote stops.
     * @param session - Session to follow.
     * @param signal - ends the stream.
     * @returns panel states in publication order.
     */
    follow(session: Session, signal: AbortSignal): AsyncIterable<ForgePanelState>;
    /**
     * Stream the last known state of every change request that a listed
     * Session the caller may read binds: the stored states first, then each
     * state a poll changes or a new binding reveals. Listing reads no Session
     * log: loaded Sessions report their bindings, others the cached Session
     * summary, and a Session without one shows nothing until it is opened.
     * Closed requests are polled at the idle cadence so reopening is observed. The
     * stream ends when `signal` aborts or the Remote stops.
     * @param signal - ends the stream.
     * @returns frames in publication order.
     * @throws when the Host lacks the Session query, projection cache, storage, or Session store service.
     */
    changeRequestStates(signal: AbortSignal): AsyncIterable<ForgeChangeRequestStatesFrame>;
    /**
     * Stream the review page's lists of the signed-in user's open change requests on every host a provider lists them on:
     * the lists read so far first, then a frame after each read settles. Readers of one repository scope share one
     * reader, which reads every `reviewListIntervalMs` while some stream lasts and backs off after failed rounds up to
     * `reviewMaxBackoffMs`; nothing is read while no stream lasts. The stream ends when `signal` aborts or the Remote stops.
     * @param repository - one repository to list in, or null for every repository the user can read.
     * @param signal - ends the stream.
     * @returns frames, each complete.
     */
    reviewLists(repository: {
        readonly owner: string;
        readonly name: string;
    } | null, signal: AbortSignal): AsyncIterable<ForgeReviewFrame>;
    /**
     * Stream the number of open change requests that ask the signed-in user for a review, summed over the hosts read:
     * the latest count first, then each change. It is read every `reviewCountIntervalMs` while some stream lasts, and a
     * list stream of every repository updates it as well. The stream ends when `signal` aborts or the Remote stops.
     * @param signal - ends the stream.
     * @returns frames, each complete.
     */
    reviewCount(signal: AbortSignal): AsyncIterable<ForgeReviewCountFrame>;
    /**
     * Read every streamed review page list and the count again at once.
     * @param signal - request cancellation.
     */
    reviewRefresh(signal: AbortSignal): Promise<void>;
    /**
     * Poll one change request the review page shows at once; its stream reports the result.
     * @param url - web URL of the change request.
     * @param signal - request cancellation.
     * @throws `forgePanel/unrecognized-url` when no provider serves the URL.
     */
    reviewPoll(url: string, signal: AbortSignal): Promise<void>;
    /**
     * Stream one change request the review page shows in full: its latest polling result first, then each later result
     * and each review change `forge/review-changed` announces for it. The change request is polled through `ctx.forge`
     * while the stream lasts. Review page reads and actions name a change request by URL and need no Session binding, so
     * only callers that may use the Host's code host credentials reach them.
     * @param url - web URL of the change request.
     * @param signal - ends the stream.
     * @returns frames, each complete.
     * @throws `forgePanel/unrecognized-url` when no provider serves the URL.
     */
    reviewChangeRequest(url: string, signal: AbortSignal): AsyncIterable<ForgeReviewChangeRequest>;
    /**
     * Read the description and labels of a change request for the review page.
     * @param url - web URL of the change request.
     * @param signal - request cancellation.
     * @returns the description.
     * @throws `forgePanel/unrecognized-url` when no provider serves the URL; `forgePanel/description-failed` with the
     * host's reason when the host does not provide it.
     */
    reviewDescription(url: string, signal: AbortSignal): Promise<ChangeRequestDescription>;
    /**
     * Read every check of a change request the review page shows.
     * @param url - web URL of the change request.
     * @param headSha - head commit whose checks the page shows.
     * @param signal - request cancellation.
     * @returns the snapshot with every check.
     * @throws as {@link ForgePanelController.changeRequestChecks} does, with `forgePanel/unrecognized-url` in place of
     * `forgePanel/not-bound`.
     */
    reviewChecks(url: string, headSha: string, signal: AbortSignal): Promise<ChangeRequestSnapshot>;
    /**
     * Read the review threads of a change request the review page shows, at the head of its latest status.
     * @param url - web URL of the change request.
     * @param headSha - head commit the page shows.
     * @param fresh - whether to read from the host even when threads at this head and update time are kept.
     * @param signal - request cancellation.
     * @returns the threads at `headSha`.
     * @throws as {@link ForgePanelController.changeRequestReview} does, with `forgePanel/unrecognized-url` in place of
     * `forgePanel/not-bound`.
     */
    reviewThreads(url: string, headSha: string, fresh: boolean, signal: AbortSignal): Promise<ForgeReviewData>;
    /**
     * Write to the review threads or the pending review of a change request the review page shows.
     * @param url - web URL of the change request.
     * @param write - the write and the head commit the user saw.
     * @param signal - request cancellation.
     * @returns whether the host took the write, as {@link ForgePanelController.changeRequestReviewWrite} does.
     * @throws `forgePanel/unrecognized-url` when no provider serves the URL; an error for an invalid write.
     */
    reviewThreadWrite(url: string, write: ForgeReviewWrite, signal: AbortSignal): Promise<ForgeReviewWriteResult>;
    /**
     * Publish a line comment or a completed review on a change request the review page shows.
     * @param url - web URL of the change request.
     * @param request - reviewed head, ranges, plain text, and explicit review decision.
     * @param signal - request cancellation.
     * @returns confirmed publication or a typed failure, as {@link ForgePanelController.submitReview} does.
     * @throws `forgePanel/unrecognized-url` when no provider serves the URL; an error for an invalid review.
     */
    reviewSubmit(url: string, request: ForgeReviewRequest, signal: AbortSignal): Promise<ForgeReviewResult>;
    /**
     * Read the changes of a change request the review page shows, or of consecutive commits of it.
     * @param url - web URL of the change request.
     * @param commits - consecutive commits of the change request, or null for all of it.
     * @param signal - request cancellation.
     * @returns the files and the commit they end at, without a local checkout count.
     * @throws as {@link ForgePanelController.changeRequestDiff} does, with `forgePanel/unrecognized-url` in place of
     * `forgePanel/not-bound`.
     */
    reviewDiff(url: string, commits: ForgeCommitRange | null, signal: AbortSignal): Promise<ForgeChangeRequestDiff>;
    /**
     * List the commits of a change request the review page shows.
     * @param url - web URL of the change request.
     * @param signal - request cancellation.
     * @returns the commits, or null when the provider does not read commits.
     * @throws `forgePanel/unrecognized-url` when no provider serves the URL; `forgePanel/diff-failed` when the host does
     * not list them.
     */
    reviewCommits(url: string, signal: AbortSignal): Promise<ForgeCommitList | null>;
    /**
     * Read one file of a change request's repository at a commit for the review page.
     * @param url - web URL of the change request.
     * @param commit - commit object name.
     * @param path - path relative to the repository root.
     * @param signal - request cancellation.
     * @returns the text.
     * @throws `forgePanel/unrecognized-url` when no provider serves the URL; `forgePanel/diff-too-large` or
     * `forgePanel/diff-failed` when the host does not provide the file.
     */
    reviewText(url: string, commit: string, path: string, signal: AbortSignal): Promise<string>;
    /**
     * Read the signed-in user's viewed marks on the files of a change request the review page shows, as
     * {@link ForgePanelController.changeRequestViewed} keeps them.
     * @param url - web URL of the change request.
     * @param headSha - head commit of the shown diff.
     * @param fresh - whether to read the host although kept marks could answer, as after a refresh.
     * @param signal - request cancellation.
     * @returns the marks, or null when the provider keeps no viewed marks.
     * @throws `forgePanel/unrecognized-url` when no provider serves the URL; `forgePanel/stale-head` or
     * `forgePanel/viewed-failed` as {@link ForgePanelController.changeRequestViewed} does.
     */
    reviewViewed(url: string, headSha: string, fresh: boolean, signal: AbortSignal): Promise<ForgeViewedFiles | null>;
    /**
     * Set or clear the signed-in user's viewed mark on one file of a change request the review page shows.
     * @param url - web URL of the change request.
     * @param request - the file, its mark, and the head commit of the shown diff.
     * @param signal - request cancellation.
     * @throws `forgePanel/unrecognized-url` when no provider serves the URL; the action errors of
     * {@link ForgePanelController.setFileViewed}.
     */
    reviewSetViewed(url: string, request: ForgeViewedRequest, signal: AbortSignal): Promise<void>;
    /**
     * Mark a draft change request the review page shows ready for review.
     * @param url - web URL of the change request.
     * @param signal - request cancellation.
     * @throws `forgePanel/unrecognized-url` when no provider serves the URL; `forgePanel/action-failed` or
     * `forgePanel/action-unknown` with the host's reason.
     */
    reviewMarkReady(url: string, signal: AbortSignal): Promise<void>;
    /**
     * Merge a change request the review page shows while its head is still `headSha`.
     * @param url - web URL of the change request.
     * @param method - how the commits enter the base branch.
     * @param headSha - head commit the user confirmed.
     * @param signal - request cancellation.
     * @throws `forgePanel/unrecognized-url` when no provider serves the URL; `forgePanel/stale-head`,
     * `forgePanel/action-failed`, or `forgePanel/action-unknown` with the host's reason.
     */
    reviewMerge(url: string, method: MergeMethod, headSha: string, signal: AbortSignal): Promise<void>;
    /**
     * Rerun the failed checks of a change request the review page shows.
     * @param url - web URL of the change request.
     * @param request - the head commit whose checks the user saw.
     * @param signal - request cancellation.
     * @throws `forgePanel/unrecognized-url` when no provider serves the URL; `forgePanel/stale-head`,
     * `forgePanel/action-failed`, or `forgePanel/action-unknown` with the host's reason.
     */
    reviewRerunChecks(url: string, request: ForgeRerunRequest, signal: AbortSignal): Promise<void>;
    /**
     * Request reviews of a change request the review page shows from more reviewers.
     * @param url - web URL of the change request.
     * @param reviewers - the reviewers to ask, by kind and login.
     * @param signal - request cancellation.
     * @throws `forgePanel/unrecognized-url` when no provider serves the URL; `forgePanel/action-failed` or
     * `forgePanel/action-unknown` with the host's reason; an error without reviewers.
     */
    reviewRequestReviews(url: string, reviewers: readonly Pick<ChangeRequestReviewer, 'kind' | 'login'>[], signal: AbortSignal): Promise<void>;
    /**
     * List accounts a review of a change request the review page shows can be requested from.
     * @param url - web URL of the change request.
     * @param query - text the login or name contains; empty for the host's suggestions.
     * @param signal - request cancellation.
     * @returns the accounts, the host's suggestions first.
     * @throws `forgePanel/unrecognized-url` when no provider serves the URL; `forgePanel/reviewers-failed` when the host
     * does not list them.
     */
    reviewReviewerCandidates(url: string, query: string, signal: AbortSignal): Promise<readonly ForgeReviewerCandidate[]>;
    /**
     * Bring the base branch's new commits into the head branch of a change request the review page shows.
     * @param url - web URL of the change request.
     * @param method - merge or rebase.
     * @param headSha - head commit the user confirmed.
     * @param signal - request cancellation.
     * @throws `forgePanel/unrecognized-url` when no provider serves the URL; `forgePanel/stale-head`,
     * `forgePanel/action-failed`, or `forgePanel/action-unknown` with the host's reason.
     */
    reviewUpdateBranch(url: string, method: BranchUpdateMethod, headSha: string, signal: AbortSignal): Promise<void>;
    /**
     * Remember the change request a review conversation's draft quotes, or forget it with null. When the Session's next
     * message enters its inbox, the change request is bound to the Session with a `track` record before the turn starts;
     * a Session that already started is bound at its next message. The choice lives in memory until then.
     * @param sessionId - the Session whose draft quotes the change request; staging neither loads nor resumes it.
     * @param url - web URL of the change request, or null.
     * @param signal - request cancellation.
     * @throws `forgePanel/unrecognized-url` when no provider serves the URL.
     */
    reviewStage(sessionId: SessionId, url: string | null, signal: AbortSignal): Promise<void>;
    /**
     * Read or await the worktree service's archive cleanup of the Session's checkout.
     * @param sessionId - Session whose cleanup is visible to the caller; reading neither loads nor resumes it.
     * @param revision - null reads now; a matching revision waits for completion.
     * @returns the cleanup state, or null without a worktree service, an attempt, or a current revision.
     */
    worktreeCleanup(sessionId: SessionId, revision: number | null): Promise<WorktreeCleanup | null>;
    /**
     * List the branches that can start a worktree of the Session's current checkout: the checked-out branch, each
     * remote's default branch, other local branches, and each remote's other remote-tracking branches, remotes in the
     * order the panel recognizes code hosts.
     * @param session - Session whose checkout is read.
     * @param query - text the branch names must contain, ignoring case; empty for every branch.
     * @param signal - request cancellation.
     * @returns the branches, at most `maxBranches` local branches and `maxBranches` per remote, most recently committed first.
     * @throws `forgePanel/not-a-checkout` outside a checkout; the Git error when Git fails or the listed refs exceed `maxDiffBytes`.
     */
    worktreeBases(session: Session, query: string, signal: AbortSignal): Promise<ForgeWorktreeBases>;
    /**
     * List the branches the `branch` scope of the Session's current checkout can compare with.
     * @param session - Session whose checkout is read.
     * @param query - text the branch names must contain, ignoring case; empty for every branch.
     * @param signal - request cancellation.
     * @returns the automatic fork point and at most `maxBranches` remote-tracking and local branches each,
     * most recently committed first, without the checked-out branch.
     * @throws `forgePanel/not-a-checkout` outside a checkout; the Git error when Git fails or the listed refs exceed `maxDiffBytes`.
     */
    diffBases(session: Session, query: string, signal: AbortSignal): Promise<ForgeBaseBranches>;
    /**
     * Bind a change request to a Session by URL, or restore a dismissed binding.
     * @param session - Session that receives the binding.
     * @param url - web URL of the change request.
     * @param signal - request cancellation.
     * @throws `forgePanel/unrecognized-url` when no registered provider serves the URL.
     */
    track(session: Session, url: string, signal: AbortSignal): Promise<void>;
    /**
     * Hide a visible binding of a Session; other URLs leave the Session unchanged.
     * @param session - Session that owns the binding.
     * @param url - web URL of the change request.
     * @param signal - request cancellation.
     */
    dismiss(session: Session, url: string, signal: AbortSignal): Promise<void>;
    /**
     * Reinspect a followed Session's checkout, probe sign-in again, and poll its
     * change requests at once; an unfollowed Session is unchanged.
     * @param sessionId - Session whose panel refreshes; refreshing neither loads nor resumes it.
     * @param signal - request cancellation.
     * @returns settles once the inspection and the sign-in probe have ended; poll results reach the panel stream later.
     */
    refresh(sessionId: SessionId, signal: AbortSignal): Promise<void>;
    /**
     * Bring a followed Session's panel up to date after its surface showed again: reinspect the checkout, poll the
     * change requests whose latest poll is older than `statusMaxAgeMs`, probe sign-in again unless the last probe found
     * the host ready, and look the upstream branch up again while the Session shows no change request; an unfollowed
     * Session is unchanged.
     * @param sessionId - Session whose panel is revisited; revisiting neither loads nor resumes it.
     * @param signal - request cancellation.
     * @returns settles once the inspection and the sign-in probe have ended; poll results reach the panel stream later.
     */
    revisit(sessionId: SessionId, signal: AbortSignal): Promise<void>;
    /**
     * Read the changes one scope covers in the checkout of the Session's
     * current directory, with Git using the Session's sandbox policy.
     * @param session - Session whose checkout is read.
     * @param scope - which changes to read.
     * @param signal - request cancellation.
     * @returns the files, the base of the `branch` scope, and the untracked files left out.
     * @throws `forgePanel/not-a-checkout` outside a checkout; `forgePanel/base-missing` when the base branch
     * chosen for the `branch` scope does not exist; `forgePanel/no-fork-point` for the `branch` scope without
     * a fork point; `forgePanel/commits-missing` when chosen commits are not between the fork point and HEAD in order;
     * `forgePanel/commits-not-linear` when a chosen commit's first parent is not the commit listed before it;
     * `forgePanel/filter-config-failed` when filter configuration cannot be read completely, before
     * any comparison; `forgePanel/diff-too-large` over `maxDiffBytes`; the Git error when Git fails.
     */
    localDiff(session: Session, scope: ForgeLocalScope, signal: AbortSignal): Promise<ForgeLocalDiff>;
    /**
     * List the commits of the `branch` scope of the Session's current checkout, which the changes view can show one or
     * several of instead of the whole scope.
     * @param session - Session whose checkout is read.
     * @param base - the base ref of the `branch` scope, or null for its automatic fork point.
     * @param signal - request cancellation.
     * @returns the newest `maxCommits` commits between the fork point and HEAD, oldest first, and HEAD's commit.
     * @throws `forgePanel/not-a-checkout` outside a checkout; `forgePanel/base-missing` when the base branch does not
     * exist; `forgePanel/no-fork-point` without a fork point; the Git error when Git fails or the listing exceeds `maxDiffBytes`.
     */
    localCommits(session: Session, base: string | null, signal: AbortSignal): Promise<ForgeLocalCommits>;
    /**
     * Read the new side of one changed file in a scope, which supplies the
     * unchanged lines between its hunks: the index for `staged`, the last chosen commit for chosen commits of
     * the `branch` scope, else the working tree.
     * @param session - Session whose checkout is read.
     * @param scope - the scope the diff was read in.
     * @param path - path relative to the checkout's top-level directory, as the diff names it.
     * @param signal - request cancellation.
     * @returns the text.
     * @throws `forgePanel/not-a-checkout` outside a checkout; `forgePanel/diff-too-large` over `maxDiffBytes`;
     * `forgePanel/commits-missing` for a chosen commit that is not a full object name; an error for a path outside
     * the checkout, binary content, or a failed read.
     */
    localText(session: Session, scope: ForgeLocalScope, path: string, signal: AbortSignal): Promise<string>;
    /**
     * Load complete checks for the change request whose list the user opened.
     * @param session - Session retaining the visible binding.
     * @param url - binding URL.
     * @param headSha - commit displayed by the card; a different head rejects the result.
     * @param signal - cancellation when the list closes.
     * @returns the complete snapshot at the displayed head.
     * @throws `forgePanel/not-bound` for an invisible binding, `forgePanel/stale-head` for a moved head,
     * or `forgePanel/checks-failed` when the provider cannot complete the read.
     */
    changeRequestChecks(session: Session, url: string, headSha: string, signal: AbortSignal): Promise<ChangeRequestSnapshot>;
    /**
     * List the commits of a change request of a Session at its current head, which the changes view can show one or
     * several of instead of the whole change request.
     * @param session - Session the change request is bound to.
     * @param url - binding URL of the change request.
     * @param signal - request cancellation.
     * @returns the commits oldest first with the head they were read at, or null when the provider does not read commits.
     * @throws `forgePanel/not-bound` unless the URL is a visible binding of the Session that a provider serves;
     * `forgePanel/diff-failed` when the host does not list them.
     */
    changeRequestCommits(session: Session, url: string, signal: AbortSignal): Promise<ForgeCommitList | null>;
    /**
     * Read the changes of a change request of a Session as its code host
     * computes them, with each file's layer following the root `.gitattributes`
     * of the commit the diff ends at. Without `commits` the diff covers the change
     * request at the head commit of its latest status; a patch already read at the
     * same head commit and base branch is reused from memory with its attributes, for
     * any Session, until `maxCachedDiffBytes` evicts it. With `commits`, it covers those
     * commits, from the first one's first parent to the last, and is read every time.
     * @param session - Session the change request is bound to.
     * @param url - binding URL of the change request.
     * @param commits - consecutive commits of the change request, or null for all of it.
     * @param signal - request cancellation.
     * @returns the files, the commit they end at, each file's web page, and the commits the checkout has beyond the head.
     * @throws `forgePanel/not-bound` unless the URL is a visible binding of the Session that a provider serves;
     * `forgePanel/commits-missing` when chosen commits are not among the change request's commits in order;
     * `forgePanel/commits-not-linear` when a chosen commit's first parent is not the commit listed before it;
     * `forgePanel/stale-head` without `commits` when the head moved past the latest status, which is then polled again;
     * `forgePanel/diff-too-large` when the host or its provider refuses the diff over a size limit;
     * `forgePanel/diff-failed` before its status was read, for a first chosen commit without a parent, and when the host
     * does not provide the commits, the diff, or an existing `.gitattributes` otherwise.
     */
    changeRequestDiff(session: Session, url: string, commits: ForgeCommitRange | null, signal: AbortSignal): Promise<ForgeChangeRequestDiff>;
    /**
     * Read one file of a change request's repository at a commit, which
     * supplies the unchanged lines between the hunks of its diff.
     * @param session - Session the change request is bound to.
     * @param url - binding URL of the change request.
     * @param commit - commit object name, the head commit of the diff.
     * @param path - path relative to the repository root.
     * @param signal - request cancellation.
     * @returns the text.
     * @throws `forgePanel/not-bound` unless the URL is a visible binding of the Session that a provider serves;
     * `forgePanel/diff-too-large` when the host or its provider refuses the file over a size limit;
     * `forgePanel/diff-failed` when the host does not provide the file otherwise.
     */
    changeRequestText(session: Session, url: string, commit: string, path: string, signal: AbortSignal): Promise<string>;
    /**
     * Register a filter lens as an effect on the calling fiber. The changes views list it while it is registered; ending
     * the registration aborts its running classifications and waits for them.
     * @param lens - the lens.
     * @returns the disposer that unregisters the lens and waits for its classifications to stop.
     * @throws when another registration holds `lens.id`.
     */
    registerLens(lens: ForgeLens): () => Promise<void>;
    /**
     * Stream the facts every changes view reads about the panel's extensions: the current facts first, then the facts
     * after each lens registration or withdrawal. The stream ends when `signal` aborts or the Remote stops.
     * @param signal - ends the stream.
     * @returns the registered lenses and the annotation limit, in publication order.
     */
    extensions(signal: AbortSignal): AsyncIterable<ForgeExtensionState>;
    /**
     * Classify the files a changes view of a Session shows with one registered lens: progress frames while the lens
     * runs, then the files it keeps. Results for the same files, lens, and lens version are reused from memory until
     * `maxCachedLensBytes` evicts them. Local changes are read with the Session's permissions; a change request's files
     * are those `changeRequestDiff` reads.
     * @param session - Session whose checkout or binding the view shows.
     * @param request - the view's source, the version of the files it shows, and the lens.
     * @param signal - ends the classification.
     * @returns progress frames, then one result frame.
     * @throws `forgePanel/lens-missing` while no lens holds the identity or once its registration ends;
     * `forgePanel/lens-stale` before a change request's status was read, when the files differ from `request.version`, and
     * when local files changed while the lens ran;
     * `forgePanel/lens-failed` when the lens fails, runs past `lensTimeoutMs`, reads past `maxLensReadBytes`, or answers
     * over `maxCachedLensBytes`; the errors of `localDiff` and `changeRequestDiff` for the files.
     */
    changesLens(session: Session, request: ForgeLensRequest, signal: AbortSignal): AsyncIterable<ForgeLensFrame>;
    /**
     * Read the signed-in user's viewed marks on the files of a change request of a Session, which the host keeps for the
     * whole change request. Marks read at the same head are kept in memory and returned until they are `reviewRefreshMs`
     * old or `maxCachedReviewBytes` evicts them; a mark saved through `ctx.forge` at that head replaces the kept state
     * of its file, so the read after a save costs no request.
     * @param session - Session the change request is bound to.
     * @param url - binding URL of the change request.
     * @param headSha - head commit of the shown diff; marks read at another head are refused.
     * @param fresh - whether to read the host although kept marks could answer, as after a refresh.
     * @param signal - request cancellation.
     * @returns the marks at `headSha`, or null when the provider keeps no viewed marks.
     * @throws `forgePanel/not-bound` unless the URL is a visible binding of the Session that a provider serves;
     * `forgePanel/stale-head` when the head moved past `headSha`, which is then polled again; `forgePanel/viewed-failed`
     * when the host does not provide the marks otherwise.
     */
    changeRequestViewed(session: Session, url: string, headSha: string, fresh: boolean, signal: AbortSignal): Promise<ForgeViewedFiles | null>;
    /**
     * Set or clear the signed-in user's viewed mark on one file of a change request of a Session.
     * @param session - Session the change request is bound to.
     * @param url - binding URL of the change request.
     * @param request - the file, its mark, and the head commit of the shown diff.
     * @param signal - request cancellation.
     * @throws `forgePanel/not-bound` unless the URL is a visible binding of the Session that a provider serves;
     * `forgePanel/stale-head` when the head moved past `request.headSha`; `forgePanel/action-failed` with the host's
     * reason when the host refuses, cannot be reached, or keeps no viewed marks; `forgePanel/action-unknown` when the host
     * did not confirm whether it saved the mark.
     */
    setFileViewed(session: Session, url: string, request: ForgeViewedRequest, signal: AbortSignal): Promise<void>;
    /**
     * Read the review threads of a change request of a Session at the head commit of its displayed diff. Threads read
     * at the same head commit and update time are reused from memory, for any Session, until they are
     * `reviewRefreshMs` old, `maxCachedReviewBytes` evicts them, or a review write through this panel drops them; a read
     * again after that age, or a `fresh` read, shows threads resolved elsewhere since, which do not change a GitHub pull
     * request's update time.
     * @param session - Session the change request is bound to.
     * @param url - binding URL of the change request.
     * @param headSha - head commit of the displayed diff.
     * @param fresh - whether to read from the host even when threads at this head and update time are kept, as after the
     * reader refreshes the view; the result replaces the kept threads.
     * @param signal - request cancellation.
     * @returns the threads at `headSha`, with `current` positions numbering the files of that diff.
     * @throws `forgePanel/not-bound` unless the URL is a visible binding of the Session that a provider serves;
     * `forgePanel/stale-head` when the latest status or the host names another head, which a host answer polls again;
     * `forgePanel/review-unsupported` when the provider cannot read reviews; `forgePanel/review-failed` before the
     * status was read and when the host does not provide the threads otherwise.
     */
    changeRequestReview(session: Session, url: string, headSha: string, fresh: boolean, signal: AbortSignal): Promise<ForgeReviewData>;
    /**
     * Publish a line comment or completed review for a visible Session binding. The threads kept for the change request
     * are dropped once the host answers, so the next read shows the comments.
     * @param session - Session retaining the change request.
     * @param url - visible binding URL.
     * @param request - reviewed head, ranges, plain text, and explicit review decision.
     * @param signal - request cancellation.
     * @returns confirmed publication or a typed failure; unknown outcomes require reconciliation on the host.
     */
    submitReview(session: Session, url: string, request: ForgeReviewRequest, signal: AbortSignal): Promise<ForgeReviewResult>;
    /**
     * Write to the review threads or the pending review of a change request of a Session while its head is still the
     * head the user saw. The threads kept for the change request are dropped once the host answers, so the next read
     * shows the write, which a resolve does not show through a GitHub pull request's update time.
     * @param session - Session the change request is bound to.
     * @param url - binding URL of the change request.
     * @param write - the write and the head commit of the threads the user saw.
     * @param signal - request cancellation.
     * @returns whether the host took the write; `stale` once the head moved, which polls the change request again, and
     * `unknown` when the outcome must be checked on the host before the write is tried again.
     * @throws `forgePanel/not-bound` unless the URL is a visible binding of the Session that a provider serves; an error
     * for a write without text, a head that is not a commit object name, or an invalid line range.
     */
    changeRequestReviewWrite(session: Session, url: string, write: ForgeReviewWrite, signal: AbortSignal): Promise<ForgeReviewWriteResult>;
    /**
     * Mark a draft change request of a Session ready for review; the change
     * request is polled again once the host answers.
     * @param session - Session the change request is bound to.
     * @param url - binding URL of the change request.
     * @param signal - request cancellation.
     * @throws `forgePanel/not-bound` unless the URL is a visible binding of the Session that a provider serves;
     * `forgePanel/action-failed` with the host's reason when the host refuses or cannot be reached.
     */
    markReady(session: Session, url: string, signal: AbortSignal): Promise<void>;
    /**
     * Merge a change request of a Session while its head is still `headSha`;
     * the change request is polled again once the host answers.
     * @param session - Session the change request is bound to.
     * @param url - binding URL of the change request.
     * @param method - how the commits enter the base branch.
     * @param headSha - head commit the user confirmed.
     * @param signal - request cancellation.
     * @throws `forgePanel/not-bound` unless the URL is a visible binding of the Session that a provider serves;
     * `forgePanel/stale-head` when the head moved past `headSha`; `forgePanel/action-failed` with the host's
     * reason when the host refuses otherwise or cannot be reached.
     */
    merge(session: Session, url: string, method: MergeMethod, headSha: string, signal: AbortSignal): Promise<void>;
    /**
     * Rerun the failed checks of a change request of a Session while its head is still the commit whose checks the user
     * saw; the change request is polled again once the host answers.
     * @param session - Session the change request is bound to.
     * @param url - binding URL of the change request.
     * @param request - the head commit whose checks the user saw.
     * @param signal - request cancellation.
     * @throws `forgePanel/not-bound` unless the URL is a visible binding of the Session that a provider serves;
     * `forgePanel/stale-head` when the head moved past `request.headSha`; `forgePanel/action-failed` with the host's
     * reason when the host refuses, cannot be reached, or reruns no checks; `forgePanel/action-unknown` when the host did
     * not confirm whether it started the rerun.
     */
    rerunChecks(session: Session, url: string, request: ForgeRerunRequest, signal: AbortSignal): Promise<void>;
    /**
     * Request reviews of a change request of a Session from more reviewers; the change request is polled again once the
     * host answers.
     * @param session - Session the change request is bound to.
     * @param url - binding URL of the change request.
     * @param reviewers - the reviewers to ask, by kind and login.
     * @param signal - request cancellation.
     * @throws `forgePanel/not-bound` unless the URL is a visible binding of the Session that a provider serves;
     * `forgePanel/action-failed` with the host's reason when the host refuses, cannot be reached, or requests no reviews;
     * `forgePanel/action-unknown` when the host did not confirm whether it requested the reviews.
     */
    requestReviews(session: Session, url: string, reviewers: readonly Pick<ChangeRequestReviewer, 'kind' | 'login'>[], signal: AbortSignal): Promise<void>;
    /**
     * List accounts a review of a change request of a Session can be requested from.
     * @param session - Session the change request is bound to.
     * @param url - binding URL of the change request.
     * @param query - text the login or name contains; empty for the host's suggestions and first accounts.
     * @param signal - request cancellation.
     * @returns the accounts, the host's suggestions first.
     * @throws `forgePanel/not-bound` unless the URL is a visible binding of the Session that a provider serves;
     * `forgePanel/reviewers-failed` when the host does not list them.
     */
    reviewerCandidates(session: Session, url: string, query: string, signal: AbortSignal): Promise<readonly ForgeReviewerCandidate[]>;
    /**
     * Bring the base branch's new commits into the head branch of a change request of a Session while its head is still
     * `headSha`; the change request is polled again once the host answers.
     * @param session - Session the change request is bound to.
     * @param url - binding URL of the change request.
     * @param method - merge commit or rebase.
     * @param headSha - head commit the user confirmed.
     * @param signal - request cancellation.
     * @throws `forgePanel/not-bound` unless the URL is a visible binding of the Session that a provider serves;
     * `forgePanel/stale-head` when the head moved past `headSha`; `forgePanel/action-failed` with the host's reason when
     * the host refuses, cannot be reached, or updates no branches; `forgePanel/action-unknown` when the host did not
     * confirm whether it started the update.
     */
    updateBranch(session: Session, url: string, method: BranchUpdateMethod, headSha: string, signal: AbortSignal): Promise<void>;
    /**
     * Ask for a new worktree before the Session's first turn, replacing an open
     * request and forgetting a failed attempt. While the next message waits in
     * the inbox, or else at the first step proposal, the panel creates the
     * branch `name`, or a generated branch per attempt when it is null, from
     * `from`, or from HEAD of the current checkout when it is null, and enters
     * its checkout; a remote-tracking `from` is fetched first. A message that
     * already waits after a failed or stopped attempt keeps waiting for
     * {@link ForgePanelController.retryWorktree}.
     * @param session - Session without a started turn.
     * @param from - full name of a local or remote-tracking base branch, or null for HEAD.
     * @param name - new branch name, or null to generate one per attempt.
     * @param signal - request cancellation.
     * @throws `forgePanel/invalid-branch` when `from` is empty; `forgePanel/invalid-name` when `name` breaks
     * a branch-name rule; `forgePanel/branch-exists` when the checkout has a local branch named `name`;
     * `forgePanel/not-a-checkout` when a name is checked outside a checkout; `forgePanel/worktrees-unavailable`
     * without a worktree service; `forgePanel/session-started` after a turn started or the worktree was
     * created; `forgePanel/session-busy` while the worktree is being created.
     */
    requestWorktree(session: Session, from: string | null, name: string | null, signal: AbortSignal): Promise<void>;
    /**
     * Withdraw the open worktree request of a Session with its failed attempt,
     * which lets a waiting message go on in the current checkout; without a
     * request the Session is unchanged. Withdrawing needs no worktree service.
     * @param session - Session without a started turn.
     * @param signal - request cancellation.
     * @throws `forgePanel/session-started` after a turn started or the worktree was created;
     * `forgePanel/session-busy` while the worktree is being created.
     */
    cancelWorktree(session: Session, signal: AbortSignal): Promise<void>;
    /**
     * Stop the creation a message of the Session waits for; the message keeps
     * waiting with the request still open. Without such a creation the Session
     * is unchanged.
     * @param session - Session whose creation stops.
     * @param signal - request cancellation.
     */
    stopCreation(session: Session, signal: AbortSignal): Promise<void>;
    /**
     * Make another attempt, on the requested branch name or a new generated
     * one, at the worktree a message of the Session waits for after a failed or
     * stopped attempt.
     * @param session - Session whose message waits.
     * @param fetch - false skips fetching a remote-tracking base branch for this attempt, which then starts from the
     * commit last fetched.
     * @param signal - request cancellation.
     * @throws `forgePanel/not-waiting` when no message waits or an attempt is running.
     */
    retryWorktree(session: Session, fetch: boolean, signal: AbortSignal): Promise<void>;
    /**
     * Check out the created worktree of a Session again at its recorded
     * directory when that directory is gone: its branch when the branch still
     * exists, otherwise a new branch of the same name at the base commit. Changes
     * that were never committed are not recovered. Runs as Agent maintenance,
     * inside the wait of a message that waits for the restoration, which then
     * goes on; without a missing directory the Session is unchanged.
     * @param session - Session whose worktree directory is gone.
     * @param signal - request cancellation, which aborts the restoration.
     * @throws `forgePanel/no-worktree` without a created worktree; `forgePanel/worktrees-unavailable`
     * without a worktree service; `forgePanel/session-busy` while the Session's Agent is not loaded or
     * has other work; `forgePanel/restore-failed` when Git fails.
     */
    restoreWorktree(session: Session, signal: AbortSignal): Promise<void>;
    /**
     * Move a Session from its created worktree to the source checkout the
     * worktree came from; the Session no longer works in the worktree. Runs as
     * Agent maintenance, inside the wait of a message that waits for the removed
     * worktree, which then goes on.
     * @param session - Session with a created worktree.
     * @param signal - request cancellation.
     * @throws `forgePanel/no-worktree` without a created worktree; `forgePanel/session-busy` while the
     * Session's Agent is not loaded or has other work; the working-directory service's error when the
     * source checkout no longer exists.
     */
    continueInProject(session: Session, signal: AbortSignal): Promise<void>;
    /**
     * Hold the turn of a message entering a Session's next-turn queue while the
     * Session's requested worktree does not exist yet, or while the worktree
     * the Session works in is checked and, when gone, until it is restored or
     * left. The message is entering, so the delivery has not woken the Agent
     * yet and its wake waits for the hold. A message for the next step, such as
     * a notice another plugin queues, opens no turn and gets no hold.
     * @param agent - Agent whose inbox receives the message.
     * @param message - the entering message.
     */
    private holdTurn;
    /**
     * Check whether the worktree the Session works in is gone.
     * @param session - Session to check.
     * @param signal - cancellation of the check.
     * @returns the missing worktree, or null while it exists or once the Session works elsewhere.
     * @throws when the filesystem or Git cannot answer.
     */
    private missingFor;
    /** The files of a change request at the head a status recorded, read once per head and base branch while the cache keeps them. */
    private headFiles;
    /** The files of consecutive commits of a change request, from the first one's first parent, which is returned too, to the last. */
    private commitFiles;
    /**
     * Read a patch that ends at `commit` together with the root `.gitattributes` at that commit. A failed patch read
     * cancels the attributes read. Both reads end before the result: the patch's failure passes on first, and the
     * attributes failure only after the patch was read, so the outcome does not depend on which read ends first.
     * @param ref - change request whose repository holds the commit.
     * @param commit - commit the patch ends at.
     * @param readPatch - reads the patch under the given cancellation.
     * @param signal - request cancellation.
     * @returns the patch and the attributes text, empty when the commit has none.
     * @throws the Remote error for a refused patch or attributes read, or `signal.reason` when it aborts.
     */
    private patchAt;
    /** The root `.gitattributes` of a change request's repository at a commit, empty when the commit has none. */
    private attributesAt;
    /** Inspect the checkout of the Session's current directory, which local diffs read. */
    private checkoutOf;
    /** Read every check of a change request, refusing a list read at another head; `recheck` runs once the host answers. */
    private readChecks;
    /** Read the changes of a change request at the head of its latest status, or of chosen commits; `ahead` counts local commits. */
    private readDiff;
    /** Read the viewed marks at a head commit, reusing marks kept for that head unless `fresh`. */
    private readViewed;
    /** Set or clear a viewed mark. */
    private writeViewed;
    /** Read the review threads at the head of the latest status, reusing threads kept for that head and update time. */
    private readThreads;
    /** Publish a comment or a completed review, then drop the threads kept for the change request. */
    private publishReview;
    /** Write to the review threads or the pending review, then drop the threads kept for the change request. */
    private writeThreads;
    /** The change request a review page URL names, with its latest polling result. */
    /** Request reviews of a change request from the given accounts, refusing an empty list or an empty login. */
    private askReviews;
    /** List accounts a review of a change request can be requested from, failing with the host's reason. */
    private candidatesOf;
    private served;
    /** Bind the change request a review conversation staged once the Session's message enters its inbox. */
    private bindStaged;
    /** A visible binding of the Session that a provider serves, which actions and reads are limited to. */
    private bound;
    private worktreeState;
    /**
     * Refuse a new branch name that breaks a branch-name rule or names a local branch of the Session's checkout. The
     * rules cover every name `git check-ref-format` refuses, which the worktree service runs again at creation.
     */
    private checkBranchName;
    private editableWorktree;
    /** The worktree state of a Session whose request may still change: no turn started, nothing created, and no attempt running. */
    private changeableWorktree;
    private createdWorktree;
    /**
     * Run work as maintenance of the Session's Agent: inside the wait of a
     * message that waits for the removed worktree, else as a task of its own,
     * which the Agent refuses while it has other work.
     */
    private maintain;
    /** The shared change request states, created for the first stream from the Host's Session and storage services. */
    private changeRequestStatesHub;
    /**
     * Bring what is kept for a change request up to date after an accepted review change, and let its panel entries
     * report it: a saved viewed mark replaces the kept state of its file, which a host lists for every changed file, and
     * leaves the kept threads; any other change drops the kept threads.
     */
    private reviewChanged;
    /** The files a lens request names with their reader and the key results for them are kept under. */
    private lensSubject;
    /** The merge base whose files the old side of a change request's diff at the status's head shows. */
    private mergeBaseOf;
    private panelOf;
}
export default ForgePanelController;
//# sourceMappingURL=index.d.ts.map