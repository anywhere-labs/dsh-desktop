/** Filter lenses registered on the forge panel host, the runs that classify one diff with one of them, and the kept results. */
import type { ForgeLens, ForgeLensFile, ForgeLensFrame, ForgeLensKeep, ForgeLensSource, ForgeRegisteredLens } from './types.ts';
/** The files a lens kept, by path. */
export type LensFiles = Readonly<Record<string, ForgeLensKeep>>;
/** Why a lens run produced no result; the message names the cause for the reader. */
export declare class LensFailed extends Error {
    name: string;
}
/** The reason a run stops when its lens's registration ends. */
export declare class LensWithdrawn extends Error {
    name: string;
}
/** One registered lens and the runs that use it. */
export interface LensRegistration {
    /** The lens as its plugin registered it. */
    readonly lens: ForgeLens;
    /** Aborts with a {@link LensWithdrawn} once the registration ends. */
    readonly lifetime: AbortSignal;
    /**
     * Keep one run among the work the registration's disposer waits for.
     * @param run - the run.
     * @returns the same run.
     */
    track<T>(run: Promise<T>): Promise<T>;
}
/**
 * The lenses registered on one panel host. Identities are unique while registered; the follow streams of every reader
 * receive the list after each change, and end once the registry closes.
 */
export declare class LensRegistry {
    private readonly entries;
    private readonly listeners;
    private readonly closed;
    /**
     * Register a lens.
     * @param lens - the lens.
     * @returns the disposer, which aborts the lens's running classifications and waits for them.
     * @throws when another registration holds `lens.id`.
     */
    add(lens: ForgeLens): () => Promise<void>;
    /**
     * Find a registered lens.
     * @param id - its identity.
     * @returns the registration, or undefined while no lens holds the identity.
     */
    get(id: string): LensRegistration | undefined;
    /**
     * Stream the registered lenses: the current list first, then the list after each change; changes that arrive while
     * the reader is busy collapse into the next list.
     * @param signal - ends the stream.
     * @returns identities and versions in registration order.
     */
    follow(signal: AbortSignal): AsyncIterable<readonly ForgeRegisteredLens[]>;
    /** End every follow stream; registrations still end through their own disposers. */
    close(): void;
    private changed;
}
/** One diff a lens classifies, with the reader of its files' sides. */
export interface LensSubject {
    /** What the view shows. */
    readonly source: ForgeLensSource;
    /** Every file of the diff in display order. */
    readonly files: readonly ForgeLensFile[];
    /**
     * Read one side of a file of `files`.
     * @returns the text, or null when the side does not exist or holds binary content.
     */
    readonly read: (side: 'old' | 'new', file: ForgeLensFile, signal: AbortSignal) => Promise<string | null>;
}
/** Bounds of one lens run, from the panel's configuration. */
export interface LensLimits {
    /** `lensTimeoutMs`. */
    readonly timeoutMs: number;
    /** `maxLensReadBytes`. */
    readonly maxReadBytes: number;
    /** `maxCachedLensBytes`, which bounds one result as JSON. */
    readonly maxResultBytes: number;
}
/**
 * Classify one diff with one lens. The lens's signal aborts with the caller's, when the registration ends, and after
 * `timeoutMs`; the run settles then even when the lens ignores its signal, while the registration's disposer waits until
 * `classify` itself settles. A run whose signal aborted before it started does not call the lens. Paths the lens names
 * outside the diff are left out of the result.
 * @param registration - the registered lens.
 * @param subject - the diff and its reader.
 * @param limits - deadline, read budget, and result bound.
 * @param signal - the caller's cancellation.
 * @param progress - receives the lens's progress while it runs.
 * @returns the files the lens kept.
 * @throws `signal.reason` once the caller aborts; a {@link LensWithdrawn} once the registration ends; a
 * {@link LensFailed} when the lens rejects, runs past the deadline, reads past the budget, or answers over the bound.
 */
export declare function runLens(registration: LensRegistration, subject: LensSubject, limits: LensLimits, signal: AbortSignal, progress: (done: number, total: number) => void): Promise<LensFiles>;
/**
 * Turn one run into frames: the latest progress whenever the lens reported some since the last frame, then the result.
 * @param run - starts the run with the progress receiver.
 * @returns progress frames, then one result frame.
 * @throws the run's failure after its last progress frame.
 */
export declare function lensFrames(run: (progress: (done: number, total: number) => void) => Promise<LensFiles>): AsyncIterable<ForgeLensFrame>;
/** Lens results kept for later requests, at most `maxBytes` of them as JSON, the least recently used dropped first. */
export declare class LensCache {
    private readonly maxBytes;
    private readonly entries;
    private bytes;
    /** @param maxBytes - `maxCachedLensBytes`. */
    constructor(maxBytes: number);
    /**
     * Read a kept result, which becomes the most recently used.
     * @param key - the request's files, lens, and lens version.
     * @returns the result, or undefined when none is kept.
     */
    get(key: string): LensFiles | undefined;
    /**
     * Keep a result no larger than `maxBytes`, replacing one under the same key and dropping the least recently used
     * results until the rest fit.
     * @param key - the request's files, lens, and lens version.
     * @param files - the result.
     */
    set(key: string, files: LensFiles): void;
}
//# sourceMappingURL=lenses.d.ts.map