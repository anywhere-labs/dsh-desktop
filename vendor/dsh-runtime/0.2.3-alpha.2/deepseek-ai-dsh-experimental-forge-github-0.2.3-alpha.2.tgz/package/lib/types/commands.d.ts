/** The GitHub CLI commands that bind pull requests to a Session through forge-session. */
import type { ForgeCommandRule } from '@deepseek-ai/dsh-experimental-forge-session';
/**
 * `gh pr create` prints the pull request it opens; `gh pr view`, `gh pr edit`, and `gh pr checkout` act on the pull
 * request a URL or a number with `--repo`/`-R` selects. A number whose repository names no host takes `GH_HOST` from
 * the command's assignments, else resolves through `gh pr view` in the call's shell. `gh api` binds the pull request its
 * REST path names, such as `repos/octo/demo/pulls/7/files`: directly with `--hostname` or `GH_HOST`, else through
 * `gh pr view`, which for the `{owner}/{repo}` placeholders reads the repository of the current directory.
 */
export declare const GH_COMMANDS: ForgeCommandRule;
//# sourceMappingURL=commands.d.ts.map