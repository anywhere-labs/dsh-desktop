/** Pull request descriptions through GraphQL, with the image addresses a browser can load without a GitHub session. */
import type { ChangeRequestDescription, ChangeRequestRef, ForgeFailure } from '@deepseek-ai/dsh-experimental-forge';
import type { GraphqlReader } from './commits.ts';
/** One pull request's description, its rendered form, and its labels; variables `owner`, `name`, and the integer `number`. */
export declare const DESCRIPTION_QUERY = "query($owner: String!, $name: String!, $number: Int!) {\n  repository(owner: $owner, name: $name) {\n    pullRequest(number: $number) { body bodyHTML createdAt labels(first: 100) { totalCount nodes { name color } } }\n  }\n}";
/**
 * Read a pull request's description. On a private repository an uploaded image's Markdown address answers only with the
 * user's GitHub session, while the rendered description names a short-lived signed address for the same upload; each
 * upload the Markdown names is mapped to its signed address. The rendered description is used for nothing else.
 * @param read - runs one GraphQL request.
 * @param ref - pull request.
 * @param signal - cancellation of the read.
 * @returns the description, or why GitHub did not provide it.
 */
export declare function readDescription(read: GraphqlReader, ref: ChangeRequestRef, signal: AbortSignal): Promise<ChangeRequestDescription | ForgeFailure>;
//# sourceMappingURL=description.d.ts.map