/**
 * Registers the GitHub provider of `ctx.forge`, which reads pull requests through the GitHub CLI on the host, and, while
 * forge-session runs, the `gh` commands that bind pull requests to a Session.
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "forge-github";
export declare const inject: string[];
/** GitHub CLI executable, served hosts, and invocation limits. */
export interface Config {
    /** GitHub CLI executable name or absolute host path. */
    ghCommand?: string;
    /** Host names this provider serves; list GitHub Enterprise hosts explicitly. */
    hosts?: string[];
    /** Deadline in milliseconds for one `gh` invocation. */
    timeoutMs?: number;
    /** Maximum captured bytes per `gh` output stream and combined JSON bytes of one complete check read or review read. */
    maxOutputBytes?: number;
    /**
     * Most review threads counted per pull request in one status read, which reports a lower bound past it, and read in
     * one review read, which reports itself truncated past it.
     */
    maxReviewThreads?: number;
    /**
     * Most pull requests one snapshot query reads. The forge registry polls that many pull requests of a host per call,
     * each call within its own fetch deadline; a read of more pull requests on one host sends several queries in turn.
     */
    snapshotBatchSize?: number;
    /** The same bound for one brief query. */
    briefBatchSize?: number;
    /** Most commits one pull request commit listing returns; GitHub lists at most 250 commits of a pull request. */
    maxCommits?: number;
    /** Most files whose viewed marks one read lists; GitHub lists at most 3,000 files of a pull request. */
    maxViewedFiles?: number;
    /** Most pull requests one viewer list read returns, at most 100, the size of one GitHub search page. */
    maxViewerItems?: number;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map