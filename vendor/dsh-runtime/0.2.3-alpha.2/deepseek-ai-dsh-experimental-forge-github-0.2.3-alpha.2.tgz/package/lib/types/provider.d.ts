/** GitHub implementation of the forge provider contract. */
import type { BranchUpdateRequest, ChangeRequestBrief, ChangeRequestDescription, ChangeRequestKey, ChangeRequestRef, ChangeRequestSnapshot, ForgeActionFailure, ForgeCommitList, ForgeFailure, ForgeViewerCapability, ForgeViewerFilter, ForgeViewerList, ForgeViewerQuery, ForgeProvider, ForgeReadiness, ForgeRepository, ForgeRerunRequest, ForgeReviewData, ForgeReviewerCandidate, ForgeReviewersRequest, ForgeReviewRequest, ForgeReviewResult, ForgeReviewWrite, ForgeReviewWriteResult, ForgeViewedFiles, ForgeViewedRequest, MergeRequest } from '@deepseek-ai/dsh-experimental-forge';
import type { GhRunner } from './gh.ts';
/** Bounds on what one read retains or counts, and on the pull requests one status query reads. */
export interface GitHubLimits {
    /** Maximum combined JSON bytes retained by an explicit check read or a review read. */
    readonly maxOutputBytes: number;
    /** Most review threads counted per pull request in one status read, and read in one review read. */
    readonly maxReviewThreads: number;
    /** Most pull requests one snapshot query reads. */
    readonly snapshotBatchSize: number;
    /** Most pull requests one brief query reads. */
    readonly briefBatchSize: number;
    /** Most commits one commit listing returns. */
    readonly maxCommits: number;
    /** Most files whose viewed marks one read lists. */
    readonly maxViewedFiles: number;
    /** Most pull requests one viewer list read returns, at most GitHub's search page size of 100. */
    readonly maxViewerItems: number;
}
/** Reads GitHub and GitHub Enterprise pull requests through a `gh` runner. */
export declare class GitHubProvider implements ForgeProvider {
    private readonly gh;
    private readonly limits;
    readonly forge = "github";
    readonly hosts: readonly string[];
    readonly label = "GitHub";
    readonly changeRequestNoun = "pull-request";
    readonly viewer: ForgeViewerCapability;
    private readonly served;
    readonly snapshotBatchSize: number;
    readonly briefBatchSize: number;
    submitReview(ref: ChangeRequestRef, request: ForgeReviewRequest, signal: AbortSignal): Promise<ForgeReviewResult>;
    /**
     * Read the review threads of a pull request at `headSha` through GraphQL, each page naming the head it was read at.
     * @see readReviewThreads
     */
    readReview(ref: ChangeRequestRef, headSha: string, signal: AbortSignal): Promise<ForgeReviewData | ForgeFailure>;
    /**
     * Write to the review threads or the pending review of a pull request through GraphQL mutations after a check of its head.
     * @see writeGitHubReview
     */
    writeReview(ref: ChangeRequestRef, write: ForgeReviewWrite, signal: AbortSignal): Promise<ForgeReviewWriteResult>;
    /**
     * @param gh - runner that executes `gh` on the host.
     * @param hosts - host names this provider serves, such as `github.com` and Enterprise hosts.
     * @param limits - bounds on retained check and review bytes, counted and read review threads, pull requests per snapshot
     * query and per brief query, listed commits, listed viewed files, and listed viewer pull requests.
     */
    constructor(gh: GhRunner, hosts: readonly string[], limits: GitHubLimits);
    /**
     * Read one list of the signed-in user's open pull requests through one GraphQL search.
     * @see readViewerList
     * @throws when the limit is not a positive integer no greater than `maxViewerItems`.
     */
    listForViewer(query: ForgeViewerQuery, signal: AbortSignal): Promise<ForgeViewerList | ForgeFailure>;
    /**
     * Count the signed-in user's open pull requests in every list through one GraphQL request.
     * @see countViewerLists
     */
    countForViewer(host: string, signal: AbortSignal): Promise<ReadonlyMap<ForgeViewerFilter, number> | ForgeFailure>;
    /**
     * Read a pull request's description and labels through GraphQL.
     * @see readDescription
     */
    readDescription(ref: ChangeRequestRef, signal: AbortSignal): Promise<ChangeRequestDescription | ForgeFailure>;
    repositoryFromRemote(url: string): ForgeRepository | undefined;
    changeRequestFromUrl(url: string): ChangeRequestRef | undefined;
    changeRequestUrl(ref: ChangeRequestRef): string;
    /**
     * Read snapshots through GraphQL, at most `snapshotBatchSize` pull requests of one host per query, one query after
     * another. Every query is built before the first request. A query whose `gh` run cannot start, times out, or prints
     * over its limit, and one GitHub refuses, fails only its own pull requests.
     * @param refs - pull requests to read.
     * @param signal - cancellation of the whole read.
     * @returns one result for each pull request in `refs`.
     * @throws with `signal.reason` once cancelled, without another request, and before any request when a reference
     * cannot be inlined.
     */
    fetch(refs: readonly ChangeRequestRef[], signal: AbortSignal): Promise<ReadonlyMap<ChangeRequestKey, ChangeRequestSnapshot | ForgeFailure>>;
    /**
     * Read briefs through GraphQL, at most `briefBatchSize` pull requests of one host per query, one query after
     * another. Every query is built before the first request. A query whose `gh` run cannot start, times out, or prints
     * over its limit, and one GitHub refuses, fails only its own pull requests.
     * @param refs - pull requests to read.
     * @param signal - cancellation of the whole read.
     * @returns one result for each pull request in `refs`.
     * @throws with `signal.reason` once cancelled, without another request, and before any request when a reference
     * cannot be inlined.
     */
    fetchBriefs(refs: readonly ChangeRequestRef[], signal: AbortSignal): Promise<ReadonlyMap<ChangeRequestKey, ChangeRequestBrief | ForgeFailure>>;
    fetchChecks(ref: ChangeRequestRef, signal: AbortSignal): Promise<ChangeRequestSnapshot | ForgeFailure>;
    findByHead(repository: ForgeRepository, branch: string, signal: AbortSignal): Promise<readonly ChangeRequestRef[]>;
    /**
     * Mark a draft pull request ready for review with `gh pr ready`; one that
     * is already ready stays ready.
     */
    markReady(ref: ChangeRequestRef, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * Merge a pull request through the REST merge endpoint with the expected
     * head commit, so GitHub refuses with 409 once new commits arrived. Unlike
     * `gh pr merge`, it never enables auto-merge, never joins a merge queue, and
     * never deletes the head branch.
     */
    merge(ref: ChangeRequestRef, request: MergeRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * Read the pull request's diff at `headSha`. One GraphQL read names the
     * current head and the base commit GitHub recorded with it; a head other
     * than `headSha` returns `stale`. Otherwise the compare endpoint reads the
     * patch from the merge base of that base commit and `headSha`, as the pull
     * request's own diff does, with both ends fixed. Given the `base` the latest
     * status recorded with `headSha`, the comparison from it runs while the
     * GraphQL read confirms the head; a stale head or another base commit
     * cancels that comparison and waits for it to end before the read returns.
     */
    diff(ref: ChangeRequestRef, headSha: string, signal: AbortSignal, base?: string): Promise<string | ForgeFailure>;
    /** Read one file at a commit through the contents API in its raw form. */
    fileText(ref: ChangeRequestRef, commit: string, path: string, signal: AbortSignal): Promise<string | ForgeFailure>;
    /** List the pull request's commits through GraphQL, at most `maxCommits`, all read at one head. */
    commits(ref: ChangeRequestRef, signal: AbortSignal): Promise<ForgeCommitList | ForgeFailure>;
    /** Read the changes between two commits through the compare API in its diff form. */
    compare(ref: ChangeRequestRef, base: string, head: string, signal: AbortSignal): Promise<string | ForgeFailure>;
    /**
     * Find the merge base through the compare API. The request names the second page of one commit per page, which
     * carries the merge base but not the changed files GitHub lists only on the first page.
     */
    mergeBase(ref: ChangeRequestRef, base: string, head: string, signal: AbortSignal): Promise<string | ForgeFailure>;
    /** Read the viewer's viewed marks through GraphQL, at most `maxViewedFiles`, every page at `headSha`. */
    viewedFiles(ref: ChangeRequestRef, headSha: string, signal: AbortSignal): Promise<ForgeViewedFiles | ForgeFailure>;
    /** Set or clear the viewer's mark with `markFileAsViewed` or `unmarkFileAsViewed` after confirming the head. */
    setViewed(ref: ChangeRequestRef, request: ForgeViewedRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * Rerun every finished workflow run with a failed GitHub Actions job on the head commit through the REST API; GitHub
     * reruns its failed jobs with the jobs that depend on them. A run with a check still pending waits, as GitHub offers
     * no rerun of a run in progress. Every eligible run is tried, and a refusal of one is reported with the others' outcome.
     * Other checks name no rerun.
     */
    rerunChecks(ref: ChangeRequestRef, request: ForgeRerunRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    requestReviews(ref: ChangeRequestRef, request: ForgeReviewersRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    reviewerCandidates(ref: ChangeRequestRef, query: string, signal: AbortSignal): Promise<readonly ForgeReviewerCandidate[] | ForgeFailure>;
    updateBranch(ref: ChangeRequestRef, request: BranchUpdateRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    fileUrl(ref: ChangeRequestRef, commit: string, path: string): string;
    readiness(host: string, signal: AbortSignal): Promise<ForgeReadiness>;
    /**
     * Run one reading `gh` command, returning its output. A refusal, a `gh` that
     * cannot start, output over `maxOutputBytes`, and a run past `timeoutMs` become failures.
     */
    private read;
    /** Run one GraphQL request; a refusal, a body that is not GraphQL, and GraphQL errors become failures. */
    private readonly graphql;
    /**
     * Run one GraphQL mutation through {@link sendMutation}, which never retries it: a refusal or a `gh` that cannot
     * start is `failed`, and an answer that does not confirm the outcome is `unknown`.
     */
    private readonly mutate;
    /** Run one changing `gh` command; a refusal or a `gh` that cannot start becomes a failure. */
    private act;
    /** Run one `gh` command; a `gh` that cannot start resolves to its error, and every other rejection passes on. */
    private attempt;
    private hostFailure;
    /**
     * Build the queries of a status read: pull requests grouped by host in the order given, at most `size` per query.
     * @param refs - pull requests to read.
     * @param results - receives the failure of each pull request on a host this provider does not serve.
     * @param size - most pull requests in one query.
     * @param build - builds the query of consecutive pull requests on one host.
     * @returns every query with its host, in request order.
     * @throws what `build` throws for a reference that cannot be inlined.
     */
    private statusQueries;
    /**
     * Read one snapshot query and the continuation pages of its pull requests.
     * @param host - host the query reads from.
     * @param query - the query and its alias targets.
     * @param signal - cancellation of the read.
     * @param completeChecks - whether to follow every check page within one `maxOutputBytes` budget.
     * @returns one result for each alias target: the same failure for all of them when the `gh` run of the query cannot
     * start, times out, or prints over its limit, and when GitHub refuses the query.
     * @throws with `signal.reason` when the read is cancelled.
     */
    private fetchSnapshots;
    /**
     * Run one GraphQL request of a status read: a snapshot query, a brief query, or a continuation page.
     * @param host - host the status is read from.
     * @param variables - `gh api graphql` field flags, the query first.
     * @param signal - cancellation of the status read.
     * @returns the output, or the failure of a `gh` that cannot start, times out, or prints over its limit.
     * @throws with `signal.reason` when the read is cancelled.
     */
    private statusOutput;
}
//# sourceMappingURL=provider.d.ts.map