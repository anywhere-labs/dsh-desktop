/** Lists of the signed-in user's open pull requests through the GitHub GraphQL search. */
import type { ForgeFailure, ForgeViewerFilter, ForgeViewerList, ForgeViewerQuery } from '@deepseek-ai/dsh-experimental-forge';
import type { GraphqlReader } from './commits.ts';
/** The lists GitHub search reads, each the same search the GitHub pull request page offers. */
export declare const VIEWER_FILTERS: ReadonlySet<ForgeViewerFilter>;
/** One page of one list with the signed-in user; variables `q` and the integer `first`. */
export declare const VIEWER_LIST_QUERY = "query($q: String!, $first: Int!) {\n  viewer { login }\n  search(type: ISSUE, query: $q, first: $first) { issueCount nodes { __typename ... on PullRequest { number title url isDraft updatedAt headRefOid reviewDecision\n  repository { name owner { login } }\n  author { __typename login avatarUrl }\n  commits(last: 1) { nodes { commit { statusCheckRollup { state } } } }\n  viewerLatestReview { state commit { oid } }\n  viewerLatestReviewRequest { requestedReviewer { __typename ... on Team { combinedSlug } } }\n  closingIssuesReferences(first: 3) { totalCount nodes { number title state url repository { name owner { login } } } } } } }\n}";
/** The size of every list in one request; variables `review`, `authored`, and `involved`. */
export declare const VIEWER_COUNT_QUERY = "query($review: String!, $authored: String!, $involved: String!) {\n  review: search(type: ISSUE, query: $review, first: 0) { issueCount }\n  authored: search(type: ISSUE, query: $authored, first: 0) { issueCount }\n  involved: search(type: ISSUE, query: $involved, first: 0) { issueCount }\n}";
/**
 * Build the search text of one list.
 * @param filter - the list.
 * @param repository - one repository to search in, or null for every repository the user can read.
 * @returns the search text, most recently updated first, or undefined for a repository whose owner or name cannot be
 * a search qualifier.
 */
export declare function searchText(filter: ForgeViewerFilter, repository: ForgeViewerQuery['repository']): string | undefined;
/**
 * Read one list through one search request: GitHub answers a search of several lists in one document with a gateway
 * error, so every list is its own request. A search result that is not a pull request, or names a repository this
 * provider cannot address, is left out.
 * @param read - runs one GraphQL request.
 * @param query - host, list, repository, and a limit the caller already bounded.
 * @param signal - cancellation of the read.
 * @returns the list, or why GitHub did not provide it.
 */
export declare function readViewerList(read: GraphqlReader, query: ForgeViewerQuery, signal: AbortSignal): Promise<ForgeViewerList | ForgeFailure>;
/**
 * Count every list on one host in one request.
 * @param read - runs one GraphQL request.
 * @param host - host to count on.
 * @param signal - cancellation of the read.
 * @returns the size of each list, or why GitHub did not provide them.
 */
export declare function countViewerLists(read: GraphqlReader, host: string, signal: AbortSignal): Promise<ReadonlyMap<ForgeViewerFilter, number> | ForgeFailure>;
//# sourceMappingURL=viewer.d.ts.map