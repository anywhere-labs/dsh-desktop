/**
 * Projection that folds shell results, program shell dispatches, and binding records into one Session's change request
 * bindings with the registered command rules.
 */
import type { ProjectionDefinition } from '@deepseek-ai/dsh-session-projection';
import type { CommandRules } from './commands.ts';
import type { ForgeChangeRequestsState } from './types.ts';
/** The `forgeChangeRequests` projection definition, with the client view its Session summary carries. */
type ForgeChangeRequestsDefinition = ProjectionDefinition<'forgeChangeRequests', ForgeChangeRequestsState> & {
    readonly wire: NonNullable<ProjectionDefinition<'forgeChangeRequests', ForgeChangeRequestsState>['wire']>;
};
/** Plugin record type of binding actions. */
export declare const BINDING_RECORD = "plugin:forge-session/binding";
/**
 * The `forgeChangeRequests` unit for one rule set. A `bash` or `pwsh` call whose command runs a rule's create or
 * reference subcommand, or `git push`, stays pending until its first result. A successful result binds every change
 * request URL of a matched rule that a creation prints; for a reference it binds the URL the command names and the URL
 * the output prints for its own change request; and it records the branches it reports as pushed. A
 * `tool/ptc-dispatch` event of a `bash` or `pwsh` call inside a program carries the arguments and the settled outcome
 * together, so it applies the same rules without a pending entry. Before parsing, the raw JSON arguments must contain a
 * rule's executable or `push`, so a command spelled only through JSON escapes is not recognized. Failed tool executions
 * bind nothing; a nonzero exit status does not matter, because the URL or ref line is the evidence. `turn/end` drops
 * calls that never received a result. Binding records bind, restore, and hide URLs. Clients, including the Session
 * summary, see the bindings; the array keeps its reference while only pending calls and pushes change. The state
 * version comes from the rule set, so a checkpoint folded with other rules is discarded and the log folds again.
 * @param rules - the registered command rules.
 * @returns the projection definition.
 */
export declare function forgeChangeRequestsProjection(rules: CommandRules): ForgeChangeRequestsDefinition;
export {};
//# sourceMappingURL=projection.d.ts.map