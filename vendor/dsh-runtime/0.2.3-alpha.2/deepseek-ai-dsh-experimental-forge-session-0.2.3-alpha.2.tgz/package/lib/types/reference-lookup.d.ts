/** Resolve unqualified CLI references in the shell execution world and persist only confirmed URLs. */
import type { Context } from '@deepseek-ai/cordis';
import type { Session } from '@deepseek-ai/dsh-session';
import type { CommandRules } from './commands.ts';
/**
 * Observe completed foreground Bash calls while tools and shell services exist.
 * Queries use the same shell service, cwd, managed environment, and standing
 * sandbox policy as the call. A call inside a program, which carries a
 * `parent` token, queues its query until the root call that encloses it
 * settles, so the query runs under that root call's cancellation after the
 * program's dispatch events are logged. Failed lookups leave bindings
 * unchanged and log a warning. Cancellation leaves bindings unchanged;
 * disposal aborts and awaits all queries. Replay performs no lookup.
 * @param ctx - owning plugin context.
 * @param timeoutMs - shell deadline for one read-only lookup.
 * @param rules - the current compiled command rules.
 * @param record - persists a confirmed URL without restoring dismissed bindings.
 */
export declare function observeReferences(ctx: Context, timeoutMs: number, rules: () => CommandRules, record: (session: Session, url: string) => void): void;
//# sourceMappingURL=reference-lookup.d.ts.map