/**
 * One-shot OAR execution, root-answer selection, and owned session disposal.
 * Native records remain in OAR; DSH receives assistant text and fixed failure facts.
 *
 * @module @deepseek-ai/dsh-experimental-subagent-oar/run
 */
import type { Runtime } from '@botiverse/oar';
import { HarnessError } from '@deepseek-ai/dsh-error';
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import { type ResolvedSubagentStartRequest, type SubagentRun, type SubagentStopReason } from '@deepseek-ai/dsh-subagent';
/** Resolved deployment settings and the runtime owned by one provider instance. */
export interface OarRunSpec {
    /** Selected OAR runtime; installation is probed for each delegation. */
    readonly runtime: Runtime;
    /** Native model id; omitted to preserve native settings. */
    readonly model?: string;
    /** Native reasoning effort; unsupported choices fail at startup. */
    readonly effort?: string;
    /** Explicit environment applied after the shared credential scrub. */
    readonly env: Readonly<Record<string, string | null>>;
    /** Native process arguments; OAR validates arguments it owns. */
    readonly launchArgs: readonly string[];
    /** Optional turn deadline in milliseconds; excludes OAR session startup. */
    readonly timeoutMs?: number;
    /** Receives safe summaries; native causes are retained for debugging and can contain secrets. */
    readonly onError?: (error: Error, stopReason: SubagentStopReason) => void;
}
/**
 * Every {@link OarFailure} code:
 * - `OAR_INVALID_TASK` — the task is empty or contains a non-text block; send one non-empty text task.
 * - `OAR_RUNTIME_UNAVAILABLE` — the selected runtime is unsupported, not installed, or its installation probe failed;
 *   install and authenticate it before retrying.
 * - `OAR_START_FAILED` — the runtime could not open or publish a session; check its installation, authentication, and launch settings.
 * - `OAR_TURN_FAILED` — the native turn failed or was rejected; check the runtime and its account before retrying.
 * - `OAR_ABORT_FAILED` — the runtime did not accept interruption; session disposal was requested.
 * - `OAR_DISPOSE_FAILED` — session disposal failed and the runtime may still be active; check it before starting another task.
 */
export declare const OAR_FAILURE_CODES: readonly ["OAR_INVALID_TASK", "OAR_RUNTIME_UNAVAILABLE", "OAR_START_FAILED", "OAR_TURN_FAILED", "OAR_ABORT_FAILED", "OAR_DISPOSE_FAILED"];
/** One code from {@link OAR_FAILURE_CODES}. */
export type OarFailureCode = typeof OAR_FAILURE_CODES[number];
/** OAR delegation failure carrying a stable {@link OarFailureCode}; native causes stay in `cause` and can contain secrets. */
export declare class OarFailure extends HarnessError {
    readonly code: OarFailureCode;
    /**
     * @param message - safe summary without native detail.
     * @param code - failure class.
     * @param options - native cause, retained for local debugging.
     */
    constructor(message: string, code: OarFailureCode, options?: ErrorOptions);
}
/**
 * Validate one text task before opening a native session.
 * @param prompt - content supplied by the shared subagent service.
 * @returns the text blocks in their original order, without inserted separators.
 * @throws {OarFailure} `OAR_INVALID_TASK` when the task is empty or contains a non-text block.
 */
export declare function textTask(prompt: readonly ContentBlock[]): string;
/**
 * Open one OAR session and return a one-shot DSH run. OAR cannot interrupt session
 * startup; cancellation during that await disposes the returned session before rejection.
 * @param request - text task, resolved child directory, parent, and cancellation signal.
 * @param spec - selected runtime, native settings, deadline, and safe diagnostic observer.
 * @returns the run after native session creation; post-publication failures settle through result.
 */
export declare function startOarRun(request: ResolvedSubagentStartRequest, spec: OarRunSpec): Promise<SubagentRun>;
//# sourceMappingURL=run.d.ts.map