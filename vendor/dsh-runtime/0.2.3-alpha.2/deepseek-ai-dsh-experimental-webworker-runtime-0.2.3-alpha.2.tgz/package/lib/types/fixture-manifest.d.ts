/** Browser-readable catalog of built-in Preview filesystem overlays. */
/** Manifest format version emitted beside the base VFS image. */
export declare const PREVIEW_FIXTURE_MANIFEST_VERSION = 1;
/** Leaf name resolved beside the base image. */
export declare const PREVIEW_FIXTURE_MANIFEST_FILE = "fixtures.json";
/** One selectable built-in fixture and its ordered overlay archives. */
export interface PreviewFixtureManifestEntry {
    readonly id: string;
    readonly label: string;
    readonly description: string;
    readonly overlays: readonly string[];
}
/** A page the source chooser links to, such as a report published beside the Preview. */
export interface PreviewLink {
    readonly label: string;
    /** URL resolved against the manifest URL; one that resolves to another origin is rejected. */
    readonly href: string;
}
/** Complete built-in fixture catalog consumed before Worker startup. */
export interface PreviewFixtureManifest {
    readonly version: number;
    /** Required default fixture id, or null when the chooser should default to an empty overlay. */
    readonly defaultFixture: string | null;
    readonly fixtures: readonly PreviewFixtureManifestEntry[];
    /** Links shown on the source chooser; the parser reads an absent list as empty. */
    readonly links: readonly PreviewLink[];
}
/**
 * Validate the static fixture catalog before it controls Worker fetches.
 * @param value - Parsed JSON response.
 * @returns A detached manifest with unique ids, non-empty overlay lists, and relative links.
 */
export declare function parsePreviewFixtureManifest(value: unknown): PreviewFixtureManifest;
//# sourceMappingURL=fixture-manifest.d.ts.map