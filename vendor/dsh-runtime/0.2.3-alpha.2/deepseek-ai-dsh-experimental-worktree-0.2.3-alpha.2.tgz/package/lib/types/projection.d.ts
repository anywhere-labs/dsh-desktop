/**
 * The `worktree` projection: every checkout this service recorded creating for a Session, which of them the
 * Session created itself, and the existing checkouts it entered.
 */
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import { z } from 'zod';
import type { CreatedWorktree, EnteredWorktree, WorktreeCreation } from './types.ts';
/** Plugin record type of a checkout this service created for the Session, written after the Session entered it. */
export declare const CREATED_RECORD = "plugin:worktree/created";
/** Plugin record type of an existing checkout the Session entered, written after the Session entered it. */
export declare const ENTERED_RECORD = "plugin:worktree/entered";
declare module '@deepseek-ai/dsh-session/types' {
    interface PluginRecordMap {
        /** A checkout the worktree service created for the Session, which entered it in the same operation. */
        'plugin:worktree/created': CreatedWorktree;
        /** An existing checkout the Session entered, and the checkout it entered from. */
        'plugin:worktree/entered': EnteredWorktree;
    }
}
declare module '@deepseek-ai/dsh-session-projection/types' {
    interface SessionProjectionMap {
        /** Checkouts recorded in the Session's log, in creation order. */
        worktree: readonly WorktreeCreation[];
    }
}
/**
 * Host state of the `worktree` unit: creations so far, the fork boundary that decides ownership, and the
 * entered checkouts, one entry per directory.
 */
export interface WorktreeProjectionState {
    readonly created: readonly WorktreeCreation[];
    readonly entered: readonly EnteredWorktree[];
    readonly inheritedEventCount: number;
}
/** Validates a `plugin:worktree/created` payload; a reader of the record applies it before trusting the data. */
export declare const createdWorktreeSchema: z.ZodType<CreatedWorktree>;
/**
 * Fold `plugin:worktree/created` and `plugin:worktree/entered` records; a
 * record whose payload fails validation is skipped, as a restored record
 * carries whatever an earlier build wrote. A creation whose seq lies inside
 * the fork-inherited prefix is a reference the fork carries, not a checkout it
 * created, so `owned` is false there and true for the Session's own records.
 * A later entry of one directory replaces the earlier one, so the entered
 * list grows with the directories entered, not with the entries.
 */
export declare const worktreeProjection: {
    key: "worktree";
    stateVersion: number;
    stateSchema: z.ZodType<WorktreeProjectionState, unknown, z.core.$ZodTypeInternals<WorktreeProjectionState, unknown>>;
    init: (_header: import("@deepseek-ai/dsh-session").SessionHeader, inheritedEventCount: import("@deepseek-ai/dsh-session").SessionLogOffset) => {
        created: never[];
        entered: never[];
        inheritedEventCount: import("@deepseek-ai/dsh-session").SessionLogOffset;
    };
    apply: (state: NoInfer<WorktreeProjectionState>, event: SessionEvent) => WorktreeProjectionState;
    wire: {
        viewSchema: z.ZodArray<z.ZodType<WorktreeCreation, unknown, z.core.$ZodTypeInternals<WorktreeCreation, unknown>>>;
        view: (state: NoInfer<WorktreeProjectionState>) => readonly WorktreeCreation[];
    };
};
//# sourceMappingURL=projection.d.ts.map