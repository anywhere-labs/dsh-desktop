/** Check, connection, and sign-out of the CLI's default Feishu account, as the operations `ctx.cliAccounts` runs. */
import type { CliOperationControl } from '@deepseek-ai/dsh-cli-account/types';
import type { FeishuAccountState, FeishuCommand, FeishuOperationKind, FeishuPhase } from './types.ts';
type Control = CliOperationControl<FeishuAccountState, FeishuPhase, FeishuCommand>;
/**
 * Carry out one account operation with lark-cli and publish the account each check observes.
 * @param kind - the requested operation.
 * @param control - phase changes, link offers, command runs, and account updates for this operation.
 * @param signal - aborts on cancellation and when the plugin unloads.
 * @returns after the operation finishes.
 * @throws when a command fails, its output is not the expected JSON, or the account it leaves is not the one the
 *   operation set out to reach.
 */
export declare function perform(kind: FeishuOperationKind, control: Control, signal: AbortSignal): Promise<void>;
export {};
//# sourceMappingURL=account.d.ts.map