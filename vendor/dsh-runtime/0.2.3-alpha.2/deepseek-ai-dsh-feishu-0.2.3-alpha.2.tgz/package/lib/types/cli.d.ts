/** Managed lark-cli location and the JSON output of its commands. */
/** The name lark-cli's guides run it by. */
export declare const PROGRAM = "lark-cli";
/**
 * Name the executable file as `@larksuite/cli` installs it.
 * @param platform - the Host platform.
 * @returns `lark-cli`, or `lark-cli.exe` on Windows.
 */
export declare function executableFileName(platform: NodeJS.Platform): string;
/**
 * Locate the managed executable.
 * @param binDir - absolute override; defaults to the installed `@larksuite/cli` package.
 * @returns the absolute path of the executable `lark-cli`, `lark-cli.exe` on Windows.
 * @throws when the executable is missing.
 */
export declare function resolveCliExecutable(binDir: string | undefined): string;
/**
 * Parse one command's JSON output.
 * @param args - the command's native arguments, for the error message.
 * @param output - the complete stream the command wrote the JSON to.
 * @returns unvalidated JSON for the caller to check.
 * @throws when the output is not JSON.
 */
export declare function parseJson(args: readonly string[], output: string): unknown;
//# sourceMappingURL=cli.d.ts.map