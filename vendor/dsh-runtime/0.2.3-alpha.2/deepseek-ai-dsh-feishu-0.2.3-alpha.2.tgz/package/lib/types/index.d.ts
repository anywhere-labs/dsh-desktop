/**
 * Feishu plugin: registers the managed lark-cli and its account with `ctx.cliAccounts`, which tells the model the CLI's
 * absolute path and shows the account on the Plugins page, and lists the packaged `feishu` skill that indexes the
 * guides embedded in that CLI. The CLI's default account is shared with the user's own terminal.
 * @module @deepseek-ai/dsh-feishu
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
/** Plugin name. */
export declare const name = "feishu";
/** Services the CLI's account and its skill register with. */
export declare const inject: string[];
/** Where lark-cli is. */
export interface Config {
    /** Absolute directory holding the `lark-cli` executable; defaults to the installed `@larksuite/cli` package. */
    binDir?: string;
}
/** Validates {@link Config}. */
export declare const Config: z<Config>;
/**
 * Register the CLI with its account, and the skill.
 * @param ctx - Context carrying the CLI account Service and the skill registry.
 * @param config - CLI location.
 * @throws when `lark-cli` is not executable, or the packaged entry skill has no name or description.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map