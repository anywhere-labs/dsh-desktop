/** The Feishu account section the Plugins page shows for each Host view. */
import type { CliAccountText } from '@deepseek-ai/dsh-cli-account/types';
import type { ConnectorAccountCopy, ConnectorAccountDisplay, ConnectorAccountOperation } from '@deepseek-ai/dsh-client-ui-connector-account/types';
import type { FeishuTextKey } from './locales.ts';
import type { FeishuOperationKind, FeishuState } from './types.ts';
type Text = CliAccountText<FeishuTextKey>;
/** The npm package whose bundle page carries the account section. */
export declare const FEISHU_PACKAGE = "@deepseek-ai/dsh-feishu";
/**
 * List the operations the section's buttons start; each but a check reports a notice in the browser that started it.
 * @param text - writes a key of the Feishu text in every shipped language.
 * @returns the operations with their notices.
 */
export declare function operations(text: Text): readonly ConnectorAccountOperation<FeishuOperationKind>[];
/**
 * Write the section's title and hint, and the prompt after the bundle is switched on while disconnected.
 * @param text - writes a key of the Feishu text in every shipped language.
 * @returns the section's fixed text.
 */
export declare function copy(text: Text): ConnectorAccountCopy;
/**
 * The account section for one Host view.
 * @param view - the CLI's default account, the operation in progress, and the last result.
 * @param text - writes a key of the Feishu text in every shipped language.
 * @returns the phase, status, tag, buttons, detail, linked-app row, and failure guidance.
 */
export declare function presentAccount(view: FeishuState, text: Text): ConnectorAccountDisplay;
export {};
//# sourceMappingURL=presentation.d.ts.map