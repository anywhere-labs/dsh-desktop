/** The packaged `feishu` entry skill: the DSH guidance, the index of the guides embedded in lark-cli, and how to open them. */
import type { SkillCandidate, SkillDefinition, SkillProvider } from '@deepseek-ai/dsh-skill';
/** Lists the packaged entry without running lark-cli; the entry is read once, when the plugin loads. */
export declare class FeishuSkillProvider implements SkillProvider {
    readonly name = "feishu";
    private readonly candidate;
    private readonly content;
    /**
     * @param entry - absolute path of the packaged `SKILL.md`, whose frontmatter gives the skill's name and description.
     * @throws when the entry has no YAML frontmatter, or its frontmatter has no skill name or no description.
     */
    constructor(entry: string);
    list(): Promise<SkillCandidate[]>;
    get(): Promise<SkillDefinition>;
}
//# sourceMappingURL=skills.d.ts.map