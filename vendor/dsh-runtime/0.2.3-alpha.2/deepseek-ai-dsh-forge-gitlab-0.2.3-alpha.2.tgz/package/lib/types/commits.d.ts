/** The commits of a merge request through the REST commit listing, oldest first. */
import type { ChangeRequestRef, ForgeCommitList, ForgeFailure } from '@deepseek-ai/dsh-experimental-forge';
import type { GitLabApi } from './api.ts';
/**
 * List a merge request's commits at its current head, at most `limit` of them. GitLab lists them newest first with the
 * total in `X-Total`, so a longer list reads the pages that hold the oldest `limit` commits.
 * @param api - GitLab reads.
 * @param ref - merge request.
 * @param limit - the most commits to list.
 * @param signal - cancellation of the read.
 * @returns the commits oldest first, the oldest `limit` when there are more, or why GitLab did not list them.
 */
export declare function readCommits(api: GitLabApi, ref: ChangeRequestRef, limit: number, signal: AbortSignal): Promise<ForgeCommitList | ForgeFailure>;
//# sourceMappingURL=commits.d.ts.map