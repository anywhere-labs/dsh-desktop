/** Merge request patches pinned to one head through MR diff versions, and comparisons of two commits. */
import type { ChangeRequestRef, ForgeFailure } from '@deepseek-ai/dsh-experimental-forge';
import { z } from 'zod';
import type { GitLabApi } from './api.ts';
/**
 * Check a commit object name before it is inlined into a request.
 * @param value - candidate object name.
 * @returns whether it is a full 40- or 64-digit hexadecimal commit.
 */
export declare function isCommit(value: string): boolean;
declare const versionSchema: z.ZodObject<{
    id: z.ZodNumber;
    head_commit_sha: z.ZodString;
    base_commit_sha: z.ZodString;
    start_commit_sha: z.ZodString;
    real_size: z.ZodOptional<z.ZodNullable<z.ZodString>>;
}, z.core.$strip>;
/** One MR diff version: the head, merge base, and target tip GitLab recorded for one push. */
export type DiffVersion = z.infer<typeof versionSchema>;
/** Reads the text of a file at a commit, for files whose diff GitLab left out. */
export type ReadText = (commit: string, path: string) => Promise<string | ForgeFailure>;
/**
 * Find the newest diff version of a merge request and check that it is at `headSha`. GitLab records a version for
 * every push, so the newest version's head is the merge request's head once GitLab has processed the push.
 * @param api - GitLab reads.
 * @param ref - merge request.
 * @param headSha - head commit the caller expects.
 * @param signal - cancellation of the read.
 * @returns the version, `stale` when the newest version is at another head, or the read's failure.
 */
export declare function newestVersion(api: GitLabApi, ref: ChangeRequestRef, headSha: string, signal: AbortSignal): Promise<DiffVersion | ForgeFailure>;
/**
 * Read the patch of one diff version, the changes from its merge base to its head.
 * @param api - GitLab reads.
 * @param ref - merge request.
 * @param version - the version.
 * @param readText - reads a file whose diff GitLab collapsed.
 * @param signal - cancellation of the read.
 * @returns the unified patch with `a/` and `b/` prefixes, or why it could not be read; a version over GitLab's file
 * limit, whose `real_size` ends in `+`, is `too-large`.
 */
export declare function versionPatch(api: GitLabApi, ref: ChangeRequestRef, version: DiffVersion, readText: ReadText, signal: AbortSignal): Promise<string | ForgeFailure>;
/**
 * Read the changes from commit `base` to commit `head` in the merge request's project.
 * @param api - GitLab reads.
 * @param ref - merge request whose project holds both commits.
 * @param base - full object name of the older commit.
 * @param head - full object name of the newer commit.
 * @param readText - reads a file whose diff GitLab collapsed.
 * @param signal - cancellation of the read.
 * @returns the unified patch, or why it could not be read; a comparison GitLab stopped for time is `too-large`.
 */
export declare function comparePatch(api: GitLabApi, ref: ChangeRequestRef, base: string, head: string, readText: ReadText, signal: AbortSignal): Promise<string | ForgeFailure>;
/** One changed file of a diff version with its diff, which GitLab's own diff or a comparison of its texts supplies. */
export interface VersionFileDiff {
    readonly oldPath: string;
    readonly newPath: string;
    /** Unified diff of the file, with `---` and `+++` lines when it was compared from the texts. */
    readonly diff: string;
}
/**
 * Read the changed files of one diff version with the diff of each, comparing a file GitLab collapsed or found too large
 * from its texts at the version's merge base and head.
 * @param api - GitLab reads.
 * @param ref - merge request.
 * @param version - id of the diff version.
 * @param readText - reads a file whose diff GitLab collapsed.
 * @param signal - cancellation of the read.
 * @returns the files in GitLab's order, or undefined when GitLab did not list them or a file's text could not be read.
 */
export declare function versionFileDiffs(api: GitLabApi, ref: ChangeRequestRef, version: number, readText: ReadText, signal: AbortSignal): Promise<VersionFileDiff[] | undefined>;
/**
 * Compare two texts as the `---`, `+++`, and hunk lines of a patch with three lines of context.
 * @param oldName - old side's name, such as `a/<path>` or `/dev/null`.
 * @param newName - new side's name.
 * @param before - old text.
 * @param after - new text.
 * @returns the patch lines, ending with a newline.
 */
export declare function textPatch(oldName: string, newName: string, before: string, after: string): string;
/**
 * Read the merge base of two commits in the merge request's project.
 * @param api - GitLab reads.
 * @param ref - merge request whose project holds both commits.
 * @param base - full object name of one commit.
 * @param head - full object name of the other.
 * @param signal - cancellation of the read.
 * @returns the merge base's full object name, or why GitLab did not name one.
 */
export declare function mergeBaseOf(api: GitLabApi, ref: ChangeRequestRef, base: string, head: string, signal: AbortSignal): Promise<string | ForgeFailure>;
/**
 * Read the text of a file at a commit.
 * @param api - GitLab reads.
 * @param ref - merge request whose project holds the file.
 * @param commit - full object name of the commit.
 * @param path - repository-relative path.
 * @param signal - cancellation of the read.
 * @returns the text, or why GitLab did not return it.
 */
export declare function fileTextOf(api: GitLabApi, ref: ChangeRequestRef, commit: string, path: string, signal: AbortSignal): Promise<string | ForgeFailure>;
export {};
//# sourceMappingURL=diff.d.ts.map