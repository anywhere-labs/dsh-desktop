/**
 * Registers the GitLab provider of `ctx.forge`, which reads merge requests through the GitLab CLI on the host, and,
 * while forge-session runs, the `glab` commands that bind merge requests to a Session.
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "forge-gitlab";
export declare const inject: string[];
/** GitLab CLI executable, served hosts, and read limits. */
export interface Config {
    /** GitLab CLI executable name or absolute host path. */
    glabCommand?: string;
    /** Host names this provider serves; list self-managed GitLab hosts explicitly. */
    hosts?: string[];
    /** Deadline in milliseconds for one `glab` invocation. */
    timeoutMs?: number;
    /** Maximum captured bytes per `glab` output stream and combined JSON bytes of one complete check read or review read. */
    maxOutputBytes?: number;
    /** Most review threads one review read returns, which reports itself truncated past it. */
    maxReviewThreads?: number;
    /** Most commits one merge request commit listing returns, the oldest ones when there are more. */
    maxCommits?: number;
    /** Most merge requests one status query reads; GitLab refuses a query over its complexity limit, which halves the batch. */
    statusBatchSize?: number;
    /** Most `glab` processes one status fetch runs at once. */
    maxConcurrentRequests?: number;
    /** Most bytes of diff version patches kept in memory for the hunks of outdated review threads. */
    maxCachedVersionBytes?: number;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map