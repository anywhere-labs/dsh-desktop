/** Bounded concurrency for independent GitLab reads. */
/**
 * Run `task` on every item, at most `limit` at a time.
 * @param items - work items.
 * @param limit - most concurrent tasks.
 * @param task - work for one item.
 * @returns settles once every task settled, so no task outlives a rejection; rejects with the first rejection.
 */
export declare function pool<T>(items: readonly T[], limit: number, task: (item: T) => Promise<void>): Promise<void>;
//# sourceMappingURL=pool.d.ts.map