/** Diff note positions on the lines of one file of a GitLab merge request diff version. */
import type { ForgeLineComment } from '@deepseek-ai/dsh-experimental-forge';
/** One changed file of a diff version. */
export interface VersionFile {
    /** Path on the old side. */
    readonly oldPath: string;
    /** Path on the new side. */
    readonly newPath: string;
    /** Unified diff of the file, with or without its `---` and `+++` lines. */
    readonly diff: string;
}
/** The commits of the diff version a position addresses. */
export interface PositionVersion {
    /** Merge base the version's diff starts at. */
    readonly base: string;
    /** Target branch tip GitLab recorded with the version. */
    readonly start: string;
    /** Head the version's diff ends at. */
    readonly head: string;
}
/**
 * Build the `position` of a diff note on the lines of a comment. GitLab places a note only on a line whose numbers on
 * both sides it can match: an added line names its new line, a deleted line its old line, and a line both sides hold
 * names both, inside or outside the file's hunks. A range is the position of its last line with a `line_range` from its
 * first line to its last, each with GitLab's line code.
 * @param version - the commits of the diff version the comment addresses.
 * @param file - the commented file's diff in that version.
 * @param comment - the comment's side and lines.
 * @returns the position, or undefined when the diff does not hold the lines on that side or cannot be parsed.
 */
export declare function textPosition(version: PositionVersion, file: VersionFile, comment: ForgeLineComment): Record<string, unknown> | undefined;
//# sourceMappingURL=position.d.ts.map