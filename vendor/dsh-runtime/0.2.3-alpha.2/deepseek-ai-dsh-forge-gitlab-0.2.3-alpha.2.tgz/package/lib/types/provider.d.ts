/** GitLab implementation of the forge provider contract, read and written through the GitLab CLI on the host. */
import type { BranchUpdateRequest, ChangeRequestKey, ChangeRequestRef, ChangeRequestSnapshot, ForgeActionFailure, ForgeCommitList, ForgeFailure, ForgeProvider, ForgeReadiness, ForgeRepository, ForgeRerunRequest, ForgeReviewData, ForgeReviewerCandidate, ForgeReviewersRequest, ForgeReviewRequest, ForgeReviewResult, ForgeReviewWrite, ForgeReviewWriteResult, MergeRequest } from '@deepseek-ai/dsh-experimental-forge';
import type { GlabRunner } from './glab.ts';
/** Bounds of the provider's reads and caches. */
export interface GitLabLimits {
    /** Maximum combined JSON bytes one check read or review read keeps. */
    readonly maxOutputBytes: number;
    /** Most review threads one review read returns. */
    readonly maxReviewThreads: number;
    /** Most commits one commit listing returns. */
    readonly maxCommits: number;
    /** Most merge requests one status query reads. */
    readonly statusBatchSize: number;
    /** Most `glab` processes one status fetch runs at once. */
    readonly maxConcurrentRequests: number;
    /** Most bytes of diff version patches kept for the hunks of outdated threads and the positions of new comments. */
    readonly maxCachedVersionBytes: number;
}
/** Reads and writes GitLab.com and self-managed GitLab merge requests through a `glab` runner. */
export declare class GitLabProvider implements ForgeProvider {
    private readonly limits;
    readonly forge = "gitlab";
    readonly hosts: readonly string[];
    readonly label = "GitLab";
    readonly changeRequestNoun = "merge-request";
    private readonly served;
    private readonly api;
    /** Closing issues by merge request; one entry per merge request this provider polled. */
    private readonly closing;
    /** Diff version patches by merge request and version, least recently read first. */
    private readonly versions;
    /** Cache fills in flight, so concurrent threads on one file read it once. */
    private readonly filling;
    private versionBytes;
    /**
     * @param glab - runner that executes `glab` on the host.
     * @param hosts - host names this provider serves, such as `gitlab.com` and self-managed hosts.
     * @param limits - read and cache bounds.
     */
    constructor(glab: GlabRunner, hosts: readonly string[], limits: GitLabLimits);
    repositoryFromRemote(url: string): ForgeRepository | undefined;
    changeRequestFromUrl(url: string): ChangeRequestRef | undefined;
    changeRequestUrl(ref: ChangeRequestRef): string;
    fetch(refs: readonly ChangeRequestRef[], signal: AbortSignal): Promise<ReadonlyMap<ChangeRequestKey, ChangeRequestSnapshot | ForgeFailure>>;
    fetchChecks(ref: ChangeRequestRef, signal: AbortSignal): Promise<ChangeRequestSnapshot | ForgeFailure>;
    findByHead(repository: ForgeRepository, branch: string, signal: AbortSignal): Promise<readonly ChangeRequestRef[]>;
    readiness(host: string, signal: AbortSignal): Promise<ForgeReadiness>;
    /** Mark a draft merge request ready through the GraphQL `mergeRequestSetDraft` mutation; a ready one stays ready. */
    markReady(ref: ChangeRequestRef, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * Merge through the REST merge endpoint with `sha` set to the confirmed head, so GitLab refuses with HTTP 409 once
     * the head moved; the method chooses squashing, and the merge request's own setting decides whether GitLab deletes the
     * head branch.
     */
    merge(ref: ChangeRequestRef, request: MergeRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * Publish a comment or a complete review through discussions and draft notes after a check of the head.
     * @see submitGitLabReview
     */
    submitReview(ref: ChangeRequestRef, request: ForgeReviewRequest, signal: AbortSignal): Promise<ForgeReviewResult>;
    /**
     * Write to the discussions or the draft notes of a merge request after a check of the head.
     * @see writeGitLabReview
     */
    writeReview(ref: ChangeRequestRef, write: ForgeReviewWrite, signal: AbortSignal): Promise<ForgeReviewWriteResult>;
    /**
     * Retry the failed jobs of the head pipeline once none of its jobs is pending.
     * @see rerunGitLabChecks
     */
    rerunChecks(ref: ChangeRequestRef, request: ForgeRerunRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    requestReviews(ref: ChangeRequestRef, request: ForgeReviewersRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    reviewerCandidates(ref: ChangeRequestRef, query: string, signal: AbortSignal): Promise<readonly ForgeReviewerCandidate[] | ForgeFailure>;
    updateBranch(ref: ChangeRequestRef, request: BranchUpdateRequest, signal: AbortSignal): Promise<ForgeActionFailure | undefined>;
    /**
     * Read the patch of the newest diff version, which GitLab records for every push, once it is at `headSha`; `base` is
     * not needed because the version names its own merge base.
     */
    diff(ref: ChangeRequestRef, headSha: string, signal: AbortSignal): Promise<string | ForgeFailure>;
    fileText(ref: ChangeRequestRef, commit: string, path: string, signal: AbortSignal): Promise<string | ForgeFailure>;
    fileUrl(ref: ChangeRequestRef, commit: string, path: string): string;
    commits(ref: ChangeRequestRef, signal: AbortSignal): Promise<ForgeCommitList | ForgeFailure>;
    compare(ref: ChangeRequestRef, base: string, head: string, signal: AbortSignal): Promise<string | ForgeFailure>;
    mergeBase(ref: ChangeRequestRef, base: string, head: string, signal: AbortSignal): Promise<string | ForgeFailure>;
    readReview(ref: ChangeRequestRef, headSha: string, signal: AbortSignal): Promise<ForgeReviewData | ForgeFailure>;
    /**
     * Read the status of merge requests on one host with one GraphQL query, halving the batch while GitLab refuses it as
     * too complex, then read each one's closing issues unless its update time is the one they were read at.
     */
    private status;
    /**
     * Complete one merge request's snapshot with the rest of its jobs, when asked for, and its closing issues, asking GitLab
     * to check its conflicts when it has not since a change.
     */
    private snapshot;
    /**
     * The issues a merge request closes. GitLab derives them from its description and commit messages, and changing
     * either changes its update time, so a list read at the same update time is reused. A failed read keeps the last
     * list, or none, marked truncated.
     */
    private closingIssues;
    /**
     * One file's patch in the diff a thread position names: from the diff version when GitLab keeps its files, else by
     * comparing the file's text at the position's merge base and head, where a missing file reads as empty. Both never
     * change, so they are kept, least recently read dropped first, until they pass `maxCachedVersionBytes`.
     */
    private positionPatch;
    /**
     * The changed files of one diff version by their path on either side, which never change, kept with the patches of
     * outdated threads. A file's new path names it over another file's old path, so after `a → b` and `b → c` the path
     * `b` names the first file.
     */
    private versionFiles;
    /** Reads the changed files of the merge request's diff versions for comment positions. */
    private filesOf;
    /** Read one cache entry, or fill it from `read` unless the read fails; concurrent callers of one key share one fill. */
    private cached;
    /**
     * Read and keep one cache entry, then drop the least recently read entries over the limit; an entry over the limit by
     * itself serves this read only.
     */
    private fill;
    /**
     * Refuse a write to a host this provider does not serve.
     * @throws when `headSha` is given and is not a full commit object name, which callers check before they write.
     */
    private writable;
    private hostFailure;
}
//# sourceMappingURL=provider.d.ts.map