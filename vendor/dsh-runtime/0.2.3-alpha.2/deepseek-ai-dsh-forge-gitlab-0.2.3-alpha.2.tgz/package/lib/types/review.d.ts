/** GitLab merge request discussions and the signed-in user's draft notes, mapped to forge review threads at one head commit. */
import type { ChangeRequestRef, ForgeCommentId, ForgeFailure, ForgeReviewData, ForgeReviewId, ForgeThreadId } from '@deepseek-ai/dsh-experimental-forge';
import type { GitLabApi } from './api.ts';
/**
 * The one pending review a GitLab user has per merge request: their draft notes, which GitLab publishes together and
 * keeps without an identity of their own.
 */
export declare const DRAFT_REVIEW: ForgeReviewId;
/**
 * Comment id of a draft note.
 * @param id - GitLab's draft note id.
 * @returns the id the forge contract carries.
 */
export declare function draftCommentId(id: number): ForgeCommentId;
/**
 * Read a comment id.
 * @param id - id from a forge write.
 * @returns the GitLab note or draft note id, or undefined for an id this provider never issued.
 */
export declare function noteOf(id: ForgeCommentId): {
    readonly draft: boolean;
    readonly id: string;
} | undefined;
/**
 * Read a thread id.
 * @param id - id from a forge write.
 * @returns GitLab's discussion id, or undefined for a draft note's thread or an id this provider never issued.
 */
export declare function discussionOf(id: ForgeThreadId): string | undefined;
/**
 * The signed-in user, their rights on a merge request, and one page of its discussions with the rights on each;
 * variables `path` and `iid` are strings, `cursor` a string or null.
 */
export declare const PERMISSIONS_QUERY = "query($path: ID!, $iid: String!, $cursor: String) {\n  currentUser { username avatarUrl }\n  project(fullPath: $path) { mergeRequest(iid: $iid) {\n    userPermissions { createNote }\n    reviewers(first: 100) { nodes { username } }\n    discussions(first: 100, after: $cursor) {\n      pageInfo { hasNextPage endCursor }\n      nodes {\n        id resolvable userPermissions { resolveNote }\n        notes(first: 100) { pageInfo { hasNextPage } nodes { id userPermissions { adminNote } } }\n      }\n    }\n  } }\n}";
/** Bounds of one review read. */
export interface ReviewLimits {
    /** Most threads one read returns. */
    readonly maxReviewThreads: number;
    /** Most JSON bytes of all discussion pages one read keeps, and of the threads it returns. */
    readonly maxOutputBytes: number;
    /** Most outdated threads whose hunks are read at once. */
    readonly maxConcurrentRequests: number;
}
/** One file of the diff a thread position was last seen in. */
export interface PositionFile {
    /** The diff version at the position's head when GitLab still keeps that version's files, else null. */
    readonly version: number | null;
    /** Merge base the position's diff starts at. */
    readonly baseSha: string;
    /** Head the position's diff ends at. */
    readonly headSha: string;
    /** Path on the old side. */
    readonly oldPath: string;
    /** Path on the new side. */
    readonly newPath: string;
}
/** Reads the unified patch of one file of a position's diff, or null when it cannot be read. */
export type VersionFilePatch = (file: PositionFile) => Promise<string | null>;
/**
 * Read the review threads of a merge request at head commit `headSha`. Discussions are read in pages of 100 up to
 * `maxReviewThreads` threads, beside the signed-in user's draft notes, their approval, and GraphQL pages of the rights
 * they hold on each discussion and note; the diff versions are read last, and the newest version must be at `headSha`,
 * else the read is `stale`, so a push during the read is detected after the threads. A thread is a discussion whose
 * first note is a diff note on a file. GitLab keeps one position per thread, the last version its lines were unchanged
 * at: a thread whose position is at `headSha` gets a `current` position, and every line thread keeps that position as
 * `original`. GitLab does not move `line_range` when it carries a thread, so a range's first line is its last line minus
 * the range's length. An outdated thread's hunk comes from the diff its position names: the diff version's file when
 * GitLab keeps it, else a comparison of the file's text at the position's merge base and head.
 *
 * Draft notes are the user's pending review: a draft reply joins its thread as a pending comment, and a draft on a file
 * position is a thread of its own whose id is the draft's. GitLab reports no creation time for a draft, so a draft's
 * comment carries the read's time. The user may review when they may comment; they may approve when GitLab lets them or
 * they already approved, and request changes only as a reviewer, since GitLab records that decision only for reviewers.
 *
 * The read is `truncated` when it stops before the last discussion page, when the rights of a discussion or a note are
 * left unread, or when the threads, with their hunks and draft notes, pass `maxOutputBytes`, in which case the threads
 * past it are dropped.
 * @param api - GitLab reads.
 * @param ref - merge request.
 * @param headSha - head commit the threads must be read at.
 * @param limits - thread and byte bounds.
 * @param filePatch - reads one file's patch at an earlier version, for outdated threads.
 * @param signal - cancellation of the read.
 * @returns the threads, or why GitLab did not provide them.
 */
export declare function readReviewThreads(api: GitLabApi, ref: ChangeRequestRef, headSha: string, limits: ReviewLimits, filePatch: VersionFilePatch, signal: AbortSignal): Promise<ForgeReviewData | ForgeFailure>;
/**
 * Cut the hunk of a one-file patch that holds a line, ending at that line, with a header that counts the kept lines.
 * @param patch - the file's patch, or null when it is unknown.
 * @param side - side the line numbers.
 * @param line - last line to keep.
 * @returns the hunk, or null when no hunk holds the line or the patch cannot be parsed.
 */
export declare function hunkUntil(patch: string | null, side: 'L' | 'R', line: number): string | null;
//# sourceMappingURL=review.d.ts.map