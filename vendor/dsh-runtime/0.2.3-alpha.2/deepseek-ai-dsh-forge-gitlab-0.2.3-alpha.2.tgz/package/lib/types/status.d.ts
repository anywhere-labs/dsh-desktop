/** GitLab merge request status through GraphQL, mapped to forge snapshots. */
import type { ChangeRequestCheck, ChangeRequestIssue, ChangeRequestRef, ChangeRequestSnapshot, ForgeCheckId, ForgeFailure } from '@deepseek-ai/dsh-experimental-forge';
import { z } from 'zod';
/** Reviewers and approvers read per merge request; GitLab counts list sizes toward a query's complexity. */
export declare const PEOPLE_PAGE = 20;
/** Jobs of the head pipeline a status poll reads; `fetchChecks` reads the rest. */
export declare const POLL_JOBS = 50;
/** Jobs per page of a complete check read. */
export declare const JOB_PAGE = 100;
/**
 * Merge request fields one status read takes; `$jobs` sizes the first page of head pipeline jobs, which leaves out jobs a
 * retry replaced, since GitLab lists those beside their retries. The merge status comes before `diffStatsSummary`, after
 * which GitLab 19.5 reports `CONFLICT` for a merge request it found mergeable.
 */
export declare const MERGE_REQUEST_FRAGMENT = "fragment MergeRequestStatus on MergeRequest {\n  iid title webUrl state draft updatedAt closedAt mergedAt\n  author { username }\n  sourceBranch targetBranch\n  diffRefs { baseSha headSha }\n  detailedMergeStatus mergeStatusEnum conflicts divergedFromTargetBranch rebaseInProgress\n  diffStatsSummary { additions deletions }\n  squash squashOnMerge squashReadOnly approved\n  resolvableDiscussionsCount resolvedDiscussionsCount\n  userPermissions { canMerge pushToSourceBranch updateMergeRequest }\n  approvedBy(first: 20) { pageInfo { hasNextPage } nodes { username avatarUrl bot } }\n  reviewers(first: 20) { pageInfo { hasNextPage } nodes { username avatarUrl bot mergeRequestInteraction { reviewState } } }\n  headPipeline { id status userPermissions { updatePipeline } jobs(first: $jobs, retried: false) { pageInfo { hasNextPage endCursor } nodes { name status allowFailure stage { name } webPath startedAt finishedAt } } }\n}";
/** Following page of head pipeline jobs, without jobs a retry replaced; variables `path`, `iid`, and `cursor` are strings. */
export declare const JOBS_QUERY = "query($path: ID!, $iid: String!, $cursor: String!) {\n  project(fullPath: $path) { mergeRequest(iid: $iid) { diffRefs { headSha } headPipeline { jobs(first: 100, after: $cursor, retried: false) {\n    pageInfo { hasNextPage endCursor } nodes { name status allowFailure stage { name } webPath startedAt finishedAt } } } } }\n}";
/**
 * Build one query that reads the status of several merge requests, each under the alias `m<index>` with the variables
 * `p<index>` (project path) and `i<index>` (number as a string).
 * @param count - number of merge requests.
 * @returns the GraphQL document.
 */
export declare function statusQuery(count: number): string;
declare const jobSchema: z.ZodObject<{
    name: z.ZodString;
    status: z.ZodNullable<z.ZodString>;
    allowFailure: z.ZodBoolean;
    stage: z.ZodNullable<z.ZodObject<{
        name: z.ZodString;
    }, z.core.$strip>>;
    webPath: z.ZodNullable<z.ZodString>;
    startedAt: z.ZodNullable<z.ZodString>;
    finishedAt: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/** One merge request as {@link MERGE_REQUEST_FRAGMENT} reads it. */
export declare const mergeRequestSchema: z.ZodObject<{
    iid: z.ZodString;
    title: z.ZodString;
    webUrl: z.ZodString;
    state: z.ZodString;
    draft: z.ZodBoolean;
    updatedAt: z.ZodString;
    closedAt: z.ZodNullable<z.ZodString>;
    mergedAt: z.ZodNullable<z.ZodString>;
    author: z.ZodNullable<z.ZodObject<{
        username: z.ZodString;
    }, z.core.$strip>>;
    sourceBranch: z.ZodString;
    targetBranch: z.ZodString;
    diffRefs: z.ZodNullable<z.ZodObject<{
        baseSha: z.ZodNullable<z.ZodString>;
        headSha: z.ZodString;
    }, z.core.$strip>>;
    diffStatsSummary: z.ZodNullable<z.ZodObject<{
        additions: z.ZodNumber;
        deletions: z.ZodNumber;
    }, z.core.$strip>>;
    detailedMergeStatus: z.ZodNullable<z.ZodString>;
    mergeStatusEnum: z.ZodNullable<z.ZodString>;
    conflicts: z.ZodBoolean;
    divergedFromTargetBranch: z.ZodBoolean;
    rebaseInProgress: z.ZodBoolean;
    squash: z.ZodBoolean;
    squashOnMerge: z.ZodBoolean;
    squashReadOnly: z.ZodBoolean;
    approved: z.ZodBoolean;
    resolvableDiscussionsCount: z.ZodNullable<z.ZodNumber>;
    resolvedDiscussionsCount: z.ZodNullable<z.ZodNumber>;
    userPermissions: z.ZodObject<{
        canMerge: z.ZodBoolean;
        pushToSourceBranch: z.ZodBoolean;
        updateMergeRequest: z.ZodBoolean;
    }, z.core.$strip>;
    approvedBy: z.ZodNullable<z.ZodObject<{
        pageInfo: z.ZodObject<{
            hasNextPage: z.ZodBoolean;
            endCursor: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strip>;
        nodes: z.ZodArray<z.ZodObject<{
            username: z.ZodString;
            avatarUrl: z.ZodNullable<z.ZodString>;
            bot: z.ZodBoolean;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    reviewers: z.ZodObject<{
        pageInfo: z.ZodObject<{
            hasNextPage: z.ZodBoolean;
            endCursor: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strip>;
        nodes: z.ZodArray<z.ZodObject<{
            username: z.ZodString;
            avatarUrl: z.ZodNullable<z.ZodString>;
            bot: z.ZodBoolean;
            mergeRequestInteraction: z.ZodNullable<z.ZodObject<{
                reviewState: z.ZodNullable<z.ZodString>;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
    }, z.core.$strip>;
    headPipeline: z.ZodNullable<z.ZodObject<{
        id: z.ZodString;
        status: z.ZodString;
        userPermissions: z.ZodObject<{
            updatePipeline: z.ZodBoolean;
        }, z.core.$strip>;
        jobs: z.ZodNullable<z.ZodObject<{
            pageInfo: z.ZodObject<{
                hasNextPage: z.ZodBoolean;
                endCursor: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strip>;
            nodes: z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                status: z.ZodNullable<z.ZodString>;
                allowFailure: z.ZodBoolean;
                stage: z.ZodNullable<z.ZodObject<{
                    name: z.ZodString;
                }, z.core.$strip>>;
                webPath: z.ZodNullable<z.ZodString>;
                startedAt: z.ZodNullable<z.ZodString>;
                finishedAt: z.ZodNullable<z.ZodString>;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
/** One aliased project of a status query. */
export declare const projectSchema: z.ZodNullable<z.ZodObject<{
    mergeRequestsFfOnlyEnabled: z.ZodBoolean;
    mergeRequest: z.ZodNullable<z.ZodObject<{
        iid: z.ZodString;
        title: z.ZodString;
        webUrl: z.ZodString;
        state: z.ZodString;
        draft: z.ZodBoolean;
        updatedAt: z.ZodString;
        closedAt: z.ZodNullable<z.ZodString>;
        mergedAt: z.ZodNullable<z.ZodString>;
        author: z.ZodNullable<z.ZodObject<{
            username: z.ZodString;
        }, z.core.$strip>>;
        sourceBranch: z.ZodString;
        targetBranch: z.ZodString;
        diffRefs: z.ZodNullable<z.ZodObject<{
            baseSha: z.ZodNullable<z.ZodString>;
            headSha: z.ZodString;
        }, z.core.$strip>>;
        diffStatsSummary: z.ZodNullable<z.ZodObject<{
            additions: z.ZodNumber;
            deletions: z.ZodNumber;
        }, z.core.$strip>>;
        detailedMergeStatus: z.ZodNullable<z.ZodString>;
        mergeStatusEnum: z.ZodNullable<z.ZodString>;
        conflicts: z.ZodBoolean;
        divergedFromTargetBranch: z.ZodBoolean;
        rebaseInProgress: z.ZodBoolean;
        squash: z.ZodBoolean;
        squashOnMerge: z.ZodBoolean;
        squashReadOnly: z.ZodBoolean;
        approved: z.ZodBoolean;
        resolvableDiscussionsCount: z.ZodNullable<z.ZodNumber>;
        resolvedDiscussionsCount: z.ZodNullable<z.ZodNumber>;
        userPermissions: z.ZodObject<{
            canMerge: z.ZodBoolean;
            pushToSourceBranch: z.ZodBoolean;
            updateMergeRequest: z.ZodBoolean;
        }, z.core.$strip>;
        approvedBy: z.ZodNullable<z.ZodObject<{
            pageInfo: z.ZodObject<{
                hasNextPage: z.ZodBoolean;
                endCursor: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strip>;
            nodes: z.ZodArray<z.ZodObject<{
                username: z.ZodString;
                avatarUrl: z.ZodNullable<z.ZodString>;
                bot: z.ZodBoolean;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
        reviewers: z.ZodObject<{
            pageInfo: z.ZodObject<{
                hasNextPage: z.ZodBoolean;
                endCursor: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            }, z.core.$strip>;
            nodes: z.ZodArray<z.ZodObject<{
                username: z.ZodString;
                avatarUrl: z.ZodNullable<z.ZodString>;
                bot: z.ZodBoolean;
                mergeRequestInteraction: z.ZodNullable<z.ZodObject<{
                    reviewState: z.ZodNullable<z.ZodString>;
                }, z.core.$strip>>;
            }, z.core.$strip>>;
        }, z.core.$strip>;
        headPipeline: z.ZodNullable<z.ZodObject<{
            id: z.ZodString;
            status: z.ZodString;
            userPermissions: z.ZodObject<{
                updatePipeline: z.ZodBoolean;
            }, z.core.$strip>;
            jobs: z.ZodNullable<z.ZodObject<{
                pageInfo: z.ZodObject<{
                    hasNextPage: z.ZodBoolean;
                    endCursor: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                }, z.core.$strip>;
                nodes: z.ZodArray<z.ZodObject<{
                    name: z.ZodString;
                    status: z.ZodNullable<z.ZodString>;
                    allowFailure: z.ZodBoolean;
                    stage: z.ZodNullable<z.ZodObject<{
                        name: z.ZodString;
                    }, z.core.$strip>>;
                    webPath: z.ZodNullable<z.ZodString>;
                    startedAt: z.ZodNullable<z.ZodString>;
                    finishedAt: z.ZodNullable<z.ZodString>;
                }, z.core.$strip>>;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
}, z.core.$strip>>;
/** A following page of head pipeline jobs as {@link JOBS_QUERY} reads it. */
export declare const jobsPageSchema: z.ZodObject<{
    project: z.ZodNullable<z.ZodObject<{
        mergeRequest: z.ZodNullable<z.ZodObject<{
            diffRefs: z.ZodNullable<z.ZodObject<{
                headSha: z.ZodString;
            }, z.core.$strip>>;
            headPipeline: z.ZodNullable<z.ZodObject<{
                jobs: z.ZodNullable<z.ZodObject<{
                    pageInfo: z.ZodObject<{
                        hasNextPage: z.ZodBoolean;
                        endCursor: z.ZodOptional<z.ZodNullable<z.ZodString>>;
                    }, z.core.$strip>;
                    nodes: z.ZodArray<z.ZodObject<{
                        name: z.ZodString;
                        status: z.ZodNullable<z.ZodString>;
                        allowFailure: z.ZodBoolean;
                        stage: z.ZodNullable<z.ZodObject<{
                            name: z.ZodString;
                        }, z.core.$strip>>;
                        webPath: z.ZodNullable<z.ZodString>;
                        startedAt: z.ZodNullable<z.ZodString>;
                        finishedAt: z.ZodNullable<z.ZodString>;
                    }, z.core.$strip>>;
                }, z.core.$strip>>;
            }, z.core.$strip>>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
}, z.core.$strip>;
/** One merge request as GitLab returned it. */
export type MergeRequestNode = z.infer<typeof mergeRequestSchema>;
/** One job as GitLab returned it. */
export type JobNode = z.infer<typeof jobSchema>;
/**
 * Whether GitLab has not checked the merge request for conflicts since it or its target changed.
 * @param node - the merge request.
 * @returns whether a REST read of the merge request should ask GitLab to check it.
 */
export declare function needsMergeCheck(node: MergeRequestNode): boolean;
/** A merge request whose status is known, and the parts of it read elsewhere. */
export interface StatusParts {
    /** The merge request. */
    readonly ref: ChangeRequestRef;
    /** Whether the project merges by fast-forward only. */
    readonly fastForwardOnly: boolean;
    /** The merge request node. */
    readonly node: MergeRequestNode;
    /** Every job read for the head pipeline, in GitLab's order. */
    readonly jobs: readonly JobNode[];
    /** Whether GitLab listed more jobs than `jobs` holds. */
    readonly jobsTruncated: boolean;
    /** Issues the merge request closes, in GitLab's order. */
    readonly closingIssues: readonly ChangeRequestIssue[];
    /** Whether GitLab listed more closing issues than `closingIssues` holds. */
    readonly closingIssuesTruncated: boolean;
}
/**
 * Map a merge request to a forge snapshot. GitLab's open, closed, merged, and locked states map to open, closed, merged,
 * and open; the merge status decides mergeability: a status GitLab has not decided or not checked since a change is
 * unknown, whatever `conflicts` and `CONFLICT` say, and `CONFLICT` is conflicting even while `conflicts` is false. Every
 * job of the head pipeline names the pipeline as its rerun, since GitLab retries a pipeline's failed and cancelled jobs
 * together. GitLab updates a head branch only by rebasing it onto the target branch, which a user who can push to the
 * head branch may start while the branches have diverged without conflicts and no rebase runs.
 * @param parts - the merge request and the parts read with it.
 * @returns the snapshot, or a failure when GitLab reports no head commit.
 */
export declare function snapshotOf(parts: StatusParts): ChangeRequestSnapshot | ForgeFailure;
/**
 * Map one job to a check. A failed job allowed to fail is neutral, as GitLab shows it passing with a warning; a manual
 * job allowed to fail is skipped, and one that blocks the pipeline is pending until someone runs it.
 * @param host - GitLab host, for the job's page.
 * @param job - the job.
 * @param rerun - global id of the job's pipeline, which a rerun retries.
 * @returns the check.
 */
export declare function checkOf(host: string, job: JobNode, rerun: ForgeCheckId | null): ChangeRequestCheck;
/**
 * Map the REST list of issues a merge request closes, keeping the ones whose page names a project.
 * @param body - the parsed `closes_issues` answer.
 * @param limit - the most issues to keep.
 * @returns the issues and whether more were listed, or undefined when the answer is not such a list.
 */
export declare function closingIssuesOf(body: unknown, limit: number): {
    readonly issues: ChangeRequestIssue[];
    readonly truncated: boolean;
} | undefined;
export {};
//# sourceMappingURL=status.d.ts.map