/** GitLab remote URL and merge request URL parsing, and validation of the project paths inlined into requests. */
import type { ChangeRequestRef, ForgeRepository } from '@deepseek-ai/dsh-experimental-forge';
/** Host, namespace, and project addressed by a URL. */
export interface GitLabLocation {
    /** Lowercase host name. */
    readonly host: string;
    /** Group or user namespace, with nested groups joined by `/`. */
    readonly owner: string;
    /** Project path without a `.git` suffix. */
    readonly name: string;
}
/**
 * Check one group or project path segment.
 * @param value - candidate segment.
 * @returns whether GitLab permits the segment and it is not a dot path.
 */
export declare function isSegment(value: string): boolean;
/**
 * Validate a merge request before its project path and number are inlined into an API path or a GraphQL variable.
 * @param ref - merge request on a GitLab host.
 * @returns the project's full path, `namespace/project`.
 * @throws when a path segment is not permitted or the number is not a positive integer.
 */
export declare function checkedProject(ref: ChangeRequestRef): string;
/**
 * The REST path prefix of a merge request, with the project path percent-encoded as GitLab requires.
 * @param ref - merge request on a GitLab host.
 * @returns `projects/<encoded path>/merge_requests/<iid>`.
 * @throws as {@link checkedProject} does.
 */
export declare function mergeRequestPath(ref: ChangeRequestRef): string;
/**
 * Parse a Git remote URL. Accepts `http(s)://[user@]host[:port]/namespace/project`, `ssh://[user@]host[:port]/…`,
 * `git://host/…`, and the scp-like `[user@]host:namespace/project`, each with an optional `.git` suffix or trailing
 * slash and with nested groups in the namespace. HTTP(S) ports belong to the host identity; SSH and Git transport
 * ports do not.
 * @param url - fetch or push URL as Git reports it.
 * @returns the location, or undefined for other URL shapes.
 */
export declare function parseRemoteUrl(url: string): GitLabLocation | undefined;
/**
 * Parse a merge request web URL such as `https://gitlab.com/group/project/-/merge_requests/12/diffs`.
 * @param url - web URL of a merge request.
 * @returns the location and number, or undefined for other URLs.
 */
export declare function parseMergeRequestUrl(url: string): (GitLabLocation & {
    readonly number: number;
}) | undefined;
/**
 * Parse an issue web URL such as `https://gitlab.com/group/project/-/issues/12`.
 * @param url - web URL of an issue.
 * @returns the location and number, or undefined for other URLs.
 */
export declare function parseIssueUrl(url: string): (GitLabLocation & {
    readonly number: number;
}) | undefined;
/**
 * Percent-encode each segment of a repository-relative path for a web or API URL.
 * @param path - repository-relative path.
 * @returns the encoded path with `/` kept between segments.
 */
export declare function encodedPath(path: string): string;
/**
 * Build the repository of a location.
 * @param location - parsed host, namespace, and project.
 * @returns the repository of the `gitlab` family.
 */
export declare function repositoryOf(location: GitLabLocation): ForgeRepository;
/**
 * Resolve an avatar URL GitLab names by its path on the host, as it does for an uploaded avatar without a separate
 * asset host.
 * @param host - GitLab host.
 * @param url - avatar URL as GitLab reports it.
 * @returns the absolute URL, or null when GitLab names none.
 */
export declare function avatarUrlOf(host: string, url: string | null): string | null;
//# sourceMappingURL=urls.d.ts.map