/** Account sign-out policy over the latest logged request route of each running Agent. */
import type { Context } from '@deepseek-ai/cordis';
/**
 * End the running Agents whose latest request used the account route `provider`, keeping their inboxes.
 * @param ctx - context whose optional Agent registry is read when this runs; without one nothing is cancelled.
 * @param provider - the account route id.
 */
export declare function cancelAccountTasks(ctx: Context, provider: string): void;
/**
 * Cancel signed-out account tasks, publish sign-in guidance for rejected
 * requests, and report running account work to the account service's
 * sign-out confirmation. Each listener attaches once the service it needs is
 * mounted and detaches with this plugin; a request that outlives the plugin
 * ends its tasks through {@link cancelAccountTasks} when its credential is
 * signed out.
 * @param ctx - account route plugin lifetime; Agents and the account service may attach later.
 * @param provider - the account route id this plugin registers.
 */
export declare function installAccountTaskCancellation(ctx: Context, provider: string): void;
//# sourceMappingURL=account-tasks.d.ts.map