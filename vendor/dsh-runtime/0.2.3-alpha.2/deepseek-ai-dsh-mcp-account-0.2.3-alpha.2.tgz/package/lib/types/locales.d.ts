/** The copy every connector's account section shares; each connector's own text comes with its registration. */
import type { LocalizedText } from '@deepseek-ai/dsh-package-manifest';
/** Chinese dictionary and key source. */
declare const zh: {
    'status.checking': string;
    'status.disconnected': string;
    'status.waiting-browser': string;
    'status.authorizing': string;
    'status.connecting': string;
    'status.connected': string;
    'status.reconnect': string;
    'status.unavailable': string;
    'detail.reconnect.expired': string;
    'detail.reconnect.binding': string;
    'detail.unavailable': string;
    hostBrowser: string;
    failed: string;
    'action.reconnect': string;
    'action.open': string;
    'action.cancel': string;
    'action.signOut': string;
    'action.reauthorize': string;
    'action.retry': string;
    'badge.connected': string;
    'badge.disconnected': string;
    'badge.reconnect': string;
    'badge.unavailable': string;
    'badge.connecting': string;
};
/** Every key of the shared copy. */
export type McpAccountKey = keyof typeof zh;
/**
 * The shared copy of one key in every shipped language.
 * @param key - the dictionary key.
 * @returns the text each browser resolves in its active language.
 */
export declare function text(key: McpAccountKey): LocalizedText;
export {};
//# sourceMappingURL=locales.d.ts.map