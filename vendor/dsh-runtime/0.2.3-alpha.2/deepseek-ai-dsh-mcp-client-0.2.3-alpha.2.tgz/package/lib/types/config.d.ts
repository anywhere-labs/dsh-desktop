/**
 * Schemas of the two server configuration shapes. The entry composes them into its `Config`, and the host resolves a
 * server configuration through its transport's schema, so a failure names the offending field instead of the whole union.
 *
 * @module
 */
import z from '@deepseek-ai/schemastery';
import type { ReconnectConfig } from './connection.ts';
import type { McpOAuthConfigInput } from './oauth-options.ts';
import type { Config, StdioConfig, StreamableHttpConfig } from './index.ts';
/** Valid `serverName`, kept below the public tool-name budget. */
export declare const SERVER_NAME_PATTERN: RegExp;
/** {@link StdioConfig} before defaults. */
type StdioConfigInput = Omit<StdioConfig, 'args' | 'env' | 'cwd' | 'toolCallTimeoutMs' | 'startupTimeoutMs' | 'failOnStartupError' | 'closeTimeoutMs' | 'expandTemplates' | 'toolLoading' | 'catalogDescriptionMaxLength'> & Partial<Pick<StdioConfig, 'args' | 'env' | 'cwd' | 'toolCallTimeoutMs' | 'startupTimeoutMs' | 'failOnStartupError' | 'closeTimeoutMs' | 'expandTemplates' | 'toolLoading' | 'catalogDescriptionMaxLength'>>;
/** {@link StreamableHttpConfig} before defaults. */
type StreamableHttpConfigInput = Omit<StreamableHttpConfig, 'oauth' | 'headers' | 'toolCallTimeoutMs' | 'startupTimeoutMs' | 'failOnStartupError' | 'closeTimeoutMs' | 'expandTemplates' | 'toolLoading' | 'catalogDescriptionMaxLength'> & Partial<Pick<StreamableHttpConfig, 'headers' | 'toolCallTimeoutMs' | 'startupTimeoutMs' | 'failOnStartupError' | 'closeTimeoutMs' | 'expandTemplates' | 'toolLoading' | 'catalogDescriptionMaxLength'>> & {
    oauth?: McpOAuthConfigInput;
};
/** One server's configuration before defaults. */
export type ConfigInput = StdioConfigInput | StreamableHttpConfigInput;
/** Reconnect-policy section schema shared by both transports. */
export declare const ReconnectSchema: z<ReconnectConfig>;
/** Schema of {@link StdioConfig}. */
export declare const StdioSchema: z<StdioConfigInput, StdioConfig>;
/** Schema of {@link StreamableHttpConfig}. */
export declare const StreamableHttpSchema: z<StreamableHttpConfigInput, StreamableHttpConfig>;
/**
 * Whether a server configures OAuth beside its own Authorization header, which an instance refuses.
 * @param config - resolved server configuration.
 * @returns true for an OAuth server whose headers include `Authorization` in any letter case.
 */
export declare function hasOAuthWithAuthorizationHeader(config: Config): boolean;
export {};
//# sourceMappingURL=config.d.ts.map