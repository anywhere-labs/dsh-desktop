/**
 * Connection diagnostics retain cause chains. Configurations that resolve
 * secrets replace every known secret value before text leaves the instance.
 */
import { HarnessError } from '@deepseek-ai/dsh-error';
import type { McpAuthorizationReason } from './types.ts';
/**
 * Every {@link McpLocalError} code:
 * - `MCP_CONNECTION_CLOSED`: the connection generation closed; outcomes of requests in flight are unknown.
 * - `MCP_TIMEOUT`: a startup, operation, or cleanup budget elapsed.
 * - `MCP_CREDENTIALS_UNAVAILABLE`: credential templates are configured but no credentials provider is mounted.
 * - `MCP_CREDENTIAL_NOT_FOUND`: a referenced credential has no configured value.
 * - `MCP_INSTRUCTIONS_TOO_LARGE`: server instructions exceed `maxInstructionBytes`.
 * - `MCP_TOOL_REGISTRATION_FAILED`: a foreign registration occupies the server's tool namespace.
 * - `MCP_AUTHORIZATION_REQUIRED`: the server needs an OAuth authorization that no saved grant satisfies; `reason` names why.
 * - `MCP_OAUTH_FAILED`: an OAuth step failed locally, such as an unavailable issuer or a rejected callback.
 */
export declare const MCP_LOCAL_ERROR_CODES: readonly ["MCP_CONNECTION_CLOSED", "MCP_TIMEOUT", "MCP_CREDENTIALS_UNAVAILABLE", "MCP_CREDENTIAL_NOT_FOUND", "MCP_INSTRUCTIONS_TOO_LARGE", "MCP_TOOL_REGISTRATION_FAILED", "MCP_AUTHORIZATION_REQUIRED", "MCP_OAUTH_FAILED"];
/** One {@link McpLocalError} code. */
export type McpLocalErrorCode = typeof MCP_LOCAL_ERROR_CODES[number];
/**
 * Local failure whose message contains no expanded configuration or upstream
 * text; `code` is one of {@link MCP_LOCAL_ERROR_CODES}.
 */
export declare class McpLocalError extends HarnessError {
    readonly code: McpLocalErrorCode;
    constructor(message: string, code: McpLocalErrorCode, options?: ErrorOptions);
}
/**
 * Every {@link McpToolError} code:
 * - `MCP_TOOL_ERROR`: the server answered the tool call with an `isError` result; the model may adjust its input.
 * - `MCP_UNSUPPORTED_TASK_EXECUTION`: the tool requires task-based execution, which the bridge does not support.
 * - `MCP_INVALID_RESULT`: the server's result violates the MCP result schema or the tool's advertised output
 *   schema, or that output schema cannot be compiled.
 * - `MCP_CONNECTION_CLOSED`: the connection closed while the request was in flight; its outcome is unknown.
 * - `MCP_TIMEOUT`: the request exceeded its deadline; its outcome is unknown.
 * - `MCP_SERVER_UNAVAILABLE`: the server was not connected, so the request was not sent.
 * - `MCP_REQUEST_FAILED`: any other protocol or SDK failure; `message` carries the JSON-RPC or SDK code.
 */
export declare const MCP_TOOL_ERROR_CODES: readonly ["MCP_TOOL_ERROR", "MCP_UNSUPPORTED_TASK_EXECUTION", "MCP_INVALID_RESULT", "MCP_CONNECTION_CLOSED", "MCP_TIMEOUT", "MCP_SERVER_UNAVAILABLE", "MCP_REQUEST_FAILED"];
/** One {@link McpToolError} code. */
export type McpToolErrorCode = typeof MCP_TOOL_ERROR_CODES[number];
/**
 * Failure of one MCP tool or resource request; `code` is one of
 * {@link MCP_TOOL_ERROR_CODES}. `message` may contain upstream text, redacted
 * when the instance resolves credential templates.
 */
export declare class McpToolError extends HarnessError {
    readonly code: McpToolErrorCode;
    constructor(message: string, code: McpToolErrorCode, options?: ErrorOptions);
}
/**
 * Classify one failed MCP request. An {@link McpLocalError}, such as the
 * generation's closure reason, keeps its identity; any other failure becomes
 * an {@link McpToolError} whose `message` carries the JSON-RPC or SDK code.
 * Without `redact` the original failure is the `cause`; with `redact` no
 * `cause` is attached, because the original text may contain secret values.
 * @param error - the request's rejection.
 * @param operation - names the request, such as `tool "echo"` or `resources/read`.
 * @param redact - removes secret values from the message when templates are enabled.
 * @returns the classified failure to throw.
 */
export declare function mcpRequestError(error: unknown, operation: string, redact?: (text: string) => string): HarnessError;
/** Safe authorization failure with no upstream messages or token values (`MCP_AUTHORIZATION_REQUIRED`). */
export declare class McpAuthorizationRequired extends McpLocalError {
    readonly reason: McpAuthorizationReason;
    constructor(reason: McpAuthorizationReason);
}
/**
 * Classify SDK authentication failures without treating ordinary forbidden responses as missing authorization.
 * @param error - local or SDK error from a connection, probe, or token request.
 * @returns an authorization reason, or undefined for other errors.
 */
export declare function oauthFailure(error: unknown): McpAuthorizationRequired | undefined;
/**
 * Replace every occurrence of known secret values, longest first so a secret
 * that contains another is replaced whole.
 * @param text - diagnostic or upstream text.
 * @param secrets - non-empty secret values known to the instance.
 * @returns the text with each occurrence replaced by `[redacted]`.
 */
export declare function redactSecrets(text: string, secrets: Iterable<string>): string;
/**
 * Flatten an error and its `cause` chain into `outer, cause: inner, …`.
 * @param error - the caught value; non-Errors stringify as-is.
 * @returns the joined diagnostic line.
 */
export declare function describeError(error: unknown): string;
//# sourceMappingURL=diagnostic.d.ts.map