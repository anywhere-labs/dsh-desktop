/**
 * The MCP client host, `ctx.mcpClientHost`: the operations a plugin that manages MCP servers needs from this package.
 * The managing plugin creates it, so the host and the server instances it mounts run below that plugin's Fiber and end
 * with it.
 *
 * @module
 */
import { Service, type Context } from '@deepseek-ai/cordis';
import type { Config, StreamableHttpConfig } from './index.ts';
import type { ConfigInput } from './config.ts';
import { McpOAuthAuthorization } from './oauth.ts';
import type { McpOAuthConfig } from './oauth-options.ts';
import type { McpProbeOptions } from './probe.ts';
import type { McpConnectionStatusHandle } from './status.ts';
import type { McpCloseResult, McpProbeResult } from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** Validates, mounts, probes, and authorizes MCP servers for the plugin that manages them. */
        mcpClientHost: McpClientHost;
    }
}
/** One server instance the host mounted below its own Fiber. */
export interface McpServerInstance {
    /** Resolves with the instance's status handle once activation finishes; rejects with the activation failure. */
    readonly ready: Promise<McpConnectionStatusHandle>;
    /**
     * Stop the instance and await its teardown.
     * @returns the cleanup result of its latest connection generation, or `undefined` when activation never registered one.
     */
    dispose(): Promise<McpCloseResult | undefined>;
}
/** Validates, mounts, probes, and authorizes MCP servers for the plugin that manages them. */
export declare class McpClientHost extends Service {
    /**
     * The host's own context. A service method's `this.ctx` is the caller's context, so instances, probes, and
     * authorization owners use this one: they run below the host and end with it.
     */
    private readonly ownerContext;
    /**
     * Provide `ctx.mcpClientHost` for the lifetime of the managing plugin.
     * @param ctx - the managing plugin's context; mounted instances, probes, and authorization owners use its services.
     */
    constructor(ctx: Context);
    /**
     * Resolve a server configuration and refuse what an instance would refuse when it starts.
     * @param input - server configuration before defaults.
     * @param path - configuration path naming the server; every failure message starts with it.
     * @returns the resolved configuration.
     * @throws when the server name, a field, a template token, the reconnect policy, or OAuth beside an Authorization
     *   header is invalid.
     */
    validate(input: ConfigInput, path: readonly string[]): Config;
    /**
     * Mount one server instance below the host. The instance registers its tools and holds its `serverName` until disposed.
     * @param config - resolved server configuration, usually from {@link McpClientHost.validate}.
     * @returns the instance's activation and disposal.
     */
    mount(config: Config): McpServerInstance;
    /**
     * Probe a server without mounting it: resolve its templates, connect, list its tools, and close.
     * @param config - resolved server configuration; its startup budget does not bound the probe.
     * @param options - whole-probe budget, listing caps, and cancellation signal.
     * @returns the connect and list outcome with the cleanup result.
     * @throws for invalid options, malformed templates, or a missing required credentials provider.
     */
    probe(config: Config, options?: McpProbeOptions): Promise<McpProbeResult>;
    /**
     * Create the explicit OAuth authorization owner of one server.
     * @param config - resolved Streamable HTTP configuration with OAuth.
     * @param changed - called after each change of the owner's attempt view.
     * @returns the owner; its caller retires and disposes it.
     */
    authorization(config: StreamableHttpConfig & {
        oauth: McpOAuthConfig;
    }, changed: () => void): McpOAuthAuthorization;
}
//# sourceMappingURL=host.d.ts.map