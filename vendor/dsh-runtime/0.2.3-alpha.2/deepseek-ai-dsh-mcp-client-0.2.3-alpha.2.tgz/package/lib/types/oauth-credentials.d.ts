import type { Context } from '@deepseek-ai/cordis';
import type { CredentialKey, CredentialRecord } from '@deepseek-ai/dsh-credentials';
import type { AuthProvider, FetchLike, StoredOAuthClientInformation } from '@modelcontextprotocol/client';
import z from 'zod';
import { McpLocalError } from './diagnostic.ts';
import type { McpOAuthConfig } from './oauth-options.ts';
declare const ClientRecordSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    type: z.ZodLiteral<"mcp-oauth-client">;
    issuer: z.ZodString;
    information: z.ZodUnion<[z.ZodObject<{
        redirect_uris: z.ZodArray<z.ZodURL>;
        token_endpoint_auth_method: z.ZodOptional<z.ZodString>;
        grant_types: z.ZodOptional<z.ZodArray<z.ZodString>>;
        response_types: z.ZodOptional<z.ZodArray<z.ZodString>>;
        application_type: z.ZodOptional<z.ZodString>;
        client_name: z.ZodOptional<z.ZodString>;
        client_uri: z.ZodOptional<z.ZodURL>;
        logo_uri: z.ZodUnion<[z.ZodOptional<z.ZodURL>, z.ZodPipe<z.ZodLiteral<"">, z.ZodTransform<undefined, "">>]>;
        scope: z.ZodOptional<z.ZodString>;
        contacts: z.ZodOptional<z.ZodArray<z.ZodString>>;
        tos_uri: z.ZodUnion<[z.ZodOptional<z.ZodURL>, z.ZodPipe<z.ZodLiteral<"">, z.ZodTransform<undefined, "">>]>;
        policy_uri: z.ZodOptional<z.ZodString>;
        jwks_uri: z.ZodOptional<z.ZodURL>;
        jwks: z.ZodOptional<z.ZodAny>;
        software_id: z.ZodOptional<z.ZodString>;
        software_version: z.ZodOptional<z.ZodString>;
        software_statement: z.ZodOptional<z.ZodString>;
        client_id: z.ZodString;
        client_secret: z.ZodOptional<z.ZodString>;
        client_id_issued_at: z.ZodOptional<z.ZodNumber>;
        client_secret_expires_at: z.ZodOptional<z.ZodNumber>;
        issuer: z.ZodCatch<z.ZodOptional<z.ZodString>>;
    }, z.core.$strip>, z.ZodObject<{
        client_id: z.ZodString;
        client_secret: z.ZodOptional<z.ZodString>;
        client_id_issued_at: z.ZodOptional<z.ZodNumber>;
        client_secret_expires_at: z.ZodOptional<z.ZodNumber>;
        issuer: z.ZodCatch<z.ZodOptional<z.ZodString>>;
    }, z.core.$strip>]>;
}, z.core.$strip>;
declare const GrantSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    type: z.ZodLiteral<"mcp-oauth-grant">;
    id: z.ZodUUID;
    serverUrl: z.ZodURL;
    issuer: z.ZodString;
    clientKey: z.ZodString;
    clientId: z.ZodString;
    configuredClientId: z.ZodOptional<z.ZodString>;
    configuredScope: z.ZodOptional<z.ZodString>;
    resource: z.ZodOptional<z.ZodURL>;
    metadata: z.ZodOptional<z.ZodUnion<[z.ZodObject<{
        issuer: z.ZodString;
        authorization_endpoint: z.ZodURL;
        token_endpoint: z.ZodURL;
        registration_endpoint: z.ZodOptional<z.ZodURL>;
        scopes_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        response_types_supported: z.ZodArray<z.ZodString>;
        response_modes_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        grant_types_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        token_endpoint_auth_methods_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        token_endpoint_auth_signing_alg_values_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        service_documentation: z.ZodOptional<z.ZodURL>;
        revocation_endpoint: z.ZodOptional<z.ZodURL>;
        revocation_endpoint_auth_methods_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        revocation_endpoint_auth_signing_alg_values_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        introspection_endpoint: z.ZodOptional<z.ZodString>;
        introspection_endpoint_auth_methods_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        introspection_endpoint_auth_signing_alg_values_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        code_challenge_methods_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        client_id_metadata_document_supported: z.ZodOptional<z.ZodBoolean>;
        authorization_response_iss_parameter_supported: z.ZodCatch<z.ZodOptional<z.ZodBoolean>>;
        dpop_signing_alg_values_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$loose>, z.ZodObject<{
        issuer: z.ZodString;
        authorization_endpoint: z.ZodURL;
        token_endpoint: z.ZodURL;
        userinfo_endpoint: z.ZodOptional<z.ZodURL>;
        jwks_uri: z.ZodURL;
        registration_endpoint: z.ZodOptional<z.ZodURL>;
        scopes_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        response_types_supported: z.ZodArray<z.ZodString>;
        response_modes_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        grant_types_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        acr_values_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        subject_types_supported: z.ZodArray<z.ZodString>;
        id_token_signing_alg_values_supported: z.ZodArray<z.ZodString>;
        id_token_encryption_alg_values_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        id_token_encryption_enc_values_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        userinfo_signing_alg_values_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        userinfo_encryption_alg_values_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        userinfo_encryption_enc_values_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        request_object_signing_alg_values_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        request_object_encryption_alg_values_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        request_object_encryption_enc_values_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        token_endpoint_auth_methods_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        token_endpoint_auth_signing_alg_values_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        display_values_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        claim_types_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        claims_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        service_documentation: z.ZodOptional<z.ZodString>;
        claims_locales_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        ui_locales_supported: z.ZodOptional<z.ZodArray<z.ZodString>>;
        claims_parameter_supported: z.ZodOptional<z.ZodBoolean>;
        request_parameter_supported: z.ZodOptional<z.ZodBoolean>;
        request_uri_parameter_supported: z.ZodOptional<z.ZodBoolean>;
        require_request_uri_registration: z.ZodOptional<z.ZodBoolean>;
        op_policy_uri: z.ZodOptional<z.ZodURL>;
        op_tos_uri: z.ZodOptional<z.ZodURL>;
        client_id_metadata_document_supported: z.ZodOptional<z.ZodBoolean>;
        authorization_response_iss_parameter_supported: z.ZodCatch<z.ZodOptional<z.ZodBoolean>>;
    }, z.core.$loose>]>>;
    tokens: z.ZodObject<{
        access_token: z.ZodString;
        id_token: z.ZodOptional<z.ZodString>;
        token_type: z.ZodString;
        expires_in: z.ZodOptional<z.ZodCoercedNumber<unknown>>;
        scope: z.ZodOptional<z.ZodString>;
        refresh_token: z.ZodOptional<z.ZodString>;
        issuer: z.ZodCatch<z.ZodOptional<z.ZodString>>;
    }, z.core.$strip>;
    expiresAt: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
/** Committed tokens bound to one authorization identity and resolved MCP endpoint. */
export type McpOAuthGrant = z.infer<typeof GrantSchema>;
/**
 * Encode an OAuth payload for the credential provider's opaque record storage.
 * @param payload - validated grant or client information.
 * @returns a JSON-compatible credential record, omitting absent optional fields.
 */
export declare function oauthRecord(payload: McpOAuthGrant | z.infer<typeof ClientRecordSchema>): CredentialRecord;
/**
 * Remove upstream error text while retaining actionable authorization reasons.
 * @param error - caught SDK, transport, or local error.
 * @returns a diagnostic safe to expose in status and tool results.
 */
export declare function safeOAuthError(error: unknown): McpLocalError;
/**
 * Require HTTPS, or HTTP on a loopback host, for an OAuth request or browser page.
 * @param value - URL the client is about to request or publish.
 * @throws McpLocalError for any other scheme or host.
 */
export declare function assertOAuthUrl(value: string | URL): void;
/**
 * Create cancellable OAuth requests that reject redirects and inherit no resource headers.
 * @param signal - authorization or connection lifetime.
 * @param timeoutMs - per-request deadline in milliseconds.
 * @returns the SDK fetch implementation.
 */
export declare function oauthFetch(signal: AbortSignal, timeoutMs: number): FetchLike;
/** Owns an entry's grant and compatible client registrations; never starts interactive authorization. */
export declare class McpOAuthCredentials {
    private readonly ctx;
    private readonly config;
    /** Durable address of the entry's active grant. */
    readonly key: CredentialKey;
    constructor(ctx: Context, config: McpOAuthConfig);
    private store;
    /**
     * Address a registration for the configured client ID and scope.
     * @param serverUrl - resolved MCP endpoint.
     * @param issuer - authorization issuer.
     * @param redirectUri - callback URI.
     * @returns the entry-owned registration key.
     */
    clientKey(serverUrl: string, issuer: string, redirectUri: string): CredentialKey;
    /**
     * Read registration, including its token endpoint authentication method.
     * @param key - registration key.
     * @param issuer - required issuer.
     * @returns registered information, or undefined when absent.
     */
    client(key: CredentialKey, issuer: string): Promise<StoredOAuthClientInformation | undefined>;
    /**
     * Persist registration after checking cancellation under the write lock.
     * @param key - registration key.
     * @param issuer - authorization issuer.
     * @param information - SDK client information.
     * @param signal - attempt lifetime.
     */
    saveClient(key: CredentialKey, issuer: string, information: StoredOAuthClientInformation, signal: AbortSignal): Promise<void>;
    /**
     * Delete a rejected dynamic registration; preserve a configured client identity.
     * @param key - rejected registration key.
     */
    invalidateClient(key: CredentialKey): Promise<void>;
    private parse;
    /**
     * Reject missing grants or incompatible endpoint and OAuth options.
     * @param serverUrl - resolved MCP endpoint.
     * @param signal - caller lifetime.
     * @returns the compatible grant.
     */
    read(serverUrl: string, signal: AbortSignal): Promise<McpOAuthGrant>;
    private refresh;
    /**
     * Bind requests and serialized refresh to one grant identity.
     * @param bound - initial grant.
     * @param signal - connection lifetime.
     * @param send - template-bound resource fetch.
     * @returns passive SDK authentication and fetch callbacks.
     */
    transport(bound: McpOAuthGrant, signal: AbortSignal, send: FetchLike): {
        authProvider: Required<AuthProvider>;
        fetch: FetchLike;
    };
}
export {};
//# sourceMappingURL=oauth-credentials.d.ts.map