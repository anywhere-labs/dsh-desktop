/** The Plugins page text that names Notion; the shared account copy comes from the account surfaces' dictionary. */
import type { McpAccountCopy } from '@deepseek-ai/dsh-mcp-account';
/** Every language the Web app ships. */
type ShippedText = Readonly<Record<'zh' | 'en' | 'ja' | 'es' | 'fr' | 'de' | 'ru' | 'pt', string>>;
/** Notion's account text in every shipped language. */
export declare const COPY: McpAccountCopy<ShippedText>;
export {};
//# sourceMappingURL=locales.d.ts.map