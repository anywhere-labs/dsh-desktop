/** Typed `plugin_market` tool failures converted from the market service's Remote failures. */
import { HarnessError } from '@deepseek-ai/dsh-error';
/**
 * Every {@link PluginMarketError} code:
 * - `PLUGIN_MARKET_INDEX_NOT_FOUND`: the URL is not a configured index source; call `list_indexes`.
 * - `PLUGIN_MARKET_INVALID_INDEX_URL`: a configured index URL is invalid; only the user can fix the source.
 * - `PLUGIN_MARKET_FETCH_FAILED`: the index could not be fetched (network, timeout, redirect, status, or size).
 * - `PLUGIN_MARKET_INVALID_INDEX`: the fetched index document is invalid.
 * - `PLUGIN_MARKET_PLUGIN_NOT_FOUND`: the index lists no plugin with the requested name.
 * - `PLUGIN_MARKET_FAILED`: any other market failure; `cause` is the original error.
 */
export declare const PLUGIN_MARKET_ERROR_CODES: readonly ["PLUGIN_MARKET_INDEX_NOT_FOUND", "PLUGIN_MARKET_INVALID_INDEX_URL", "PLUGIN_MARKET_FETCH_FAILED", "PLUGIN_MARKET_INVALID_INDEX", "PLUGIN_MARKET_PLUGIN_NOT_FOUND", "PLUGIN_MARKET_FAILED"];
/** One {@link PluginMarketError} code. */
export type PluginMarketErrorCode = typeof PLUGIN_MARKET_ERROR_CODES[number];
/** Typed `plugin_market` failure; `code` is one of {@link PLUGIN_MARKET_ERROR_CODES}. */
export declare class PluginMarketError extends HarnessError {
    readonly code: PluginMarketErrorCode;
    constructor(message: string, code: PluginMarketErrorCode, options?: ErrorOptions);
}
/**
 * Convert a market failure for the tool registry. A market `RemoteError` with
 * one of the codes `search` and `entry` reject with keeps its message and
 * becomes the matching code with the Remote failure as `cause`; any other
 * `HarnessError` keeps its identity; anything else is `PLUGIN_MARKET_FAILED`.
 * @param error - the rejection of a market service call.
 * @returns the failure to throw from the tool body.
 */
export declare function pluginMarketToolError(error: unknown): HarnessError;
//# sourceMappingURL=error.d.ts.map