/** Validate and capture the binding names available to one program. */
import { PtcImage } from '@deepseek-ai/dsh-ptc-runtime';
import type { PtcBindingFunction, PtcBindingNamespace, PtcJsonValue, PtcProgramFormat, PtcRunRequest } from '@deepseek-ai/dsh-ptc-runtime';
import { type PtcImageWire } from './json-wire.ts';
import type { BindingResult } from './protocol.ts';
/**
 * Reject unusable namespaces before starting a process.
 * @param request - Host-owned binding declarations.
 * @param programFormat - Evaluator syntax whose internal identifiers must remain reserved.
 * @returns Namespaces keyed by their declared global.
 */
export declare function validateBindings(request: PtcRunRequest, programFormat: PtcProgramFormat): Map<string, PtcBindingNamespace>;
/**
 * Invoke a host binding and encode its lossless result.
 * @param binding - Current evaluation's function, absent if it was removed.
 * @param args - Validated JSON arguments detached from the program.
 * @param image - Registers host-issued images with the owning process.
 * @returns Flat binding data; unavailable bindings and invalid results reject.
 */
export declare function invokeBinding(binding: PtcBindingFunction | undefined, args: PtcJsonValue, image?: (value: PtcImage) => PtcImageWire): Promise<BindingResult>;
//# sourceMappingURL=bindings.d.ts.map