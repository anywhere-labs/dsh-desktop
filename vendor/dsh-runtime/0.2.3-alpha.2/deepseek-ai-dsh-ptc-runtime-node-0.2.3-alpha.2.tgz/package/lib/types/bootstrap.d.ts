/**
 * Output capture, result encoding, and host binding proxies over the process channel.
 * @module @deepseek-ai/dsh-ptc-runtime-node/src/bootstrap
 */
import { type InspectOptions } from 'node:util';
import type { PtcJsonValue } from '@deepseek-ai/dsh-ptc-runtime';
import type { HostMethods, ProgramResult, ProgramBootData } from './protocol.ts';
import { type PtcImageWire } from './json-wire.ts';
/** Text and the original JSON data associated with one binding result. */
export interface BindingInspection {
    /** Detached data used to detect changes before selecting the text. */
    snapshot: PtcJsonValue;
    /** Host-authored text for direct inspection of the unchanged value. */
    text: string;
}
/** Node formatting options shared with the runtime-owned Image hook. */
export interface ImageInspectOptions extends InspectOptions {
    /** Primitive token retained by Node when passing options to a formatter in another VM context. */
    ptcImageCollector?: symbol;
}
/**
 * A writable stream's `write` slot, as the bootstrap patches it (see
 * {@link captureStreamWrites}). Method-typed so the real
 * `process.stdout`/`process.stderr` (narrower chunk parameters) remain
 * assignable.
 */
export interface PatchableStream {
    write(chunk: unknown, ...rest: unknown[]): boolean;
}
/**
 * Ordered text capture under the shared outer JSON-byte budget, delivered to
 * a sink as each item lands (the real sink sends text to the host eagerly,
 * so captured output survives a mid-run termination). It includes the log
 * array syntax and string escaping in its accounting. Once exhausted it emits
 * the fitting prefix and reports truncation once; execution continues.
 */
export declare class LogBuffer {
    private bytes;
    private entries;
    private truncated;
    private readonly sink;
    private readonly onLimit;
    private readonly maxBytes;
    constructor(maxBytes: number, sink: (text: string) => void, onLimit?: () => void);
    /**
     * Emit text to the sink, charging it against the budget (drops + marks once exhausted).
     * @param text - the captured text to deliver.
     */
    push(text: string): void;
    /** Discard further output after the host exhausts the combined text and image budget. */
    discard(): void;
    /** Whether captured text has exceeded the shared output budget. */
    get overflowed(): boolean;
}
/**
 * Render arguments without depth, array-length or string-length previews and emit registered images in order.
 * @param logs - the buffer every rendered line is pushed into.
 * @param images - Image identities owned by the execution process.
 * @param emitImage - Emits a registered image in the current evaluation.
 * @param inspections - Process-owned text associated with original binding result identities.
 * @returns The program's inspect function and its matching Image collection hook.
 * @throws If object formatting fails; preceding arguments remain visible.
 */
export declare function makeInspect(logs: Pick<LogBuffer, 'push' | 'overflowed'>, images: Pick<WeakMap<object, string>, 'get'>, emitImage: (id: string) => void, inspections?: Pick<WeakMap<object, BindingInspection>, 'get'>): {
    inspect: (...args: unknown[]) => void;
    collectImage: (image: object, options: ImageInspectOptions) => void;
};
/**
 * Redirect a stream's `write` into the log buffer (the program-visible
 * `process.stdout`/`process.stderr` in the Node child), so raw writes land in emission order
 * alongside console output instead of racing down a pipe. It preserves Node's optional callback
 * contract: the callback runs asynchronously after admission, even when the log budget drops
 * the write.
 *
 * @param logs - the buffer captured writes are pushed into.
 * @param stream - the stream whose `write` slot is patched.
 * @returns the restore function (the in-process tests un-patch; the real
 *   child never needs to).
 */
export declare function captureStreamWrites(logs: Pick<LogBuffer, 'push'>, stream: PatchableStream): () => void;
/**
 * Prepare the program's completion value for the run result. Only lossless
 * JSON crosses, and a value that does not fit even without captured output
 * reports `output-limit`; the host revalidates hostile traffic and
 * remains authoritative for native pipe writes the program shim cannot observe.
 *
 * @param value - the program's completion value.
 * @param availableBytes - bytes available to the completion or diagnostic.
 * @param maxOutputBytes - the configured cap named in an overflow diagnostic.
 * @returns the result fragment: `{}` for `undefined`, else a flat wire `{ value }`.
 */
export declare function prepareCompletion(value: unknown, availableBytes: number, maxOutputBytes?: number): ProgramResult;
/**
 * Prepare a thrown program value, including cross-realm errors, without sending
 * an unbounded stack or string across the process channel.
 * @param error - the value thrown by the program.
 * @param availableBytes - bytes available to the completion or diagnostic.
 * @returns a bounded exception preserving its kind and indicating truncated diagnostics.
 */
export declare function prepareException(error: unknown, availableBytes: number): ProgramResult;
/** Constructor type for one program-visible binding rejection class. */
export type BindingErrorConstructor = new (memberName: string, message: string) => Error;
/**
 * Materialize the real error constructor declared by one namespace.
 * @param descriptor - program-global class name and member-name property.
 * @returns the constructor injected into the program and used for rejections.
 */
export declare function makeBindingErrorClass(descriptor: {
    name: string;
    memberNameProperty: string;
}): BindingErrorConstructor;
/**
 * Build null-prototype binding globals with namespace-specific rejection classes.
 * @param data - Namespace declarations injected into the program.
 * @param host - Evaluation-scoped remote binding calls.
 * @param errorClasses - Constructors shared with program globals, resolved per invocation.
 * @param inspections - Required process-owned inspection text indexed by decoded result identity.
 * @param decodeImage - Optional decoder for host-issued images; image tokens are rejected when absent.
 * @param isImage - Optional recognition of decoded images; omission restricts inspection snapshots to JSON data.
 * @returns One namespace object per declaration.
 */
export declare function makeNamespaces(data: Pick<ProgramBootData, 'namespaces'>, host: Pick<HostMethods, 'invoke'>, errorClasses: Pick<ReadonlyMap<string, BindingErrorConstructor>, 'get'>, inspections: Pick<WeakMap<object, BindingInspection>, 'set'>, decodeImage?: (wire: PtcImageWire) => PtcJsonValue, isImage?: (value: object) => boolean): Record<string, unknown>[];
//# sourceMappingURL=bootstrap.d.ts.map