/** Combined byte accounting for retained program output. */
import type { PtcOutput, PtcJsonValue, PtcRunFailure, PtcRunResult } from '@deepseek-ai/dsh-ptc-runtime';
/** One run's combined outer-output ledger; binding values never enter it. */
export declare class OutputLedger {
    private readonly maxBytes;
    private bytes;
    private entries;
    truncated: boolean;
    constructor(maxBytes: number);
    /** Admit one ordered text or image entry against the combined output budget. */
    admit(entry: PtcOutput, sink: PtcOutput[]): boolean;
    /** Finalize a successful absent-or-JSON completion against the combined cap. */
    success(output: PtcOutput[], value?: PtcJsonValue): PtcRunResult;
    /** Prioritize the terminal diagnostic without changing its failure kind. */
    failure(output: PtcOutput[], error: PtcRunFailure): PtcRunResult;
    /** Keep an ordered prefix after reserving bytes for the completion or diagnostic. */
    private retain;
}
//# sourceMappingURL=output-ledger.d.ts.map