/**
 * Records the last process event seen before runtime teardown, for the SDK
 * server's liveness failures. The launcher owns signal and failure handling;
 * this module only observes.
 *
 * @module @deepseek-ai/dsh-sdk-jsonrpc-server/process-events
 */
import { type Context, type Fiber } from '@deepseek-ai/cordis';
import type { Readable } from 'node:stream';
import type { RuntimeObservation } from './server.ts';
/** The slice of `process` this module observes; `node:events` emitters satisfy it. */
export interface RuntimeProcessEvents {
    listenerCount(event: string): number;
    prependListener(event: string, listener: (...args: unknown[]) => void): unknown;
    off(event: string, listener: (...args: unknown[]) => void): unknown;
}
/**
 * Observe runtime disposal, termination signals, fatal failures, and input end until `ctx` is disposed.
 * A signal or unhandled rejection is observed only when another listener already
 * handles it, because the first listener for those events disables Node's default
 * termination. Recording stops once runtime disposal begins, so an event caused by
 * the teardown does not replace the one before it.
 * @param ctx - context that owns the listeners.
 * @param runtimeFiber - fiber whose disposal ends the whole runtime.
 * @param processEvents - process event source.
 * @param input - protocol input whose end is recorded as `stdin closed`.
 * @returns whether runtime disposal is in progress, and the last event recorded before it began.
 */
export declare function observeRuntime(ctx: Context, runtimeFiber: Fiber, processEvents: RuntimeProcessEvents, input: Readable): RuntimeObservation;
//# sourceMappingURL=process-events.d.ts.map