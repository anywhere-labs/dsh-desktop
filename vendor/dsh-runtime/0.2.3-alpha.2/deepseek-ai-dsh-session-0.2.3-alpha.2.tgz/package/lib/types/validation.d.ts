/**
 * Session header, seed-event, and inherited-cut validation shared by Session
 * construction and log validation.
 * @module @deepseek-ai/dsh-session/validation
 */
import { SessionLogOffset } from './types.ts';
import type { SessionEvent, SessionHeader, SessionHeaderMeta, SessionId, SessionSeedEventState } from './types.ts';
import { SurfaceManager } from './surface.ts';
import type { SessionMessageProjection } from './surface.ts';
/**
 * Validate and freeze one exclusively owned persistence header in place.
 * @param id - Session identity the header must carry.
 * @param input - decoded header, owned by the caller and frozen in place.
 * @returns the validated, deeply frozen header.
 * @throws when `input` is not a plain JSON record or fails header validation.
 */
export declare function validateRestoredSessionHeader(id: SessionId, input: unknown): SessionHeader;
/**
 * Detach, validate, and freeze the creation metadata published by a session.
 * @param id - Session identity the header must carry.
 * @param source - borrowed header; omitted synthesizes a minimal current-format header.
 * @returns a validated, deeply frozen copy.
 * @throws when `source` is not losslessly JSON-serializable or fails header validation.
 */
export declare function snapshotSessionHeader(id: SessionId, source?: SessionHeader): SessionHeader;
/**
 * Validate only the event-specific invariants needed to safely replay a message.
 * @param event - candidate event record; events that produce no message pass unchecked.
 * @param subject - description of the event that prefixes each error message.
 * @throws when a message event lacks its message or has an invalid role, source, or content.
 */
export declare function assertMessageEventShape(event: Record<string, unknown>, subject: string): void;
/** Construction mode: `snapshot` borrows events like `Session.create`; an event state adopts them like `Session.fromRestore`. */
export type SessionSeedMode = 'snapshot' | SessionSeedEventState;
/**
 * Validate one seed event's lossless JSON form, envelope, and position.
 * @param source - borrowed (`snapshot`) or adopted event at `index`.
 * @param index - position in the seed.
 * @param mode - whether the event is copied before validation.
 * @returns the detached copy in `snapshot` mode, otherwise `source`.
 * @throws when the event is not losslessly JSON-serializable, has an invalid envelope, or its seq is not `index`.
 */
export declare function validateSeedEvent(source: SessionEvent, index: number, mode: SessionSeedMode): SessionEvent;
/**
 * Admit one validated seed event through the surface transition.
 * @param event - validated event at `index`, not yet in the log `surface` reads.
 * @param index - position in the seed.
 * @param surface - incremental surface validator carrying the message interpreters.
 * @throws `invalid seed event at index <index>: …` when the surface rejects the event.
 */
export declare function replaySurfaceEvent(event: SessionEvent, index: number, surface: SurfaceManager): void;
/**
 * Validate seed events in order and push each accepted event into `log`, which `surface` reads.
 * Each event passes {@link validateSeedEvent} and then {@link replaySurfaceEvent} before it enters `log`.
 * @param seed - borrowed or adopted events.
 * @param mode - `snapshot` pushes deeply frozen copies; an event state pushes the adopted events.
 * @param log - empty log that `surface` was constructed over.
 * @param surface - incremental surface validator carrying the message interpreters.
 * @throws on the first invalid event; `log` then holds the accepted prefix.
 */
export declare function acceptSeedEvents(seed: readonly SessionEvent[], mode: SessionSeedMode, log: SessionEvent[], surface: SurfaceManager): void;
/**
 * Validate the inherited cut of a constructed log against its validated header.
 * @param header - validated header.
 * @param hasSeed - whether construction received a seed (an empty seed counts).
 * @param supplied - inherited event count supplied by the caller.
 * @param log - accepted seed events.
 * @param mode - construction mode; only `snapshot` requires a fresh seeded seed to equal its inherited prefix or mark its cut.
 * @returns the inherited event count, 0 when omitted for an unseeded header.
 * @throws when the cut is missing, inconsistent with `isSeeded`, beyond the log, or not the final inherited marker.
 */
export declare function validateInheritedCut(header: SessionHeader, hasSeed: boolean, supplied: SessionLogOffset | undefined, log: readonly SessionEvent[], mode: SessionSeedMode): SessionLogOffset;
/**
 * Whether a fresh fork child must append its tagged inherited marker: the
 * header is seeded and the event at the inherited cut is not
 * `session/end-seed { inherited: true }`. A copied ancestor marker earlier in
 * the prefix does not count. Session construction applies this rule to a
 * borrowed seed; a restored log keeps its durable marker.
 * @param header - header of the new Session.
 * @param events - seed events, contiguous from seq 0.
 * @param inheritedEventCount - inherited cut.
 * @returns true when the marker must be appended at seq `events.length`.
 */
export declare function needsInheritedSeedMarker(header: SessionHeader, events: readonly SessionEvent[], inheritedEventCount: SessionLogOffset): boolean;
/** A validated session log: header, inherited cut, and events. */
export interface CheckSessionLogResult {
    /** Validated, deeply frozen header. */
    readonly header: SessionHeader;
    /** Inherited event count validated against `header` and `events`. */
    readonly inheritedEventCount: SessionLogOffset;
}
/**
 * Validate a header, seed, and inherited cut in Session construction order.
 * An event-state `mode` validates the header first; `snapshot` validates the
 * events first. Each event passes the surface transition before the next is read.
 * @param id - Session identity the header must carry.
 * @param header - borrowed (`snapshot`) or adopted header; omitted synthesizes a minimal header in `snapshot` mode.
 * @param seed - borrowed or adopted events; omitted means no seed.
 * @param inheritedEventCount - exact fork-inherited prefix length; required when the header is seeded.
 * @param mode - construction mode.
 * @param events - empty log that `surface` was constructed over; receives the accepted events.
 * @param surface - incremental surface validator carrying the message interpreters.
 * @returns the validated header and inherited cut.
 * @throws on the first invalid header field, event envelope, sequence, surface transition, or inherited cut.
 */
export declare function checkSessionLog(id: SessionId, header: SessionHeader | undefined, seed: readonly SessionEvent[] | undefined, inheritedEventCount: SessionLogOffset | undefined, mode: SessionSeedMode, events: SessionEvent[], surface: SurfaceManager): CheckSessionLogResult;
/**
 * Validate a header and event log with every check that constructing a Session
 * performs, in the same order and with the same errors, without constructing one.
 * Without `eventState` the checks match `Session.create`: events and header are
 * copied before validation. With it they match `Session.fromRestore`, which
 * validates and deeply freezes `header` in place and leaves events uncopied.
 * Embedded Assistant streams are not replayed.
 * @param header - header whose `id` is the Session identity.
 * @param events - seed events; omitted means no seed.
 * @param inheritedEventCount - exact fork-inherited prefix length; required when `header.isSeeded`.
 * @param eventState - aliasing state of adopted events; omitted for borrowed events.
 * @param projections - message interpreters for plugin-owned events.
 * @throws on the first invalid header field, event envelope, sequence, surface transition, or inherited cut.
 */
export declare function validateSessionLog(header: SessionHeader, events?: readonly SessionEvent[], inheritedEventCount?: SessionLogOffset, eventState?: SessionSeedEventState, projections?: readonly SessionMessageProjection[]): void;
/**
 * Build the header of a new Session: the current format version, `createdAt`
 * (the current time when omitted), `isSeeded` (false when omitted), and the
 * other supplied fields. The result is not validated; Session construction validates it.
 * @param id - identity of the new Session.
 * @param meta - caller-supplied storage fields.
 * @returns a fresh, unfrozen header.
 */
export declare function buildSessionHeader(id: SessionId, meta?: SessionHeaderMeta): SessionHeader;
//# sourceMappingURL=validation.d.ts.map