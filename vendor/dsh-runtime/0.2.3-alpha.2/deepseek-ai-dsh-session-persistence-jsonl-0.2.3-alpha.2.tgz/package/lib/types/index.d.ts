/**
 * JSONL durable session-persistence backend. It stores a header and contiguous
 * events in immutable generation files under one directory per session and serves the handle-based
 * `SessionPersistence` API: `create`/`open` return per-session handles, and
 * every read validates the same fail-closed storage contract.
 * @module @deepseek-ai/dsh-session-persistence-jsonl
 */
import { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { SessionPersistence, type SessionAccess, type SessionHandle, type SessionHandleReadResult, type SessionPersistenceCreateOptions, type SessionPersistenceListOptions, type SessionPersistenceOpenOptions, type SessionPersistenceSnapshot, type SessionPersistenceStatOptions, type SessionPersistenceRevision as PersistenceRevision } from '@deepseek-ai/dsh-session-persistence';
import { JsonlBackendTracker, JsonlSessionHandle } from './storage.ts';
import { SessionWriteLease } from './lease.ts';
import type { SessionEvent, SessionId, SessionHeader, SessionLogOffset as SessionLogOffsetType } from '@deepseek-ai/dsh-session';
import { type JsonlCompression } from './format.ts';
/** Logical JSONL history retained until its destination commits under write ownership. */
interface LegacySessionSnapshot {
    readonly header: SessionHeader;
    readonly inheritedEventCount: SessionLogOffsetType;
    readonly events: readonly SessionEvent[];
}
/** Prepared legacy history whose related sources are checked before destination publication. */
interface PreparedLegacySession {
    commit(publish: (snapshot: LegacySessionSnapshot) => Promise<void>): Promise<void>;
}
export type { JsonlCompression } from './format.ts';
/** Loader schema for the JSONL artifact's physical encoding. */
export declare const JsonlCompressionSchema: z<JsonlCompression>;
/** Plugin config for the JSONL backend's root, physical encoding, and listing concurrency. */
export interface Config {
    /**
     * Root directory for all session files. Required (no default): a default of
     * `process.cwd()` would scatter session files as the process's cwd changes
     * (bash calls, subprocesses). Sessions group under human-readable project
     * directories, then per-session directories. An existing root must be a
     * readable directory; an absent root is created on first materialization.
     */
    root: string;
    /** Physical encoding; defaults to checksummed Zstandard frames. */
    compression?: JsonlCompression;
    /**
     * Maximum directory, header, and stat reads in flight across all concurrent
     * listings of this backend (`list()`, the root encoding check, and historical
     * fingerprints). Defaults to 3.
     */
    listConcurrency?: number;
}
/** One stored event graph whose producer has established immutable sharing. */
interface FrozenStoredEvents extends SessionHandleReadResult {
    readonly eventState: 'shared-frozen';
}
/** State shared by prepared historical and published current logs. */
interface StoredLogBase extends FrozenStoredEvents {
    readonly meta: SessionHeader;
    readonly tornTruncateTo: number | undefined;
    /** Complete events recovered from the torn final frame; the write path rewrites them durably. */
    readonly recoveredTail: SessionEvent[];
    /** Exact fork-inherited prefix length stored in the header line. */
    readonly inheritedEventCount: SessionLogOffsetType;
    readonly revision: PersistenceRevision;
}
/** A decoded current generation that is already durable. */
interface CurrentStoredLog extends StoredLogBase {
    readonly status: 'current';
}
/**
 * JSONL Session persistence with historical-format migration.
 * Sessions materialize lazily: a created session is
 * visible to this process immediately, reaches disk on its first append or
 * flush, and never existed if the process crashes before that.
 */
export declare class JsonlSessionPersistence extends SessionPersistence {
    config: Config;
    private readonly tracker;
    private root;
    private compression;
    /**
     * Bounds directory, header, and stat I/O across every concurrent listing of
     * this backend (`list()`, the root encoding check, historical fingerprints).
     * Queued tasks of a cancelled listing run and reject at their signal check.
     */
    private readonly listLimit;
    private rootEncodingCheck;
    private readonly generationFormat;
    /**
     * Bounded LRU of parsed, validated stored logs keyed by session id and
     * guarded by the stat-derived revision, so an immediate cold-read handoff
     * (observation then resume) parses the artifact once. Every local mutation
     * for an id invalidates its entry; a foreign write misses through the
     * revision guard.
     */
    private readonly coldLogMemo;
    /**
     * Generation headers observed by the latest complete listing, keyed by
     * source path and guarded by the stat-derived revision, so a listing reads
     * only the first frame of logs whose file changed. Each complete listing
     * replaces the map, which drops deleted paths.
     *
     * Reuse relies on this backend never rewriting a generation's header line
     * in place: publication creates a new file, append grows it, and repair
     * truncates its tail, so every content change moves the revision. The
     * revision is file metadata, not a byte checksum. A reused entry also
     * reuses the path-identity check its first read passed.
     */
    private listedHeaders;
    /** One joinable decode/migration operation per selected historical Session file revision. */
    private readonly migrationPreparations;
    /**
     * @param ctx - context used for scoped diagnostics and filesystem reads.
     * @param config - JSONL root, physical encoding, and listing concurrency.
     * @param tracker - handle bookkeeping; omitted creates bookkeeping for legacy reads.
     */
    constructor(ctx: Context, config: Config, tracker?: JsonlBackendTracker);
    /**
     * Refusal-diagnostics hook: the absolute target path, without touching the filesystem.
     * @param meta - the stored header naming the session and its cwd.
     * @returns the artifact kind and absolute path.
     */
    private locate;
    /**
     * Prepare logical history while the caller retains Session write ownership.
     * @param id - stored Session identity.
     * @param signal - optional cancellation for decoding and destination publication.
     * @returns a commit operation that validates related sources before publishing the history.
     */
    prepare(id: SessionId, signal?: AbortSignal): Promise<PreparedLegacySession>;
    /**
     * Check whether a JSONL artifact occupies the Session identity.
     * @param id - stored Session identity.
     * @returns whether the artifact exists.
     */
    hasStoredJsonl(id: SessionId): Promise<boolean>;
    /**
     * Create a new stored session and take its write ownership. The session is
     * visible to this process immediately; the physical artifact appears on the
     * first append or flush. A fork source copies its complete history into
     * the child artifact before creation resolves.
     * @param header - the immutable header to store; must be losslessly
     *   JSON-serializable with a non-negative safe-integer `createdAt`.
     * @param options - optional cancellation, inherited prefix length, and fork source.
     * @returns the owned write handle.
     */
    create(header: SessionHeader, options?: SessionPersistenceCreateOptions): Promise<SessionHandle>;
    /**
     * Open an existing stored session for `read` or single-writer `write`.
     * @param id - the stored session to open.
     * @param access - `read` (no ownership) or `write` (atomic in-process claim).
     * @param options - optional cancellation.
     * @returns the open handle.
     */
    open(id: SessionId, access: SessionAccess, options?: SessionPersistenceOpenOptions): Promise<SessionHandle>;
    /**
     * Flush every active write handle in one durability barrier; see the seam
     * contract.
     * @returns resolution once every write handle active at the call has flushed.
     */
    flush(): Promise<void>;
    /**
     * Observe one stored session without reading its event log.
     * @param id - the stored session to observe.
     * @param options - optional cancellation.
     * @returns the snapshot (`sizeBytes` carries the physical artifact size), or
     *   `undefined` when the session does not exist.
     */
    stat(id: SessionId, options?: SessionPersistenceStatOptions): Promise<SessionPersistenceSnapshot | undefined>;
    /**
     * List every stored session visible to this process: materialized artifacts
     * plus this process's created-but-unmaterialized sessions.
     * @param options - optional cancellation.
     * @returns one snapshot per session, in no promised order.
     */
    list(options?: SessionPersistenceListOptions): Promise<readonly SessionPersistenceSnapshot[]>;
    /** Resolve and read one stored log, refusing loudly when the artifact is absent. */
    private requireStoredLog;
    /** Probe the memo and otherwise decode one historical generation under backend cancellation. */
    private loadStoredMigration;
    /** Await shared preparation for one caller and abort it only after its last waiter leaves. */
    private waitForPreparation;
    /** Decode one historical generation without publishing a successor. */
    private prepareStoredMigration;
    /** Publish a prepared historical log before granting write access. */
    private publishStoredMigration;
    /** Translate generation-layer failures into the persistence seam's error vocabulary. */
    private generationFailure;
    /**
     * Read, parse, and validate one stored log as the current logical prefix.
     * @param path - the artifact file to read.
     * @param expectedId - the session identity the artifact must carry.
     * @param signal - optional cancellation for the stat/read/decode work.
     * @returns the validated stored log with any torn-tail truncation point.
     */
    readStoredLog(path: string, expectedId: SessionId, signal?: AbortSignal): Promise<CurrentStoredLog>;
    /** Decode and memoize one already-stable current physical snapshot. */
    private decodeStoredLog;
    /** Insert one parsed log into the bounded handoff cache. */
    private memoizeStoredLog;
    /**
     * Resolve a session's current-generation log path.
     * @param id - the stored session to locate.
     * @param signal - optional cancellation for the directory scans.
     * @returns the current artifact path, or `undefined` while only a historical generation exists.
     */
    resolveCurrentLog(id: SessionId, signal?: AbortSignal): Promise<string | undefined>;
    /**
     * Durably append one validated batch; lazily materializes on the first write.
     * @param header - the session's stored header.
     * @param events - the validated contiguous batch, in seq order.
     * @param isMaterialized - whether the session already has a durable artifact.
     * @param inheritedEventCount - the exact fork-inherited prefix length written into a materializing header line.
     */
    persistBatch(header: SessionHeader, events: readonly SessionEvent[], isMaterialized: boolean, inheritedEventCount: SessionLogOffsetType): Promise<void>;
    /**
     * Materialize a header-only artifact for an explicitly durable empty session.
     * @param header - the session's stored header.
     * @param inheritedEventCount - the exact fork-inherited prefix length written into the header line.
     */
    persistHeader(header: SessionHeader, inheritedEventCount: SessionLogOffsetType): Promise<void>;
    /**
     * Truncate a torn physical tail durably before this session's first new append.
     * @param header - the session's stored header.
     * @param truncateTo - the byte offset the artifact is truncated to.
     */
    truncateTornTail(header: SessionHeader, truncateTo: number): Promise<void>;
    /**
     * Whether this process still tracks a created-but-unmaterialized session.
     * @param id - the session to test.
     * @returns true while the pending entry exists.
     */
    hasPendingSession(id: SessionId): boolean;
    /**
     * Release one handle's backend bookkeeping on close.
     * @param handle - the closing handle.
     * @param materialized - whether the session reached durable storage.
     */
    releaseHandle(handle: JsonlSessionHandle, materialized: boolean): void;
    /**
     * Acquire the session directory's kernel write lock; the kernel holds it
     * until the handle's close releases the descriptor, including on process death.
     * @param id - the session the lock guards.
     * @param cwd - header cwd used to derive the directory for a fresh session.
     * @param dir - the resolved directory of an existing artifact, when known.
     * @returns the held lock.
     */
    private acquireLease;
    /**
     * Acquire the cross-process write lock for a materializing created session,
     * called by its handle immediately before the first log bytes publish.
     * @param header - the session's stored header (its cwd derives the directory).
     * @returns the held lock.
     */
    acquireWriteLease(header: SessionHeader): Promise<SessionWriteLease>;
    /** Decode complete frames and retain complete JSONL records from a torn final frame. */
    private readZstdPrefix;
    /** Enumerate selected physical generations without interpreting their headers or bodies. */
    private listGenerations;
    /**
     * Apply `task` to every Session directory through the shared listing
     * limiter. Results and the first failure follow the sequential
     * project-then-directory order; a project whose listing fails ends the
     * traversal after the directories of the projects before it.
     * @param task - per-directory operation; must not wait on the listing limiter.
     * @param signal - optional cancellation for directory listings.
     * @returns per-directory results in traversal order.
     */
    private mapSessionDirectories;
    /** Historical logical events depend on the corpus, including members with unreadable headers. */
    private historicalCorpusRevision;
    /**
     * Read every listed Session's generation header with one stat per generation.
     * @param signal - optional cancellation.
     * @returns the readable artifacts, and the revision of every generation
     *   (`missing` when it vanished) for {@link corpusDigest}.
     */
    private listArtifacts;
    /** Read one listed generation header; an unsupported or corrupt log is not a listed Session. */
    private readListedHeader;
    /** Read and translate one selected generation header without inspecting its body. */
    private readGenerationHeader;
    /** Convert format-catalog string identities to current branded Session metadata. */
    private currentHeader;
    /** Atomically write the header line + first batch (temp-write, fsync, publish). */
    private materialize;
    private materializePosix;
    private materializeWin32;
    private rejectExistingLog;
    private writeSyncedTempFile;
    /** Encode the header and first batch without combining their frame boundaries. */
    private encodeMaterialization;
    /** Encode one durable append batch in the configured physical representation. */
    private encodeEventBatch;
    /** fsync a POSIX directory so a just-created/renamed entry is crash-durable. */
    private syncDirPosix;
    /**
     * Append and fsync event lines. On a partial write or sync failure, restore the
     * previous size before rethrowing because the unchanged cursor will retry the
     * batch; leaving partial bytes would create duplicate sequence numbers.
     */
    private appendLines;
    private rollbackAppend;
    /** Truncate the log file to `offset` bytes and fsync (discard the crash tail). */
    private repair;
    /**
     * Read the first newline-terminated line of a file without loading the whole
     * file. Returns undefined if the file is empty or has no complete first line.
     * Reads in bounded chunks so a huge log costs only the header read.
     */
    private readFirstLine;
    /** Read only the header frame; compression failures reject as corruption, while I/O and cancellation propagate. */
    private readFirstZstdLine;
    /** Select the numerically highest canonical generation in one Session directory. */
    private resolveGenerationInDirectory;
    /** Find the unique authoritative generation for an id across project directories. */
    private findLog;
    /** Require an existing configured root to be a readable directory. */
    private assertUsableRoot;
    /** Reject metadata that does not identify the selected physical log. */
    private assertStoredIdentity;
    /** Validate a supported historical header against the selected source path. */
    private validateSourceIdentity;
    /**
     * Whether two path spellings resolve to the same physical file. This admits
     * case aliases on case-insensitive filesystems without weakening identity
     * checks on case-sensitive stores.
     */
    private sameFile;
    /** The human-readable project directories under the configured root. */
    private listProjectDirs;
    /** List session-owned directories and reject the obsolete flat-file layout. */
    private listSessionDirs;
    /** Reject a root that already belongs to the other physical encoding. */
    private ensureRootEncoding;
    private checkRootEncoding;
    private rejectLegacyFlatArtifact;
    private rejectOppositeArtifact;
    /** Return the highest canonical generation encoded with the other configured suffix. */
    private findOppositeGenerationInDirectory;
    private oppositeCompression;
    private encodingMismatch;
    private legacyLayout;
    private exists;
    private assertLogParentAllowsAbsence;
}
/** JSONL persistence plugin label. */
export declare const name = "session-persistence-jsonl";
/** Loader schema for the backend's root, physical encoding, and listing concurrency. */
export declare const Config: z<Config>;
/**
 * Mount persistence with live routing and handles retained through the
 * consumer unloads triggered by removing this provider. Consumers must own
 * cleanup in their injecting scope; concurrent root disposal is not ordered.
 * @param ctx - the owning plugin context.
 * @param config - the storage root, physical encoding, and listing concurrency.
 * @returns resolves when the service is ready.
 */
export declare function apply(ctx: Context, config: Config): Promise<void>;
//# sourceMappingURL=index.d.ts.map