/** Ordered live-event batching shared by the persistence backends. @module */
import type { SessionEvent } from '@deepseek-ai/dsh-session';
/** Backend-owned serialization and commit operations for a live batch. */
interface LiveWriteOptions {
    delayMs: number;
    maxEvents: number;
    enqueue(operation: () => Promise<void>): Promise<unknown>;
    persist(batch: readonly SessionEvent[]): Promise<void>;
    retry(error: unknown): boolean;
    canSchedule(): boolean;
}
/** Retains admitted copies until commit, pausing automatic retries after failure. */
export declare class LiveWriteBuffer {
    private readonly options;
    private events;
    private timer;
    private draining;
    private paused;
    private report;
    constructor(options: LiveWriteOptions);
    /** Number of admitted events awaiting commit. */
    get length(): number;
    /** Whether a durability drain is in progress. */
    get active(): boolean;
    /**
     * Admit exclusively owned event copies and schedule their durability deadline.
     * @param events - backend-validated or snapshotted live events.
     * @param report - observes automatic write failures.
     */
    append(events: readonly SessionEvent[], report: (error: unknown) => void): void;
    /**
     * Commit all admitted events in order; concurrent callers join one drain.
     * @returns durability completion, rejecting with the backend's write failure.
     */
    drain(): Promise<void>;
    private cancelTimer;
    private commit;
}
export {};
//# sourceMappingURL=buffer.d.ts.map