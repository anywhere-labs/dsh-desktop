import { SessionLogOffset } from '@deepseek-ai/dsh-session';
import type { SessionEvent, SessionHeader } from '@deepseek-ai/dsh-session';
import type { SessionFormatEvent } from '@deepseek-ai/dsh-session-format';
/** SQLite's logical format version; a new Session version requires an explicit storage migration. */
export declare const SQLITE_SESSION_FORMAT_VERSION = 4;
/**
 * Read current logical Session metadata from a stored JSON object.
 * @param value - untrusted SQLite header parsed from JSON.
 * @returns validated metadata with an explicit delegation depth.
 */
export declare function decodeHeader(value: unknown): SessionHeader;
/**
 * Preserve the existing seeded/cut checks before reserving or importing a Session.
 * @param metadata - detached creation or import header.
 * @param inheritedEventCount - exact inherited prefix, required for seeded Sessions.
 * @returns normalized logical metadata for SQLite JSON storage.
 */
export declare function materializeHeader(metadata: SessionHeader, inheritedEventCount?: SessionLogOffset): SessionHeader;
/**
 * Read a logical event envelope; native payload validation remains in Session adoption.
 * Source coordinates stay as arrays and are never decoded from JSONL ranges.
 * @param value - untrusted SQLite event parsed from JSON.
 * @returns logical event for vocabulary validation and Session adoption.
 */
export declare function decodeEvent(value: unknown): SessionFormatEvent & SessionEvent;
//# sourceMappingURL=codec.d.ts.map