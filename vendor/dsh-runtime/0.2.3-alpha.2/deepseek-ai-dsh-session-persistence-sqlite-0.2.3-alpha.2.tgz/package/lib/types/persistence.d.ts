import type { Context } from '@deepseek-ai/cordis';
import type { Config } from './index.ts';
import { SessionPersistence } from '@deepseek-ai/dsh-session-persistence';
import type { SessionAccess, SessionPersistenceCreateOptions, SessionPersistenceOpenOptions, SessionPersistenceStatOptions, SessionPersistenceListOptions, SessionPersistenceSnapshot } from '@deepseek-ai/dsh-session-persistence';
import { SessionId } from '@deepseek-ai/dsh-session';
import type { SessionHeader } from '@deepseek-ai/dsh-session';
import { SessionWriteLease } from './lease.ts';
import type { JsonlBackend } from './migration.ts';
/** Routes the existing logical Session API; Segment identifiers never cross this service. */
export declare class SqliteSessionPersistence extends SessionPersistence {
    private readonly directory;
    private readonly sqlite;
    private readonly migration;
    private readonly rootPath;
    private readonly jsonl;
    private readonly listLimit;
    private readonly publishedRoutes;
    constructor(ctx: Context, owner: Context, config: Config, jsonl: JsonlBackend);
    /**
     * Initialize SQLite before a Session is created or opened.
     * @returns resolves once SQLite is ready.
     */
    start(): Promise<void>;
    /**
     * Claim the existing artifact lock before a new Session first commits.
     * @param header - pending Session metadata.
     * @returns the held artifact lock.
     */
    protected acquireCreationLease(header: SessionHeader): Promise<SessionWriteLease>;
    private markerPath;
    /** Decode one routing record and require it to name `id` in the configured database. */
    private readMarker;
    private selected;
    /**
     * Atomically publish durable backend selection once per Session in this provider after the database commit.
     * @param id - committed Session identity.
     */
    protected publish(id: SessionId): Promise<void>;
    private syncDirectory;
    create(header: SessionHeader, options?: SessionPersistenceCreateOptions): Promise<import("./sqlite.ts").SqliteSessionHandle>;
    open(id: SessionId, access: SessionAccess, options?: SessionPersistenceOpenOptions): Promise<import("@deepseek-ai/dsh-session-persistence").SessionHandle>;
    stat(id: SessionId, options?: SessionPersistenceStatOptions): Promise<SessionPersistenceSnapshot | undefined>;
    list(options?: SessionPersistenceListOptions): Promise<SessionPersistenceSnapshot[]>;
    flush(): Promise<void>;
}
//# sourceMappingURL=persistence.d.ts.map