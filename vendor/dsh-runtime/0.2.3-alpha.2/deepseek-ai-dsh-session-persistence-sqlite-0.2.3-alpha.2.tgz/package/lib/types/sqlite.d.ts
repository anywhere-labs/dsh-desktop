import type { Branded } from '@deepseek-ai/dsh-brand';
import type { DatabaseSync } from 'node:sqlite';
import type { Context } from '@deepseek-ai/cordis';
import { z } from 'zod';
import { SessionLogOffset, SessionId as sessionIdentity } from '@deepseek-ai/dsh-session';
import type { SessionEvent, SessionHeader, SessionId } from '@deepseek-ai/dsh-session';
import type { SessionAccess, SessionHandle, SessionHandleAppendOptions, SessionHandleFlushOptions, SessionHandleReadOptions, SessionPersistenceCreateOptions, SessionPersistenceSnapshot } from '@deepseek-ai/dsh-session-persistence';
import type { FrameCompression } from './frame.ts';
/** Private Segment storage database schema version; incompatible versions are refused, never reset. */
export declare const SCHEMA_VERSION = 1;
type SegmentId = Branded<'SessionSegmentId'>;
declare const metadata: z.ZodObject<{
    header: z.ZodString;
    event_count: z.ZodNumber;
    base_seq: z.ZodNumber;
    tail_segment_uuid: z.ZodPipe<z.ZodString, z.ZodTransform<SegmentId, string>>;
    inherited_count: z.ZodNumber;
}, z.core.$strip>;
declare const segmentRow: z.ZodUnion<readonly [z.ZodObject<{
    parent_segment_uuid: z.ZodNull;
    parent_end_seq: z.ZodNull;
    base_seq: z.ZodLiteral<0>;
    segment_uuid: z.ZodPipe<z.ZodString, z.ZodTransform<SegmentId, string>>;
    event_count: z.ZodNumber;
}, z.core.$strip>, z.ZodObject<{
    parent_segment_uuid: z.ZodPipe<z.ZodString, z.ZodTransform<SegmentId, string>>;
    parent_end_seq: z.ZodNumber;
    base_seq: z.ZodNumber;
    segment_uuid: z.ZodPipe<z.ZodString, z.ZodTransform<SegmentId, string>>;
    event_count: z.ZodNumber;
}, z.core.$strip>]>;
type Metadata = z.infer<typeof metadata>;
type Segment = z.infer<typeof segmentRow>;
/**
 * Whether a filesystem rejection reports a missing path.
 * @param error - rejected value from a `node:fs` operation.
 * @returns true for `ENOENT`.
 */
export declare function isAbsent(error: unknown): boolean;
/** Resolved settings and provider callbacks for one SQLite Segment store. */
export interface SqliteStoreOptions {
    /** Absolute database path. */
    readonly path: string;
    /** Resolved JSONL root holding the per-Session write-lock directories and `.segments` routing records. */
    readonly legacyRoot: string;
    /** Physical frame encoding for new writes; stored frames decode by their own codec regardless. */
    readonly compression: FrameCompression;
    /** Maximum events per new frame; stored frames keep their written size. */
    readonly frameEvents: number;
    /** Publish a Session's routing record after its first commit. */
    readonly publish: (id: SessionId) => Promise<void>;
    /** Claim a new Session across the provider's physical backends. */
    readonly acquireCreationLease: (header: SessionHeader) => Promise<{
        release(): Promise<void>;
    }>;
    /** Report a background live-write failure; the Session's next durability barrier retries and rejects. */
    readonly report: (id: SessionId, error: unknown) => void;
}
/** Trace persistence over private predecessor-linked Segments in one SQLite database. */
export declare class SqliteStore {
    /** Absolute database path, recorded in routing records. */
    readonly path: string;
    private readonly legacyRoot;
    private readonly compression;
    private readonly frameEvents;
    private readonly published;
    private readonly acquireCreationLease;
    private readonly report;
    private readonly pendingCreates;
    private readonly creating;
    private readonly directorySyncs;
    private readonly statements;
    private ready;
    private closing;
    private failure;
    private readonly chains;
    private readonly handles;
    private readonly writers;
    /** Appended batches awaiting the next group commit, in arrival order. */
    private readonly commitQueue;
    private commitDrain;
    constructor(options: SqliteStoreOptions);
    private corruption;
    private parseHeader;
    private database;
    /**
     * Refuse to use or create a database while routing records claim one that is missing.
     * @returns resolves when the database file exists or no routing record requires it.
     */
    assertRoutingDatabase(): Promise<void>;
    private initialize;
    /** Persist newly created directory entries, retaining unfinished synchronization for initialization retries. */
    private ensureDirectory;
    private schemaState;
    private createSchema;
    /** Maintain immutable ancestor ranges in the same transaction as each new Segment. */
    private createAncestrySchema;
    private transaction;
    private assertHealthy;
    private check;
    private statement;
    private row;
    private parseMetadata;
    private segment;
    /** Fetch indexed ancestor metadata together, retaining the authoritative chain checks during reads. */
    private parents;
    private newSegment;
    private insertTrace;
    /** Store consecutive frames from `start`; the last frame's end becomes the Segment's event count. */
    private insertFrames;
    /** Serialize and compress a batch before its transaction: one frame per chunk, yielding between chunks of a long batch. */
    private encodeBatch;
    /**
     * Locate the Segment a fork of `source` at `end` attaches to, through the ancestor index rather than the parent chain.
     * Fork creation is the consumer; `end` never exceeds the source event count.
     * @param db - open database inside the caller's transaction.
     * @param source - forked Trace metadata.
     * @param end - exclusive logical prefix length shared with the source.
     * @returns the attachment Segment and the prefix length within it; no Segment for an empty prefix.
     */
    cut(db: DatabaseSync, source: Metadata, end: number): {
        parent?: Segment;
        end: number;
    };
    /**
     * Reserve a fresh Trace, or commit fork history and its shared prefix in one transaction.
     * @param header - loop-owned metadata.
     * @param options - optional cancellation, logical inherited count, and selected fork history.
     * @returns exclusive in-process write handle.
     */
    create(header: SessionHeader, options?: SessionPersistenceCreateOptions): Promise<SqliteSessionHandle>;
    /** Share the parent's persisted prefix and commit the child's remaining events under one creation lease. */
    private createFork;
    /**
     * Acquire a handle; a write open reads the stored log once to validate it before the restore read.
     * @param id - trace_uuid identifying the event list.
     * @param access - read or in-process exclusive write access.
     * @param signal - optional cancellation.
     * @param ownership - optional import lease, transferred only to a successful write open.
     * @returns handle over the original stored identity.
     */
    open(id: SessionId, access: SessionAccess, signal?: AbortSignal, ownership?: {
        release(): Promise<void>;
    }): Promise<SqliteSessionHandle>;
    /**
     * Claim existing Session ownership for a legacy import and its subsequent write open.
     * @param header - legacy metadata identifying the artifact lock.
     * @returns database and artifact leases, retained until release or successful write-open transfer.
     */
    acquireSessionLease(header: SessionHeader): Promise<{
        release(): Promise<void>;
    }>;
    /**
     * Import a validated legacy log as one independent root Segment under caller-held Session ownership.
     * A transaction failure leaves no partial Session; publication failure leaves the committed row authoritative.
     * @param header - current logical metadata decoded by the legacy reader.
     * @param inheritedCount - exact logical inheritance count from the legacy header.
     * @param events - complete, contiguous legacy prefix without consumer-generated repairs.
     * @param signal - cancellation checked before the synchronous transaction.
     */
    importLegacy(header: SessionHeader, inheritedCount: SessionLogOffset, events: readonly SessionEvent[], signal?: AbortSignal): Promise<void>;
    /** Publish routing after a commit; the committed rows stay authoritative when publication fails. */
    private route;
    /** Hold both database-wide Session ownership and the root's artifact/creation guards. */
    private acquireWriteLease;
    /**
     * Admit a handle. A write open takes the cross-process lease now; a created Session takes it
     * immediately before its first commit, so an unused create leaves no filesystem footprint.
     */
    private admit;
    /**
     * Read only the requested indexed list slice, validating the decoded event vocabulary.
     * @param header - selected Trace metadata.
     * @param offset - first sequence.
     * @param length - maximum number of events.
     * @returns independently owned event slice.
     */
    read(header: SessionHeader, offset: number, length: number): Promise<SessionEvent[]>;
    /**
     * Insert a new suffix atomically; recover the append position through the event index without updating metadata counters.
     * @param header - selected Trace metadata.
     * @param batch - independently materialized new events.
     */
    append(header: SessionHeader, batch: readonly SessionEvent[]): Promise<void>;
    /** Start draining queued batches unless a drain is running; a finished drain restarts for batches queued meanwhile. */
    private scheduleCommits;
    /**
     * Commit queued batches a group at a time. The yield before each group lets batches that other writers
     * append in the same turn share one transaction, so a checkpoint costs one commit and one fsync per group
     * rather than per writer, and it returns the process to its I/O phase between commits; a lone writer pays
     * the same single yield per commit. A batch that fails on its own terms rolls back to its savepoint and
     * rejects alone; an error that ends the whole transaction rejects every batch of the group, and each
     * handle retains its batch for retry.
     */
    private drainCommits;
    /** Dequeue the next group: consecutive batches up to the event cap, always at least one. */
    private takeCommitGroup;
    private ensureRow;
    /**
     * Materialize a pending empty Session at its explicit durability barrier.
     * @param header - pending Session metadata.
     */
    materialize(header: SessionHeader): Promise<void>;
    /**
     * Observe metadata without querying any event payloads.
     * @param id - selected trace_uuid.
     * @param signal - optional cancellation.
     * @returns header, exact count and revision, or absence.
     */
    stat(id: SessionId, signal?: AbortSignal): Promise<SessionPersistenceSnapshot | undefined>;
    private snapshot;
    private databaseFileExists;
    private exists;
    /**
     * Whether the configured database file exists without opening or creating it.
     * @returns true when the database file exists.
     */
    hasDatabase(): Promise<boolean>;
    /**
     * Open or create the configured database and validate its schema.
     * @returns resolves once the database is ready for session operations.
     */
    start(): Promise<void>;
    /**
     * List Sessions, omitting rows whose stored header is corrupt or of an unsupported version.
     * Matching an unreadable JSONL generation header, an omitted row still rejects direct
     * `open` and `stat`. Invalid row metadata and an identity mismatch reject the listing.
     * @param signal - optional cancellation.
     * @returns listed snapshots and the ids of stored rows omitted for their header.
     */
    scan(signal?: AbortSignal): Promise<{
        entries: SessionPersistenceSnapshot[];
        omitted: Set<SessionId>;
    }>;
    /**
     * Register live-event and durability listeners for the provider lifetime.
     * @param ctx - owning parent scope, disposed after injected consumers.
     * @param beforeClose - optional admitted-import settlement before handle teardown.
     */
    install(ctx: Context, beforeClose?: () => Promise<void>): void;
    /**
     * Report a background failure while retaining the rejected durability state.
     * @param id - affected Session.
     * @param error - retained failure.
     */
    reportFailure(id: SessionId, error: unknown): void;
    /** Join all admitted writer operations; commits already use FULL synchronous durability. */
    flush(): Promise<void>;
    /** Drain admitted handles before closing the database connection. */
    close(): Promise<void>;
}
/** One SessionHandle over a logical SQLite event stream. */
export declare class SqliteSessionHandle implements SessionHandle {
    readonly header: SessionHeader;
    readonly access: SessionAccess;
    private readonly store;
    private readonly release;
    private readonly acquireLease;
    private readonly checkStorage;
    readonly inheritedEventCount: SessionLogOffset;
    private closed;
    private pending;
    private closing;
    private failure;
    private primed;
    private readonly buffer;
    constructor(header: SessionHeader, access: SessionAccess, store: SqliteStore, release: () => Promise<void>, acquireLease: () => Promise<void>, checkStorage: () => void, inheritedEventCount?: SessionLogOffset);
    get id(): sessionIdentity;
    /** Completion of an already-started close, including its final durability drain. */
    get closeCompletion(): Promise<void> | undefined;
    private check;
    read(offset?: number, length?: number, options?: SessionHandleReadOptions): Promise<{
        eventState: "detached";
        events: SessionEvent[];
    }>;
    /**
     * Retain the validated write-open prefix for the immediate restore read.
     * @param events - exclusively owned validated prefix.
     */
    prime(events: SessionEvent[]): void;
    /**
     * Admit one live event into the bounded batching window, including while close drains the routed producer.
     * @param event - newly emitted event, copied before asynchronous persistence.
     * @returns admission completion; durability requires flush. Rejects once the close drain has finished.
     */
    receive(event: SessionEvent): Promise<void>;
    /** Drain admitted live records without forcing an unused empty Session to materialize. */
    drainLive(): Promise<void>;
    append(events: readonly SessionEvent[], options?: SessionHandleAppendOptions): Promise<void>;
    flush(options?: SessionHandleFlushOptions): Promise<void>;
    private enqueue;
    close(): Promise<void>;
    [Symbol.asyncDispose](): Promise<void>;
}
export {};
//# sourceMappingURL=sqlite.d.ts.map