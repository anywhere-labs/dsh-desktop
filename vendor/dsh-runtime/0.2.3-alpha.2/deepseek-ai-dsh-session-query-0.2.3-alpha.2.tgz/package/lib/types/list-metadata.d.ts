/** Session-list metadata projection definition registered by `SessionQueryEngine`. */
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import { z } from 'zod';
import type { SessionListMetadata } from './types.ts';
/** Advance blankness and human-prompt recency without retaining history. */
declare function applySessionListMetadata(state: SessionListMetadata, event: SessionEvent): SessionListMetadata;
/** Blankness and latest human-prompt time folded per Session; persisted at state version 1. */
export declare const sessionListMetadataDefinition: {
    key: "sessionListMetadata";
    stateSchema: z.ZodType<SessionListMetadata, unknown, z.core.$ZodTypeInternals<SessionListMetadata, unknown>>;
    init: () => {
        blank: true;
        lastPromptAt: null;
    };
    apply: typeof applySessionListMetadata;
    wire: {
        viewSchema: z.ZodType<SessionListMetadata, unknown, z.core.$ZodTypeInternals<SessionListMetadata, unknown>>;
        view: (state: NoInfer<SessionListMetadata>) => SessionListMetadata;
    };
    stateVersion: number;
};
export {};
//# sourceMappingURL=list-metadata.d.ts.map