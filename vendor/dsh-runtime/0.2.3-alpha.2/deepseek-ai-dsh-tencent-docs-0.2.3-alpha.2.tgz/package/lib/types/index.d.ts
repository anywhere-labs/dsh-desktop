/**
 * Tencent Docs plugin: registers Tencent Docs' hosted MCP server with the
 * shared MCP manager for this plugin's lifetime, tells the model to call it the
 * Tencent Docs plugin, and shows the account on the Plugins page while the
 * account registry runs. The manager owns connection, OAuth authorization,
 * saved grants, and sign-out; once a grant exists, the server's
 * `mcp__tencent-docs__*` tools are listed in the system prompt and each agent
 * loads the ones it needs.
 * @module @deepseek-ai/dsh-tencent-docs
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "tencent-docs";
export declare const inject: string[];
/** Tencent Docs MCP endpoint and tool loading for the managed server entry. */
export interface Config {
    /** Streamable HTTP MCP endpoint; defaults to Tencent Docs' hosted server. */
    url: string;
    /** `on-demand` (default) keeps Tencent Docs' tools hidden from each agent until it loads them; `eager` sends all of them. */
    toolLoading: 'eager' | 'on-demand';
}
/** Runtime configuration schema for the Tencent Docs plugin. */
export declare const Config: z<Partial<Config>, Config>;
/**
 * Register the Tencent Docs server, its naming guidance, and, while the account registry runs, its Plugins page account; all
 * are withdrawn when the plugin unloads.
 * @param ctx - Context carrying the MCP manager and system prompt.
 * @param config - Tencent Docs endpoint and tool loading.
 * @throws when another configured or registered server already uses the `tencent-docs` name or credential key.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map