/** Managed tmeet location: the platform executable that `@tencentcloud/tmeet` ships under its own name. */
/** The name tmeet's guides run it by. */
export declare const PROGRAM = "tmeet";
/**
 * Name the executable file a `binDir` holds.
 * @param platform - the Host platform.
 * @returns `tmeet`, or `tmeet.exe` on Windows.
 */
export declare function executableFileName(platform: NodeJS.Platform): string;
/**
 * Locate the managed executable.
 * @param binDir - absolute override holding an executable `tmeet`, `tmeet.exe` on Windows; defaults to the installed `@tencentcloud/tmeet`
 *   executable for this platform.
 * @returns the absolute path of the executable.
 * @throws when the platform has no packaged executable or the executable is missing or not executable.
 */
export declare function resolveCliExecutable(binDir: string | undefined): string;
//# sourceMappingURL=directory.d.ts.map