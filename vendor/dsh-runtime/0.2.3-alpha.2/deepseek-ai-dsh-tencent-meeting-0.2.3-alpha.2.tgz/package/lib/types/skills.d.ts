/** The packaged `tencent-meeting` entry skill and the upstream guide it indexes. */
import type { UpstreamSkillSet } from '@deepseek-ai/dsh-upstream-skills';
/** The packaged entry, which opens the guide by its repository path `skills/tmeet-skill/SKILL.md`. */
export declare const ENTRY: string;
/**
 * The official tmeet guide at the release the plugin installs, without `scripts/agent_init.py`, which the entry tells the
 * agent to skip because DSH runs `tmeet` by its absolute path.
 */
export declare const TMEET_SKILLS: UpstreamSkillSet;
//# sourceMappingURL=skills.d.ts.map