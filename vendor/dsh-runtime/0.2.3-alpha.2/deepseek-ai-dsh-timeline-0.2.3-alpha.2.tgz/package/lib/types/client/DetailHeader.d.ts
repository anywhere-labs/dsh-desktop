import type { ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
/** A compact back control sits beside the detail title in both task and report views. */
export declare function DetailHeader({ title, back, children, t, }: {
    title: string;
    back: () => void;
    children?: ReactNode;
} & PropsLocale<'timeline'>): ReactNode;
//# sourceMappingURL=DetailHeader.d.ts.map