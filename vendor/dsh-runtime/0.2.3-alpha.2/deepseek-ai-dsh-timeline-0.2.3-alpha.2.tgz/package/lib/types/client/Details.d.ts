import type { ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ProgressPrecision } from '../policy.ts';
import type { TimelineView } from '../records.ts';
import type { DetailTarget } from './navigation.ts';
import type { PlaybackState } from './TaskActions.tsx';
import type { AnnotationDraftControl } from './store.ts';
import type { AnnotationRequest, PriorityRequest, TaskRequest } from './actions.ts';
type TaskDetailsProps = {
    view: TimelineView;
    locale?: string;
    target: Extract<DetailTarget, {
        kind: 'task';
    }>;
    decimals: ProgressPrecision;
    back: () => void;
    requestTask: (request: TaskRequest) => Promise<void>;
    playback: PlaybackState;
    setPriority: (request: PriorityRequest) => Promise<void>;
    annotate: (request: AnnotationRequest) => Promise<{
        notified: boolean;
    }>;
    annotationDraft?: AnnotationDraftControl | undefined;
} & PropsLocale<'timeline'>;
/** The active Task Tree or Timeline tab owns this detail page and its return history. */
export declare function Details({ view, locale, target, decimals, back, open, requestTask, playback, setPriority, annotate, annotationDraft, t, }: Omit<TaskDetailsProps, 'target'> & {
    target: DetailTarget;
    open: (target: DetailTarget) => void;
}): ReactNode;
export {};
//# sourceMappingURL=Details.d.ts.map