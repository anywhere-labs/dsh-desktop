import type { ReactNode } from 'react';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ObservableSnapshot, PropsStore } from '@deepseek-ai/dsh-client-store';
import type { ConfigFormSnapshot } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { Config } from '../config.ts';
import type { createSettingsStore } from './store.ts';
export type EditableSettings = Pick<Config, 'language' | 'progressDecimals' | 'segmentedProgress' | 'allowTodo' | 'autoOpenSidebar' | 'reminderIterations' | 'reportsEnabled' | 'taskPrompt' | 'summaryPrompt' | 'levelPrompts'> & {
    periods: number[];
};
export interface SettingsInjected {
    hooks: {
        locale: ObservableSnapshot<{
            active: string;
        }>;
        settings: ObservableSnapshot<ConfigFormSnapshot<Config>>;
    };
    save: (value: EditableSettings, revision: number | undefined) => Promise<boolean>;
}
type SettingsProps = PropsRuntime<'plugins.bundle.config'> & PropsLocale<'timeline'> & PropsStore<ReturnType<typeof createSettingsStore>> & InjectFace<SettingsInjected>;
/** Materialize previous per-rollup overrides before saving level-specific instructions. */
export declare function editableSettings(value: Config): EditableSettings;
/**
 * Edit Timeline settings from its plugin detail page.
 * @param props Localized settings, draft store and save action.
 * @returns The settings form.
 */
export declare function Settings({ useSettings, useLocale, useStore, actions, save, t }: SettingsProps): ReactNode;
export {};
//# sourceMappingURL=Settings.d.ts.map