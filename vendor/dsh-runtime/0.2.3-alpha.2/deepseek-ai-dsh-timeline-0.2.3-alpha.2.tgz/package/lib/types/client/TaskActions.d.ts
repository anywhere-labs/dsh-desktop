import type { ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { Annotation, Priority, Task, Tree } from '../records.ts';
import type { TaskRequest } from './actions.ts';
export interface PlaybackState {
    annotations: readonly Annotation[];
    trees: readonly Tree[];
    now: number;
}
/** Express user intent without editing agent-owned progress optimistically. */
export declare function TaskActions({ tree, task, status, playback, request, setPriority, annotate, annotationOpen, t, children, }: {
    tree: Tree;
    task?: Task | undefined;
    status: Task['status'];
    playback: PlaybackState;
    request: (value: TaskRequest) => Promise<void>;
    setPriority?: (value: Priority) => Promise<void>;
    annotate?: () => void;
    annotationOpen?: boolean;
    children?: ReactNode;
} & PropsLocale<'timeline'>): ReactNode;
//# sourceMappingURL=TaskActions.d.ts.map