import type { ReactNode } from 'react';
import type { ToolCallViewProps } from '@deepseek-ai/dsh-client-ui-tool/client';
import type { InjectFace, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ObservableSnapshot } from '@deepseek-ai/dsh-client-store';
import type { ConfigFormSnapshot } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { Config } from '../config.ts';
import type { Task, Tree } from '../records.ts';
export interface TaskCardInjected {
    hooks: {
        locale: ObservableSnapshot<{
            active: string;
        }>;
        settings: ObservableSnapshot<ConfigFormSnapshot<Config>>;
    };
    openTask: (tree: Tree['id'], task?: Task['id']) => void;
}
type TaskCardProps = ToolCallViewProps & PropsLocale<'timeline'> & InjectFace<TaskCardInjected>;
/** Render a fixed saved receipt; pending, rejected and older calls keep their ordinary tool details. */
export declare function TaskCard({ phase, block, useDisclosure, useSettings, useLocale, openTask, inspect, t, }: TaskCardProps): ReactNode;
export {};
//# sourceMappingURL=TaskCard.d.ts.map