import type { ReactNode } from 'react';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ObservableSnapshot, PropsStore } from '@deepseek-ai/dsh-client-store';
import type { ConfigFormSnapshot } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { Config } from '../config.ts';
import type { createViewStore } from './store.ts';
import type { TreeTransferActions } from './TreeTransfer.tsx';
export interface TaskDockInjected extends Pick<TreeTransferActions, 'removeTree'> {
    hooks: {
        settings: ObservableSnapshot<ConfigFormSnapshot<Config>>;
    };
    toggleSidebar: (showingTree: boolean) => void;
}
type TaskDockProps = PropsRuntime<'conversation.input.dock'> & PropsLocale<'timeline'> & PropsStore<ReturnType<typeof createViewStore>> & InjectFace<TaskDockInjected>;
/** Keep the active plan visible beside the composer using the sidebar's shared view. */
export declare function TaskDock({ sessionId, useProjection, useStore, actions, useSettings, useSession, toggleSidebar, removeTree, t, }: TaskDockProps): ReactNode;
export {};
//# sourceMappingURL=TaskDock.d.ts.map