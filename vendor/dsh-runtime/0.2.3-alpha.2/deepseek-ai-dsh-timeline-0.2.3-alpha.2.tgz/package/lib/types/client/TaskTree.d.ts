import type { ReactNode } from 'react';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { Task, Tree, TimelineView } from '../records.ts';
import type { ViewState } from './store.ts';
import type { ProgressPrecision } from '../policy.ts';
import type { PlaybackState } from './TaskActions.tsx';
import type { TaskRequest } from './actions.ts';
import type { TreeTransferActions } from './TreeTransfer.tsx';
interface TaskTreeProps extends PropsLocale<'timeline'>, TreeTransferActions {
    sessionId: string;
    view: TimelineView;
    state: ViewState;
    now: number;
    decimals: ProgressPrecision;
    segmented?: boolean;
    update: (patch: Partial<ViewState>) => void;
    toggle: (tree: Tree['id'], id: Task['id']) => void;
    openTask: (tree: Tree['id'], task: Task['id']) => void;
    requestTask: (request: TaskRequest) => Promise<void>;
    playback: PlaybackState;
    running: boolean;
}
/** Expandable task hierarchy with host-native semantic status tags. */
export declare function TaskTree({ sessionId, view, state, now, decimals, segmented, update, toggle, openTask, requestTask, playback, running, importTree, removeTree, t, }: TaskTreeProps): ReactNode;
export {};
//# sourceMappingURL=TaskTree.d.ts.map