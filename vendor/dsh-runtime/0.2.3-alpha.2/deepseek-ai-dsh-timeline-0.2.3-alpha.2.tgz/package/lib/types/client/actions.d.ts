import type { ISessions } from '@deepseek-ai/dsh-api-session-controller/client';
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client';
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
import type { Task, Tree } from '../records.ts';
import type { UserEdit, UserEditResult } from '../protocol.ts';
type TaskAction = 'resume' | 'pause';
/** A user request to pause or continue a tree or one branch. */
export interface TaskRequest {
    action: TaskAction;
    tree: Pick<Tree, 'id' | 'title'>;
    task?: Pick<Task, 'id' | 'title'>;
}
/** User discussion text and the task or report it addresses. */
export type AnnotationRequest = Omit<Extract<UserEdit, {
    action: 'annotate';
}>, 'action' | 'sessionId'>;
/** User priority change for a task in a selected tree. */
export type PriorityRequest = Omit<Extract<UserEdit, {
    action: 'priority';
}>, 'action' | 'sessionId'>;
/** A validated portable tree and its import destination. */
export type ImportRequest = Omit<Extract<UserEdit, {
    action: 'import';
}>, 'action' | 'sessionId'>;
declare module '@deepseek-ai/dsh-api-session-controller/client' {
    interface SessionReferenceSourceMap {
        timelineTaskAction: unknown;
    }
}
/** Session actions owned by the Timeline client fiber. */
interface TaskRequester {
    importTree: (sessionId: SessionId, request: ImportRequest) => Promise<Extract<UserEditResult, {
        action: 'import';
    }>>;
    removeTree: (sessionId: SessionId, tree: Tree['id'], draft?: boolean) => Promise<Extract<UserEditResult, {
        action: 'remove';
    }>>;
    send: (sessionId: SessionId, request: TaskRequest) => Promise<void>;
    setPriority: (sessionId: SessionId, request: PriorityRequest) => Promise<void>;
    annotate: (sessionId: SessionId, request: AnnotationRequest) => Promise<{
        notified: boolean;
    }>;
    close: () => Promise<void>;
}
/**
 * Send visible user instructions through the normal Session admission path; the agent owns task edits.
 * @param sessions - client service that opens sessions for user actions.
 * @param connection - authenticated connection to the host.
 * @param t - Timeline label translator.
 * @returns client actions and a cleanup function.
 */
export declare function createTaskRequester(sessions: Pick<ISessions, 'using'>, connection: Pick<ConnectionHandle, 'rpc'>, t: TranslateNS<'timeline'>): TaskRequester;
export {};
//# sourceMappingURL=actions.d.ts.map