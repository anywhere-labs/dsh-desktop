import type { Context } from '@deepseek-ai/cordis';
import './timeline.css';
/** Client services required to mount Timeline. */
export declare const inject: string[];
/**
 * Register Timeline's plugin settings, right sidebar, and composer strip.
 * @param ctx Client context.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map