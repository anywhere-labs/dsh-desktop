/** Semantic colors for each displayed task status. */
export declare const statusTones: {
    readonly pending: "neutral";
    readonly active: "info";
    readonly paused: "neutral";
    readonly blocked: "warning";
    readonly done: "success";
    readonly retired: "quiet";
};
//# sourceMappingURL=status.d.ts.map