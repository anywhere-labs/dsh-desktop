import type { EngineStoreHandle } from '@deepseek-ai/dsh-client-store';
import type { IntervalReport, Task, Tree } from '../records.ts';
import type { EditableSettings } from './Settings.tsx';
import type { DetailTarget } from './navigation.ts';
/** One unsaved discussion and its request identity across navigation. */
export interface AnnotationDraft {
    open: boolean;
    text: string;
    id: string | null;
    busy: boolean;
    messageKey: 'annotationSaved' | 'annotationNotifyFailed' | 'annotationSaveFailed' | null;
}
/** Initial state before a discussion editor has been opened. */
export declare const emptyDraft: AnnotationDraft;
/** The current discussion draft and its target-scoped update. */
export interface AnnotationDraftControl {
    draft: AnnotationDraft;
    update: (patch: Partial<AnnotationDraft>) => void;
}
/** Session view state shared by the dock, sidebar, and tool cards. */
export interface ViewState {
    tree: Tree['id'] | null;
    collapsed: Record<string, Task['id'][]>;
    zoom: number | null;
    /** Null follows the first available level. All gives the columns equal widths. */
    level: number | 'all' | null;
    /** A positive offset in live mode keeps the newest report in view. */
    scrollMs: number;
    scrollLeft: number;
    /** An explicit history position, or null to follow live reports. */
    anchor: number | null;
    /** The last report present when the user entered history. Null means the list was empty. */
    historyReport: IntervalReport['id'] | null | undefined;
    tab: 'tasks' | 'timeline';
    historyOpen: boolean;
    details: Record<'tasks' | 'timeline', {
        target: DetailTarget;
        scrollTop: number;
    }[]>;
    drafts: Record<string, AnnotationDraft>;
}
/**
 * Session-scoped viewing state, owned and instantiated by slot registration.
 * @returns a handle that creates independent session views.
 */
export declare function createViewStore(): EngineStoreHandle<ViewState, {
    open: (state: ViewState, tree: Tree['id'], task?: Task['id']) => void;
    forgetTree: (state: ViewState, tree: Tree['id']) => void;
    update: (state: ViewState, patch: Partial<ViewState>) => void;
    toggle: (state: ViewState, tree: Tree['id'], id: Task['id']) => void;
    draft: (state: ViewState, key: string, patch: Partial<AnnotationDraft>) => void;
}>;
/** Unsaved settings and the current editor selection. */
export interface SettingsState {
    draft: EditableSettings | null;
    revision: number | undefined;
    level: number;
    units: ('minute' | 'hour')[];
    saving: boolean;
    messageKey: 'saved' | 'saveFailed' | null;
}
/**
 * Keep unsaved edits across panel navigation; the official settings service owns accepted values.
 * @returns a handle that creates a settings editor store.
 */
export declare function createSettingsStore(): EngineStoreHandle<SettingsState, {
    update: (state: SettingsState, patch: Partial<SettingsState>) => void;
}>;
//# sourceMappingURL=store.d.ts.map