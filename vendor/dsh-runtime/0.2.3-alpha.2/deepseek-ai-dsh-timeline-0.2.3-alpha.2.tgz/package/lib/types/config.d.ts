import Schema from '@deepseek-ai/schemastery';
import type { Volatile } from '@deepseek-ai/cordis';
import type { Language, OutputLanguage, ProgressPrecision } from './policy.ts';
/** Profile-owned task tracking, report cadence, and summarization instructions. */
export interface Config {
    /** Generate new interval reports. */
    reportsEnabled: boolean;
    /** Minimum elapsed time between reports, in milliseconds. */
    intervalMs: number;
    /** Ratios between successive report periods. */
    rollupFactors: number[];
    /** Language for task trees, report summaries, and discussion replies. */
    language: Language;
    /** Host display language used for task and report text. */
    uiLanguage: OutputLanguage;
    /** Number of decimal places in displayed progress. */
    progressDecimals: ProgressPrecision;
    /** Show progress by status on the bar. */
    segmentedProgress: boolean;
    /** Keep Todo tools available when the agent preset provides them. */
    allowTodo: boolean;
    /** Open the sidebar when the first task tree appears in a conversation. */
    autoOpenSidebar: boolean;
    /** Agent iterations without an update before a reminder. */
    reminderIterations: number;
    /** Maximum tasks in one tree. */
    maxTasks: number;
    /** Maximum trees in a session. */
    maxTrees: number;
    /** Maximum simultaneous report requests. */
    maxConcurrent: number;
    /** Maximum time for a report request, in milliseconds. */
    timeoutMs: number;
    /** Maximum bytes accepted from a report response. */
    maxResponseBytes: number;
    /** Writing guidance for the task update tool. */
    taskPrompt: string;
    /** Instructions shared by all report levels. */
    summaryPrompt: string;
    /** Extra report instructions for each level. */
    levelPrompts: string[];
    /** Maximum model tokens in one report response. */
    reportMaxTokens: number;
    /** Optional reasoning effort supported by the selected report model. */
    reportReasoningEffort?: string;
}
/** Loader input with live references for settings that can change without a restart. */
export interface PluginConfig extends Pick<Config, 'maxTasks' | 'maxTrees' | 'maxConcurrent' | 'timeoutMs' | 'maxResponseBytes' | 'reportMaxTokens' | 'reportReasoningEffort'> {
    /** Generate new interval reports. */
    reportsEnabled: Volatile<Config['reportsEnabled']>;
    /** Minimum elapsed time between reports, in milliseconds. */
    intervalMs: Volatile<Config['intervalMs']>;
    /** Ratios between successive report periods. */
    rollupFactors: Volatile<Config['rollupFactors']>;
    /** Language for task trees, report summaries, and discussion replies. */
    language: Volatile<Config['language']>;
    /** Number of decimal places in displayed progress. */
    progressDecimals: Volatile<Config['progressDecimals']>;
    /** Show progress by status on the bar. */
    segmentedProgress: Volatile<Config['segmentedProgress']>;
    /** Keep Todo tools available when the agent preset provides them. */
    allowTodo: Volatile<Config['allowTodo']>;
    /** Open the sidebar when the first task tree appears in a conversation. */
    autoOpenSidebar: Volatile<Config['autoOpenSidebar']>;
    /** Agent iterations without an update before a reminder. */
    reminderIterations: Volatile<Config['reminderIterations']>;
    /** Writing guidance for the task update tool. */
    taskPrompt: Volatile<Config['taskPrompt']>;
    /** Instructions shared by all report levels. */
    summaryPrompt: Volatile<Config['summaryPrompt']>;
    /** Extra report instructions for each level. */
    levelPrompts: Volatile<Config['levelPrompts']>;
}
/** No tool-call or browser-visibility gate is applied to timed reports. */
export declare const Config: Schema<Partial<Config>, PluginConfig>;
/**
 * Keep loader-owned references; reparsing them here would detach live settings updates.
 * @param input - input to validate.
 * @param readLanguage - the Host display language reader.
 * @returns a view that reads the current value of each live setting.
 */
export declare function liveConfig(input: PluginConfig, readLanguage?: () => string): Config;
//# sourceMappingURL=config.d.ts.map