import type { Annotation, ControlTarget, Tree } from './records.ts';
/** An elapsed wait permits an explicit retry; it never proves success or failure. */
export declare const CONTROL_WAIT_MS: number;
/**
 * Find the latest request for the exact tree or task.
 * @param annotations - saved notes and work requests.
 * @param target - addressed tree or task.
 * @returns the most recent matching note, if one exists.
 */
export declare function latestControl(annotations: readonly Annotation[], target: ControlTarget): Annotation | undefined;
/**
 * Check whether two requests affect any shared branch.
 * @param left - first request target.
 * @param right - second request target.
 * @param trees - the task trees for the current session.
 * @returns whether the targets affect shared work.
 */
export declare function controlTargetsOverlap(left: Annotation['target'], right: Annotation['target'], trees: readonly Tree[]): boolean;
/**
 * Find a request that is still within its confirmation period.
 * @param annotations - saved notes and work requests.
 * @param target - addressed tree or task.
 * @param trees - the task trees for the current session.
 * @param now - current wall clock time in milliseconds.
 * @returns the newest matching request awaiting confirmation.
 */
export declare function pendingControl(annotations: readonly Annotation[], target: ControlTarget, trees: readonly Tree[], now: number): Annotation | undefined;
/**
 * A receipt confirms recorded plan state, never the absence of external side effects.
 * @param annotation - the saved discussion or work request.
 * @param trees - the task trees for the current session.
 * @param at - wall clock time associated with the update.
 * @returns the original or updated note with its observed outcome.
 */
export declare function reconcileControl(annotation: Annotation, trees: readonly Tree[], at: number): Annotation;
//# sourceMappingURL=controls.d.ts.map