import { HarnessError } from '@deepseek-ai/dsh-error';
import type { output, ZodType } from 'zod';
/** A Timeline failure with a stable tool-result code. */
export declare class TimelineError extends HarnessError {
    constructor(message: string, code?: 'TIMELINE_INVALID_ARGUMENT' | 'TIMELINE_PERSISTENCE' | 'TIMELINE_PLUGIN_CONFLICT', options?: ErrorOptions);
}
/**
 * Read one tool argument and name the field when validation fails.
 * @param schema - argument validation rules.
 * @param value - argument to validate.
 * @param field - argument name shown to the model.
 * @returns the validated argument.
 */
export declare function parseArgument<S extends ZodType>(schema: S, value: unknown, field: string): output<S>;
//# sourceMappingURL=error.d.ts.map