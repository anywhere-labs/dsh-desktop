import { z } from 'zod';
import type { ProjectionDefinition } from '@deepseek-ai/dsh-session-projection';
import type { Context } from '@deepseek-ai/cordis';
import type { Session } from '@deepseek-ai/dsh-session';
/** Validate the private recovery state and its user view. */
export declare const stateSchema: z.ZodObject<{
    sessionId: z.ZodString;
    inherited: z.ZodNumber;
    hasTurn: z.ZodDefault<z.ZodBoolean>;
    toolCount: z.ZodNumber;
    covered: z.ZodNumber;
    lastReportEnd: z.ZodNumber;
    activity: z.ZodObject<{
        start: z.ZodNumber;
        olderWorkMs: z.ZodNumber;
        ranges: z.ZodArray<z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>>;
        open: z.ZodNullable<z.ZodNumber>;
    }, z.core.$strip>;
    preparedImport: z.ZodNullable<z.ZodObject<{
        version: z.ZodLiteral<1>;
        sessionId: z.ZodString;
        callId: z.ZodString;
        tree: z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
            title: z.ZodString;
            description: z.ZodString;
            tasks: z.ZodArray<z.ZodObject<{
                id: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
                parent: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">>;
                title: z.ZodString;
                description: z.ZodString;
                status: z.ZodEnum<{
                    pending: "pending";
                    active: "active";
                    paused: "paused";
                    blocked: "blocked";
                    done: "done";
                    retired: "retired";
                }>;
                done: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                timeShare: z.ZodNumber;
                remaining: z.ZodNullable<z.ZodNumber>;
                mode: z.ZodEnum<{
                    serial: "serial";
                    parallel: "parallel";
                }>;
                note: z.ZodString;
                details: z.ZodString;
                priority: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                    P0: "P0";
                    P1: "P1";
                    P2: "P2";
                    P3: "P3";
                }>>>;
                createdAt: z.ZodNumber;
                updatedAt: z.ZodNumber;
                history: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    done: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                    status: z.ZodEnum<{
                        pending: "pending";
                        active: "active";
                        paused: "paused";
                        blocked: "blocked";
                        done: "done";
                        retired: "retired";
                    }>;
                    parent: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">>;
                    title: z.ZodString;
                    description: z.ZodString;
                    note: z.ZodString;
                    details: z.ZodString;
                    priority: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                        P0: "P0";
                        P1: "P1";
                        P2: "P2";
                        P3: "P3";
                    }>>>;
                    at: z.ZodNumber;
                    progress: z.ZodNumber;
                    previousProgress: z.ZodNullable<z.ZodNumber>;
                    weight: z.ZodNumber;
                }, z.core.$strict>>>;
            }, z.core.$strict>>;
            createdAt: z.ZodNumber;
            lastTaskUpdate: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>;
        receipt: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            version: z.ZodLiteral<1>;
            tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
            title: z.ZodString;
            branch: z.ZodNullable<z.ZodString>;
            at: z.ZodNumber;
            previousAt: z.ZodNullable<z.ZodNumber>;
            before: z.ZodNumber;
            after: z.ZodNumber;
            total: z.ZodNumber;
            tasks: z.ZodArray<z.ZodObject<{
                id: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
                title: z.ZodString;
                note: z.ZodString;
                status: z.ZodEnum<{
                    pending: "pending";
                    active: "active";
                    paused: "paused";
                    blocked: "blocked";
                    done: "done";
                    retired: "retired";
                }>;
                before: z.ZodNumber;
                after: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
        annotations: z.ZodArray<z.ZodObject<{
            id: z.ZodUnion<readonly [z.ZodUUID, z.ZodString]>;
            target: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"tree">;
                tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"task">;
                tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
                task: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"report">;
                report: z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">;
            }, z.core.$strict>], "kind">;
            text: z.ZodString;
            createdAt: z.ZodNumber;
            reply: z.ZodNullable<z.ZodObject<{
                text: z.ZodString;
                createdAt: z.ZodNumber;
            }, z.core.$strict>>;
            control: z.ZodOptional<z.ZodObject<{
                action: z.ZodEnum<{
                    pause: "pause";
                    resume: "resume";
                }>;
                delivery: z.ZodEnum<{
                    unknown: "unknown";
                    sending: "sending";
                    accepted: "accepted";
                }>;
                outcome: z.ZodNullable<z.ZodObject<{
                    status: z.ZodEnum<{
                        applied: "applied";
                        completed: "completed";
                        unavailable: "unavailable";
                        answered: "answered";
                        superseded: "superseded";
                    }>;
                    at: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        prepared: z.ZodOptional<z.ZodLiteral<true>>;
        continuation: z.ZodOptional<z.ZodObject<{
            id: z.ZodUUID;
            text: z.ZodString;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    calls: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
        receipt: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            version: z.ZodLiteral<1>;
            tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
            title: z.ZodString;
            branch: z.ZodNullable<z.ZodString>;
            at: z.ZodNumber;
            previousAt: z.ZodNullable<z.ZodNumber>;
            before: z.ZodNumber;
            after: z.ZodNumber;
            total: z.ZodNumber;
            tasks: z.ZodArray<z.ZodObject<{
                id: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
                title: z.ZodString;
                note: z.ZodString;
                status: z.ZodEnum<{
                    pending: "pending";
                    active: "active";
                    paused: "paused";
                    blocked: "blocked";
                    done: "done";
                    retired: "retired";
                }>;
                before: z.ZodNumber;
                after: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
        continuation: z.ZodOptional<z.ZodObject<{
            id: z.ZodUUID;
            text: z.ZodString;
        }, z.core.$strip>>;
        notified: z.ZodOptional<z.ZodLiteral<true>>;
    }, z.core.$strip>>>;
    view: z.ZodObject<{
        trees: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
            title: z.ZodString;
            description: z.ZodString;
            tasks: z.ZodArray<z.ZodObject<{
                id: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
                parent: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">>;
                title: z.ZodString;
                description: z.ZodString;
                status: z.ZodEnum<{
                    pending: "pending";
                    active: "active";
                    paused: "paused";
                    blocked: "blocked";
                    done: "done";
                    retired: "retired";
                }>;
                done: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                timeShare: z.ZodNumber;
                remaining: z.ZodNullable<z.ZodNumber>;
                mode: z.ZodEnum<{
                    serial: "serial";
                    parallel: "parallel";
                }>;
                note: z.ZodString;
                details: z.ZodString;
                priority: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                    P0: "P0";
                    P1: "P1";
                    P2: "P2";
                    P3: "P3";
                }>>>;
                createdAt: z.ZodNumber;
                updatedAt: z.ZodNumber;
                history: z.ZodDefault<z.ZodArray<z.ZodObject<{
                    done: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                    status: z.ZodEnum<{
                        pending: "pending";
                        active: "active";
                        paused: "paused";
                        blocked: "blocked";
                        done: "done";
                        retired: "retired";
                    }>;
                    parent: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">>;
                    title: z.ZodString;
                    description: z.ZodString;
                    note: z.ZodString;
                    details: z.ZodString;
                    priority: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                        P0: "P0";
                        P1: "P1";
                        P2: "P2";
                        P3: "P3";
                    }>>>;
                    at: z.ZodNumber;
                    progress: z.ZodNumber;
                    previousProgress: z.ZodNullable<z.ZodNumber>;
                    weight: z.ZodNumber;
                }, z.core.$strict>>>;
            }, z.core.$strict>>;
            createdAt: z.ZodNumber;
            lastTaskUpdate: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        annotations: z.ZodDefault<z.ZodArray<z.ZodObject<{
            id: z.ZodUnion<readonly [z.ZodUUID, z.ZodString]>;
            target: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"tree">;
                tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"task">;
                tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
                task: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"report">;
                report: z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">;
            }, z.core.$strict>], "kind">;
            text: z.ZodString;
            createdAt: z.ZodNumber;
            reply: z.ZodNullable<z.ZodObject<{
                text: z.ZodString;
                createdAt: z.ZodNumber;
            }, z.core.$strict>>;
            control: z.ZodOptional<z.ZodObject<{
                action: z.ZodEnum<{
                    pause: "pause";
                    resume: "resume";
                }>;
                delivery: z.ZodEnum<{
                    unknown: "unknown";
                    sending: "sending";
                    accepted: "accepted";
                }>;
                outcome: z.ZodNullable<z.ZodObject<{
                    status: z.ZodEnum<{
                        applied: "applied";
                        completed: "completed";
                        unavailable: "unavailable";
                        answered: "answered";
                        superseded: "superseded";
                    }>;
                    at: z.ZodNumber;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>>;
        activeTreeId: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">>;
        reports: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">;
            level: z.ZodNumber;
            start: z.ZodNumber;
            end: z.ZodNumber;
            createdAt: z.ZodOptional<z.ZodNumber>;
            policy: z.ZodString;
            children: z.ZodArray<z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">>;
            source: z.ZodEnum<{
                model: "model";
                "no-activity": "no-activity";
            }>;
            toolCount: z.ZodNumber;
            covered: z.ZodNumber;
            contextSeq: z.ZodNumber;
            workMs: z.ZodOptional<z.ZodNumber>;
            ranges: z.ZodOptional<z.ZodArray<z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>>>;
            summary: z.ZodObject<{
                progress: z.ZodArray<z.ZodString>;
                uncertainties: z.ZodArray<z.ZodString>;
                userActions: z.ZodArray<z.ZodString>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
        error: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
}, z.core.$strip>;
/** Session recovery facts and current Timeline view. */
export type TimelineState = z.infer<typeof stateSchema>;
/** Internal reader shared by tools and the scheduler. */
export interface TimelineReader {
    stateOf(session: Session): TimelineState;
}
/**
 * Register the session projection before exposing a synchronous reader.
 * @param ctx - owning plugin context.
 * @returns a reader after registration is ready.
 */
export declare function registerProjection(ctx: Context): Promise<TimelineReader>;
type TimelineProjection = ProjectionDefinition<'timeline', TimelineState>;
/**
 * Replay Timeline records and inherit the plan at the fork point.
 * @returns the Timeline and session activity projection definition.
 */
export declare function createProjection(): TimelineProjection & {
    wire: NonNullable<TimelineProjection['wire']>;
};
/**
 * Apply one validated change to the current Timeline state.
 * @param state - the current Timeline recovery state.
 * @param record - the change to validate and apply.
 * @returns the updated state, or the original state for an invalid change.
 */
export declare function foldRecord(state: TimelineState, record: {
    type: string;
    data: unknown;
}): TimelineState;
export {};
//# sourceMappingURL=projection.d.ts.map