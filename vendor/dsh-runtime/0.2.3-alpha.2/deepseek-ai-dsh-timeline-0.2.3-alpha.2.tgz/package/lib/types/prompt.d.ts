import type { OutputLanguage } from './policy.ts';
import type { Summary } from './records.ts';
/** Fixed writing constraints also apply when a user supplies a custom emphasis prompt. */
export declare const reportStyle = "Write a report only. Use ASD-STE100 clarity principles in the required language: plain words, active voice, and self-contained sentences. Name the affected capability or problem, the result, and its impact on the goal. Distinguish verified outcomes, findings from inspection, claims, and plans. Use only supported facts.\nState what the work found or changed. For example, write \"Import can erase saved notes without confirmation.\" Give counts only when they answer the user's question, and explain what they measure. Use names a reader can understand without the conversation. Omit internal identifiers, jargon, metaphors, and irrelevant implementation details.\nReturn only JSON: {\"progress\":[\"<result and impact>\",\"<evidence>\",\"<remaining gap or decided next step>\"],\"uncertainties\":[],\"userActions\":[]}. Use 1\u20134 progress items, normally 3\u20134 when supported. Make the first item a standalone preview. Use later items for evidence, limits, or a decided next step. Preserve distinct findings in rollups and merge repeated results.\nEach item is plain text on one line, at most 320 characters, or 160 for Chinese or Japanese. List up to two evidenced unresolved decisions in uncertainties. Label recommendations as proposals. List up to two useful actions the user can take in parallel now in userActions. Omit routine approvals and the agent's own work. Use empty arrays for groups with no applicable items.";
/**
 * Validate the new compact output without rejecting older, longer durable reports on replay.
 * @param text - the text to parse.
 * @param language - required output language; without one, a line written mostly in Chinese or Japanese characters uses the shorter limit.
 * @returns the validated progress, questions, and actions.
 */
export declare function parseSummary(text: string, language: OutputLanguage | undefined): Summary;
//# sourceMappingURL=prompt.d.ts.map