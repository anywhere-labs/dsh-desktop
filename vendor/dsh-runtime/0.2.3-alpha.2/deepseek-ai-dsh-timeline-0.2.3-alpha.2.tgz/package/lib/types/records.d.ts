import { z } from 'zod';
import type { GenerateOptions } from '@deepseek-ai/dsh-llm';
import type { PluginRecordMap, SessionId } from '@deepseek-ai/dsh-session/types';
/** Validate an agent-assigned identifier within a tree. */
export declare const taskId: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
/** Validate a host-assigned task tree identifier. */
export declare const treeId: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
/** Validate a report identifier. */
export declare const reportId: z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">;
/** Status values accepted in saved task data. */
export declare const statuses: readonly ["pending", "active", "paused", "blocked", "done", "retired"];
/** Priority values the user can choose. */
export declare const priorities: readonly ["P0", "P1", "P2", "P3"];
/** Validate a user priority or its absence. */
export declare const prioritySchema: z.ZodNullable<z.ZodEnum<{
    P0: "P0";
    P1: "P1";
    P2: "P2";
    P3: "P3";
}>>;
/** Validate the tree or task scope of a work request. */
export declare const controlTargetSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"tree">;
    tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"task">;
    tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
    task: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
}, z.core.$strict>], "kind">;
/** Validate the tree, task, or report linked to a note. */
export declare const annotationTargetSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"tree">;
    tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"task">;
    tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
    task: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"report">;
    report: z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">;
}, z.core.$strict>], "kind">;
/** Validate current and historical note identifiers. */
export declare const annotationId: z.ZodUnion<readonly [z.ZodUUID, z.ZodString]>;
/** Validate the body of a user note or agent reply. */
export declare const annotationText: z.ZodString;
/** Validate a wall clock timestamp in milliseconds. */
export declare const timestampSchema: z.ZodNumber;
/** Validate pause and continue actions. */
export declare const controlActionSchema: z.ZodEnum<{
    pause: "pause";
    resume: "resume";
}>;
/** Validate the admission state of a work request. */
export declare const controlDeliverySchema: z.ZodEnum<{
    unknown: "unknown";
    sending: "sending";
    accepted: "accepted";
}>;
/** Validate a saved discussion and its optional work request. */
export declare const annotationSchema: z.ZodObject<{
    id: z.ZodUnion<readonly [z.ZodUUID, z.ZodString]>;
    target: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"tree">;
        tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"task">;
        tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
        task: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"report">;
        report: z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">;
    }, z.core.$strict>], "kind">;
    text: z.ZodString;
    createdAt: z.ZodNumber;
    reply: z.ZodNullable<z.ZodObject<{
        text: z.ZodString;
        createdAt: z.ZodNumber;
    }, z.core.$strict>>;
    control: z.ZodOptional<z.ZodObject<{
        action: z.ZodEnum<{
            pause: "pause";
            resume: "resume";
        }>;
        delivery: z.ZodEnum<{
            unknown: "unknown";
            sending: "sending";
            accepted: "accepted";
        }>;
        outcome: z.ZodNullable<z.ZodObject<{
            status: z.ZodEnum<{
                applied: "applied";
                completed: "completed";
                unavailable: "unavailable";
                answered: "answered";
                superseded: "superseded";
            }>;
            at: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
/** Validate one entry in a task's edit history. */
export declare const taskRevisionSchema: z.ZodObject<{
    done: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
    status: z.ZodEnum<{
        pending: "pending";
        active: "active";
        paused: "paused";
        blocked: "blocked";
        done: "done";
        retired: "retired";
    }>;
    parent: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">>;
    title: z.ZodString;
    description: z.ZodString;
    note: z.ZodString;
    details: z.ZodString;
    priority: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
        P0: "P0";
        P1: "P1";
        P2: "P2";
        P3: "P3";
    }>>>;
    at: z.ZodNumber;
    progress: z.ZodNumber;
    previousProgress: z.ZodNullable<z.ZodNumber>;
    weight: z.ZodNumber;
}, z.core.$strict>;
/** Validate one task in the saved plan. */
export declare const taskSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
    parent: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">>;
    title: z.ZodString;
    description: z.ZodString;
    status: z.ZodEnum<{
        pending: "pending";
        active: "active";
        paused: "paused";
        blocked: "blocked";
        done: "done";
        retired: "retired";
    }>;
    done: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
    timeShare: z.ZodNumber;
    remaining: z.ZodNullable<z.ZodNumber>;
    mode: z.ZodEnum<{
        serial: "serial";
        parallel: "parallel";
    }>;
    note: z.ZodString;
    details: z.ZodString;
    priority: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
        P0: "P0";
        P1: "P1";
        P2: "P2";
        P3: "P3";
    }>>>;
    createdAt: z.ZodNumber;
    updatedAt: z.ZodNumber;
    history: z.ZodDefault<z.ZodArray<z.ZodObject<{
        done: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
        status: z.ZodEnum<{
            pending: "pending";
            active: "active";
            paused: "paused";
            blocked: "blocked";
            done: "done";
            retired: "retired";
        }>;
        parent: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">>;
        title: z.ZodString;
        description: z.ZodString;
        note: z.ZodString;
        details: z.ZodString;
        priority: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
            P0: "P0";
            P1: "P1";
            P2: "P2";
            P3: "P3";
        }>>>;
        at: z.ZodNumber;
        progress: z.ZodNumber;
        previousProgress: z.ZodNullable<z.ZodNumber>;
        weight: z.ZodNumber;
    }, z.core.$strict>>>;
}, z.core.$strict>;
/** Validate partial updates to one task. */
export declare const patchSchema: z.ZodObject<{
    done: z.ZodOptional<z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>>;
    status: z.ZodOptional<z.ZodEnum<{
        pending: "pending";
        active: "active";
        paused: "paused";
        blocked: "blocked";
        done: "done";
        retired: "retired";
    }>>;
    parent: z.ZodOptional<z.ZodNullable<z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">>>;
    title: z.ZodOptional<z.ZodString>;
    description: z.ZodOptional<z.ZodString>;
    timeShare: z.ZodOptional<z.ZodNumber>;
    remaining: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    mode: z.ZodOptional<z.ZodEnum<{
        serial: "serial";
        parallel: "parallel";
    }>>;
    note: z.ZodOptional<z.ZodString>;
    details: z.ZodOptional<z.ZodString>;
    id: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
    subtree: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
/** Validate a tree and its task records. */
export declare const treeSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
    title: z.ZodString;
    description: z.ZodString;
    tasks: z.ZodArray<z.ZodObject<{
        id: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
        parent: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">>;
        title: z.ZodString;
        description: z.ZodString;
        status: z.ZodEnum<{
            pending: "pending";
            active: "active";
            paused: "paused";
            blocked: "blocked";
            done: "done";
            retired: "retired";
        }>;
        done: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
        timeShare: z.ZodNumber;
        remaining: z.ZodNullable<z.ZodNumber>;
        mode: z.ZodEnum<{
            serial: "serial";
            parallel: "parallel";
        }>;
        note: z.ZodString;
        details: z.ZodString;
        priority: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
            P0: "P0";
            P1: "P1";
            P2: "P2";
            P3: "P3";
        }>>>;
        createdAt: z.ZodNumber;
        updatedAt: z.ZodNumber;
        history: z.ZodDefault<z.ZodArray<z.ZodObject<{
            done: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
            status: z.ZodEnum<{
                pending: "pending";
                active: "active";
                paused: "paused";
                blocked: "blocked";
                done: "done";
                retired: "retired";
            }>;
            parent: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">>;
            title: z.ZodString;
            description: z.ZodString;
            note: z.ZodString;
            details: z.ZodString;
            priority: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                P0: "P0";
                P1: "P1";
                P2: "P2";
                P3: "P3";
            }>>>;
            at: z.ZodNumber;
            progress: z.ZodNumber;
            previousProgress: z.ZodNullable<z.ZodNumber>;
            weight: z.ZodNumber;
        }, z.core.$strict>>>;
    }, z.core.$strict>>;
    createdAt: z.ZodNumber;
    lastTaskUpdate: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
/** Bounded, replayable UI data; ordinary native tool text excludes it. */
export declare const taskReceiptSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
    title: z.ZodString;
    branch: z.ZodNullable<z.ZodString>;
    at: z.ZodNumber;
    previousAt: z.ZodNullable<z.ZodNumber>;
    before: z.ZodNumber;
    after: z.ZodNumber;
    total: z.ZodNumber;
    tasks: z.ZodArray<z.ZodObject<{
        id: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
        title: z.ZodString;
        note: z.ZodString;
        status: z.ZodEnum<{
            pending: "pending";
            active: "active";
            paused: "paused";
            blocked: "blocked";
            done: "done";
            retired: "retired";
        }>;
        before: z.ZodNumber;
        after: z.ZodNumber;
    }, z.core.$strict>>;
}, z.core.$strict>;
/** Changes shown in a conversation card after a task update. */
export type TaskReceipt = z.infer<typeof taskReceiptSchema>;
/** Compact progress-check-style content; empty optional groups are normal. */
export declare const summarySchema: z.ZodObject<{
    progress: z.ZodArray<z.ZodString>;
    uncertainties: z.ZodArray<z.ZodString>;
    userActions: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
declare const timeRangeSchema: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
/** Host-only turn timing retained for report generation. */
export declare const activitySchema: z.ZodObject<{
    start: z.ZodNumber;
    olderWorkMs: z.ZodNumber;
    ranges: z.ZodArray<z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>>;
    open: z.ZodNullable<z.ZodNumber>;
}, z.core.$strip>;
/** Validate a saved interval or rollup report. */
export declare const reportSchema: z.ZodObject<{
    id: z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">;
    level: z.ZodNumber;
    start: z.ZodNumber;
    end: z.ZodNumber;
    createdAt: z.ZodOptional<z.ZodNumber>;
    policy: z.ZodString;
    children: z.ZodArray<z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">>;
    source: z.ZodEnum<{
        model: "model";
        "no-activity": "no-activity";
    }>;
    toolCount: z.ZodNumber;
    covered: z.ZodNumber;
    contextSeq: z.ZodNumber;
    workMs: z.ZodOptional<z.ZodNumber>;
    ranges: z.ZodOptional<z.ZodArray<z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>>>;
    summary: z.ZodObject<{
        progress: z.ZodArray<z.ZodString>;
        uncertainties: z.ZodArray<z.ZodString>;
        userActions: z.ZodArray<z.ZodString>;
    }, z.core.$strict>;
}, z.core.$strict>;
/** Validate Timeline state sent to the client. */
export declare const viewSchema: z.ZodObject<{
    trees: z.ZodArray<z.ZodObject<{
        id: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
        title: z.ZodString;
        description: z.ZodString;
        tasks: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
            parent: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">>;
            title: z.ZodString;
            description: z.ZodString;
            status: z.ZodEnum<{
                pending: "pending";
                active: "active";
                paused: "paused";
                blocked: "blocked";
                done: "done";
                retired: "retired";
            }>;
            done: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
            timeShare: z.ZodNumber;
            remaining: z.ZodNullable<z.ZodNumber>;
            mode: z.ZodEnum<{
                serial: "serial";
                parallel: "parallel";
            }>;
            note: z.ZodString;
            details: z.ZodString;
            priority: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                P0: "P0";
                P1: "P1";
                P2: "P2";
                P3: "P3";
            }>>>;
            createdAt: z.ZodNumber;
            updatedAt: z.ZodNumber;
            history: z.ZodDefault<z.ZodArray<z.ZodObject<{
                done: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                status: z.ZodEnum<{
                    pending: "pending";
                    active: "active";
                    paused: "paused";
                    blocked: "blocked";
                    done: "done";
                    retired: "retired";
                }>;
                parent: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">>;
                title: z.ZodString;
                description: z.ZodString;
                note: z.ZodString;
                details: z.ZodString;
                priority: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                    P0: "P0";
                    P1: "P1";
                    P2: "P2";
                    P3: "P3";
                }>>>;
                at: z.ZodNumber;
                progress: z.ZodNumber;
                previousProgress: z.ZodNullable<z.ZodNumber>;
                weight: z.ZodNumber;
            }, z.core.$strict>>>;
        }, z.core.$strict>>;
        createdAt: z.ZodNumber;
        lastTaskUpdate: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    annotations: z.ZodDefault<z.ZodArray<z.ZodObject<{
        id: z.ZodUnion<readonly [z.ZodUUID, z.ZodString]>;
        target: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"tree">;
            tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"task">;
            tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
            task: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"report">;
            report: z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">;
        }, z.core.$strict>], "kind">;
        text: z.ZodString;
        createdAt: z.ZodNumber;
        reply: z.ZodNullable<z.ZodObject<{
            text: z.ZodString;
            createdAt: z.ZodNumber;
        }, z.core.$strict>>;
        control: z.ZodOptional<z.ZodObject<{
            action: z.ZodEnum<{
                pause: "pause";
                resume: "resume";
            }>;
            delivery: z.ZodEnum<{
                unknown: "unknown";
                sending: "sending";
                accepted: "accepted";
            }>;
            outcome: z.ZodNullable<z.ZodObject<{
                status: z.ZodEnum<{
                    applied: "applied";
                    completed: "completed";
                    unavailable: "unavailable";
                    answered: "answered";
                    superseded: "superseded";
                }>;
                at: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
    activeTreeId: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">>;
    reports: z.ZodArray<z.ZodObject<{
        id: z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">;
        level: z.ZodNumber;
        start: z.ZodNumber;
        end: z.ZodNumber;
        createdAt: z.ZodOptional<z.ZodNumber>;
        policy: z.ZodString;
        children: z.ZodArray<z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">>;
        source: z.ZodEnum<{
            model: "model";
            "no-activity": "no-activity";
        }>;
        toolCount: z.ZodNumber;
        covered: z.ZodNumber;
        contextSeq: z.ZodNumber;
        workMs: z.ZodOptional<z.ZodNumber>;
        ranges: z.ZodOptional<z.ZodArray<z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>>>;
        summary: z.ZodObject<{
            progress: z.ZodArray<z.ZodString>;
            uncertainties: z.ZodArray<z.ZodString>;
            userActions: z.ZodArray<z.ZodString>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    error: z.ZodNullable<z.ZodString>;
}, z.core.$strip>;
/** One task or group in a plan. */
export type Task = z.infer<typeof taskSchema>;
/** A saved task edit shown in the task history. */
export type TaskRevision = z.infer<typeof taskRevisionSchema>;
/** A user note with an optional reply or request state. */
export type Annotation = z.infer<typeof annotationSchema>;
/** The task tree, task, or report referenced by a note. */
export type AnnotationTarget = z.infer<typeof annotationTargetSchema>;
/** The tree or task a work request addresses. */
export type ControlTarget = Exclude<AnnotationTarget, {
    kind: 'report';
}>;
/** An assigned priority or no priority. */
export type Priority = z.infer<typeof prioritySchema>;
/** A start and end time in milliseconds. */
export type TimeRange = z.infer<typeof timeRangeSchema>;
/** Observed intervals during which the session ran. */
export type Activity = z.infer<typeof activitySchema>;
/** A partial change to a task record. */
export type TaskPatch = z.infer<typeof patchSchema>;
/** The tasks and identifying details for one goal. */
export type Tree = z.infer<typeof treeSchema>;
/** A saved progress summary for a time interval. */
export type IntervalReport = z.infer<typeof reportSchema>;
/** Report text grouped by progress, questions, and user actions. */
export type Summary = z.infer<typeof summarySchema>;
/** Task trees, reports, and discussions shown for a session. */
export type TimelineView = z.infer<typeof viewSchema>;
/** Captured model request with its live cancellation signal removed. */
export type StoredRequest = Omit<GenerateOptions, 'signal'>;
interface TreeRecord {
    version: 1;
    sessionId: SessionId;
    callId: string;
    tree: Tree;
    receipt?: TaskReceipt | null;
}
interface SelectionRecord {
    version: 1;
    sessionId: SessionId;
    callId: string;
    treeId: Tree['id'];
}
interface ReportRecord {
    version: 1;
    sessionId: SessionId;
    report: IntervalReport;
}
/** Import continuation admitted through the normal user inbox. */
export declare const importContinuationSchema: z.ZodObject<{
    id: z.ZodUUID;
    text: z.ZodString;
}, z.core.$strip>;
declare module '@deepseek-ai/dsh-session/types' {
    interface PluginRecordMap {
        /** Restore a user-selected task tree and its discussions. */
        'plugin:timeline/import': TreeRecord & {
            annotations: Annotation[];
            prepared?: true;
            continuation?: z.infer<typeof importContinuationSchema>;
        };
        /** Publish an import after its full payload has reached durable storage. */
        'plugin:timeline/import-ready': {
            version: 1;
            sessionId: SessionId;
            callId: string;
        };
        /** Remove a tree and its discussions from the current plan. */
        'plugin:timeline/remove': {
            version: 1;
            sessionId: SessionId;
            treeId: Tree['id'];
        };
        /** Save a task tree and the tool call that changed it. */
        'plugin:timeline/tree': TreeRecord;
        /** Select a saved task tree for subsequent work. */
        'plugin:timeline/select': SelectionRecord;
        /** Save a validated interval report and its coverage. */
        'plugin:timeline/report': ReportRecord;
        /** Record a discussion or control request from the user. */
        'plugin:timeline/annotation': {
            version: 1;
            sessionId: SessionId;
            annotation: Annotation;
        };
        /** Save the agent’s reply to one discussion. */
        'plugin:timeline/reply': {
            version: 1;
            sessionId: SessionId;
            id: Annotation['id'];
            text: string;
            createdAt: number;
        };
        /** Record whether the agent accepted a control request. */
        'plugin:timeline/delivery': {
            version: 1;
            sessionId: SessionId;
            id: Annotation['id'];
            delivery: 'accepted' | 'unknown';
        };
        /** Save a priority change made by the user. */
        'plugin:timeline/priority': {
            version: 1;
            sessionId: SessionId;
            treeId: Tree['id'];
            taskId: Task['id'];
            priority: Priority;
            createdAt: number;
        };
        /** Record the report request with its reference to a reused Session prefix. */
        'plugin:timeline/request': {
            version: 1;
            sessionId: SessionId;
            id: IntervalReport['id'];
            contextSeq: number;
            prefixLength: number;
            request: StoredRequest;
        };
        /** Record a failed interval report attempt. */
        'plugin:timeline/failure': {
            version: 1;
            sessionId: SessionId;
            id: IntervalReport['id'];
            message: string;
        };
    }
}
/** Timeline changes stored as ignorable Session records. */
export type TimelineRecordMap = Pick<PluginRecordMap, Extract<keyof PluginRecordMap, `plugin:timeline/${string}`>>;
declare module '@deepseek-ai/dsh-session-projection/types' {
    interface SessionProjectionMap {
        timeline: TimelineView;
    }
}
/** Validate a saved task tree update. */
export declare const treeRecordSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    sessionId: z.ZodString;
    callId: z.ZodString;
    tree: z.ZodObject<{
        id: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
        title: z.ZodString;
        description: z.ZodString;
        tasks: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
            parent: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">>;
            title: z.ZodString;
            description: z.ZodString;
            status: z.ZodEnum<{
                pending: "pending";
                active: "active";
                paused: "paused";
                blocked: "blocked";
                done: "done";
                retired: "retired";
            }>;
            done: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
            timeShare: z.ZodNumber;
            remaining: z.ZodNullable<z.ZodNumber>;
            mode: z.ZodEnum<{
                serial: "serial";
                parallel: "parallel";
            }>;
            note: z.ZodString;
            details: z.ZodString;
            priority: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                P0: "P0";
                P1: "P1";
                P2: "P2";
                P3: "P3";
            }>>>;
            createdAt: z.ZodNumber;
            updatedAt: z.ZodNumber;
            history: z.ZodDefault<z.ZodArray<z.ZodObject<{
                done: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                status: z.ZodEnum<{
                    pending: "pending";
                    active: "active";
                    paused: "paused";
                    blocked: "blocked";
                    done: "done";
                    retired: "retired";
                }>;
                parent: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">>;
                title: z.ZodString;
                description: z.ZodString;
                note: z.ZodString;
                details: z.ZodString;
                priority: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                    P0: "P0";
                    P1: "P1";
                    P2: "P2";
                    P3: "P3";
                }>>>;
                at: z.ZodNumber;
                progress: z.ZodNumber;
                previousProgress: z.ZodNullable<z.ZodNumber>;
                weight: z.ZodNumber;
            }, z.core.$strict>>>;
        }, z.core.$strict>>;
        createdAt: z.ZodNumber;
        lastTaskUpdate: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>;
    receipt: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        version: z.ZodLiteral<1>;
        tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
        title: z.ZodString;
        branch: z.ZodNullable<z.ZodString>;
        at: z.ZodNumber;
        previousAt: z.ZodNullable<z.ZodNumber>;
        before: z.ZodNumber;
        after: z.ZodNumber;
        total: z.ZodNumber;
        tasks: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
            title: z.ZodString;
            note: z.ZodString;
            status: z.ZodEnum<{
                pending: "pending";
                active: "active";
                paused: "paused";
                blocked: "blocked";
                done: "done";
                retired: "retired";
            }>;
            before: z.ZodNumber;
            after: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
}, z.core.$strip>;
/** Validate an imported tree and its discussions. */
export declare const importRecordSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    sessionId: z.ZodString;
    callId: z.ZodString;
    tree: z.ZodObject<{
        id: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
        title: z.ZodString;
        description: z.ZodString;
        tasks: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
            parent: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">>;
            title: z.ZodString;
            description: z.ZodString;
            status: z.ZodEnum<{
                pending: "pending";
                active: "active";
                paused: "paused";
                blocked: "blocked";
                done: "done";
                retired: "retired";
            }>;
            done: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
            timeShare: z.ZodNumber;
            remaining: z.ZodNullable<z.ZodNumber>;
            mode: z.ZodEnum<{
                serial: "serial";
                parallel: "parallel";
            }>;
            note: z.ZodString;
            details: z.ZodString;
            priority: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                P0: "P0";
                P1: "P1";
                P2: "P2";
                P3: "P3";
            }>>>;
            createdAt: z.ZodNumber;
            updatedAt: z.ZodNumber;
            history: z.ZodDefault<z.ZodArray<z.ZodObject<{
                done: z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>;
                status: z.ZodEnum<{
                    pending: "pending";
                    active: "active";
                    paused: "paused";
                    blocked: "blocked";
                    done: "done";
                    retired: "retired";
                }>;
                parent: z.ZodNullable<z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">>;
                title: z.ZodString;
                description: z.ZodString;
                note: z.ZodString;
                details: z.ZodString;
                priority: z.ZodDefault<z.ZodNullable<z.ZodEnum<{
                    P0: "P0";
                    P1: "P1";
                    P2: "P2";
                    P3: "P3";
                }>>>;
                at: z.ZodNumber;
                progress: z.ZodNumber;
                previousProgress: z.ZodNullable<z.ZodNumber>;
                weight: z.ZodNumber;
            }, z.core.$strict>>>;
        }, z.core.$strict>>;
        createdAt: z.ZodNumber;
        lastTaskUpdate: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>;
    receipt: z.ZodOptional<z.ZodNullable<z.ZodObject<{
        version: z.ZodLiteral<1>;
        tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
        title: z.ZodString;
        branch: z.ZodNullable<z.ZodString>;
        at: z.ZodNumber;
        previousAt: z.ZodNullable<z.ZodNumber>;
        before: z.ZodNumber;
        after: z.ZodNumber;
        total: z.ZodNumber;
        tasks: z.ZodArray<z.ZodObject<{
            id: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
            title: z.ZodString;
            note: z.ZodString;
            status: z.ZodEnum<{
                pending: "pending";
                active: "active";
                paused: "paused";
                blocked: "blocked";
                done: "done";
                retired: "retired";
            }>;
            before: z.ZodNumber;
            after: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>>>;
    annotations: z.ZodArray<z.ZodObject<{
        id: z.ZodUnion<readonly [z.ZodUUID, z.ZodString]>;
        target: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"tree">;
            tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"task">;
            tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
            task: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"report">;
            report: z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">;
        }, z.core.$strict>], "kind">;
        text: z.ZodString;
        createdAt: z.ZodNumber;
        reply: z.ZodNullable<z.ZodObject<{
            text: z.ZodString;
            createdAt: z.ZodNumber;
        }, z.core.$strict>>;
        control: z.ZodOptional<z.ZodObject<{
            action: z.ZodEnum<{
                pause: "pause";
                resume: "resume";
            }>;
            delivery: z.ZodEnum<{
                unknown: "unknown";
                sending: "sending";
                accepted: "accepted";
            }>;
            outcome: z.ZodNullable<z.ZodObject<{
                status: z.ZodEnum<{
                    applied: "applied";
                    completed: "completed";
                    unavailable: "unavailable";
                    answered: "answered";
                    superseded: "superseded";
                }>;
                at: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    prepared: z.ZodOptional<z.ZodLiteral<true>>;
    continuation: z.ZodOptional<z.ZodObject<{
        id: z.ZodUUID;
        text: z.ZodString;
    }, z.core.$strip>>;
}, z.core.$strip>;
/** Validate the reference to a durably saved import. */
export declare const importReadySchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    sessionId: z.ZodString;
    callId: z.ZodString;
}, z.core.$strip>;
/** Validate a removed tree reference. */
export declare const removalRecordSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    sessionId: z.ZodString;
    treeId: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
}, z.core.$strip>;
/** Validate a selected tree reference. */
export declare const selectionRecordSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    sessionId: z.ZodString;
    callId: z.ZodString;
    treeId: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
}, z.core.$strip>;
/** Validate a new saved user note. */
export declare const annotationRecordSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    sessionId: z.ZodString;
    annotation: z.ZodObject<{
        id: z.ZodUnion<readonly [z.ZodUUID, z.ZodString]>;
        target: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"tree">;
            tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"task">;
            tree: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
            task: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"report">;
            report: z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">;
        }, z.core.$strict>], "kind">;
        text: z.ZodString;
        createdAt: z.ZodNumber;
        reply: z.ZodNullable<z.ZodObject<{
            text: z.ZodString;
            createdAt: z.ZodNumber;
        }, z.core.$strict>>;
        control: z.ZodOptional<z.ZodObject<{
            action: z.ZodEnum<{
                pause: "pause";
                resume: "resume";
            }>;
            delivery: z.ZodEnum<{
                unknown: "unknown";
                sending: "sending";
                accepted: "accepted";
            }>;
            outcome: z.ZodNullable<z.ZodObject<{
                status: z.ZodEnum<{
                    applied: "applied";
                    completed: "completed";
                    unavailable: "unavailable";
                    answered: "answered";
                    superseded: "superseded";
                }>;
                at: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strip>;
/** Validate a saved agent reply. */
export declare const replyRecordSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    sessionId: z.ZodString;
    id: z.ZodUnion<readonly [z.ZodUUID, z.ZodString]>;
    text: z.ZodString;
    createdAt: z.ZodNumber;
}, z.core.$strip>;
/** Validate a work request's admission result. */
export declare const deliveryRecordSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    sessionId: z.ZodString;
    id: z.ZodUnion<readonly [z.ZodUUID, z.ZodString]>;
    delivery: z.ZodEnum<{
        unknown: "unknown";
        accepted: "accepted";
    }>;
}, z.core.$strip>;
/** Validate a user priority change. */
export declare const priorityRecordSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    sessionId: z.ZodString;
    treeId: z.core.$ZodBranded<z.ZodString, "TimelineTreeId", "out">;
    taskId: z.core.$ZodBranded<z.ZodString, "TimelineTaskId", "out">;
    priority: z.ZodNullable<z.ZodEnum<{
        P0: "P0";
        P1: "P1";
        P2: "P2";
        P3: "P3";
    }>>;
    createdAt: z.ZodNumber;
}, z.core.$strip>;
/** Validate a saved interval report record. */
export declare const reportRecordSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    sessionId: z.ZodString;
    report: z.ZodObject<{
        id: z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">;
        level: z.ZodNumber;
        start: z.ZodNumber;
        end: z.ZodNumber;
        createdAt: z.ZodOptional<z.ZodNumber>;
        policy: z.ZodString;
        children: z.ZodArray<z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">>;
        source: z.ZodEnum<{
            model: "model";
            "no-activity": "no-activity";
        }>;
        toolCount: z.ZodNumber;
        covered: z.ZodNumber;
        contextSeq: z.ZodNumber;
        workMs: z.ZodOptional<z.ZodNumber>;
        ranges: z.ZodOptional<z.ZodArray<z.ZodTuple<[z.ZodNumber, z.ZodNumber], null>>>;
        summary: z.ZodObject<{
            progress: z.ZodArray<z.ZodString>;
            uncertainties: z.ZodArray<z.ZodString>;
            userActions: z.ZodArray<z.ZodString>;
        }, z.core.$strict>;
    }, z.core.$strict>;
}, z.core.$strip>;
/** Validate a report failure record. */
export declare const failureRecordSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    sessionId: z.ZodString;
    id: z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">;
    message: z.ZodString;
}, z.core.$strip>;
/** Validate the saved report request and its reference to the Session message prefix. */
export declare const requestRecordSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    sessionId: z.ZodString;
    id: z.core.$ZodBranded<z.ZodString, "TimelineReportId", "out">;
    contextSeq: z.ZodNumber;
    prefixLength: z.ZodNumber;
    request: z.ZodJSONSchema;
}, z.core.$strip>;
/**
 * Match Harness Job-style IDs; a supplied digest keeps new-tree retries repeatable.
 * @param kind - the kind of record being identified.
 * @param hex - random or stable hexadecimal input for the identifier.
 * @returns the identifier for the requested kind of record.
 */
export declare function newId(kind: 'tree' | 'report' | 'note', hex?: string): string;
export {};
//# sourceMappingURL=records.d.ts.map