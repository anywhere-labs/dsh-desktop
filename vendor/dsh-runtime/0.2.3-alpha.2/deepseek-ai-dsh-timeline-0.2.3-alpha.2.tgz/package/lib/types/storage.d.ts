import { Service } from '@deepseek-ai/cordis';
import type { Context } from '@deepseek-ai/cordis';
import type { Session } from '@deepseek-ai/dsh-session';
import type { Config } from './config.ts';
import type { TimelineReader, TimelineState } from './projection.ts';
import type { TimelineRecordMap } from './records.ts';
import type { UserEdit, UserEditResult } from './protocol.ts';
import type { OutputLanguage } from './policy.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        timeline: TimelineStorage;
    }
    interface Events {
        /**
         * A saved user edit entered or left P0. Model task patches do not emit it.
         * @mode emit
         * @param session - the session that owns the task.
         */
        'timeline/priority'(session: Session): void;
    }
}
/** Coordinate Timeline edits through the live Session writer. */
export declare class TimelineStorage extends Service implements TimelineReader {
    private readonly projection;
    private readonly config;
    private readonly pending;
    private readonly unflushed;
    private closed;
    constructor(ctx: Context, projection: TimelineReader, config: Config, setBrowserLanguage: (language: OutputLanguage) => void);
    /**
     * Check whether the live Session can own new Timeline records.
     * @param session - the session whose plan or reports are affected.
     * @returns whether the Session is live with a persistence backend.
     */
    available(session: Session): boolean;
    private enqueue;
    /**
     * Only the owner Client can create feedback or set priority. Model tools have narrower operations.
     * @param input - input to validate.
     * @returns the acknowledged result of the edit.
     */
    edit(input: UserEdit): Promise<UserEditResult>;
    private transfer;
    /** Save before admission. The write queue arbitrates duplicate requests from every Client. */
    private control;
    /** Read task, report, and activity state from the Session projection. */
    stateOf(session: Session): TimelineState;
    /**
     * Serialize changes to one live Session and flush its append-only log.
     * @param session - session whose plan or reports are affected.
     * @param type - discriminator of the record being written.
     * @param change - record or function that derives it from the latest state.
     */
    append<K extends keyof TimelineRecordMap>(session: Session, type: K, change: TimelineRecordMap[K] | ((state: TimelineState) => TimelineRecordMap[K] | undefined)): Promise<void>;
}
//# sourceMappingURL=storage.d.ts.map