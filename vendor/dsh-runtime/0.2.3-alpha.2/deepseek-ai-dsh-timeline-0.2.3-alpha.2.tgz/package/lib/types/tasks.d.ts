import type { Priority, Task, TaskPatch } from './records.ts';
/** The four categories shown on a segmented progress bar. */
export declare const progressStates: readonly ["done", "active", "pending", "blocked"];
/** Weighted shares and leaf counts by displayed status. */
export type ProgressParts = Record<(typeof progressStates)[number], {
    fraction: number;
    leaves: number;
    titles: string[];
}>;
/** Weighted completion and an optional Client-only visual breakdown. */
interface Measure {
    progress: number;
    remaining: number | null;
    status: Task['status'];
    parts?: ProgressParts;
}
/**
 * Apply an atomic patch batch; unknown parents, cycles, and invalid groups fail without changing input.
 * @param previous - task records before the edit.
 * @param input - input to validate.
 * @param at - wall clock time associated with the update.
 * @param limit - upper bound on the number of entries.
 * @param source - an edit needs a reason for status changes; a checkpoint already records the status.
 * @returns the updated tasks after the whole batch validates.
 */
export declare function patchTasks(previous: readonly Task[], input: readonly TaskPatch[], at: number, limit: number, source?: 'edit' | 'checkpoint'): Task[];
/**
 * Capture semantic edits, including derived group progress, in the same durable task write.
 * @param previous - task records before the edit.
 * @param tasks - task records for the addressed tree.
 * @param at - wall clock time associated with the update.
 * @returns the updated tasks with new history for changed entries.
 */
export declare function recordTaskHistory(previous: readonly Task[], tasks: readonly Task[], at: number): Task[];
/**
 * User priority applies to a subtree; an explicit child priority overrides its parent.
 * @param tasks - task records for the addressed tree.
 * @returns the effective priority of each task.
 */
export declare function prioritiesOf(tasks: readonly Task[]): ReadonlyMap<Task['id'], Priority>;
/**
 * Keep the next-work queue short and exclude completed or deliberately unavailable work.
 * @param trees - the task trees for the current session.
 * @param limit - upper bound on the number of entries.
 * @returns eligible leaves in priority order, up to the limit.
 */
export declare function prioritizedTasks(trees: readonly {
    id: string;
    tasks: readonly Task[];
}[], limit?: number): {
    tree: string;
    task: Task['id'];
    title: string;
    priority: NonNullable<Priority>;
    status: Task['status'];
}[];
/**
 * Measure each leaf and group once, including the virtual root at null.
 * @param tasks - task records for the addressed tree.
 * @param withParts - whether to include the breakdown by status.
 * @returns progress by task, including the virtual root at null.
 */
export declare function measureAll(tasks: readonly Task[], withParts?: boolean): ReadonlyMap<Task['id'] | null, Measure>;
export {};
//# sourceMappingURL=tasks.d.ts.map