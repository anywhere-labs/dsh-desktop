import type { Context } from '@deepseek-ai/cordis';
import type { Config } from './config.ts';
import type { TimelineStorage } from './storage.ts';
/**
 * Keep planning, reading, and annotation replies separate from user-owned edits.
 * @param ctx - owning plugin context.
 * @param config - current Timeline settings.
 * @param storage - Timeline's session data service.
 */
export declare function installTools(ctx: Context, config: Config, storage: TimelineStorage): void;
//# sourceMappingURL=tools.d.ts.map