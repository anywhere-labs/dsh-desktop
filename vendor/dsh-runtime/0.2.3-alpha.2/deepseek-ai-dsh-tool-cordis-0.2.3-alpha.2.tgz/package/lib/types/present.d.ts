/** Pure replay-safe render intents for runtime inspection. */
import type { GenericCallView } from '@deepseek-ai/dsh-tools';
/**
 * Render a provider directory or one exact query.
 * @param args - Optional query target.
 * @returns replay-safe generic call presentation.
 */
export declare function presentInspectCall(args: {
    query?: {
        platform: string;
        provider: string;
        method: string;
    };
}): GenericCallView;
//# sourceMappingURL=present.d.ts.map