/**
 * Program images for tool values that reference their result images through
 * `{ type: 'image', attachment }` entries, such as admitted MCP image blocks.
 * @module
 */
import type { ImageBlock } from '@deepseek-ai/dsh-llm';
import type { PtcJsonValue } from '@deepseek-ai/dsh-ptc-runtime';
import type { JsonValue } from '@deepseek-ai/dsh-util-values';
/**
 * Replace each image entry whose attachment is one of the finalized result images.
 * Entries naming another attachment, such as an image a policy removed, stay JSON.
 * @param value - Canonical tool value; it is not modified.
 * @param images - Image blocks of the finalized result content.
 * @param image - Creates the program value for one finalized reference, or returns undefined when the program cannot read it.
 * @returns The substituted value, or undefined unless every finalized image was substituted.
 */
export declare function substituteProgramImages(value: JsonValue, images: readonly ImageBlock[], image: (ref: ImageBlock['attachment']) => PtcJsonValue | undefined): PtcJsonValue | undefined;
//# sourceMappingURL=program-images.d.ts.map