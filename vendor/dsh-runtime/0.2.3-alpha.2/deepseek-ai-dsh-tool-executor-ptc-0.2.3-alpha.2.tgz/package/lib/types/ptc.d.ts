/**
 * Shared program transport. Programs call their admitted tools through nested
 * executions scheduled under the native concurrency contract; each sub-dispatch
 * is logged for reconstruction, while only the outer curated result enters model
 * history.
 * @module
 */
import { type Context } from '@deepseek-ai/cordis';
import type { PtcRuntime } from '@deepseek-ai/dsh-ptc-runtime';
import { RUN_CODE_NAME } from '@deepseek-ai/dsh-tools';
import type { ToolExecutionPipeline } from '@deepseek-ai/dsh-tools/pipeline';
import type { PtcCalls } from './ptc-calls.ts';
import type { Config } from './config.ts';
import type { RunCodeToolOptions } from './run-code.ts';
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
/** The model-facing name of the PTC mode tool. */
export { RUN_CODE_NAME };
/**
 * Read the active runtime, rejecting missing providers and unsupported languages.
 * @param ctx - executor context containing the runtime provider.
 * @returns the mounted TypeScript provider.
 */
export declare function requirePtcRuntime(ctx: Context): PtcRuntime;
/**
 * Reject providers whose source language the executor cannot present.
 * @param runtime - Mounted or explicitly supplied provider.
 * @returns The supported provider.
 * @throws ToolContextUnavailableError for a language other than TypeScript.
 */
export declare function requireRuntimeLanguage(runtime: PtcRuntime): PtcRuntime;
/**
 * Build a program transport using the shared nested-call scheduler.
 * @param ctx - executor context owning policy listeners and active program cleanup.
 * @param executor - shared invocation pipeline for nested calls.
 * @param config - validated timeout-based tool-call allowance and concurrency limits.
 * @param calls - Executor-owned cancellation and reset coordination.
 * @param options - Fixed runtime and tools for a registered program tool; omission selects PTC's visible registry and current runtime.
 * @returns the transport definition with runtime-dependent schema text.
 */
export declare function createRunCodeTransport(ctx: Context, executor: ToolExecutionPipeline, config: Config, calls: PtcCalls, options?: Omit<RunCodeToolOptions, 'limits'>): ToolDefinition;
//# sourceMappingURL=ptc.d.ts.map