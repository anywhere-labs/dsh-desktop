/**
 * Model-authored messages to ordinary Web Sessions with runtime-owned sender attribution.
 * @module @deepseek-ai/dsh-tool-session-control
 */
import type { Context } from '@deepseek-ai/cordis';
import { HarnessError } from '@deepseek-ai/dsh-error';
/** Cordis plugin name. */
export declare const name = "tool-session-control";
/** Services used by Session message tools. */
export declare const inject: string[];
/** Failures callers distinguish without parsing a display message. */
export type SessionMessageErrorCode = 'SESSION_MESSAGE_SELF' | 'SESSION_MESSAGE_ARCHIVED' | 'SESSION_MESSAGE_SUBAGENT_OWNED';
/** Rejection before the target inbox accepted the message; a retry repeats no accepted delivery. */
export declare class SessionMessageError extends HarnessError {
    readonly code: SessionMessageErrorCode;
    /**
     * @param message - actionable description of the rejected delivery.
     * @param code - stable failure classification.
     * @param options - original cause when converting a dependency failure.
     */
    constructor(message: string, code: SessionMessageErrorCode, options?: ErrorOptions);
}
/**
 * Register Session message delivery for a Web composition.
 * @param ctx - context providing the tool registry, Session controller, and Workspace registry.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map