/**
 * Upstream skills of CLI app plugins: the Host Service `ctx.upstreamSkills` downloads the files that a plugin's entry
 * skill indexes from one directory of the vendor's GitHub repository at a pinned commit, verifies them, publishes them
 * in the DSH cache, and lists the entry skill over them once they are there. In a profile, each plugin's files have
 * a directory of their own, from which a registration deletes the other pins once its own pin is in place.
 * @module @deepseek-ai/dsh-upstream-skills
 */
import { Service, type Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { UpstreamSkillsHandle, UpstreamSkillsRegistration } from './types.ts';
export type * from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** The upstream skills CLI app plugins register. */
        upstreamSkills: UpstreamSkills;
    }
}
/** Where every registered plugin's upstream files are downloaded from. */
export interface Config {
    /** Archive download prefixes tried in order; each serves `<owner>/<repository>/tar.gz/<commit>`. */
    skillsUrls: string[];
    /** How long one prefix may take to deliver the whole archive before the next one is tried. */
    skillsTimeoutMs: number;
}
/** Holds what CLI app plugins register: for each plugin, the entry skill and the download of the upstream files it indexes. */
export default class UpstreamSkills extends Service {
    private readonly config;
    static inject: string[];
    /** `skillsUrls` defaults to GitHub's archive host. */
    static Config: z<Partial<Config>, Config>;
    constructor(ctx: Context, config: Config);
    /**
     * Register the calling plugin's entry skill and start downloading the upstream files unless they are in place. The
     * download starts at load so that a session without a client also gets the skill; a failure is logged as a warning
     * and waits for `retry()`. In a profile, the files go to that profile's own directory for the plugin, and the
     * registration deletes the other pins there once, the first time its own pin is in place. The registration belongs
     * to the calling plugin: unloading that plugin aborts the download and removes the entry skill.
     * @param registration - the plugin's provider name, entry, pinned files, and optional skills directory.
     * @returns the handle the plugin's view observes and its check retries.
     * @throws when the entry has no skill name or description in its frontmatter, `skillsDir` is not a directory, or a
     *   skill provider named `name` is already registered.
     */
    register(registration: UpstreamSkillsRegistration): UpstreamSkillsHandle;
}
//# sourceMappingURL=index.d.ts.map