/**
 * Authentication and redirect-rejecting transport shared by the Search and
 * Fetch API providers in this package
 * ([rationale](../../../../.agents/notes/implemented/feature/2026-10-15-deepseek-search-fetch-api.md)).
 * @module @deepseek-ai/dsh-web-deepseek-api/transport
 */
import type { DeepSeekAuthCandidate } from '@deepseek-ai/dsh-deepseek-auth';
import { WebError } from '@deepseek-ai/dsh-web';
/** One credential an operation can send, bound to the endpoint it is sent to. */
export type DeepSeekWebAuthSource = 
/**
 * A credential kind `ctx.deepseekAuth` bound to the operation's endpoint. It answers presence and releases the
 * request headers per use; read failures reject.
 */
DeepSeekAuthCandidate
/** A credential whose settings do not resolve; reaching it fails the operation with `WEB_PROVIDER_MISCONFIGURED`. */
 | {
    kind: 'misconfigured';
    /** Model-facing diagnostic naming the settings and their recoveries. */
    message: string;
};
/**
 * Credentials of one operation in the order the caller chose. The operation reads them in order and sends one request
 * with the first that is present; a later source is not read once an earlier one is present, fails to read, or is
 * misconfigured. Request failures never move to another source.
 */
export interface DeepSeekWebAuth {
    /** Candidate credentials, first preferred. */
    sources: readonly DeepSeekWebAuthSource[];
    /** Model-facing `WEB_PROVIDER_CREDENTIAL_MISSING` diagnostic; omitted uses a generic missing-credential message. */
    missingCredentialMessage?: string;
}
/** User-owned endpoint settings named by dispatch failures. */
export interface DeepSeekWebGuidance {
    /** Capability whose endpoint failed. */
    subject: 'Search' | 'Fetch';
    /** Plugin configuration namespace. */
    plugin: string;
    /** Whether the endpoint is the capability's own base URL rather than one derived from a model route. */
    custom: boolean;
    /** Configuration field of the capability's own base URL. */
    baseURLField: string;
    /** Configuration field of the capability's own credential reference. */
    apiKeyEnvField: string;
}
/** One fully resolved web API request. */
interface DeepSeekWebRequest<T> {
    /** JSON request body. */
    body: object;
    /** Protocol headers without credentials. */
    headers?: Readonly<Record<string, string>>;
    /** Validate and project the response. */
    decode: (payload: unknown) => T;
    /** Endpoint recovery settings. */
    guidance: DeepSeekWebGuidance;
    /** Record model input before dispatch; a throw prevents dispatch. */
    recordRequest?: (endpoint: string) => void;
    /** Wait for permission to send after credentials resolve; a rejection prevents dispatch. */
    waitToSend?: (signal?: AbortSignal) => Promise<void>;
}
/**
 * Check synchronously whether an operation has a source to try, without reading credentials.
 * @param auth - Sources for the operation.
 * @returns Whether any source exists: a credential kind bound to the endpoint, or a misconfigured source the
 *   operation reports.
 */
export declare function hasDeepSeekWebCredential(auth: DeepSeekWebAuth): boolean;
/**
 * Check whether an operation would find a credential, reading the sources in the order {@link dispatchDeepSeekWeb}
 * does. Each source is only asked whether a credential is configured, so a malformed or wrong key counts as ready. A
 * misconfigured source or a failed read answers false without reading later sources, because the operation fails there
 * too. Nothing is sent and nothing is retained.
 * @param auth - Sources for the operation.
 * @returns Whether a source before any misconfigured or unreadable one is present.
 */
export declare function isDeepSeekWebAuthReady(auth: DeepSeekWebAuth): Promise<boolean>;
/** Narrow a remote JSON object.
 * @param value - Untrusted JSON.
 * @returns Whether readable object fields exist.
 */
export declare function isRecord(value: unknown): value is Record<string, unknown>;
/** Report malformed upstream JSON without embedding response content.
 * @returns The stable provider error.
 */
export declare function invalidResponse(): WebError;
/** Dispatch one operation using a single settings and credential snapshot: one request, with the first present source.
 * @param options - Ordered authentication sources for this operation.
 * @param request - JSON payload and response decoder.
 * @param signal - Caller cancellation signal.
 * @returns The validated provider result.
 */
export declare function dispatchDeepSeekWeb<T>(options: DeepSeekWebAuth, request: DeepSeekWebRequest<T>, signal?: AbortSignal): Promise<T>;
/**
 * Build the provider's stable cancellation error while retaining the caller's reason.
 * @param signal - the aborted caller signal; its reason becomes the cause.
 * @param fallback - the cause when the signal has not aborted, such as a fetch `AbortError`.
 * @returns a `WEB_ABORTED` error.
 */
export declare function searchAborted(signal?: AbortSignal, fallback?: unknown): WebError;
export {};
//# sourceMappingURL=transport.d.ts.map