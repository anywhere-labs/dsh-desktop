---
description: "ctx.web 的 DeepSeek 搜索提供方：部署方如何通过 Anthropic 兼容 Messages API 挂载 DeepSeek 原生 web 搜索，并逐次解析凭据。"
kind: "package-reference"
---

# @deepseek-ai/dsh-web-search-deepseek

[English](README.md) | 中文

## 概述

有了 `dsh-web-search-deepseek`，harness 可以通过 DeepSeek 原生搜索检索 web，使用 DeepSeek 账号登录或部署已有的 `DEEPSEEK_API_KEY`。当部署希望使用 DeepSeek 原生搜索、并接受一次搜索在延迟与 token 上消耗一个完整模型轮次时选择它；[dsh-web-deepseek-api](../web-deepseek-api/README.zh.md) 中的 DeepSeek Search 与 Fetch API 无需模型轮次即可检索。结果来自 DeepSeek 的结构化搜索块，绝不取自回复文本。对没有可用凭据的模型请求，提供方报告自身未就绪，因此 `dsh-tool-web` 会对该请求撤下 `web_search`；仍然到达的调用，或缺少搜索结果块的响应，都以结构化错误失败。

## 目录

- [使用本包](#use-this-package)
- [理解实现](#understand-the-implementation)
- [进一步探索](#further-exploration)
- [模型体验](#model-experience)
- [已知限制与延期工作](#known-limitations-and-deferred-work)
- [开发备注](#dev-note)

-----

<a id="use-this-package"></a>
## 使用本包

在已加载 web 服务和为它释放凭据的 [`dsh-deepseek-auth`](../../account/deepseek-auth/README.zh.md) 的组合中挂载本提供方；它以 `deepseek-official` 搜索提供方身份注册，因此当它是唯一可用的搜索后端时，`ctx.web.search()` 会自动解析到它；没有配置搜索提供方时，为 `deepseek-official` 或 `deepseek-account` 模型路由上的模型请求发起的搜索也解析到它（[提供方选择](../web/README.zh.md#provider-selection)）——也可以用 `searchProvider: deepseek-official` 固定。

### 何时选择

当部署希望使用 DeepSeek 原生服务端 web 搜索、且其用户登录 DeepSeek 账号或持有 `DEEPSEEK_API_KEY` 时选择此后端——提供方按[鉴权](#authentication)所述复用这些凭据。一次搜索比专用检索端点更重：DeepSeek 在完整模型轮次内执行搜索，因此每次搜索都要预期一次 Messages 调用的延迟与生成 token，每次请求最多 `maxUses` 次服务端搜索。DeepSeek 不对它按次收费，因此其成本是该模型轮次的 token。当延迟占主导时避免使用它。

### 最小配置

加载 web 服务、DeepSeek 鉴权服务与本提供方；密钥在已挂载 `ctx.credentials` 服务时从其解析，否则从进程环境解析。辅助搜索调用有独立的端点设置，使用 Anthropic 兼容基址 `https://api.deepseek.com/anthropic/v1`，并追加 `/messages`。它读取 `$DEEPSEEK_SEARCH_BASE_URL`，与会话适配器的 `$DEEPSEEK_BASE_URL` 相互独立；`dsh` 启动器从启动环境或 `$DSH_HOME/.env` 接受这两个变量，绝不从项目 `.env` 接受（[app-boot](../../boot/app-boot/README.zh.md)）。

```yaml
- name: '@deepseek-ai/dsh-web'
- name: '@deepseek-ai/dsh-deepseek-auth'
- name: '@deepseek-ai/dsh-web-search-deepseek'
  config:
    apiKeyEnv: DEEPSEEK_API_KEY
    baseURL: https://gateway.internal/anthropic/v1
```

| 字段 | 默认值 | 含义 |
|---|---|---|
| `apiKey` | 未设置 | DeepSeek API 密钥字面值；优先使用 `apiKeyEnv`，避免密钥进入配置。非空字面值优先于 `apiKeyEnv`；账号 token 优先于两者 |
| `apiKeyEnv` | `DEEPSEEK_API_KEY` | 每次搜索通过 `ctx.credentials` 解析的凭据引用；没有该服务时从进程环境解析。需要 API 密钥却解析不到时，搜索以 `WEB_PROVIDER_CREDENTIAL_MISSING` 失败 |
| `baseURL` | `https://api.deepseek.com/anthropic/v1` | Anthropic 兼容端点基址；追加 `/messages`。缺省时回退到 `$DEEPSEEK_SEARCH_BASE_URL`；无法解析时提供方不可用 |
| `model` | `deepseek-v4-flash` | Anthropic 格式模型名称 |
| `apiVersion` | `2023-06-01` | `anthropic-version` 标头值 |
| `maxTokens` | `4096` | Messages 请求生成 token 的正整数上限 |
| `maxUses` | `5` | 每次请求使用 `web_search` 服务器工具的正整数上限 |

生成的[配置目录](../../../docs/config-catalog.zh.md#deepseek-aidsh-web-search-deepseek) 列出所有接受的字段。每次搜索从即时 Config 引用捕获选项。

<a id="authentication"></a>
### 鉴权

当发起会话最近的 `request/context` 事件指明 `deepseek-account` 模型路由，搜索端点与该路由的基础地址同源，且 `ctx.deepseekAuth` 为搜索端点释放了账号登录凭据时，搜索使用 DeepSeek 账号鉴权。只有同源时才会索取该凭据，因此它不会发往其他部署的搜索端点。账号服务仅在已登录时、且仅对部署配置的推理 origin（默认 `https://api.deepseek.com`）释放凭据。这类搜索只发送该凭据的请求头 `x-dsh-auth-token`，即使配置了 API 密钥也是如此。其余所有搜索，包括没有发起会话的调用以及端点属于其他 origin 的搜索，都把 API 密钥同时作为 `x-api-key` 与 `Authorization: Bearer` 发送。账号鉴权的搜索收到 HTTP 401 时以 `WEB_PROVIDER_ERROR` 失败，附带登录指引而非端点指引，并通过凭据自身的失效操作只作废该搜索实际发送的凭据：更新的登录不受影响，凭据删除失败或错误正文读取被取消既不会跳过作废，也不会替换所报告的失败。API 密钥请求的 401 与所有 HTTP 403 不影响账号登录状态。账号退登时仍在途的账号鉴权搜索会通过凭据的 `revoked` 信号结束，并以 `WEB_PROVIDER_ERROR` 失败，附带登录指引。

提供方的 `ready()` 回答模型请求将发起的搜索是否有凭据，不论模型路由：在 `deepseek-account` 路由上账号登录凭据已为搜索端点配置（这要求该端点位于该路由基础地址的 origin 之下），或者设置了字面 `apiKey`，或 `ctx.credentials.describe` 报告 `apiKeyEnv` 引用已配置（没有该服务时，进程环境中必须存在该变量）。它按搜索解析凭据的顺序检查；路由设置无法解析，或读取账号凭据或凭据存储失败时回答 false，因为搜索会在那里失败，而不会尝试下一种凭据。本提供方是选中的搜索提供方时，[`dsh-tool-web`](../tool-web/README.zh.md#search-readiness) 会从它回答 false 的每个请求中撤下 `web_search` 及其提示词说明。这里只检查凭据是否存在：错误的密钥，或不提供原生 `web_search_20250305` 服务器工具的端点，都视为就绪并使每次调用失败。仍然到达的调用会在运行时解析凭据。

引用密钥由 `ctx.deepseekAuth` 通过 [`dsh-credentials`](../../credentials/credentials/README.zh.md) 的凭据引用函数读取，接受与模型请求相同的首尾空白规范化和格式校验。引用密钥格式错误会在发送请求前失败；就绪判断仍只检查是否存在。

### 搜索返回什么

`content` 始终省略：DeepSeek 的提供方文本不作为答案受到信任。`sources[]` 来自 `web_search_tool_result` 块内的 `web_search_result` 条目——`url` 和 `title` 直接取自同名字段，`publishedAt` 取自 `page_age`，`snippet` 取自条目自带的 `snippet`，条目没有时取自按 URL 关联且存在摘录的 `cited_text` 条目。结果按 URL 去重，且由于 DeepSeek 不公开结果数量旋钮，服务通过截断并标记来强制执行 `maxResults`。

### 请求日志

由发起 agent（智能体）运行的搜索会在发出请求前一刻，追加仅用于日志的 `web/deepseek-search-llm-request` 会话事件。其中包含已解析端点、API 版本，以及发送给 DeepSeek 且不含密钥的精确 JSON 请求体；不包含标头和凭据。发出请求前发生凭据失败或取消时不会创建事件，而发出请求后的 HTTP 或响应失败会保留本次请求尝试的持久记录。

### 失败与恢复

失败抛出携带可按机器路由 code 的 `WebError`：凭据缺失为 `WEB_PROVIDER_CREDENTIAL_MISSING`，调用方取消为 `WEB_ABORTED`，提供方或传输失败，包括响应中没有 `web_search_tool_result` 块，为 `WEB_PROVIDER_ERROR`。HTTP 重定向会在接触 `Location` 指向的目标之前被拒绝。请求发出后的每项失败都会指出已解析的搜索端点，并说明搜索端点配置独立于聊天端点。如果该端点不符合用户预期，错误消息会要求会话模型指导用户进入 Plugins > Built-in plugin settings > Web search and fetch，在 Search 中选择 DeepSeek 服务端搜索，修改其 Base URL 并保存。该页面不可用时，消息会把 `web-search-deepseek.baseURL` 作为部署配置方式。模型不得替用户选择或修改端点。面向模型的 `web_search` 工具会在自己的错误包装层内呈现这段文本。

-----

<a id="understand-the-implementation"></a>
## 理解实现

<details>
<summary>实现细节——点击展开</summary>

本节解释提供方背后的设计决策；可观察行为已在[使用本包](#use-this-package)中完整说明。

### 设计理念

本提供方建立在两项承诺之上：

- **只取结构化块。** DeepSeek 在服务端执行搜索并返回结构化的 `web_search_tool_result` 块；提供方解析这些块，绝不从模型文本中抓取 URL。严格模式下，没有此类块的响应会抛出 `WEB_PROVIDER_ERROR`，而非降级。
- **会话凭据，逐次解析。** 提供方不新增密钥：发起会话位于账号路由且该路由的部署与搜索端点同源时，搜索使用账号登录凭据，其余搜索复用 `DEEPSEEK_API_KEY` 引用。辅助请求端点通过 `$DEEPSEEK_SEARCH_BASE_URL` 保持独立。已挂载的凭据服务具有权威性；没有该服务时回退到启动进程的环境。按次解析意味着在 Web 的 Models 页中存储或轮换的密钥，或一次账号登录，无需重启即可用于下一次搜索。

### 源码地图

| 文件 | 职责 |
|---|---|
| [`src/index.ts`](src/index.ts) | Config schema、每次搜索的选项捕获，以及搜索就绪判断 |
| [`src/provider.ts`](src/provider.ts) | `DeepSeekSearchProvider`：Messages 请求分发、块解析、引用拼接、凭据解析 |
| [`src/types.ts`](src/types.ts) | 搜索响应的 Anthropic 协议类型 |

### 请求流程

每次搜索先把当前 Config 段投影为提供方选项——端点、模型、密钥引用、上限——然后向 [`ctx.deepseekAuth`](../../account/deepseek-auth/README.zh.md) 索取搜索端点的凭据：账号路由上的会话取账号登录凭据，否则取经由 `ctx.credentials`（或环境）读取的引用密钥，追加仅用于日志的会话事件，并以原生 `web_search` 服务器工具分发 Messages 请求。响应中的 `web_search_tool_result` 块变为 `sources[]`，各带其条目自带的 snippet；文本块中的 `cited_text` 条目按 URL 关联，作为没有 snippet 的条目的 snippet；结果按 URL 去重；服务在返回路径上强制执行请求的来源上限。

就绪判断捕获相同的选项，但不读取 API 密钥的值：它依次询问 `ctx.deepseekAuth` 为这次搜索返回的每个候选其凭据是否已配置，在账号路由上的会话里先是面向搜索端点的账号登录凭据，然后经由 `ctx.credentials.describe()`（或环境）询问密钥引用。字面密钥总是算作已配置。

</details>

-----

<a id="further-exploration"></a>
## 进一步探索

当包级约定不够用时阅读以下页面。它们从共享词汇逐步进入服务、面向模型的工具与设计依据。

- [web 子系统](../../../docs/subsystems/web.zh.md)——穷尽式的搜索请求／结果词汇与错误码。
- [web 包映射](../README.zh.md)——Web 包家族与各角色。
- [dsh-web](../web/README.zh.md)——本提供方注册进入的 web 服务。
- [dsh-tool-web](../tool-web/README.zh.md)——渲染本提供方来源的面向模型 `web_search` 工具。
- [生成配置目录](../../../docs/config-catalog.zh.md#deepseek-aidsh-web-search-deepseek)——每个受支持配置字段及其源声明。
- [web 能力 seam 决策](../../../.agents/notes/implemented/architecture/2026-06-24-web-capability-seam.zh.md)——搜索与抓取为何共用一项提供方选择服务。
- [搜索就绪决策](../../../.agents/notes/implemented/architecture/2026-09-27-web-search-offered-by-provider-readiness.zh.md)——本提供方为何报告就绪状态，而由 `dsh-tool-web` 撤下 `web_search`。

-----

<a id="model-experience"></a>
## 模型体验

### 辅助 DeepSeek 搜索请求

#### 模型看到的内容

独立的 DeepSeek 模型会原样接收 `Perform a web search for the query: <query>` 作为用户文本，并收到一个原生 `web_search` 服务器工具定义，思考模式关闭。该请求不属于会话模型上下文。

#### Token 影响

每次搜索都会产生独立的提供方输入与输出 token；关闭思考模式不产生推理 token，`maxTokens` 限制生成输出，`maxUses` 限制原生搜索次数。

#### KV Cache 影响

与会话请求缓存相互独立。辅助指令与原生工具定义可以形成稳定前缀，但查询或模型路由的每次变化都会阻止从首个差异起的复用。

### 间接的会话工具结果

#### 模型看到的内容

通过 `dsh-tool-web`，会话模型会看到结构化搜索块中去重后的 URL、标题、日期与 snippet；提供方文本不会作为答案受到信任。该提供方的具体失败消息包括带有处理指引的凭据缺失消息（其中也提到 DeepSeek 账号登录）、`DeepSeek search credential resolution failed: <error>` 和 `DeepSeek search aborted`。账号鉴权的搜索收到 HTTP 401 时，会追加引导用户重新登录 DeepSeek 的指引。被账号退登结束的搜索报告 `The DeepSeek account signed out before this web search finished. Guide the user to sign in to DeepSeek again; the search endpoint does not need changing.` 其他请求、HTTP、原生搜索和响应正文失败会追加已解析端点及前述条件式配置指引。错误包装属于消费方。

#### Token 影响

注册不会直接产生会话 token。结果 token 随返回源与 snippet 增长，随后服务强制执行请求的来源上限。

#### KV Cache 影响

仅追加；新可见内容位于可复用请求前缀之后，不会使现有 KV Cache 条目失效。

### 会话工具列表（间接）

#### 模型看到的内容

本提供方被选中时，它未就绪的会话请求既不包含 `web_search` 的 schema，也不包含它的提示词说明；该效果由 [`dsh-tool-web`](../tool-web/README.zh.md#search-readiness) 负责。

#### Token 影响

撤下时，请求中不再包含 `web_search` 的 schema 及其提示词说明。

#### KV Cache 影响

重新提供或移除 `web_search` 会按 [`dsh-tool-web`](../tool-web/README.zh.md#search-readiness) 所述改变声明的工具。

## 已知限制与延期工作

<a id="known-limitations-and-deferred-work"></a>


这些限制说明提供方在哪些情况下昂贵或不完整。它们是当前包约束。

- **一次搜索消耗一个完整的 Messages 模型轮次**——产生延迟与生成 token，最多执行 `maxUses` 次服务端搜索；[dsh-web-deepseek-api](../web-deepseek-api/README.zh.md) 改用专用的 Search API。
- **提供方选择看不到缺失的密钥**——同步可用性检查可以确认解析器存在，但无法查询异步凭据存储，因此 `ctx.web` 仍会选中没有密钥的提供方，直接搜索会以 `WEB_PROVIDER_CREDENTIAL_MISSING` 失败；异步的 `ready()` 只影响哪些模型请求会获得 `web_search`。
- **就绪判断只检查凭据是否存在，不检查是否有效**——错误的密钥，或不提供原生 `web_search_20250305` 服务器工具的端点，都视为就绪，因此 `web_search` 继续提供，每次调用都以结构化错误失败。
- **搜索不跟随聊天地址**——官方路由经网关聊天时，搜索仍把密钥发往配置的搜索端点（默认是官方端点），除非该端点接受这个密钥，否则调用失败。
- **超量返回的来源仍消耗 token**——协议没有结果数量旋钮，`maxResults` 只能由服务在事后截断。
- **来源的 `snippet` 取决于端点**——它是端点随结果条目返回的摘录，否则是匹配其 URL 的文本块引用（`cited_text`）；两者都不返回的 Anthropic 兼容端点产生没有 snippet 的来源。

<a id="dev-note"></a>
### 开发备注

<details>
<summary>维护者的工作上下文——点击展开</summary>

本开发备注是维护者的工作上下文：开放问题与尚未决定的探索方向。它明确不具权威性——已交付的行为、限制与既定理由以上文和相关 Agent Note 为准。

#### 专用检索端点

无需完整模型轮次的 DeepSeek Search 与 Fetch API 位于 [dsh-web-deepseek-api](../web-deepseek-api/README.zh.md)，由「网页搜索与获取」设置页的搜索和获取下拉框分别选择。内置配置不固定搜索提供方，因此本提供方为 DeepSeek 模型路由上的模型请求运行，其他路由运行 Search API；`searchProvider: deepseek-official` 会在所有路由上选用本提供方（例如网关未提供 Search API 路由时）。

</details>
