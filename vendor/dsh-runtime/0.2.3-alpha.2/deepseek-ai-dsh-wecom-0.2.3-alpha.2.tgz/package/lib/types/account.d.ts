/**
 * Check and QR-code binding of the wecom-cli bot that the user's terminal shares, as the operations `ctx.cliAccounts`
 * runs; binding again replaces it.
 */
import type { CliOperationControl } from '@deepseek-ai/dsh-cli-account/types';
import type { UpstreamSkillsHandle } from '@deepseek-ai/dsh-upstream-skills/types';
import type { WecomAccountState, WecomCommand, WecomOperationKind, WecomPhase } from './types.ts';
type Control = CliOperationControl<WecomAccountState, WecomPhase, WecomCommand>;
/** The upstream guides whose state the account carries and whose failed download each check restarts. */
type Guides = Pick<UpstreamSkillsHandle, 'state' | 'retry'>;
/**
 * Bind the WeCom account operations to the upstream guides.
 * @param guides - the registered upstream guides.
 * @returns the function that carries out one operation with wecom-cli and publishes the authorization each check
 *   observes; it throws when a command fails, prints an unknown status, or leaves no authorization after a binding.
 */
export declare function performWith(guides: Guides): (kind: WecomOperationKind, control: Control, signal: AbortSignal) => Promise<void>;
export {};
//# sourceMappingURL=account.d.ts.map