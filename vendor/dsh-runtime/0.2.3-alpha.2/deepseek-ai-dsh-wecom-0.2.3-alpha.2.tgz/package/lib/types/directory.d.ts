/** Managed wecom-cli location: the platform binary package that `@wecom/cli` installs. */
/** The name wecom-cli's guides and scripts run it by. */
export declare const PROGRAM = "wecom-cli";
/**
 * Name the executable file as the platform package installs it.
 * @param platform - the Host platform.
 * @returns `wecom-cli`, or `wecom-cli.exe` on Windows.
 */
export declare function executableFileName(platform: NodeJS.Platform): string;
/**
 * Locate the managed executable.
 * @param binDir - absolute override; defaults to the `bin` of the installed `@wecom/cli-<platform>-<arch>` package.
 * @returns the absolute path of the executable `wecom-cli`, `wecom-cli.exe` on Windows.
 * @throws when the platform package is missing or the executable is not executable.
 */
export declare function resolveCliExecutable(binDir: string | undefined): string;
//# sourceMappingURL=directory.d.ts.map