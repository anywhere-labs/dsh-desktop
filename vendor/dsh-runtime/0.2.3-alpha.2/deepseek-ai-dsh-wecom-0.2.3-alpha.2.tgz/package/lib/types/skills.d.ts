/** The packaged `wecom` entry skill and the upstream guides it indexes. */
import type { UpstreamSkillSet } from '@deepseek-ai/dsh-upstream-skills';
/** The packaged entry, whose index names each guide by its repository path `skills/<guide>/SKILL.md`. */
export declare const ENTRY: string;
/** Every skill of the official WeCom CLI repository, at the commit the entry's index and guidance were verified with. */
export declare const WECOM_SKILLS: UpstreamSkillSet;
//# sourceMappingURL=skills.d.ts.map